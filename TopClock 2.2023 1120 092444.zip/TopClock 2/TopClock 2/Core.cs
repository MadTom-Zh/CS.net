﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;

namespace MadTomDev.App
{
    internal class Core
    {
        internal static Core instance = null;
        internal static Core GetInstance()
        {
            if (instance == null)
            {
                instance = new Core();
            }
            return instance;
        }
        private Core()
        {
            setting = Setting.GetInstance();
            timer = Common.MillisecondTimer.New();
            timer.LoopType = Common.MillisecondTimer.LoopTypes.Wait1ms;
            timer.Tick += Timer_Tick;
        }


        public Setting setting;
        private Common.MillisecondTimer timer;
        public WindowClock clockWnd;
        public UI.FileFolderSelector selectFileWnd;
        public UI.FileFolderSelector NewSelectFileWnd(string titel, string initDir)
        {
            if (string.IsNullOrWhiteSpace(titel))
                titel = "Select image file";
            selectFileWnd = new UI.FileFolderSelector()
            {
                Title = titel,
                canSelectDirs = false,
                canSelectFiles = true,
                isSingleSelectFile = true,
                showFiles = true,
                btn_ok_finalText = "OK",
            };
            if (!string.IsNullOrEmpty(initDir))
                selectFileWnd.InitedDir = initDir;
            return selectFileWnd;
        }

        public UI.ColorExpertDialog selectClrWnd;
        internal UI.ColorExpertDialog NewSelectClrWnd(Color curColor)
        {
            selectClrWnd = new UI.ColorExpertDialog()
            {
                IsPanelSVHChecked = false,
                IsPanelSLHChecked = false,
                IsPanelScreenPPChecked = false,
                IsPanelCMYKChecked = false,
                //IsPanelARGBChecked = false,
                IsPanelColorCacheChecked = false,
                WorkingColor = curColor,
            };
            return selectClrWnd;
        }


        public WindowSetting settingWnd = null;
        internal void ShowSettingWindow()
        {
            if (settingWnd != null)
                return;

            bool isCWL = setting.isClockWndLocked;
            setting.isClockWndLocked = false;
            clockWnd.WorkingMode = WindowClock.WorkingModes.Design;
            settingWnd = new WindowSetting();
            settingWnd.Show();

            settingWnd.Closed += (s1, e1) =>
            {
                if (settingWnd.closeResult == true)
                {
                    setting.Save();
                }
                else
                {
                    setting.Reload();
                    ApplyAll();
                }
                settingWnd = null;
                clockWnd.WorkingMode = WindowClock.WorkingModes.Product;
                setting.isClockWndLocked = isCWL;
            };
        }


        DateTime now;
        public DateTime GetNow()
        {
            now = DateTime.Now;
            return now;
        }

        private bool isRefreshTextDate = false, isRefreshTextDay = false, isRefreshTextTime = false;
        private Setting.RefreshRates curFreshRate = Setting.RefreshRates.fps1;
        private bool _timer_is500ms = false;
        private void Timer_Tick(Common.MillisecondTimer sender, DateTime tickTime, bool is500ms, bool is1000ms)
        {
            RefreshAll(_timer_is500ms);
            TryBringWindowToFront();
        }

        private bool isRefreshingAll = false;
        private int _refresh_preDay = -1;
        private bool _refreshDay;
        private void RefreshAll(bool is500ms)
        {
            if (isRefreshingAll)
                return;
            isRefreshingAll = true;
            clockWnd.Dispatcher.Invoke(() =>
            {
                GetNow();
                if (is500ms)
                {
                    if (250 < now.Millisecond && now.Millisecond <= 750)
                        now = new DateTime(now.Year, now.Month, now.Day, now.Hour, now.Minute, now.Second, 500);
                    else
                    {
                        now = new DateTime(now.Year, now.Month, now.Day, now.Hour, now.Minute, now.Second, 0);
                        if (750 < now.Millisecond)
                        {
                            now.AddSeconds(1);
                        }
                    }
                }
                if (_refresh_preDay != now.Day)
                {
                    _refresh_preDay = now.Day;
                    _refreshDay = true;
                }
                if (isClockOrDigital)
                {
                    if (isRefreshHandHour || isRefreshHandMin || isRefreshHandSec)
                        RefreshHands();
                    if (_refreshDay)
                    {
                        if (isRefreshTextDate)
                            RefreshText(clockWnd.tb_date, clock_culture_date, clock_format_date);
                        if (isRefreshTextDay)
                            RefreshText(clockWnd.tb_day, clock_culture_day, clock_format_day);
                    }
                    if (isRefreshTextTime)
                        RefreshText(clockWnd.tb_time, clock_culture_time, clock_format_time);
                }
                else
                {
                    if (_refreshDay)
                    {
                        if (isRefreshTextDate)
                            RefreshText(clockWnd.tb_date, digital_culture_date, digital_format_date);
                        if (isRefreshTextDay)
                            RefreshText(clockWnd.tb_day, digital_culture_day, digital_format_day);
                    }
                    if (isRefreshTextTime)
                        RefreshText(clockWnd.tb_time, digital_culture_time, digital_format_time);
                }
                _refreshDay = false;
            });
            isRefreshingAll = false;
        }


        private bool isRefreshLoopQuitFlag = true;
        private void RefreshLoopStart()
        {
            _timer_is500ms = false;
            isRefreshLoopQuitFlag = false;
            Task.Run(() =>
            {
                while (!isRefreshingAll)
                {
                    RefreshAll(false);
                    if (isRefreshLoopQuitFlag)
                        break;
                }
            });
        }
        private void RefreshLoopStop()
        {
            isRefreshLoopQuitFlag = true;
        }


        private DateTime BringWindowToFront_lastTime = DateTime.MinValue;
        private void TryBringWindowToFront()
        {
            if (setting.apparence != Setting.Apparences.None)
            {
                DateTime now = DateTime.Now;
                if ((now - BringWindowToFront_lastTime).TotalSeconds > 300)
                {
                    BringWindowToFront_lastTime = now;
                    clockWnd.Dispatcher.BeginInvoke(() =>
                    {
                        if (!clockWnd.IsVisible)
                        {
                            clockWnd.Show();
                        }

                        if (clockWnd.WindowState == WindowState.Minimized)
                        {
                            clockWnd.WindowState = WindowState.Normal;
                        }

                        //clockWnd.Activate(); // 这一行会导致焦点聚焦到窗口，从而打断当前的键盘操作；
                        if (setting.isTopMost)
                        {
                            clockWnd.Topmost = false; // important
                            clockWnd.Topmost = true;  // important
                        }
                        else
                        {
                            clockWnd.Topmost = true;  // important
                            clockWnd.Topmost = false; // important
                        }
                        //clockWnd.Focus();         // important
                    });
                }
            }
        }


        public void ApplyAll()
        {
            ApplyApparence();
            switch (setting.apparence)
            {
                default:
                case Setting.Apparences.DigitalPanel:
                    ApplyDigitalAll();
                    break;
                case Setting.Apparences.RoundClock:
                    ApplyClockAll();
                    break;
            }
        }


        #region setting - general

        internal void ApplyApparence()
        {
            if (clockWnd != null)
            {
                // apparence
                clockWnd.SetApparence(setting.apparence);
                // top-most
                clockWnd.Topmost = setting.isTopMost;
            }
        }
        internal void NotifyClockWindowLocationChanged(double left, double top)
        {
            if (settingWnd != null)
            {
                settingWnd.SetWndPosi(left, top);
            }
        }
        internal void NotifyClockWindowSizeChanged(double width, double height)
        {
            if (settingWnd != null)
            {
                settingWnd.SetWndSize(width, height);
            }
        }


        #endregion


        #region other, resources
        private BitmapSource _BGColorBG = null;
        public BitmapSource BGColorBG
        {
            get
            {
                if (_BGColorBG == null)
                {
                    _BGColorBG = UI.QuickGraphics.Image.GetChessboardImage(30, 20);
                }
                return _BGColorBG;
            }
        }

        private List<ColorItem> _ColorList = null;
        public List<ColorItem> ColorList
        {
            get
            {
                if (_ColorList == null)
                {
                    _ColorList = new List<ColorItem>();
                    _ColorList.Add(new ColorItem()
                    { name = "Custom..", color = Colors.Transparent, });

                    Type csType = typeof(Colors);
                    Type cType = typeof(Color);
                    object test;
                    foreach (System.Reflection.PropertyInfo pi in csType.GetProperties())
                    {
                        if (pi.PropertyType == cType)
                        {
                            test = pi.GetValue(null);
                            if (test != null)
                            {
                                _ColorList.Add(new ColorItem()
                                { name = pi.Name, color = (Color)test, });
                            }
                        }
                    }
                }
                return _ColorList;
            }
        }
        public class ColorItem
        {
            public string name { set; get; }
            public Color color { set; get; }

            private SolidColorBrush _colorBrush = null;
            public SolidColorBrush colorBrush
            {
                get
                {
                    if (_colorBrush == null)
                    {
                        _colorBrush = new SolidColorBrush(color);
                    }
                    return _colorBrush;
                }
            }
        }
        #endregion


        #region round-clock

        public void ApplyClockAll()
        {
            isClockOrDigital = true;
            ApplyClockWindowPosi();
            ApplyClockWindowSize();
            ApplyClockBG();
            ApplyClockHandHour();
            ApplyClockHandMin();
            ApplyClockHandSec();
            ApplyClockDate();
            ApplyClockDay();
            ApplyClockTime();
            ApplyClockRefreshRate();
        }
        public void ApplyClockWindowPosi()
        {
            clockWnd.settingWindowFlag = true;
            clockWnd.Left = setting.roundClockSetting.windowPosition.X;
            clockWnd.Top = setting.roundClockSetting.windowPosition.Y;
            clockWnd.settingWindowFlag = false;
        }
        public void ApplyClockWindowSize()
        {
            clockWnd.settingWindowFlag = true;
            clockWnd.Width = setting.roundClockSetting.windowSize.X;
            clockWnd.Height = setting.roundClockSetting.windowSize.Y;
            clockWnd.settingWindowFlag = false;
        }
        internal void ApplyClockBG()
        {
            Setting.RoundClockSettings rcs = setting.roundClockSetting;
            if (System.IO.File.Exists(rcs.backgroundImageFile))
            {
                clockWnd.img_bg.Source = new BitmapImage(new Uri(rcs.backgroundImageFile));
            }
            if (rcs.backgroundColor == Colors.Transparent)
            {
                clockWnd.grid_bg.Background = null;
            }
            else
            {
                clockWnd.grid_bg.Background = new SolidColorBrush(rcs.backgroundColor);
            }
            ApplyClockHandHour();
            ApplyClockHandMin();
            ApplyClockHandSec();
        }

        private bool isClockOrDigital = false, isRefreshHandHour = false, isRefreshHandMin = false, isRefreshHandSec = false;
        private void SetHand(Grid shadowContainer, Grid container, Image image, Setting.HandSettings hSetting, ref bool isEnalbed)
        {
            isEnalbed = hSetting.isEnabled
                = System.IO.File.Exists(hSetting.imageFile);
            if (isEnalbed)
            {
                container.Visibility = Visibility.Visible;
                try
                {
                    image.Source = new BitmapImage(new Uri(hSetting.imageFile));
                }
                catch (Exception)
                {
                    MessageBox.Show("Illegal Image.");
                    return;
                }


                // set position
                Point posi = (Point)(setting.roundClockSetting.AxisPoint - hSetting.axisPoint);
                container.Margin = new Thickness(posi.X, posi.Y, 0, 0);

                // set axes, when refresh

                // set shadow
                Setting.DropShadowSettings shSetting = hSetting.shadow;
                if (shSetting.isEnabled)
                {
                    DropShadowEffect se = new DropShadowEffect()
                    {
                        Color = shSetting.color,
                        Opacity = shSetting.opacity,
                        ShadowDepth = shSetting.depth,
                        BlurRadius = shSetting.blurRadius,
                        Direction = shSetting.direction,
                    };
                    shadowContainer.Effect = se;
                }
                else
                {
                    shadowContainer.Effect = null;
                }
            }
            else
            {
                container.Visibility = Visibility.Hidden;
                shadowContainer.Effect = null;
            }
        }
        internal void ApplyClockHandHour()
        {
            GetNow();
            SetHand(clockWnd.grid_sdw_hour, clockWnd.grid_handHour, clockWnd.img_handHour, setting.roundClockSetting.hourHand, ref isRefreshHandHour);
            if (isRefreshHandHour)
                RefreshHands();
        }
        internal void ApplyClockHandMin()
        {
            GetNow();
            SetHand(clockWnd.grid_sdw_min, clockWnd.grid_handMin, clockWnd.img_handMin, setting.roundClockSetting.minHand, ref isRefreshHandMin);
            if (isRefreshHandMin)
                RefreshHands();
        }
        internal void ApplyClockHandSec()
        {
            GetNow();
            SetHand(clockWnd.grid_sdw_sec, clockWnd.grid_handSec, clockWnd.img_handSec, setting.roundClockSetting.secHand, ref isRefreshHandSec);
            if (isRefreshHandSec)
                RefreshHands();
        }
        private static int totalMS_min = 60000;
        private static int totalMS_hour = 3600000;
        private static int totalMS_12hour = 43200000;
        private void RefreshHands()
        {
            // visible? rotate
            int totalMS = now.Millisecond;
            totalMS += now.Second * 1000;
            double a;
            System.Windows.Point c;
            RotateTransform r;
            if (isRefreshHandSec)
            {
                a = (double)totalMS / totalMS_min * 360;
                c = setting.roundClockSetting.secHand.axisPoint;
                r = new RotateTransform(a, c.X, c.Y);
                clockWnd.grid_handSec.RenderTransform = r;
            }
            totalMS += now.Minute * totalMS_min;
            if (isRefreshHandMin)
            {
                a = (double)totalMS / totalMS_hour * 360;
                c = setting.roundClockSetting.minHand.axisPoint;
                r = new RotateTransform(a, c.X, c.Y);
                clockWnd.grid_handMin.RenderTransform = r;
            }
            totalMS += (now.Hour % 12) * totalMS_hour;
            if (isRefreshHandHour)
            {
                a = (double)totalMS / totalMS_12hour * 360;
                c = setting.roundClockSetting.hourHand.axisPoint;
                r = new RotateTransform(a, c.X, c.Y);
                clockWnd.grid_handHour.RenderTransform = r;
            }
        }


        private CultureInfo clock_culture_date = null;
        private CultureInfo clock_culture_day = null;
        private CultureInfo clock_culture_time = null;
        private string clock_format_date;
        private string clock_format_day;
        private string clock_format_time;
        internal void ApplyClockDate()
        {
            _refresh_preDay = -1;
            GetNow();
            SetTextBlock(clockWnd.grid_date, clockWnd.tb_date, setting.roundClockSetting.dateText,
                ref clock_culture_date, ref clock_format_date, ref isRefreshTextDate);
            if (isRefreshTextDate)
                RefreshText(clockWnd.tb_date, clock_culture_date, clock_format_date);
        }
        internal void ApplyClockDay()
        {
            _refresh_preDay = -1;
            GetNow();
            SetTextBlock(clockWnd.grid_day, clockWnd.tb_day, setting.roundClockSetting.dayText,
                ref clock_culture_day, ref clock_format_day, ref isRefreshTextDay);
            if (isRefreshTextDay)
                RefreshText(clockWnd.tb_day, clock_culture_day, clock_format_day);
        }
        internal void ApplyClockTime()
        {
            GetNow();
            SetTextBlock(clockWnd.grid_time, clockWnd.tb_time, setting.roundClockSetting.timeText,
                ref clock_culture_time, ref clock_format_time, ref isRefreshTextTime);
            if (isRefreshTextTime)
                RefreshText(clockWnd.tb_time, clock_culture_time, clock_format_time);
        }


        internal void ApplyClockRefreshRate()
        {
            ApplyFreshRate(setting.roundClockSetting.freshRate);
        }
        private void ApplyFreshRate(Setting.RefreshRates rate)
        {
            RefreshLoopStop();
            switch (rate)
            {
                default:
                case Setting.RefreshRates.fps1:
                    _timer_is500ms = true;
                    timer.Interval = Common.MillisecondTimer.Intervals.ms1000;
                    break;
                case Setting.RefreshRates.fps2:
                    _timer_is500ms = true;
                    timer.Interval = Common.MillisecondTimer.Intervals.ms500;
                    break;
                case Setting.RefreshRates.fps10:
                    _timer_is500ms = false;
                    timer.Interval = Common.MillisecondTimer.Intervals.ms100;
                    break;
                case Setting.RefreshRates.fps100:
                    _timer_is500ms = false;
                    timer.Interval = Common.MillisecondTimer.Intervals.ms10;
                    break;
                case Setting.RefreshRates.Unlimited:
                    _timer_is500ms = false;
                    timer.Interval = Common.MillisecondTimer.Intervals.ms1000;
                    RefreshLoopStart();
                    break;
            }
        }
        #endregion


        #region digital-panel

        public void ApplyDigitalAll()
        {
            isClockOrDigital = false;
            ApplyDigitalWindowPosi();
            ApplyDigitalWindowSize();
            ApplyDigitalBG();
            GetNow();
            ApplyDigitalDate();
            ApplyDigitalDay();
            ApplyDigitalTime();
            ApplyDigitalRefreshRate();
        }
        public void ApplyDigitalWindowPosi()
        {
            clockWnd.settingWindowFlag = true;
            clockWnd.Left = setting.digitalPanelSetting.windowPosition.X;
            clockWnd.Top = setting.digitalPanelSetting.windowPosition.Y;
            clockWnd.settingWindowFlag = false;
        }
        public void ApplyDigitalWindowSize()
        {
            clockWnd.settingWindowFlag = true;
            clockWnd.Width = setting.digitalPanelSetting.windowSize.X;
            clockWnd.Height = setting.digitalPanelSetting.windowSize.Y;
            clockWnd.settingWindowFlag = false;
        }
        internal void ApplyDigitalBG()
        {
            Setting.DigitalPanelSettings dps = setting.digitalPanelSetting;
            string imgFile = dps.backgroundImageFile;
            if (System.IO.File.Exists(imgFile))
            {
                clockWnd.img_bg.Source = new BitmapImage(new Uri(imgFile));
            }
            else
            {
                clockWnd.img_bg.Source = null;
            }
            if (dps.backgroundColor == Colors.Transparent)
            {
                clockWnd.grid_bg.Background = null;
            }
            else
            {
                clockWnd.grid_bg.Background = new SolidColorBrush(dps.backgroundColor);
            }
        }


        private void SetTextBlock(Grid container, TextBlock tb, Setting.TextSettings txSetting,
            ref CultureInfo culture, ref string format, ref bool isEnabled)
        {
            isEnabled = txSetting.isEnabled;
            if (isEnabled)
            {
                // style
                container.Visibility = Visibility.Visible;
                tb.Foreground = new SolidColorBrush(txSetting.foreColor);
                tb.FontFamily = txSetting.fontFamily;
                tb.FontSize = txSetting.fontSize;
                tb.FontWeight = txSetting.fontWeight;
                tb.FontStyle = txSetting.fontStyle;
                tb.TextDecorations = txSetting.decoration;

                // position
                double width = txSetting.fontSize * 30;
                double doubleD2 = width / 2;
                container.Width = width;
                container.Margin = new Thickness(
                    txSetting.position.X - doubleD2,
                    txSetting.position.Y,
                    0, 0);

                // shadow
                if (txSetting.shadow.isEnabled)
                {
                    Setting.DropShadowSettings shSetting = txSetting.shadow;
                    DropShadowEffect se = new DropShadowEffect()
                    {
                        Color = shSetting.color,
                        Opacity = shSetting.opacity,
                        ShadowDepth = shSetting.depth,
                        BlurRadius = shSetting.blurRadius,
                        Direction = shSetting.direction,
                    };
                    tb.Effect = se;
                }
                else
                {
                    tb.Effect = null;
                }

                // format

                string oFormat = txSetting.format;
                if (oFormat.Contains('&'))
                {
                    try
                    {
                        int idxN = oFormat.IndexOf('&');
                        culture = CultureInfo.GetCultureInfo(oFormat.Substring(0, idxN));
                        format = oFormat.Substring(idxN + 1);
                    }
                    catch (Exception)
                    {
                        culture = null;
                        format = "Error!";
                    }
                }
                else
                {
                    culture = null;
                    format = oFormat;
                }
            }
            else
            {
                container.Visibility = Visibility.Hidden;
            }
        }
        public void RefreshText(TextBlock tb, CultureInfo culture, string format)
        {
            try
            {
                if (culture == null)
                {
                    tb.Text = now.ToString(format);
                }
                else
                {
                    tb.Text = now.ToString(format, culture);
                }
            }
            catch (Exception)
            {
                tb.Text = "Error!";
            }
        }


        private CultureInfo digital_culture_date = null;
        private CultureInfo digital_culture_day = null;
        private CultureInfo digital_culture_time = null;
        private string digital_format_date;
        private string digital_format_day;
        private string digital_format_time;


        public void ApplyDigitalDate()
        {
            _refresh_preDay = -1;
            GetNow();
            SetTextBlock(clockWnd.grid_date, clockWnd.tb_date, setting.digitalPanelSetting.dateText,
                ref digital_culture_date, ref digital_format_date, ref isRefreshTextDate);
            if (isRefreshTextDate)
                RefreshText(clockWnd.tb_date, digital_culture_date, digital_format_date);
        }
        public void ApplyDigitalDay()
        {
            _refresh_preDay = -1;
            GetNow();
            SetTextBlock(clockWnd.grid_day, clockWnd.tb_day, setting.digitalPanelSetting.dayText,
                ref digital_culture_day, ref digital_format_day, ref isRefreshTextDay);
            if (isRefreshTextDay)
                RefreshText(clockWnd.tb_day, digital_culture_day, digital_format_day);
        }
        public void ApplyDigitalTime()
        {
            GetNow();
            SetTextBlock(clockWnd.grid_time, clockWnd.tb_time, setting.digitalPanelSetting.timeText,
                ref digital_culture_time, ref digital_format_time, ref isRefreshTextTime);
            if (isRefreshTextTime)
                RefreshText(clockWnd.tb_time, digital_culture_time, digital_format_time);
        }

        internal void ApplyDigitalRefreshRate()
        {
            ApplyFreshRate(setting.digitalPanelSetting.freshRate);
        }

        #endregion


        #region notify icon

        Hardcodet.Wpf.TaskbarNotification.TaskbarIcon? notifyIcon = null;
        public ContextMenu contextMenu_notifyIcon;
        public MenuItem contextMenu_notifyIcon_roundClock;
        public MenuItem contextMenu_notifyIcon_digitalPanel;
        public MenuItem contextMenu_notifyIcon_toCenter;
        public void NotifyIcon_Init()
        {
            if (notifyIcon == null)
            {
                notifyIcon = new Hardcodet.Wpf.TaskbarNotification.TaskbarIcon() { ToolTipText = "TopClock2 by MadTom 2023 0302", };
                //string test = System.Reflection.Assembly.GetExecutingAssembly().Location;
                //notifyIcon.Icon = System.Drawing.Icon.ExtractAssociatedIcon(test);
                ImageSource iconImage = new BitmapImage(new Uri("pack://application:,,,/nIcon.ico"));
                notifyIcon.IconSource = iconImage;

                contextMenu_notifyIcon = new ContextMenu();

                contextMenu_notifyIcon_roundClock = new MenuItem()
                { Header = "Round Clock", IsCheckable = true, };
                contextMenu_notifyIcon_roundClock.Click += (s1, e1) => NotifyIco_ItemCall("roundClock");
                contextMenu_notifyIcon.Items.Add(contextMenu_notifyIcon_roundClock);

                contextMenu_notifyIcon_digitalPanel = new MenuItem()
                { Header = "Digital Panel", IsCheckable = true, };
                contextMenu_notifyIcon_digitalPanel.Click += (s1, e1) => NotifyIco_ItemCall("digitalPanel");
                contextMenu_notifyIcon.Items.Add(contextMenu_notifyIcon_digitalPanel);

                contextMenu_notifyIcon.Items.Add(new Separator());

                MenuItem mi = new MenuItem()
                { Header = "Setting", };
                mi.Click += (s1, e1) => NotifyIco_ItemCall("setting");
                contextMenu_notifyIcon.Items.Add(mi);

                contextMenu_notifyIcon.Items.Add(new Separator());

                contextMenu_notifyIcon_toCenter = new MenuItem()
                { Header = "Put to CenterScreen", };
                contextMenu_notifyIcon_toCenter.Click += (s1, e1) => NotifyIco_ItemCall("toCenter");
                contextMenu_notifyIcon.Items.Add(contextMenu_notifyIcon_toCenter);

                contextMenu_notifyIcon.Items.Add(new Separator());

                mi = new MenuItem()
                { Header = "Exit", };
                mi.Click += (s1, e1) => NotifyIco_ItemCall("exit");
                contextMenu_notifyIcon.Items.Add(mi);

                notifyIcon.ContextMenu = contextMenu_notifyIcon;

                // both opening event not firing,,,, why ???
                //notifyIcon.ContextMenu.ContextMenuOpening += ContextMenu_ContextMenuOpening;
                //contextMenu_notifyIcon.ContextMenuOpening += NotifyIcon_ContextMenuOpening;

                contextMenu_notifyIcon.Opened += NotifyIcon_ContextMenuOpened;
            }
        }

        //private void ContextMenu_ContextMenuOpening(object sender, ContextMenuEventArgs e)
        //{
        //    throw new NotImplementedException();
        //}
        //public void NotifyIcon_ContextMenuOpening(object sender, ContextMenuEventArgs e)
        //{
        //    // not firing, don't know why
        //}

        private void NotifyIcon_ContextMenuOpened(object sender, RoutedEventArgs e)
        {
            bool isClockWndVisible = clockWnd.Visibility == Visibility.Visible;
            contextMenu_notifyIcon_roundClock.IsChecked = isClockWndVisible && setting.apparence == Setting.Apparences.RoundClock;
            contextMenu_notifyIcon_digitalPanel.IsChecked = isClockWndVisible && setting.apparence == Setting.Apparences.DigitalPanel;
            contextMenu_notifyIcon_toCenter.IsEnabled = isClockWndVisible;
        }

        public void NotifyIco_ItemCall(string arg)
        {
            bool isClockWndVisible = clockWnd.Visibility == Visibility.Visible;
            switch (arg)
            {
                case "roundClock":
                    if (isClockWndVisible)
                    {
                        if (setting.apparence == Setting.Apparences.RoundClock)
                        {
                            setting.apparence = Setting.Apparences.None;
                            clockWnd.Hide();
                        }
                        else
                        {
                            setting.apparence = Setting.Apparences.RoundClock;
                            ApplyAll();
                        }
                    }
                    else
                    {
                        setting.apparence = Setting.Apparences.RoundClock;
                        ApplyAll();
                        clockWnd.Show();
                    }
                    break;
                case "digitalPanel":
                    if (isClockWndVisible)
                    {
                        if (setting.apparence == Setting.Apparences.DigitalPanel)
                        {
                            setting.apparence = Setting.Apparences.None;
                            clockWnd.Hide();
                        }
                        else
                        {
                            setting.apparence = Setting.Apparences.DigitalPanel;
                            ApplyAll();
                        }
                    }
                    else
                    {
                        setting.apparence = Setting.Apparences.DigitalPanel;
                        ApplyAll();
                        clockWnd.Show();
                    }
                    break;
                case "setting":
                    if (settingWnd == null)
                    {
                        ShowSettingWindow();
                    }
                    else
                    {
                        if (settingWnd.WindowState == WindowState.Minimized)
                            settingWnd.WindowState = WindowState.Normal;
                        if (settingWnd.Visibility != Visibility.Visible)
                            settingWnd.Visibility = Visibility.Visible;
                        settingWnd.Activate();
                    }
                    break;
                case "toCenter":
                    // clockWnd is already visible
                    clockWnd.Left = SystemParameters.PrimaryScreenWidth / 2 - clockWnd.ActualWidth / 2;
                    clockWnd.Top = SystemParameters.PrimaryScreenHeight / 2 - clockWnd.ActualHeight / 2;
                    break;
                case "exit":
                    Exit();
                    break;
                default:
                    break;
            }
        }
        #endregion


        public void Exit()
        {
            if (timer != null)
                timer.Interval = Common.MillisecondTimer.Intervals.Stoped;
            timer?.Dispose();
            selectFileWnd?.Close();
            settingWnd?.Close();
            clockWnd?.Close();
        }

    }
}
