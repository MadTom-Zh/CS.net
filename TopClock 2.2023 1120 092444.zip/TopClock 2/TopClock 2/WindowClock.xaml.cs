﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace MadTomDev.App
{
    /// <summary>
    /// Interaction logic for WindowClock.xaml
    /// </summary>
    public partial class WindowClock : Window
    {
        public WindowClock()
        {
            InitializeComponent();

            core = Core.GetInstance();
            setting = Setting.GetInstance();
            apparence = setting.apparence;
        }
        private Core core;
        private Setting setting;
        private bool firstActivate = true;
        private void Window_Activated(object sender, EventArgs e)
        {
            if (firstActivate)
            {
                firstActivate = false;
                core = Core.GetInstance();
                core.clockWnd = this;
                setting = Setting.GetInstance();

                // init notify icon
                core.NotifyIcon_Init();

                // init clock window
                core.ApplyAll();


                if (!setting.SettingExists)
                {
                    core.ShowSettingWindow();
                }
            }
        }



        public enum WorkingModes
        { Design, Product, }
        private WorkingModes _WorkingMode = WorkingModes.Product;
        public WorkingModes WorkingMode
        {
            get => _WorkingMode;
            set
            {
                if (_WorkingMode == value)
                    return;

                #region border visibility
                Visibility visibility = Visibility.Visible;
                switch (value)
                {
                    default:
                    case WorkingModes.Product:
                        visibility = Visibility.Hidden;
                        break;
                    case WorkingModes.Design:
                        break;
                }
                bdr_wnd.Visibility = visibility;
                bdr_bg.Visibility = visibility;
                bdr_date.Visibility = visibility;
                bdr_day.Visibility = visibility;
                bdr_time.Visibility = visibility;
                bdr_handHour.Visibility = visibility;
                bdr_handMin.Visibility = visibility;
                bdr_handSec.Visibility = visibility;
                #endregion

                _WorkingMode = value;
            }
        }

        #region setting - general

        private Setting.Apparences apparence = Setting.Apparences.None;
        public void SetApparence(Setting.Apparences apparence)
        {
            if (this.apparence == apparence)
                return;

            Visibility handsVisible = Visibility.Visible;
            switch (apparence)
            {
                case Setting.Apparences.RoundClock:
                    break;
                case Setting.Apparences.DigitalPanel:
                    handsVisible = Visibility.Hidden;
                    break;
            }
            grid_handHour.Visibility = handsVisible;
            grid_handMin.Visibility = handsVisible;
            grid_handSec.Visibility = handsVisible;

            this.apparence = apparence;
        }


        public bool settingWindowFlag = false;
        private void Window_LocationChanged(object sender, EventArgs e)
        {
            if (settingWindowFlag)
                return;
            core.NotifyClockWindowLocationChanged(this.Left, this.Top);
        }
        private void Window_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            if (settingWindowFlag)
                return;
            core.NotifyClockWindowSizeChanged(this.ActualWidth, this.ActualHeight);
        }

        #endregion




        //private void Window_ContentRendered(object sender, EventArgs e)
        //{
        //    if (apparence == Setting.Apparences.RoundClock)
        //    {
        //        if (setting.roundClockSetting.freshRate == Setting.RefreshRates.Unlimited)
        //            Refresh();
        //    }
        //    else if (apparence == Setting.Apparences.DigitalPanel)
        //    {
        //        if (setting.digitalPanelSetting.freshRate == Setting.RefreshRates.Unlimited)
        //            Refresh();
        //    }
        //}

        //private bool isRendering = false;
        //private static Action EmptyDelegate = delegate () { };
        //public void Refresh()
        //{
        //    if (isRendering)
        //        return;
        //    isRendering = true;
        //    Dispatcher.Invoke(DispatcherPriority.Render, EmptyDelegate);
        //    isRendering = false;
        //}


        private bool isAltDown = false;

        private void Window_PreviewKeyUp(object sender, KeyEventArgs e)
        {
            if (core.settingWnd == null)
                return;
            if (e.Key == e.SystemKey)
            {
                if (e.SystemKey == Key.LeftAlt || e.SystemKey == Key.RightAlt)
                {
                    isAltDown = false;
                }
            }
        }
        private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (core.settingWnd == null)
                return;
            if (setting.isClockWndLocked)
                return;

            // when press alt, it will be handled by system, then use SystemKey
            if (e.Key == e.SystemKey)
            {
                if (e.SystemKey == Key.LeftAlt || e.SystemKey == Key.RightAlt)
                {
                    isAltDown = true;
                    return;
                }
            }

            bool isCtrl = Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl);
            bool isShift = Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift);
            if (isAltDown)
            {
                // size window
                switch (e.Key)
                {
                    case Key.Left:
                        double w = this.ActualWidth;
                        CalSize(ref w, false, SystemParameters.PrimaryScreenWidth);
                        this.Width = w;
                        break;
                    case Key.Right:
                        w = this.ActualWidth;
                        CalSize(ref w, true, SystemParameters.PrimaryScreenWidth);
                        this.Width = w;
                        break;
                    case Key.Up:
                        double h = this.ActualHeight;
                        CalSize(ref h, false, SystemParameters.PrimaryScreenHeight);
                        this.Height = h;
                        break;
                    case Key.Down:
                        h = this.ActualHeight;
                        CalSize(ref h, false, SystemParameters.PrimaryScreenHeight);
                        this.Height = h;
                        break;
                }
            }
            else
            {
                // move window
                switch (e.Key)
                {
                    case Key.Left:
                        double x = this.Left;
                        CalMove(ref x, false, this.ActualWidth, SystemParameters.PrimaryScreenWidth);
                        this.Left = x;
                        break;
                    case Key.Right:
                        x = this.Left;
                        CalMove(ref x, true, this.ActualWidth, SystemParameters.PrimaryScreenWidth);
                        this.Left = x;
                        break;
                    case Key.Up:
                        double y = this.Top;
                        CalMove(ref y, false, this.ActualHeight, SystemParameters.PrimaryScreenHeight);
                        this.Top = y;
                        break;
                    case Key.Down:
                        y = this.Top;
                        CalMove(ref y, true, this.ActualHeight, SystemParameters.PrimaryScreenHeight);
                        this.Top = y;
                        break;
                }
            }


            #region methods
            void CalMove(ref double v, bool isIncre, double offMin, double offMax)
            {
                if (isCtrl && isShift) v += isIncre ? 100 : -100;
                else if (isShift) v += isIncre ? 50 : -50;
                else if (isCtrl) v += isIncre ? 10 : -10;
                else v += isIncre ? 1 : -1;
                if (v + offMin < 1)
                    v = 1 - offMin;
                else if (v >= offMax)
                    v = offMax - 1;
            }
            void CalSize(ref double v, bool isIncre, double max)
            {
                if (isCtrl && isShift) v += isIncre ? 100 : -100;
                else if (isShift) v += isIncre ? 50 : -50;
                else if (isCtrl) v += isIncre ? 10 : -10;
                else v += isIncre ? 1 : -1;
                if (v < 2)
                    v = 2;
                else if (v > max)
                    v = max;
            }
            #endregion
        }

    }
}
