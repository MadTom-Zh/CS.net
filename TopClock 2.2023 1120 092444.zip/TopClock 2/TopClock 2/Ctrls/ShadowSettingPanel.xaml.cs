﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MadTomDev.App.Ctrls
{
    /// <summary>
    /// Interaction logic for ShadowSettingPanel.xaml
    /// </summary>
    public partial class ShadowSettingPanel : UserControl
    {
        public ShadowSettingPanel()
        {
            InitializeComponent();
            DataContext = this;
            core = Core.GetInstance();
        }
        Core core;

        public static readonly RoutedEvent SettingChangedEvent = EventManager.RegisterRoutedEvent(
            nameof(SettingChanged), RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(ShadowSettingPanel));
        public event RoutedEventHandler SettingChanged
        {
            add { this.AddHandler(SettingChangedEvent, value); }
            remove { this.RemoveHandler(SettingChangedEvent, value); }
        }
        private void RaiseSettingChangedEvent()
        {
            RaiseEvent(new RoutedEventArgs(SettingChangedEvent, this));
        }




        public bool IsChecked
        {
            get => pgb.IsChecked;
            set => pgb.IsChecked = value;
        }
        private void pgb_CheckChanged(object sender, RoutedEventArgs e)
        {
            e.Handled = true;
            RaiseSettingChangedEvent();
        }


        #region get ui controls

        private Grid _grid = null;
        public Grid grid
        {
            get
            {
                if (_grid == null)
                {
                    _grid = (Grid)pgb.Content;
                }
                return _grid;
            }
        }

        private Border _bdr_color = null;
        public Border bdr_color
        {
            get
            {
                if (_bdr_color == null)
                {
                    _bdr_color = (Border)grid.Children[1];
                }
                return _bdr_color;
            }
        }
        private UI.NumericSlider _ns_depth = null;
        public UI.NumericSlider ns_depth
        {
            get
            {
                if (_ns_depth == null)
                {
                    _ns_depth = (UI.NumericSlider)grid.Children[4];
                }
                return _ns_depth;
            }
        }
        private UI.NumericSlider _ns_radios = null;
        public UI.NumericSlider ns_radios
        {
            get
            {
                if (_ns_radios == null)
                {
                    _ns_radios = (UI.NumericSlider)grid.Children[6];
                }
                return _ns_radios;
            }
        }
        private UI.NumericSlider _ns_opacity = null;
        public UI.NumericSlider ns_opacity
        {
            get
            {
                if (_ns_opacity == null)
                {
                    _ns_opacity = (UI.NumericSlider)grid.Children[8];
                }
                return _ns_opacity;
            }
        }
        private UI.NumericSlider _ns_direction = null;
        public UI.NumericSlider ns_direction
        {
            get
            {
                if (_ns_direction == null)
                {
                    _ns_direction = (UI.NumericSlider)grid.Children[10];
                }
                return _ns_direction;
            }
        }

        #endregion



        public Color ShadowColor
        {
            get => ((SolidColorBrush)bdr_color.Background).Color;
            set
            {
                bdr_color.Background = new SolidColorBrush(value);
                RaiseSettingChangedEvent();
            }
        }


        private void btn_shadowColor_Click(object sender, RoutedEventArgs e)
        {
            if (core.NewSelectClrWnd(ShadowColor).ShowDialog() == true)
            {
                ShadowColor = core.selectClrWnd.WorkingColor;
            }
        }

        public double ShadowDepth
        {
            get => ns_depth.Value;
            set
            {
                ns_depth.Value = value;
                //RaiseSettingChangedEvent();
            }
        }


        public double ShadowBlurRadios
        {
            get => ns_radios.Value;
            set
            {
                ns_radios.Value = value;
            }
        }

        public double ShadowOpacity
        {
            get => ns_opacity.Value;
            set
            {
                ns_opacity.Value = value;
            }
        }

        public double ShadowDirection
        {
            get => ns_direction.Value;
            set
            {
                ns_direction.Value = value;
            }
        }

        private void NumericSlider_ValueChanged(UI.NumericSlider sender)
        {
            RaiseSettingChangedEvent();
        }
    }
}
