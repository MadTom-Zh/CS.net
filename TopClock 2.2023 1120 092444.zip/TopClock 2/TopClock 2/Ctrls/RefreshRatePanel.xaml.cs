﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MadTomDev.App.Ctrls
{
    /// <summary>
    /// Interaction logic for RefreshRatePanel.xaml
    /// </summary>
    public partial class RefreshRatePanel : UserControl
    {
        public RefreshRatePanel()
        {
            InitializeComponent();
        }


        public static readonly RoutedEvent SettingChangedEvent = EventManager.RegisterRoutedEvent(
            nameof(SettingChanged), RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(RefreshRatePanel));
        public event RoutedEventHandler SettingChanged
        {
            add { this.AddHandler(SettingChangedEvent, value); }
            remove { this.RemoveHandler(SettingChangedEvent, value); }
        }
        private void RaiseSettingChangedEvent()
        {
            RaiseEvent(new RoutedEventArgs(SettingChangedEvent, this));
        }

        public Setting.RefreshRates SelectedFreshRate
        {
            get
            {
                if (rb_realTime.IsChecked == true)
                    return Setting.RefreshRates.Unlimited;
                if (rb_2.IsChecked == true)
                    return Setting.RefreshRates.fps2;
                if (rb_10.IsChecked == true)
                    return Setting.RefreshRates.fps10;
                if (rb_100.IsChecked == true)
                    return Setting.RefreshRates.fps100;
                else
                    return Setting.RefreshRates.fps1;
            }
            set
            {
                outerSetting = true;
                switch (value)
                {
                    case Setting.RefreshRates.fps1:
                        rb_1.IsChecked = true; break;
                    case Setting.RefreshRates.fps2:
                        rb_2.IsChecked = true; break;
                    case Setting.RefreshRates.fps10:
                        rb_10.IsChecked = true; break;
                    case Setting.RefreshRates.fps100:
                        rb_100.IsChecked = true; break;
                    case Setting.RefreshRates.Unlimited:
                        rb_realTime.IsChecked = true; break;
                }
                outerSetting = false;
            }
        }
        private bool outerSetting = false;
        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            if (outerSetting)
                return;

            RaiseSettingChangedEvent();
        }
    }
}
