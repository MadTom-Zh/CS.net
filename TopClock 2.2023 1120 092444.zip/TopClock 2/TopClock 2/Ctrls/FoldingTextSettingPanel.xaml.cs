﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MadTomDev.App.Ctrls
{
    /// <summary>
    /// Interaction logic for FoldingTextSettingPanel.xaml
    /// </summary>
    public partial class FoldingTextSettingPanel : UserControl, INotifyPropertyChanged
    {
        public FoldingTextSettingPanel()
        {
            InitializeComponent();
            DataContext = this;

            core = Core.GetInstance();
            bdr_frColorBG.Background = new ImageBrush(core.BGColorBG);
            combo_frColor.ItemsSource = core.ColorList;
        }

        Core core;

        #region get ui within a user-control container
        private Border _bdr_frColorBG = null;
        private Border bdr_frColorBG
        {
            get
            {
                if (_bdr_frColorBG == null)
                {
                    StackPanel container = (StackPanel)pgb_textSetting.Content;
                    _bdr_frColorBG = (Border)((Grid)container.Children[0]).Children[4];
                }
                return _bdr_frColorBG;
            }
        }
        private Border _bdr_frColor = null;
        private Border bdr_frColor
        {
            get
            {
                if (_bdr_frColor == null)
                {
                    StackPanel container = (StackPanel)pgb_textSetting.Content;
                    _bdr_frColor = (Border)((Grid)container.Children[0]).Children[5];
                }
                return _bdr_frColor;
            }
        }
        private ComboBox _combo_frColor = null;
        private ComboBox combo_frColor
        {
            get
            {
                if (_combo_frColor == null)
                {
                    StackPanel container = (StackPanel)pgb_textSetting.Content;
                    _combo_frColor = (ComboBox)((Grid)container.Children[0]).Children[6];
                }
                return _combo_frColor;
            }
        }
        #endregion


        public bool IsChecked
        {
            get => pgb_textSetting.IsChecked;
            set => pgb_textSetting.IsChecked = value;
        }
        private void pgb_textSetting_CheckChanged(object sender, RoutedEventArgs e)
        {
            RaiseSettingChangedEvent();
        }
        public string HeaderText
        {
            get => pgb_textSetting.HeaderText;
            set => pgb_textSetting.HeaderText = value;
        }

        #region get ui control
        private TextBox _tb_format;
        public TextBox tb_format
        {
            get
            {
                if (_tb_format == null)
                {
                    StackPanel container = (StackPanel)pgb_textSetting.Content;
                    _tb_format = (TextBox)((Grid)container.Children[0]).Children[1];
                }
                return _tb_format;
            }
        }

        private ShadowSettingPanel _SDP;
        public ShadowSettingPanel SDP
        {
            get
            {
                if (_SDP == null)
                {
                    StackPanel container = (StackPanel)pgb_textSetting.Content;
                    _SDP = (ShadowSettingPanel)container.Children[1];
                }
                return _SDP;
            }
        }
        private UI.NumericUpDown _nud_posiX;
        public UI.NumericUpDown nud_posiX
        {
            get
            {
                if (_nud_posiX == null)
                {
                    StackPanel container = (StackPanel)pgb_textSetting.Content;
                    _nud_posiX = (UI.NumericUpDown)((Grid)container.Children[2]).Children[1];
                }
                return _nud_posiX;
            }
        }
        private UI.NumericUpDown _nud_posiY;
        public UI.NumericUpDown nud_posiY
        {
            get
            {
                if (_nud_posiY == null)
                {
                    StackPanel container = (StackPanel)pgb_textSetting.Content;
                    _nud_posiY = (UI.NumericUpDown)((Grid)container.Children[2]).Children[3];
                }
                return _nud_posiY;
            }
        }

        #endregion


        public string FormatText
        {
            get => tb_format.Text;
            set => tb_format.Text = value;
        }
        private void tb_format_textChanged(object sender, TextChangedEventArgs e)
        {
            RaiseSettingChangedEvent();
        }



        public static readonly RoutedEvent SettingChangedEvent = EventManager.RegisterRoutedEvent(
            nameof(SettingChanged), RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(FoldingTextSettingPanel));
        public event RoutedEventHandler SettingChanged
        {
            add { this.AddHandler(SettingChangedEvent, value); }
            remove { this.RemoveHandler(SettingChangedEvent, value); }
        }
        private void RaiseSettingChangedEvent()
        {
            RaiseEvent(new RoutedEventArgs(SettingChangedEvent, this));
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        public void RaisePropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private UI.FontDialog fontDialog = null;
        public FontFamily textFontFamily = new FontFamily("consolas");
        public double textFontSize = 20;
        public FontWeight textFontWeight = FontWeights.Bold;
        public FontStyle textFontStyle = FontStyles.Normal;
        public TextDecorationCollection textDecoration = null;
        private void btn_font_Click(object sender, RoutedEventArgs e)
        {
            fontDialog = new UI.FontDialog()
            {
                SettingFontFamily = textFontFamily,
                SettingFontSize = textFontSize,
                SettingFontWeight = textFontWeight,
                SettingFontStyle = textFontStyle,
                SettingTextDecoration = textDecoration,
            };
            if (fontDialog.ShowDialog() == true)
            {
                textFontFamily = fontDialog.SettingFontFamily;
                textFontSize = fontDialog.SettingFontSize;
                textFontWeight = fontDialog.SettingFontWeight;
                textFontStyle = fontDialog.SettingFontStyle;
                textDecoration = fontDialog.SettingTextDecoration;
                RaiseSettingChangedEvent();
            }
        }





        public Color FrColor
        {
            get => ((SolidColorBrush)bdr_frColor.Background).Color;
            set
            {
                bdr_frColor.Background = new SolidColorBrush(value);
                RaiseSettingChangedEvent();
            }
        }

        private void combo_frColor_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (combo_frColor.SelectedItem is Core.ColorItem)
            {
                Core.ColorItem ci = (Core.ColorItem)combo_frColor.SelectedItem;
                if (ci.name.ToLower() != "custom.")
                {
                    FrColor = ci.color;
                }
            }
        }
        private void btn_frColor_Click(object sender, RoutedEventArgs e)
        {
            if (core.NewSelectClrWnd(FrColor).ShowDialog() == true)
            {
                combo_frColor.SelectedIndex = 0;
                FrColor = core.selectClrWnd.WorkingColor;
            }
        }


        private void ShadowSettingPanel_SettingChanged(object sender, RoutedEventArgs e)
        {
            e.Handled = true;
            RaiseSettingChangedEvent();
        }


        public double PosiX
        {
            get => (double)nud_posiX.Value;
            set => nud_posiX.Value = (decimal)value;
        }
        public double PosiY
        {
            get => (double)nud_posiY.Value;
            set => nud_posiY.Value = (decimal)value;
        }
        private void nud_posiX_ValueChanged(UI.NumericUpDown sender)
        {
            RaiseSettingChangedEvent();
        }

        private void nud_posiY_ValueChanged(UI.NumericUpDown sender)
        {
            RaiseSettingChangedEvent();
        }

    }
}
