﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MadTomDev.App.Ctrls
{
    /// <summary>
    /// Interaction logic for AxesedImageSettingPanel.xaml
    /// </summary>
    public partial class AxesedImageSettingPanel : UserControl
    {
        public AxesedImageSettingPanel()
        {
            InitializeComponent();
            DataContext = this;

            core = Core.GetInstance();
            bdr_bgColorBG.Background = new ImageBrush(core.BGColorBG);
            combo_bgColor.ItemsSource = core.ColorList;
        }
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            core = Core.GetInstance();
            //object test = core.ToString();
        }


        public static readonly RoutedEvent SettingChangedEvent = EventManager.RegisterRoutedEvent(
            nameof(SettingChanged), RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(AxesedImageSettingPanel));
        public event RoutedEventHandler SettingChanged
        {
            add { this.AddHandler(SettingChangedEvent, value); }
            remove { this.RemoveHandler(SettingChangedEvent, value); }
        }
        private void RaiseSettingChangedEvent()
        {
            RaiseEvent(new RoutedEventArgs(SettingChangedEvent, this));
        }
        private void shadowPanel_SettingChanged(object sender, RoutedEventArgs e)
        {
            RaiseSettingChangedEvent();
        }




        public string Title
        {
            get { return (string)GetValue(TitleProperty); }
            set { SetValue(TitleProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MyProperty.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TitleProperty =
            DependencyProperty.Register(nameof(Title), typeof(string), typeof(AxesedImageSettingPanel), new PropertyMetadata("Title"));

        public string ImageFile
        {
            get { return (string)GetValue(ImageFileProperty); }
            set
            {
                SetValue(ImageFileProperty, value);
                if (tb_fileName != null)
                    tb_fileName.Text = System.IO.Path.GetFileName(value);
                RaiseSettingChangedEvent();
            }
        }

        // Using a DependencyProperty as the backing store for MyProperty.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ImageFileProperty =
            DependencyProperty.Register(nameof(ImageFile), typeof(string), typeof(AxesedImageSettingPanel), new PropertyMetadata(""));

        Core core;
        private void Button_removeBG_Click(object sender, RoutedEventArgs e)
        {
            ImageFile = "";
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // select image
            if (core.NewSelectFileWnd($"Select image of {Title}", System.IO.Path.GetDirectoryName(ImageFile)).ShowDialog() == true)
            {
                ImageFile = core.selectFileWnd.selected_files[0];
            }
        }





        public Color BGColor
        {
            get => ((SolidColorBrush)bdr_bgColor.Background).Color;
            set
            {
                if (bdr_bgColor != null)
                    bdr_bgColor.Background = new SolidColorBrush(value);
                RaiseSettingChangedEvent();
            }
        }
        private void combo_bgColor_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (combo_bgColor.SelectedItem is Core.ColorItem)
            {
                Core.ColorItem ci = (Core.ColorItem)combo_bgColor.SelectedItem;
                if (ci.name.ToLower() != "custom.")
                {
                    BGColor = ci.color;
                }
            }
        }
        private void btn_bgColor_Click(object sender, RoutedEventArgs e)
        {
            if (core.NewSelectClrWnd(BGColor).ShowDialog() == true)
            {
                combo_bgColor.SelectedIndex = 0;
                BGColor = core.selectClrWnd.WorkingColor;
            }
        }




        public double PosiX
        {
            get => (double)nud_axX.Value;
            set
            {
                nud_axX.Value = (decimal)value;
            }
        }
        private void nud_axX_ValueChanged(UI.NumericUpDown sender)
        {
            RaiseSettingChangedEvent();
        }


        public double PosiY
        {
            get => (double)nud_axY.Value;
            set
            {
                nud_axY.Value = (decimal)value;
            }
        }
        private void nud_axY_ValueChanged(UI.NumericUpDown sender)
        {
            RaiseSettingChangedEvent();
        }



        public bool IsGBColorEnabled
        {
            get => btn_bgColor.IsEnabled == true;
            set
            {
                combo_bgColor.IsEnabled = value;
                btn_bgColor.IsEnabled = value;
            }
        }


        public bool IsAxesEnabled
        {
            get => nud_axX.IsEnabled;
            set
            {
                nud_axX.IsEnabled = value;
                nud_axY.IsEnabled = value;
            }
        }
    }
}
