﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.IO;
using System.Windows.Media;
using System.Windows;
using System.Windows.Media.Imaging;

namespace MadTomDev.App
{
    public class Setting
    {
        private Setting() { }
        private string xmlFile = Path.Combine(Common.Variables.IOPath.SettingDir, "topClock2.xml");
        private static Setting instance;
        public static Setting GetInstance()
        {
            if (instance == null)
            {
                instance = new Setting();
                instance.Reload();
            }
            return instance;
        }

        #region load or save

        private bool _SettingExists = false;
        public bool SettingExists
        {
            get => _SettingExists;
        }
        private static string baseDir = AppDomain.CurrentDomain.BaseDirectory;
        public void Reload()
        {
            if (File.Exists(instance.xmlFile))
            {
                Data.SettingXML.Node settingNode = ReGetSettingNode(out Data.SettingXML missing);
                if (settingNode != null)
                {
                    if (Enum.TryParse(typeof(Apparences), settingNode.attributes["apparence"], out object result))
                    {
                        instance.apparence = (Apparences)result;
                    }
                    if (bool.TryParse(settingNode.attributes["isTopMost"], out bool testBool))
                    {
                        instance.isTopMost = testBool;
                    }
                    if (bool.TryParse(settingNode.attributes["isClockWndLocked"], out testBool))
                    {
                        instance.isClockWndLocked = testBool;
                    }
                    instance.language = settingNode.attributes["language"];

                    Data.SettingXML.Node digNode = settingNode.FindFirst("digitalPanel");
                    if (digNode != null)
                    {
                        SetPnSettingsFromXML(digitalPanelSetting, digNode);
                    }

                    Data.SettingXML.Node clcNode = settingNode.FindFirst("roundClockSetting");
                    if (clcNode != null)
                    {
                        SetPnSettingsFromXML(roundClockSetting, clcNode);
                        roundClockSetting.AxisPoint
                            = Point.Parse(clcNode.attributes["axisPoint"]);

                        Data.SettingXML.Node hdNode;
                        hdNode = clcNode.FindFirst("hourHand");
                        if (hdNode != null)
                            SetHandSettingsFromXML(roundClockSetting.hourHand, hdNode);
                        hdNode = clcNode.FindFirst("minHand");
                        if (hdNode != null)
                            SetHandSettingsFromXML(roundClockSetting.minHand, hdNode);
                        hdNode = clcNode.FindFirst("secHand");
                        if (hdNode != null)
                            SetHandSettingsFromXML(roundClockSetting.secHand, hdNode);
                    }
                }
            }
        }
        private Data.SettingXML.Node ReGetSettingNode(out Data.SettingXML xmlDoc)
        {
            _SettingExists = false;
            if (File.Exists(instance.xmlFile))
            {
                xmlDoc = new Data.SettingXML(instance.xmlFile);
            }
            else
            {
                xmlDoc = new Data.SettingXML("Root") { xmlFile = instance.xmlFile };
            }
            Data.SettingXML.Node settingNode = null;
            foreach (Data.SettingXML.Node n in xmlDoc.rootNode["Instance"])
            {
                if (n.attributes["appPath"] == AppDomain.CurrentDomain.BaseDirectory)
                {
                    settingNode = n;
                    _SettingExists = true;
                    break;
                }
            }
            return settingNode;
        }
        public void Save()
        {
            Data.SettingXML xmlDoc;
            Data.SettingXML.Node istNode = ReGetSettingNode(out xmlDoc);
            foreach (Data.SettingXML.Node n in xmlDoc.rootNode["Instance"])
            {
                if (n.attributes["appPath"] == AppDomain.CurrentDomain.BaseDirectory)
                {
                    istNode = n;
                    break;
                }
            }
            if (istNode == null)
            {
                istNode = new Data.SettingXML.Node() { nodeName = "Instance" };
                xmlDoc.rootNode.Add(istNode);
                istNode.attributes.AddUpdate("appPath", AppDomain.CurrentDomain.BaseDirectory);
            }
            istNode.attributes.AddUpdate("apparence", apparence.ToString());
            istNode.attributes.AddUpdate("isTopMost", isTopMost.ToString());
            istNode.attributes.AddUpdate("isClockWndLocked", isClockWndLocked.ToString());
            istNode.attributes.AddUpdate("language", language);

            #region digital panel

            Data.SettingXML.Node digNode;
            digNode = istNode.FindFirst("digitalPanel");
            if (digNode == null)
            {
                digNode = new Data.SettingXML.Node() { nodeName = "digitalPanel" };
                istNode.Add(digNode);
            }
            SetPnSettingsToXML(digNode, digitalPanelSetting);
            #endregion


            #region round clock

            Data.SettingXML.Node clcNode;
            clcNode = istNode.FindFirst("roundClockSetting");
            if (clcNode == null)
            {
                clcNode = new Data.SettingXML.Node() { nodeName = "roundClockSetting" };
                istNode.Add(clcNode);
            }
            SetPnSettingsToXML(clcNode, roundClockSetting);
            clcNode.attributes.AddUpdate("axisPoint", roundClockSetting.AxisPoint.ToString());

            Data.SettingXML.Node hdNode;
            hdNode = clcNode.FindFirst("hourHand");
            if (hdNode == null)
            {
                hdNode = new Data.SettingXML.Node() { nodeName = "hourHand" };
                clcNode.Add(hdNode);
            }
            SetHandSettingsToXML(hdNode, roundClockSetting.hourHand);
            hdNode = clcNode.FindFirst("minHand");
            if (hdNode == null)
            {
                hdNode = new Data.SettingXML.Node() { nodeName = "minHand" };
                clcNode.Add(hdNode);
            }
            SetHandSettingsToXML(hdNode, roundClockSetting.minHand);
            hdNode = clcNode.FindFirst("secHand");
            if (hdNode == null)
            {
                hdNode = new Data.SettingXML.Node() { nodeName = "secHand" };
                clcNode.Add(hdNode);
            }
            SetHandSettingsToXML(hdNode, roundClockSetting.secHand);

            #endregion

            xmlDoc.Save();
            _SettingExists = true;
        }
        private static void SetPnSettingsToXML(Data.SettingXML.Node pnNode, DigitalPanelSettings pnSetting)
        {
            pnNode.attributes.AddUpdate("windowPosition", pnSetting.windowPosition.ToString());
            pnNode.attributes.AddUpdate("windowSize", pnSetting.windowSize.ToString());
            pnNode.attributes.AddUpdate("backgroundColor", pnSetting.backgroundColor.ToString());
            string relaPath = Data.Utilities. FilePath.GetPathRelated(pnSetting.backgroundImageFile, baseDir);
            pnNode.attributes.AddUpdate("backgroundImageFile", relaPath == null ? "[null]" : relaPath);
            pnNode.attributes.AddUpdate("backgroundImagePosition", pnSetting.backgroundImagePosition.ToString());

            Data.SettingXML.Node txNode;
            txNode = pnNode.FindFirst("timeText");
            if (txNode == null)
            {
                txNode = new Data.SettingXML.Node() { nodeName = "timeText" };
                pnNode.Add(txNode);
            }
            SetTxSettingsToXML(txNode, pnSetting.timeText);
            txNode = pnNode.FindFirst("dateText");
            if (txNode == null)
            {
                txNode = new Data.SettingXML.Node() { nodeName = "dateText" };
                pnNode.Add(txNode);
            }
            SetTxSettingsToXML(txNode, pnSetting.dateText);
            txNode = pnNode.FindFirst("dayText");
            if (txNode == null)
            {
                txNode = new Data.SettingXML.Node() { nodeName = "dayText" };
                pnNode.Add(txNode);
            }
            SetTxSettingsToXML(txNode, pnSetting.dayText);

            pnNode.attributes.AddUpdate("freshRate", pnSetting.freshRate.ToString());
        }
        private static void SetPnSettingsFromXML(DigitalPanelSettings pnSetting, Data.SettingXML.Node pnNode)
        {
            pnSetting.windowPosition
                = Point.Parse(pnNode.attributes["windowPosition"]);
            pnSetting.windowSize
                = Point.Parse(pnNode.attributes["windowSize"]);
            string testStr = pnNode.attributes["backgroundColor"];
            if (string.IsNullOrWhiteSpace(testStr))
            {
                pnSetting.backgroundColor = Colors.Transparent;
            }
            else
            {
                pnSetting.backgroundColor
                    = (Color)ColorConverter.ConvertFromString(testStr);
            }


            testStr = pnNode.attributes["backgroundImageFile"];
            string fullPath;
            if (string.IsNullOrEmpty(testStr) || testStr == "[null]")
                fullPath = null;
            else
                fullPath = Data.Utilities.FilePath.GetPathAbsolute(testStr, baseDir);
            pnSetting.backgroundImageFile = fullPath;

            pnSetting.backgroundImagePosition
                = Point.Parse(pnNode.attributes["backgroundImagePosition"]);

            Data.SettingXML.Node txNode = pnNode.FindFirst("timeText");
            if (txNode != null)
            {
                SetTxSettingsFromXML(pnSetting.timeText, txNode);
            }
            txNode = pnNode.FindFirst("dateText");
            if (txNode != null)
            {
                SetTxSettingsFromXML(pnSetting.dateText, txNode);
            }
            txNode = pnNode.FindFirst("dayText");
            if (txNode != null)
            {
                SetTxSettingsFromXML(pnSetting.dayText, txNode);
            }

            if (Enum.TryParse(typeof(RefreshRates), pnNode.attributes["freshRate"], out object o))
                pnSetting.freshRate = (RefreshRates)o;
        }
        private static void SetTxSettingsToXML(Data.SettingXML.Node txNode, TextSettings txSetting)
        {
            txNode.attributes.AddUpdate("isEnabled", txSetting.isEnabled.ToString());
            txNode.attributes.AddUpdate("format", txSetting.format);
            txNode.attributes.AddUpdate("fontFamily", txSetting.fontFamily.ToString());
            txNode.attributes.AddUpdate("foreColor", txSetting.foreColor.ToString());
            txNode.attributes.AddUpdate("fontStyle", txSetting.fontStyle.ToString());
            txNode.attributes.AddUpdate("fontSize", txSetting.fontSize.ToString());
            txNode.attributes.AddUpdate("fontWeight", txSetting.fontWeight.ToString());
            if (txSetting.decoration == null)
                txNode.attributes.AddUpdate("decoration", null);
            else
                txNode.attributes.AddUpdate("decoration", txSetting.decoration[0].Location.ToString());
            txNode.attributes.AddUpdate("position", txSetting.position.ToString());

            Data.SettingXML.Node sdNode = txNode.FindFirst("shadow");
            if (sdNode == null)
            {
                sdNode = new Data.SettingXML.Node() { nodeName = "shadow" };
                txNode.Add(sdNode);
            }
            SetShadowSettingsToXML(sdNode, txSetting.shadow);
        }
        private static void SetTxSettingsFromXML(TextSettings txSetting, Data.SettingXML.Node txNode)
        {
            if (bool.TryParse(txNode.attributes["isEnabled"], out bool b))
                txSetting.isEnabled = b;
            txSetting.format = txNode.attributes["format"];
            string testStr = txNode.attributes["fontFamily"];
            if (!string.IsNullOrWhiteSpace(testStr))
                txSetting.fontFamily = new FontFamily(testStr);
            txSetting.foreColor = (Color)ColorConverter.ConvertFromString(txNode.attributes["foreColor"]);

            testStr = txNode.attributes["fontStyle"];
            object? textObj;
            if (!string.IsNullOrEmpty(testStr))
            {
                textObj = new FontStyleConverter().ConvertFrom(testStr);
                if (textObj != null)
                    txSetting.fontStyle = (FontStyle)textObj;
            }
            if (double.TryParse(txNode.attributes["fontSize"], out double d))
                txSetting.fontSize = d;
            testStr = txNode.attributes["fontWeight"];
            if (!string.IsNullOrEmpty(testStr))
            {
                textObj = new FontWeightConverter().ConvertFrom(testStr);
                if (textObj != null)
                    txSetting.fontWeight = (FontWeight)textObj;
            }

            testStr = txNode.attributes["decoration"];
            if (string.IsNullOrEmpty(testStr))
            {
                txSetting.decoration = null;
            }
            else if (testStr == nameof(TextDecorations.Underline))
            {
                txSetting.decoration = TextDecorations.Underline;
            }
            else if (testStr == nameof(TextDecorations.Baseline))
            {
                txSetting.decoration = TextDecorations.Baseline;
            }
            else if (testStr == nameof(TextDecorations.OverLine))
            {
                txSetting.decoration = TextDecorations.OverLine;
            }
            else if (testStr == nameof(TextDecorations.Strikethrough))
            {
                txSetting.decoration = TextDecorations.Strikethrough;
            }

            txSetting.position = Point.Parse(txNode.attributes["position"]);

            Data.SettingXML.Node sdNode = txNode.FindFirst("shadow");
            if (sdNode != null)
                SetShadowSettingsFromXML(txSetting.shadow, sdNode);
        }
        private static void SetShadowSettingsToXML(Data.SettingXML.Node sdNode, DropShadowSettings sdSetting)
        {
            sdNode.attributes.AddUpdate("isEnabled", sdSetting.isEnabled.ToString());
            sdNode.attributes.AddUpdate("color", sdSetting.color.ToString());
            sdNode.attributes.AddUpdate("depth", sdSetting.depth.ToString());
            sdNode.attributes.AddUpdate("blurRadius", sdSetting.blurRadius.ToString());
            sdNode.attributes.AddUpdate("opacity", sdSetting.opacity.ToString());
            sdNode.attributes.AddUpdate("direction", sdSetting.direction.ToString());
        }
        private static void SetShadowSettingsFromXML(DropShadowSettings sdSetting, Data.SettingXML.Node sdNode)
        {
            if (bool.TryParse(sdNode.attributes["isEnabled"], out bool b))
                sdSetting.isEnabled = b;
            sdSetting.color = (Color)ColorConverter.ConvertFromString(sdNode.attributes["color"]);
            if (double.TryParse(sdNode.attributes["depth"], out double d))
                sdSetting.depth = d;
            if (double.TryParse(sdNode.attributes["blurRadius"], out d))
                sdSetting.blurRadius = d;
            if (double.TryParse(sdNode.attributes["opacity"], out d))
                sdSetting.opacity = d;
            if (double.TryParse(sdNode.attributes["direction"], out d))
                sdSetting.direction = d;
        }
        private static void SetHandSettingsToXML(Data.SettingXML.Node hdNode, HandSettings hdSetting)
        {
            hdNode.attributes.AddUpdate("isEnabled", hdSetting.isEnabled.ToString());
            string relaPath = Data.Utilities.FilePath.GetPathRelated(hdSetting.imageFile, baseDir);
            hdNode.attributes.AddUpdate("imageFile", relaPath == null ? "[null]" : relaPath);
            hdNode.attributes.AddUpdate("axisPoint", hdSetting.axisPoint.ToString());
            Data.SettingXML.Node sdNode = hdNode.FindFirst("shadow");
            if (sdNode == null)
            {
                sdNode = new Data.SettingXML.Node() { nodeName = "shadow" };
                hdNode.Add(sdNode);
            }
            SetShadowSettingsToXML(sdNode, hdSetting.shadow);
        }
        private static void SetHandSettingsFromXML(HandSettings hdSetting, Data.SettingXML.Node hdNode)
        {
            if (bool.TryParse(hdNode.attributes["isEnabled"], out bool b))
                hdSetting.isEnabled = b;

            string testStr = hdNode.attributes["imageFile"];
            string fullPath;
            if (string.IsNullOrEmpty(testStr) || testStr == "[null]")
                fullPath = null;
            else
                fullPath = Data.Utilities.FilePath.GetPathAbsolute(testStr, baseDir);
            hdSetting.imageFile = fullPath;
            hdSetting.axisPoint = Point.Parse(hdNode.attributes["axisPoint"]);
            Data.SettingXML.Node sdNode = hdNode.FindFirst("shadow");
            if (sdNode != null)
            {
                SetShadowSettingsFromXML(hdSetting.shadow, sdNode);
            }
        }

        #endregion

        public bool isClockWndLocked;
        public enum Apparences
        { None, DigitalPanel, RoundClock }
        public Apparences apparence = Apparences.DigitalPanel;

        public bool isTopMost = true;
        public string language;

        public class TextSettings
        {
            public bool isEnabled = false;
            public string format = null;
            public FontFamily fontFamily = new FontFamily("consolas");
            public FontStyle fontStyle;
            public double fontSize = 20;
            public FontWeight fontWeight = FontWeights.Bold;
            public TextDecorationCollection decoration;
            public Color foreColor = Colors.Black;
            public Point position = new Point(0, 0);
            public DropShadowSettings shadow = new DropShadowSettings();
        }
        public class DropShadowSettings
        {
            public bool isEnabled = false;
            public Color color = Colors.Gray;
            public double depth = 5;
            public double blurRadius = 25;
            public double opacity = 0.7;
            public double direction = 135;
        }
        public class HandSettings
        {
            public bool isEnabled = false;
            public string imageFile;
            public Point axisPoint = new Point(0, 0);
            public DropShadowSettings shadow = new DropShadowSettings();
        }
        public enum RefreshRates
        { Unlimited, fps100, fps10, fps2, fps1, }
        public class DigitalPanelSettings
        {
            public Point windowPosition = new Point(0, 0);
            public Point windowSize = new Point(100, 100);

            public Color backgroundColor = Colors.Transparent;
            public string backgroundImageFile;
            public Point backgroundImagePosition = new Point(0, 0);

            public TextSettings timeText = new TextSettings();
            public TextSettings dateText = new TextSettings();
            public TextSettings dayText = new TextSettings();

            public RefreshRates freshRate = RefreshRates.fps1;
        }
        public class RoundClockSettings : DigitalPanelSettings
        {
            public Point AxisPoint = new Point(50, 50);
            public HandSettings hourHand = new HandSettings();
            public HandSettings minHand = new HandSettings();
            public HandSettings secHand = new HandSettings();
        }


        public DigitalPanelSettings digitalPanelSetting = new DigitalPanelSettings();

        public RoundClockSettings roundClockSetting = new RoundClockSettings();

    }
}
