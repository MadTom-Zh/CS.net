﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace MadTomDev.App
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private Core core;
        private Setting setting;
        private void Application_Startup(object sender, StartupEventArgs e)
        {


            //object test = e.Args;
            //string output = "";
            //foreach (string a in e.Args)
            //    output += a + "\r\n";
            //MessageBox.Show(output);

            // 空格分割多个参数
        }
    }
}
