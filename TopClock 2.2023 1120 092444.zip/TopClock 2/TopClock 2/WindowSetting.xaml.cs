﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MadTomDev.App
{
    /// <summary>
    /// Interaction logic for WindowSetting.xaml
    /// </summary>
    public partial class WindowSetting : Window
    {
        public WindowSetting()
        {
            InitializeComponent();
        }

        Core core;
        Setting setting;
        private bool isInit = true;
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            isInit = true;
            core = Core.GetInstance();
            setting = Setting.GetInstance();
            tBtn_clock.IsChecked = false;
            tBtn_digit.IsChecked = false;
            switch (setting.apparence)
            {
                case Setting.Apparences.RoundClock:
                    tBtn_clock.IsChecked = true;
                    ((TabItem)tabCtrl.Items[2]).IsEnabled = false;
                    break;
                case Setting.Apparences.DigitalPanel:
                    tBtn_digit.IsChecked = true;
                    ((TabItem)tabCtrl.Items[1]).IsEnabled = false;
                    break;
            }
            cb_isTopMost.IsChecked = setting.isTopMost;

            #region setting to UI, clock

            SettingToUI_ClockBackGround();

            SettingToUI_ClockImage(setting.roundClockSetting.hourHand, aisp_clock_hour);
            SettingToUI_ClockImage(setting.roundClockSetting.minHand, aisp_clock_min);
            SettingToUI_ClockImage(setting.roundClockSetting.secHand, aisp_clock_sec);

            SettingToUI_Shadow(setting.roundClockSetting.hourHand.shadow, sdp_clock_hour);
            SettingToUI_Shadow(setting.roundClockSetting.minHand.shadow, sdp_clock_min);
            SettingToUI_Shadow(setting.roundClockSetting.secHand.shadow, sdp_clock_sec);

            SettingToUI_Text(setting.roundClockSetting.dateText, tsp_clock_date);
            SettingToUI_Text(setting.roundClockSetting.dayText, tsp_clock_day);
            SettingToUI_Text(setting.roundClockSetting.timeText, tsp_clock_time);

            nud_clock_wndX.Value = (decimal)setting.roundClockSetting.windowPosition.X;
            nud_clock_wndY.Value = (decimal)setting.roundClockSetting.windowPosition.Y;
            nud_clock_wndW.Value = (decimal)setting.roundClockSetting.windowSize.X;
            nud_clock_wndH.Value = (decimal)setting.roundClockSetting.windowSize.Y;

            rrp_clock.SelectedFreshRate = setting.roundClockSetting.freshRate;

            #endregion

            #region setting to UI, digital

            SettingToUI_DigitalBackGround();

            SettingToUI_Text(setting.digitalPanelSetting.dateText, tsp_digital_date);
            SettingToUI_Text(setting.digitalPanelSetting.dayText, tsp_digital_day);
            SettingToUI_Text(setting.digitalPanelSetting.timeText, tsp_digital_time);

            nud_digital_wndX.Value = (decimal)setting.digitalPanelSetting.windowPosition.X;
            nud_digital_wndY.Value = (decimal)setting.digitalPanelSetting.windowPosition.Y;
            nud_digital_wndW.Value = (decimal)setting.digitalPanelSetting.windowSize.X;
            nud_digital_wndH.Value = (decimal)setting.digitalPanelSetting.windowSize.Y;

            rrp_digital.SelectedFreshRate = setting.digitalPanelSetting.freshRate;


            #endregion

            isInit = false;
        }


        #region general

        private void tBtn_clock_Checked(object sender, RoutedEventArgs e)
        {
            tBtn_digit.IsChecked = false;
            ((TabItem)tabCtrl.Items[1]).IsEnabled = true;
            ((TabItem)tabCtrl.Items[2]).IsEnabled = false;
            if (isInit)
                return;
            setting.apparence = Setting.Apparences.RoundClock;
            core.ApplyApparence();
            core.ApplyClockAll();
        }
        private void tBtn_digit_Checked(object sender, RoutedEventArgs e)
        {
            tBtn_clock.IsChecked = false;
            ((TabItem)tabCtrl.Items[1]).IsEnabled = false;
            ((TabItem)tabCtrl.Items[2]).IsEnabled = true;
            if (isInit)
                return;
            setting.apparence = Setting.Apparences.DigitalPanel;
            core.ApplyApparence();
            core.ApplyDigitalAll();
        }
        private void cb_isTopMost_CheckChanged(object sender, RoutedEventArgs e)
        {
            if (isInit)
                return;
            setting.isTopMost = cb_isTopMost.IsChecked == true;
            core.ApplyApparence();
        }




        #endregion



        #region setting - clock

        #region clock, setting <-> UI, UI <-> setting
        private void SettingToUI_ClockBackGround()
        {
            aisp_clock_bg.ImageFile = setting.roundClockSetting.backgroundImageFile;
            aisp_clock_bg.PosiX = setting.roundClockSetting.AxisPoint.X;
            aisp_clock_bg.PosiY = setting.roundClockSetting.AxisPoint.Y;
            aisp_clock_bg.BGColor = setting.roundClockSetting.backgroundColor;
        }
        private void UIToSetting_ClockBackGround()
        {
            setting.roundClockSetting.backgroundImageFile = aisp_clock_bg.ImageFile;
            setting.roundClockSetting.AxisPoint.X = aisp_clock_bg.PosiX;
            setting.roundClockSetting.AxisPoint.Y = aisp_clock_bg.PosiY;
            setting.roundClockSetting.backgroundColor = aisp_clock_bg.BGColor;
        }

        private void SettingToUI_ClockImage(Setting.HandSettings handSetting, Ctrls.AxesedImageSettingPanel aisp)
        {
            aisp.ImageFile = handSetting.imageFile;
            aisp.PosiX = handSetting.axisPoint.X;
            aisp.PosiY = handSetting.axisPoint.Y;
        }
        private void UIToSetting_ClockImage(Ctrls.AxesedImageSettingPanel aisp, Setting.HandSettings handSetting)
        {
            handSetting.imageFile = aisp.ImageFile;
            handSetting.axisPoint.X = aisp.PosiX;
            handSetting.axisPoint.Y = aisp.PosiY;
        }

        private void SettingToUI_Text(Setting.TextSettings textSetting, Ctrls.FoldingTextSettingPanel ftsp)
        {
            ftsp.IsChecked = textSetting.isEnabled;
            ftsp.FormatText = textSetting.format;

            ftsp.textFontFamily = textSetting.fontFamily;
            ftsp.FrColor = textSetting.foreColor;
            ftsp.textFontSize = textSetting.fontSize;
            ftsp.textFontWeight = textSetting.fontWeight;
            ftsp.textFontStyle = textSetting.fontStyle;
            ftsp.textDecoration = textSetting.decoration;

            SettingToUI_Shadow(textSetting.shadow, ftsp.SDP);
            ftsp.PosiX = textSetting.position.X;
            ftsp.PosiY = textSetting.position.Y;
        }
        private void UIToSetting_Text(Ctrls.FoldingTextSettingPanel ftsp, Setting.TextSettings textSetting)
        {
            textSetting.isEnabled = ftsp.IsChecked;
            textSetting.format = ftsp.FormatText;

            textSetting.fontFamily = ftsp.textFontFamily;
            textSetting.foreColor = ftsp.FrColor;
            textSetting.fontSize = ftsp.textFontSize;
            textSetting.fontWeight = ftsp.textFontWeight;
            textSetting.fontStyle = ftsp.textFontStyle;
            textSetting.decoration = ftsp.textDecoration;

            UIToSetting_Shadow(ftsp.SDP, textSetting.shadow);
            textSetting.position.X = ftsp.PosiX;
            textSetting.position.Y = ftsp.PosiY;
        }
        private void SettingToUI_Shadow(Setting.DropShadowSettings sd, Ctrls.ShadowSettingPanel sdp)
        {
            sdp.ShadowColor = sd.color;
            sdp.ShadowDepth = sd.depth;
            sdp.ShadowBlurRadios = sd.blurRadius;
            sdp.ShadowOpacity = sd.opacity;
            sdp.ShadowDirection = sd.direction;

            sdp.IsChecked = sd.isEnabled;
        }
        private void UIToSetting_Shadow(Ctrls.ShadowSettingPanel sdp, Setting.DropShadowSettings sd)
        {
            sd.isEnabled = sdp.IsChecked;
            sd.color = sdp.ShadowColor;
            sd.depth = sdp.ShadowDepth;
            sd.blurRadius = sdp.ShadowBlurRadios;
            sd.opacity = sdp.ShadowOpacity;
            sd.direction = sdp.ShadowDirection;
        }

        #endregion

        private void aisp_clock_bg_SettingChanged(object sender, RoutedEventArgs e)
        {
            if (isInit)
                return;
            UIToSetting_ClockBackGround();
            core.ApplyClockBG();
        }


        #region clock - hands - image, axes
        private void aisp_clock_hour_SettingChanged(object sender, RoutedEventArgs e)
        {
            if (isInit)
                return;
            UIToSetting_ClockImage(aisp_clock_hour, setting.roundClockSetting.hourHand);
            core.GetNow();
            core.ApplyClockHandHour();
        }

        private void aisp_clock_min_SettingChanged(object sender, RoutedEventArgs e)
        {
            if (isInit)
                return;
            UIToSetting_ClockImage(aisp_clock_min, setting.roundClockSetting.minHand);
            core.GetNow();
            core.ApplyClockHandMin();
        }

        private void aisp_clock_sec_SettingChanged(object sender, RoutedEventArgs e)
        {
            if (isInit)
                return;
            UIToSetting_ClockImage(aisp_clock_sec, setting.roundClockSetting.secHand);
            core.GetNow();
            core.ApplyClockHandSec();
        }
        #endregion

        #region clock - hands - shadow
        private void sdp_clock_hour_SettingChanged(object sender, RoutedEventArgs e)
        {
            if (isInit)
                return;
            UIToSetting_Shadow(sdp_clock_hour, setting.roundClockSetting.hourHand.shadow);
            core.ApplyClockHandHour();
        }

        private void sdp_clock_min_SettingChanged(object sender, RoutedEventArgs e)
        {
            if (isInit)
                return;
            UIToSetting_Shadow(sdp_clock_min, setting.roundClockSetting.minHand.shadow);
            core.ApplyClockHandMin();
        }

        private void sdp_clock_sec_SettingChanged(object sender, RoutedEventArgs e)
        {
            if (isInit)
                return;
            UIToSetting_Shadow(sdp_clock_sec, setting.roundClockSetting.secHand.shadow);
            core.ApplyClockHandSec();
        }
        #endregion

        #region clock - date, day, time

        private void tsp_clock_date_SettingChanged(object sender, RoutedEventArgs e)
        {
            if (isInit)
                return;
            UIToSetting_Text(tsp_clock_date, setting.roundClockSetting.dateText);
            core.GetNow();
            core.ApplyClockDate();
        }
        private void tsp_clock_day_SettingChanged(object sender, RoutedEventArgs e)
        {
            if (isInit)
                return;
            UIToSetting_Text(tsp_clock_day, setting.roundClockSetting.dayText);
            core.GetNow();
            core.ApplyClockDay();
        }
        private void tsp_clock_time_SettingChanged(object sender, RoutedEventArgs e)
        {
            if (isInit)
                return;
            UIToSetting_Text(tsp_clock_time, setting.roundClockSetting.timeText);
            core.GetNow();
            core.ApplyClockTime();
        }

        #endregion

        #region clock, window posi, window size
        private void nud_clock_wndX_ValueChanged(UI.NumericUpDown sender)
        {
            if (isInit)
                return;
            setting.roundClockSetting.windowPosition
                = new Point((double)nud_clock_wndX.Value, (double)nud_clock_wndY.Value);
            core.ApplyClockWindowPosi();
        }

        private void nud_clock_wndY_ValueChanged(UI.NumericUpDown sender)
        {
            if (isInit)
                return;
            setting.roundClockSetting.windowPosition
                = new Point((double)nud_clock_wndX.Value, (double)nud_clock_wndY.Value);
            core.ApplyClockWindowPosi();
        }
        private void nud_wndW_clock_ValueChanged(UI.NumericUpDown sender)
        {
            if (isInit)
                return;
            setting.roundClockSetting.windowSize
                = new Point((double)nud_clock_wndW.Value, (double)nud_clock_wndH.Value);
            core.ApplyClockWindowSize();
        }

        private void nud_wndH_clock_ValueChanged(UI.NumericUpDown sender)
        {
            if (isInit)
                return;
            setting.roundClockSetting.windowSize
                = new Point((double)nud_clock_wndW.Value, (double)nud_clock_wndH.Value);
            core.ApplyClockWindowSize();
        }

        public void SetWndPosi(double x, double y)
        {
            isInit = true;
            switch (setting.apparence)
            {
                case Setting.Apparences.RoundClock:
                    setting.roundClockSetting.windowPosition = new Point(x, y);
                    nud_clock_wndX.Value = (decimal)x;
                    nud_clock_wndY.Value = (decimal)y;
                    break;
                case Setting.Apparences.DigitalPanel:
                    setting.digitalPanelSetting.windowPosition = new Point(x, y);
                    nud_digital_wndX.Value = (decimal)x;
                    nud_digital_wndY.Value = (decimal)y;
                    break;
            }
            isInit = false;
        }
        public void SetWndSize(double w, double h)
        {
            isInit = true;
            switch (setting.apparence)
            {
                case Setting.Apparences.RoundClock:
                    setting.roundClockSetting.windowSize = new Point(w, h);
                    nud_clock_wndW.Value = (decimal)w;
                    nud_clock_wndH.Value = (decimal)h;
                    break;
                case Setting.Apparences.DigitalPanel:
                    setting.digitalPanelSetting.windowSize = new Point(w, h);
                    nud_digital_wndW.Value = (decimal)w;
                    nud_digital_wndH.Value = (decimal)h;
                    break;
            }
            isInit = false;
        }
        #endregion

        #region clock-freshRate
        private void rrp_clock_SettingChanged(object sender, RoutedEventArgs e)
        {
            if (isInit)
                return;
            setting.roundClockSetting.freshRate = rrp_clock.SelectedFreshRate;
            core.ApplyClockRefreshRate();
        }
        #endregion

        #endregion


        #region setting - digital

        #region clock, setting <-> UI, UI <-> setting
        private void SettingToUI_DigitalBackGround()
        {
            asip_digital_bg.ImageFile = setting.digitalPanelSetting.backgroundImageFile;
            asip_digital_bg.BGColor = setting.digitalPanelSetting.backgroundColor;
        }
        private void UIToSetting_DigitalBackGround()
        {
            setting.digitalPanelSetting.backgroundImageFile = asip_digital_bg.ImageFile;
            setting.digitalPanelSetting.backgroundColor = asip_digital_bg.BGColor;
        }
        #endregion


        private void asip_digital_bg_SettingChanged(object sender, RoutedEventArgs e)
        {
            if (isInit)
                return;
            UIToSetting_DigitalBackGround();
            core.ApplyDigitalBG();
        }


        #region digital, date, day, time

        private void tsp_digital_date_SettingChanged(object sender, RoutedEventArgs e)
        {
            if (isInit)
                return;
            UIToSetting_Text(tsp_digital_date, setting.digitalPanelSetting.dateText);
            core.GetNow();
            core.ApplyDigitalDate();
        }
        private void tsp_digital_day_SettingChanged(object sender, RoutedEventArgs e)
        {
            if (isInit)
                return;
            UIToSetting_Text(tsp_digital_day, setting.digitalPanelSetting.dayText);
            core.GetNow();
            core.ApplyDigitalDay();
        }
        private void tsp_digital_time_SettingChanged(object sender, RoutedEventArgs e)
        {
            if (isInit)
                return;
            UIToSetting_Text(tsp_digital_time, setting.digitalPanelSetting.timeText);
            core.GetNow();
            core.ApplyDigitalTime();
        }
        #endregion

        #region digital, window posi, window size

        private void nud_wndX_digital_ValueChanged(UI.NumericUpDown sender)
        {
            if (isInit)
                return;
            setting.digitalPanelSetting.windowPosition
                = new Point((double)nud_digital_wndX.Value, (double)nud_digital_wndY.Value);
            core.ApplyDigitalWindowPosi();
        }
        private void nud_wndY_digital_ValueChanged(UI.NumericUpDown sender)
        {
            if (isInit)
                return;
            setting.digitalPanelSetting.windowPosition
                = new Point((double)nud_digital_wndX.Value, (double)nud_digital_wndY.Value);
            core.ApplyDigitalWindowPosi();
        }


        private void nud_wndW_digital_ValueChanged(UI.NumericUpDown sender)
        {
            if (isInit)
                return;
            setting.digitalPanelSetting.windowSize
                = new Point((double)nud_digital_wndW.Value, (double)nud_digital_wndH.Value);
            core.ApplyDigitalWindowSize();
        }
        private void nud_wndH_digital_ValueChanged(UI.NumericUpDown sender)
        {
            if (isInit)
                return;
            setting.digitalPanelSetting.windowSize
                = new Point((double)nud_digital_wndW.Value, (double)nud_digital_wndH.Value);
            core.ApplyDigitalWindowSize();
        }

        #endregion

        private void rrp_digital_SettingChanged(object sender, RoutedEventArgs e)
        {
            if (isInit)
                return;
            setting.digitalPanelSetting.freshRate = rrp_digital.SelectedFreshRate;
            core.ApplyDigitalRefreshRate();
        }


        #endregion



        public bool? closeResult = null;
        private void btn_ok_Click(object sender, RoutedEventArgs e)
        {
            closeResult = true;
            Close();
        }

        private void btn_cancel_Click(object sender, RoutedEventArgs e)
        {
            closeResult = false;
            Close();
        }
    }
}
