﻿// See https://aka.ms/new-console-template for more information


Console.WriteLine("Hello, World!");


//string xmlFile = @"D:\Dev.net\App&Tools\TopClock 2\test.xml";

//MadTomDev.Data.SettingXML xmlSetting = new MadTomDev.Data.SettingXML();

//xmlSetting.Reload(xmlFile);

//xmlSetting.rootNode.nodeName = "Root";
//xmlSetting.rootNode.attributes.attList.Add("testAtt1", "1");
//xmlSetting.rootNode.attributes.attList.Add("testAtt2", "abc");
//xmlSetting.rootNode.attributes.attList.Add("testAtt3", "asfadsf");
//xmlSetting.rootNode.text = "2097349876098!#@$^@^*!~~#! dg sdg sedr ";

//xmlSetting.rootNode.text = null;
//xmlSetting.rootNode.children.Add(new MadTomDev.Data.SettingXML.Node()
//{ nodeName="lef1", text = "lif1 text" });

//MadTomDev.Data.SettingXML.Node lef2 = new MadTomDev.Data.SettingXML.Node()
//{ nodeName = "lef2" };
//lef2.attributes.attList.Add("at1", "123");
//lef2.attributes.attList.Add("at2", "123");

//xmlSetting.rootNode.children.Add(lef2);

//xmlSetting.Save();










Console.ReadLine();