﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using SharpCompress;
using System.IO;

namespace CodeSharing.Entities
{
    public class DataProcessing
    {

        public class QREncodeRequest
        {
            public enum Params
            {
                Coding = 0,
                CLevel = 1,
                Version = 2,
                Scale = 3,
                Text = 4,
            }
            public string coding;
            public string clevel;
            public string version;
            public string scale;
            public string text;
            public QREncodeRequest(string coding, string clevel, string version, string scale, string text)
            {
                this.coding = coding;
                this.clevel = clevel;
                this.version = version;
                this.scale = scale;
                this.text = text;
            }
            public QREncodeRequest(string ioContent)
            {
                this.IOContent = ioContent;
            }
            public string IOContent
            {
                get
                {
                    string str = "";
                    str += Params.Coding.ToString() + ":" + coding + Environment.NewLine;
                    str += Params.CLevel.ToString() + ":" + clevel + Environment.NewLine;
                    str += Params.Version.ToString() + ":" + version + Environment.NewLine;
                    str += Params.Scale.ToString() + ":" + scale + Environment.NewLine;
                    str += Params.Text.ToString() + ":" + text;
                    return Compressor.Compress(str);
                }
                set
                {
                    string[] lines = Compressor.DeCompress(value).Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string line in lines)
                    {
                        if (line.StartsWith(Params.Coding.ToString()))
                        {
                            coding = line.Substring(Params.Coding.ToString().Length + 1);
                        }
                        else if (line.StartsWith(Params.CLevel.ToString()))
                        {
                            clevel = line.Substring(Params.CLevel.ToString().Length + 1);
                        }
                        else if (line.StartsWith(Params.Version.ToString()))
                        {
                            version = line.Substring(Params.Version.ToString().Length + 1);
                        }
                        else if (line.StartsWith(Params.Scale.ToString()))
                        {
                            scale = line.Substring(Params.Scale.ToString().Length + 1);
                        }
                        else if (line.StartsWith(Params.Text.ToString()))
                        {
                            text = line.Substring(Params.Text.ToString().Length + 1);
                        }
                    }
                }
            }
        }

        public class Compressor
        {
            //public StringCompress()
            //{

            //}

            public static string Compress(string unCompressedString)
            {
                byte[] inputBuf = Encoding.Unicode.GetBytes(unCompressedString);
                if (inputBuf.Length == 0)
                {
                    return null;
                }
                MemoryStream ms = new MemoryStream();

                SharpCompress.Compressor.BZip2.BZip2Stream zipSteam = new SharpCompress.Compressor.BZip2.BZip2Stream(ms, SharpCompress.Compressor.CompressionMode.Compress);
                zipSteam.Write(inputBuf, 0, inputBuf.Length);
                zipSteam.Close();

                byte[] outputBuf = ms.ToArray();
                ms.Close();
                ms.Dispose();
                zipSteam.Dispose();

                return System.Convert.ToBase64String(outputBuf);
            }
            public static byte[] Compress(byte[] unCompressedBytes)
            {
                if (unCompressedBytes == null || unCompressedBytes.Length == 0)
                {
                    return null;
                }
                MemoryStream ms = new MemoryStream();

                SharpCompress.Compressor.BZip2.BZip2Stream zipSteam = new SharpCompress.Compressor.BZip2.BZip2Stream(ms, SharpCompress.Compressor.CompressionMode.Compress);
                zipSteam.Write(unCompressedBytes, 0, unCompressedBytes.Length);
                zipSteam.Close();

                byte[] result = ms.ToArray();
                ms.Close();
                ms.Dispose();
                zipSteam.Dispose();
                return result;
            }

            public static string DeCompress(string compressedString)
            {
                if (compressedString == null) return null;
                byte[] inputBuf = System.Convert.FromBase64String(compressedString);
                if (inputBuf == null || inputBuf.Length == 0)
                {
                    return null;
                }
                MemoryStream ms = new MemoryStream(inputBuf);
                ms.Position = 0;
                SharpCompress.Compressor.BZip2.BZip2Stream zipSteam = new SharpCompress.Compressor.BZip2.BZip2Stream(ms, SharpCompress.Compressor.CompressionMode.Decompress);

                MemoryStream outputMem = new MemoryStream();
                int readLength = 512;
                int readLengthCur = readLength;
                byte[] tmpBuf;
                while (readLengthCur == readLength)
                {
                    tmpBuf = new byte[readLength];
                    readLengthCur = zipSteam.Read(tmpBuf, 0, readLength);
                    outputMem.Write(tmpBuf, 0, readLengthCur);
                }

                byte[] outputBuf = outputMem.ToArray();
                outputMem.Close();
                outputMem.Dispose();
                ms.Close();
                ms.Dispose();
                zipSteam.Close();
                zipSteam.Dispose();

                string result = Encoding.Unicode.GetString(outputBuf, 0, outputBuf.Length);
                return result;
            }
            public static byte[] DeCompress(byte[] compressedBytes)
            {
                if (compressedBytes.Length == 0)
                {
                    return null;
                }
                MemoryStream ms = new MemoryStream(compressedBytes);
                ms.Position = 0;
                SharpCompress.Compressor.BZip2.BZip2Stream zipSteam = new SharpCompress.Compressor.BZip2.BZip2Stream(ms, SharpCompress.Compressor.CompressionMode.Decompress);

                MemoryStream outputMem = new MemoryStream();
                int readLength = 512;
                int readLengthCur = readLength;
                byte[] tmpBuf;
                while (readLengthCur == readLength)
                {
                    tmpBuf = new byte[readLength];
                    readLengthCur = zipSteam.Read(tmpBuf, 0, readLength);
                    outputMem.Write(tmpBuf, 0, readLengthCur);
                }

                byte[] result = outputMem.ToArray();
                outputMem.Close();
                outputMem.Dispose();
                ms.Close();
                ms.Dispose();
                zipSteam.Close();
                zipSteam.Dispose();

                return result;
            }
        }
    }
}
