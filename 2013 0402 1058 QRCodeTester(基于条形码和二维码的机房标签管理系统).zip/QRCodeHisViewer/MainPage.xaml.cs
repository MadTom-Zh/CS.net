﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using System.Windows.Threading;
using System.Windows.Browser;

namespace QRCodeHisViewer
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
            timer = new DispatcherTimer();
            timer.Interval = new TimeSpan(0, 0, 0, 0, 100);
            timer.Stop();
            timer.Tick += timer_Tick;
        }

        #region UI 辅助

        int timer_Tick_showInfo = 0;
        int timer_Tick_showWarning = 0;
        int timer_Tick_showError = 0;
        void timer_Tick(object sender, EventArgs e)
        {
            _timer_Tick_CheckStop();
            _timer_Tick_Info();
        }
        private void _timer_Tick_CheckStop()
        {
            if (timer_Tick_showInfo == 0
                && timer_Tick_showWarning == 0
                && timer_Tick_showError == 0)
            {
                timer.Stop();
            }
        }
        private void _timer_Tick_Info()
        {
            if (timer_Tick_showInfo > 0)
            {
                int sw = timer_Tick_showInfo % 2;
                if (sw == 0)
                {
                    Brush br = new SolidColorBrush(Colors.Green);
                    textbox_status.Background = br;
                }
                else
                {
                    Brush br = new SolidColorBrush(Colors.White);
                    textbox_status.Background = br;
                }
                timer_Tick_showInfo--;
            }
            if (timer_Tick_showWarning > 0)
            {
                int sw = timer_Tick_showWarning % 2;
                if (sw == 0)
                {
                    Brush br = new SolidColorBrush(Colors.Orange);
                    textbox_status.Background = br;
                }
                else
                {
                    Brush br = new SolidColorBrush(Colors.White);
                    textbox_status.Background = br;
                }
                timer_Tick_showWarning--;
            }
            if (timer_Tick_showError > 0)
            {
                int sw = timer_Tick_showError % 2;
                if (sw == 0)
                {
                    Brush br = new SolidColorBrush(Colors.Red);
                    textbox_status.Background = br;
                }
                else
                {
                    Brush br = new SolidColorBrush(Colors.White);
                    textbox_status.Background = br;
                }
                timer_Tick_showError--;
            }
        }

        DispatcherTimer timer;
        private void _ShowInfo(string msg)
        {
            textbox_status.Text = msg;
            timer.Start();
            timer_Tick_showInfo = 2;
        }
        private void _ShowWarning(string msg)
        {
            textbox_status.Text = msg;
            timer.Start();
            timer_Tick_showWarning = 4;
        }
        private void _ShowError(Exception err)
        {
            textbox_status.Text = err.Message;
            timer.Start();
            timer_Tick_showError = 6;
        }

        #endregion

        private void hyperlinkButton_QRMaker_Click(object sender, RoutedEventArgs e)
        {
            HtmlPage.Window.Navigate(new Uri("Default.aspx", UriKind.Relative));
        }
    }
}
