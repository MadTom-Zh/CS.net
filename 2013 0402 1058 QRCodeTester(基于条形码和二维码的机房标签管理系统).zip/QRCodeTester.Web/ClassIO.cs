﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.IO;
using System.Data;
using System.Data.SQLite;

namespace QRCodeTester.Web
{
    public class ClassIO
    {
        public static string PhysicsPath_AppData
        {
            get
            {
                string dir = AppDomain.CurrentDomain.BaseDirectory + "\\AppData";
                dir = dir.Replace("\\\\", "\\");
                if (Directory.Exists(dir) == false)
                {
                    Directory.CreateDirectory(dir);
                }
                return dir;
            }
        }
        public static string PhysicsPath_AppData_tmpQRUpload
        {
            get
            {
                string dir = PhysicsPath_AppData + "\\tmpQRUpload";
                dir = dir.Replace("\\\\", "\\");
                if (Directory.Exists(dir) == false)
                {
                    Directory.CreateDirectory(dir);
                }
                return dir;
            }
        }        
        public static string PhysicsFile_AppData_statisticsDB3
        {
            get
            {
                return ClassIO.PhysicsPath_AppData + "\\STATISTICS.db3";
            }
        }


        public enum LogContentLevel
        {
            Info = 0,
            Warning = 1,
            Error = 2,
            None = 3,
        }
        public static void Log(string msg, LogContentLevel level)
        {
            DateTime now = DateTime.Now;
            string fileName = now.ToString("yyyy-MM-dd HH") + ".txt";
            string ioContent = now.ToString("yyyy-MM-dd HH:mm:ss.fff ");
            switch (level)
            {
                case LogContentLevel.Info:
                    ioContent += "Info:";
                    break;
                case LogContentLevel.Warning:
                    ioContent += "Warning:";
                    break;
                case LogContentLevel.Error:
                    ioContent += "Error:";
                    break;
                default:
                    ioContent += ":";
                    break;
            }
            ioContent += msg;
            string dir = PhysicsPath_AppData + "\\Log";
            if (Directory.Exists(dir) == false)
            {
                Directory.CreateDirectory(dir);
            }
            File.AppendAllText(dir+"\\"+fileName, Environment.NewLine + ioContent);
        }
        public static void Log(string info)
        {
            Log(info, LogContentLevel.Info);
        }
        public static void Log(Exception err)
        {
            Log(err.ToString(), LogContentLevel.Error);
        }
    }

}