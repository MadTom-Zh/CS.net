﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;

namespace QRCodeTester.Web.Services
{
    [ServiceContract(Namespace = "")]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class ServiceAllInOne
    {
        [OperationContract]
        public QRImageResponseData QREncode(string request)
        {
            return ClassQRHelper.MakeQRImage(request);
        }

        [OperationContract]
        public QRImageUploadResult QRImageUpload(QRImageUploadRequestData dataPack)
        {
            return ClassQRHelper.QRImageUpload(dataPack);
        }

        [OperationContract]
        public QRImageDecodeResult QRDecode(QRImageDecodeRequestData dataPack)
        {
            return ClassQRHelper.QRDecode(dataPack);
        }
    }

    [DataContract]
    public class QRImageResponseData
    {
        bool _IsErrorImage;
        Guid _id;
        byte[] _QRImag_Compressede;
        DateTime _CreateTime;

        [DataMember]
        public bool IsErrorImage
        {
            get { return _IsErrorImage; }
            set { _IsErrorImage = value; }
        }
        [DataMember]
        public Guid id
        {
            get { return _id; }
            set { _id = value; }
        }
        [DataMember]
        public byte[] QRImage_Compressed
        {
            get { return _QRImag_Compressede; }
            set { _QRImag_Compressede = value; }
        }
        [DataMember]
        public DateTime CreateTime
        {
            get { return _CreateTime; }
            set { _CreateTime = value; }
        }
    }

    [DataContract]
    public class QRImageUploadRequestData
    {
        long _FileOA;
        byte[] _Bytes;
        int _RetryCount;
        bool _IsLastPackage;

        [DataMember]
        public long FileOA
        {
            set { _FileOA = value; }
            get { return _FileOA; }
        }
        [DataMember]
        public byte[] Bytes
        {
            set { _Bytes = value; }
            get { return _Bytes; }
        }
        [DataMember]
        public int RetryCount
        {
            set { _RetryCount = value; }
            get { return _RetryCount; }
        }
        [DataMember]
        public bool IsLastPackage
        {
            set { _IsLastPackage = value; }
            get { return _IsLastPackage; }
        }
    }

    [DataContract]
    public class QRImageUploadResult
    {
        bool _IsCurrentComplete;
        bool _IsFinalComplete;
        Guid _CompleteDecodeRecID;

        [DataMember]
        public bool IsCurrentComplete
        {
            set { _IsCurrentComplete = value; }
            get { return _IsCurrentComplete; }
        }
        [DataMember]
        public bool IsFinalComplete
        {
            set { _IsFinalComplete = value; }
            get { return _IsFinalComplete; }
        }
        [DataMember]
        public Guid CompleteDecodeRecID
        {
            set { _CompleteDecodeRecID = value; }
            get { return _CompleteDecodeRecID; }
        }
    }

    [DataContract]
    public class QRImageDecodeRequestData
    {
        bool _IsPicInTableRECORDS;
        Guid _PicId;

        [DataMember]
        public bool IsPicInTableRECORDS
        {
            set { _IsPicInTableRECORDS = value; }
            get { return _IsPicInTableRECORDS; }
        }
        [DataMember]
        public Guid PicId
        {
            set { _PicId = value; }
            get { return _PicId; }
        }
    }

    [DataContract]
    public class QRImageDecodeResult
    {
        bool _DecodeSeccess;
        string _DecodeFailMsg;
        string _DecodedString;

        [DataMember]
        public bool DecodeSeccess
        {
            set { _DecodeSeccess = value; }
            get { return _DecodeSeccess; }
        }
        [DataMember]
        public string DecodeFailMsg
        {
            set { _DecodeFailMsg = value; }
            get { return _DecodeFailMsg; }
        }
        [DataMember]
        public string DecodedString
        {
            set { _DecodedString = value; }
            get { return _DecodedString; }
        }
    }
}
