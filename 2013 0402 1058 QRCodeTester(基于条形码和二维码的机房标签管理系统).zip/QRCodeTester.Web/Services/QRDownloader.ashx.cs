﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using CodeSharing.Entities;

namespace QRCodeTester.Web.Services
{
    /// <summary>
    /// QRDownloader 的摘要说明
    /// </summary>
    public class QRDownloader : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            //string id = context.Request.QueryString["ID"];

            //string requestIO = context.Request.QueryString["REQ"];


            //QREncodeResponseData result = null;
            //context.Response.ContentType = "application/octet-stream";
            //if (id != null)
            //{
            //    //context.Response.AddHeader("Content-Disposition", "attachment;  filename=" +
            //    //    HttpUtility.UrlEncode(fileName, System.Text.Encoding.UTF8));
            //    context.Response.AddHeader("Content-Disposition", "attachment;  filename="
            //        + HttpUtility.UrlEncode(id, System.Text.Encoding.UTF8));

            //    Guid guid = Guid.Parse(id);
            //    result = ClassQRHelper.GetQRImage(guid);
            //}
            //else if (requestIO != null)
            //{
            //    DataProcessing.QREncodeRequest QRER = new DataProcessing.QREncodeRequest(requestIO);
            //    context.Response.AddHeader("Content-Disposition", "attachment;  filename=" + HttpUtility.UrlEncode(QRER.text
            //        + "_" + QRER.coding
            //        + "_clv" + QRER.clevel
            //        + "_ver" + QRER.version
            //        + "_scl" + QRER.scale,
            //        System.Text.Encoding.UTF8));
            //    DataProcessing.QREncodeRequest.Params.Coding coding = DataProcessing.QREncodeRequest.Params.Coding
            //    result = ClassQRHelper.GetQRImage(DataProcessing.QREncodeRequest.Params.Coding QRER.coding,
            //        int.Parse(QRER.clevel),
            //        int.Parse(QRER.version),
            //        int.Parse(QRER.scale), QRER.text);
            //}
            //else
            //{
            //    context.Response.StatusCode = 404;
            //}

            //context.Response.Close();
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}