﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using CodeSharing.Entities;
using System.Drawing;
using System.Drawing.Drawing2D;
//using System.Drawing.Text;
using ThoughtWorks.QRCode.Codec;
using ThoughtWorks.QRCode.Codec.Data;
using System.IO;
using System.Data;
using System.Data.SQLite;

namespace QRCodeTester.Web
{
    public class ClassQRHelper
    {
        public static Services.QRImageResponseData MakeQRImage(string requestIOContent)
        {
            Services.QRImageResponseData result
                = new Services.QRImageResponseData();
            DataProcessing.QREncodeRequest QRER = new DataProcessing.QREncodeRequest(requestIOContent);

            Exception err = CheckAndSetParams(QRER.coding, QRER.clevel, QRER.version, QRER.scale, QRER.text);

            Bitmap imgBitMap = null;
            byte[] imgBytes = new byte[0];
            if (err != null)
            {
                result.IsErrorImage = true;
                result.QRImage_Compressed = DataProcessing.Compressor.Compress(MakeQRImage_ReturnErrorImage(err));
                return result;
            }

            SQLiteConnectionStringBuilder connStrBuilder = new SQLiteConnectionStringBuilder();
            connStrBuilder.DataSource = ClassIO.PhysicsFile_AppData_statisticsDB3;

            using (SQLiteConnection conn = new SQLiteConnection(connStrBuilder.ConnectionString))
            {
                conn.Open();

                string selectSql
                    = "SELECT * FROM RECORDS " +
                            "WHERE ENCODE='" + qrCodingMode.ToString() + "' " +
                            "AND CLEVEL='" + qrCorrectLevel.ToString() + "' " +
                            "AND VERSION='" + qrVersion.ToString() + "' " +
                            "AND SCALE='" + qrScale.ToString() + "' " +
                            "AND TEXT='" + qrText + "' " +
                            "LIMIT 1";
                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(selectSql, conn))
                {
                    DataSet ds = new DataSet();

                    SQLiteCommandBuilder commandBuilder = new SQLiteCommandBuilder(adapter);
                    adapter.InsertCommand = commandBuilder.GetInsertCommand();
                    //adapter.DeleteCommand = commandBuilder.GetDeleteCommand();
                    adapter.UpdateCommand = commandBuilder.GetUpdateCommand();

                    adapter.Fill(ds, "RECORDS");
                    DataTable dt = ds.Tables["RECORDS"];
                    if (dt.Rows.Count > 0 && System.DBNull.Value != dt.Rows[0]["QRIMAGE"])
                    {
                        // 在数据库中找到QR图码
                        imgBytes = (byte[])(dt.Rows[0]["QRIMAGE"]);
                        result.IsErrorImage = false;
                        result.id = (Guid)dt.Rows[0]["ID"];
                        result.QRImage_Compressed = DataProcessing.Compressor.Compress(imgBytes);
                        result.CreateTime = (DateTime)(dt.Rows[0]["CREATE_TIME"]);
                    }
                    else
                    {
                        QRCodeEncoder encoder = new QRCodeEncoder();
                        encoder.QRCodeEncodeMode = qrCodingMode;
                        encoder.QRCodeErrorCorrect = qrCorrectLevel;
                        encoder.QRCodeVersion = qrVersion;
                        encoder.QRCodeScale = qrScale;
                        try
                        {
                            imgBitMap = encoder.Encode(qrText, System.Text.Encoding.UTF8);
                        }
                        catch (Exception err1)
                        {
                            ClassIO.Log(new Exception("不能编码文本[" + qrText + "]，"
                                + "在编码模式[" + qrCodingMode + "]纠错率[" + qrCorrectLevel + "]"
                                + "版本[" + qrVersion + "]缩放[" + qrScale + "]条件下！", err1));
                            imgBitMap = null;
                        }
                        imgBytes = BitMap2Bytes(imgBitMap);


                        if (dt.Rows.Count < 1)
                        {
                            // insert
                            DataRow newRow = dt.NewRow();
                            newRow["ID"] = Guid.NewGuid();
                            newRow["ENCODE"] = qrCodingMode;
                            newRow["CLEVEL"] = qrCorrectLevel;
                            newRow["VERSION"] = qrVersion;
                            newRow["SCALE"] = qrScale;
                            newRow["TEXT"] = qrText;
                            newRow["QRIMAGE"] = imgBytes;
                            newRow["CREATE_TIME"] = DateTime.Now;

                            ds.Tables["RECORDS"].Rows.Add(newRow);
                        }
                        else
                        {
                            // update
                            DataRow tarRow = dt.Rows[0];
                            tarRow["QRIMAGE"] = imgBytes;
                            tarRow["CREATE_TIME"] = DateTime.Now;
                        }
                        result.IsErrorImage = false;
                        result.id = (Guid)dt.Rows[0]["ID"];
                        result.QRImage_Compressed = DataProcessing.Compressor.Compress(imgBytes);
                        result.CreateTime = (DateTime)(dt.Rows[0]["CREATE_TIME"]);

                        adapter.Update(ds, "RECORDS");
                        ds.AcceptChanges();
                    }
                }
                conn.Close();
            }
            return result;
        }
        private static byte[] MakeQRImage_ReturnErrorImage(Exception err)
        {
            // make error image
            Bitmap imgBitMap = new Bitmap(500, 200);
            try
            {
                //Image myImage = System.Drawing.Image.FromFile(str);
                //Bitmap map = new Bitmap(myImage);
                //myImage.Dispose();
                Graphics graphics = Graphics.FromImage(imgBitMap);
                graphics.InterpolationMode = InterpolationMode.HighQualityBilinear;
                SolidBrush brush = new SolidBrush(Color.LightPink);
                PointF P = new PointF(14, 14);
                Font font = new Font("宋体", 11, FontStyle.Bold);
                graphics.DrawString(err.ToString(), font, brush, P);
                //map.Save(str.Substring(0, str.LastIndexOf("\\") + 1) + "new" + str.Substring(str.LastIndexOf("\\") + 1, str.LastIndexOf(".") - str.LastIndexOf("\\") - 1) + str.Substring(str.LastIndexOf("."), str.Length - str.LastIndexOf(".")), ImageFormat.Jpeg);
                //MessageBox.Show("写入成功");
                font.Dispose();
                graphics.Dispose();
            }
            catch (Exception err1)
            {
                ClassIO.Log(err1);
            }

            return BitMap2Bytes(imgBitMap);
        }

        public static Services.QRImageResponseData GetQRImage(QRCodeEncoder.ENCODE_MODE codeMode, int cLevel, int version, int scale, string text)
        {
            Services.QRImageResponseData result
                = new Services.QRImageResponseData();
            SQLiteConnectionStringBuilder connStrBuilder = new SQLiteConnectionStringBuilder();
            connStrBuilder.DataSource = ClassIO.PhysicsFile_AppData_statisticsDB3;
            using (SQLiteConnection conn = new SQLiteConnection(connStrBuilder.ConnectionString))
            {
                conn.Open();

                string selectSql
                    = "SELECT * FROM RECORDS " +
                            "WHERE ENCODE='" + codeMode.ToString() + "' " +
                            "AND CLEVEL='" + cLevel + "' " +
                            "AND VERSION='" + version + "' " +
                            "AND SCALE='" + scale + "' " +
                            "AND TEXT='" + text + "' " +
                            "LIMIT 1";
                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(selectSql, conn))
                {
                    DataSet ds = new DataSet();

                    SQLiteCommandBuilder commandBuilder = new SQLiteCommandBuilder(adapter);
                    adapter.InsertCommand = commandBuilder.GetInsertCommand();
                    //adapter.DeleteCommand = commandBuilder.GetDeleteCommand();
                    adapter.UpdateCommand = commandBuilder.GetUpdateCommand();

                    adapter.Fill(ds, "RECORDS");
                    DataTable dt = ds.Tables["RECORDS"];
                    if (dt.Rows.Count > 0 && System.DBNull.Value != dt.Rows[0]["QRIMAGE"])
                    {
                        // 在数据库中找到QR图码
                        byte[] imgBytes = (byte[])(dt.Rows[0]["QRIMAGE"]);
                        result.QRImage_Compressed = DataProcessing.Compressor.Compress(imgBytes);
                        result.CreateTime = (DateTime)(dt.Rows[0]["CREATE_TIME"]);
                    }
                    else
                    {
                        ClassIO.Log("No QRImage found with codeMode[" + codeMode.ToString() + "], "
                            + "cLevel[" + cLevel + "], version[" + version + "], "
                            + "scale[" + scale + "] and text[" + text + "].",
                            ClassIO.LogContentLevel.Warning);
                    }
                }
                conn.Close();
            }
            return result;
        }
        public static Services.QRImageResponseData GetQRImage(Guid id)
        {
            Services.QRImageResponseData result
                = new Services.QRImageResponseData();
            SQLiteConnectionStringBuilder connStrBuilder = new SQLiteConnectionStringBuilder();
            connStrBuilder.DataSource = ClassIO.PhysicsFile_AppData_statisticsDB3;
            using (SQLiteConnection conn = new SQLiteConnection(connStrBuilder.ConnectionString))
            {
                conn.Open();

                string selectSql
                    = "SELECT * FROM RECORDS " +
                            "WHERE ID='" + id + "' " +
                            "LIMIT 1";
                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(selectSql, conn))
                {
                    DataSet ds = new DataSet();

                    SQLiteCommandBuilder commandBuilder = new SQLiteCommandBuilder(adapter);
                    adapter.InsertCommand = commandBuilder.GetInsertCommand();
                    //adapter.DeleteCommand = commandBuilder.GetDeleteCommand();
                    adapter.UpdateCommand = commandBuilder.GetUpdateCommand();

                    adapter.Fill(ds, "RECORDS");
                    DataTable dt = ds.Tables["RECORDS"];
                    if (dt.Rows.Count > 0 && System.DBNull.Value != dt.Rows[0]["QRIMAGE"])
                    {
                        // 在数据库中找到QR图码
                        byte[] imgBytes = (byte[])(dt.Rows[0]["QRIMAGE"]);
                        result.QRImage_Compressed = DataProcessing.Compressor.Compress(imgBytes);
                        result.CreateTime = (DateTime)(dt.Rows[0]["CREATE_TIME"]);
                    }
                    else
                    {
                        ClassIO.Log("No QRImage found with id[" + id + "]", ClassIO.LogContentLevel.Warning);
                    }
                }
                conn.Close();
            }
            return result;
        }

        public static Services.QRImageUploadResult QRImageUpload(Services.QRImageUploadRequestData dataPack)
        {
            if (dataPack.RetryCount > 2)
            {
                Exception err = new Exception("Image Upload Faild, FileName[" + dataPack.FileOA + "], RetryCount > 2.");
                ClassIO.Log(err);
                throw err;
            }
            Services.QRImageUploadResult result
                = new Services.QRImageUploadResult();
            string fileFullName;
            try
            {
                fileFullName = ClassIO.PhysicsPath_AppData_tmpQRUpload + "\\" + dataPack.FileOA + ".jpg.tmp";
                FileStream fs = new FileStream(fileFullName, FileMode.Append, FileAccess.Write);
                //byte[] orgBytes = DataProcessing.Compressor.DeCompress(dataPack.Bytes);
                byte[] orgBytes = dataPack.Bytes;
                fs.Position = fs.Length;
                fs.Write(orgBytes, 0, orgBytes.Length);
                fs.Flush();
                fs.Close();
                if (dataPack.IsLastPackage == false)
                {
                    result.IsCurrentComplete = true;
                    result.IsFinalComplete = false;
                    return result;
                }
            }
            catch (Exception err)
            {
                ClassIO.Log(err);
                result.IsCurrentComplete = false;
                result.IsFinalComplete = false;
                return result;
            }
            if (dataPack.IsLastPackage == true)
            {
                string okFileFullName
                    = ClassIO.PhysicsPath_AppData_tmpQRUpload + "\\" + dataPack.FileOA + ".jpg";
                File.Move(fileFullName, okFileFullName);

                SQLiteConnectionStringBuilder connStrBuilder = new SQLiteConnectionStringBuilder();
                connStrBuilder.DataSource = ClassIO.PhysicsFile_AppData_statisticsDB3;
                using (SQLiteConnection conn = new SQLiteConnection(connStrBuilder.ConnectionString))
                {
                    conn.Open();

                    string selectSql
                        = "SELECT * FROM RECORDS_DECODE WHERE 1=0";
                    using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(selectSql, conn))
                    {
                        DataSet ds = new DataSet();

                        SQLiteCommandBuilder commandBuilder = new SQLiteCommandBuilder(adapter);
                        adapter.InsertCommand = commandBuilder.GetInsertCommand();
                        //adapter.DeleteCommand = commandBuilder.GetDeleteCommand();
                        //adapter.UpdateCommand = commandBuilder.GetUpdateCommand();

                        adapter.Fill(ds, "RECORDS_DECODE");
                        DataTable dt = ds.Tables["RECORDS_DECODE"];

                        string decodedString = null;
                        byte[] imgBytes = null;
                        FileStream imgFileStream = new FileStream(okFileFullName, FileMode.Open);
                        try
                        {
                            QRCodeDecoder decoder = new QRCodeDecoder();
                            Bitmap bitmap = new Bitmap(imgFileStream);
                            imgBytes = BitMap2Bytes(bitmap);
                            decodedString = decoder.decode(new QRCodeBitmapImage(bitmap));
                        }
                        catch (Exception err)
                        {
                            ClassIO.Log(err);
                        }
                        finally
                        {
                            imgFileStream.Close();
                            imgFileStream.Dispose();
                        }

                        // insert
                        result.CompleteDecodeRecID = Guid.NewGuid();
                        result.IsCurrentComplete = true;
                        result.IsFinalComplete = true;

                        DataRow newRow = dt.NewRow();
                        newRow["ID"] = result.CompleteDecodeRecID;
                        newRow["QRIMAGE_TMP"] = imgBytes;

                        newRow["TEXT"] = decodedString;
                        newRow["CREATE_TIME"] = DateTime.Now;
                        ds.Tables["RECORDS_DECODE"].Rows.Add(newRow);

                        adapter.Update(ds, "RECORDS_DECODE");
                        ds.AcceptChanges();
                    }
                    conn.Close();
                }
            }
            return result;
        }

        public static Services.QRImageDecodeResult QRDecode(Services.QRImageDecodeRequestData dataPack)
        {
            Services.QRImageDecodeResult result
                = new Services.QRImageDecodeResult();
            SQLiteConnectionStringBuilder connStrBuilder = new SQLiteConnectionStringBuilder();
            connStrBuilder.DataSource = ClassIO.PhysicsFile_AppData_statisticsDB3;

            using (SQLiteConnection conn = new SQLiteConnection(connStrBuilder.ConnectionString))
            {
                conn.Open();

                string selectSql;
                if (dataPack.IsPicInTableRECORDS == true)
                {
                    selectSql = "SELECT ID, QRIMAGE, TEXT FROM RECORDS " +
                        "WHERE ID=X'" + _SQLGetGuidStr(dataPack.PicId) + "' " +
                        "LIMIT 1";
                }
                else
                {
                    selectSql = "SELECT ID, REC_ID, QRIMAGE_TMP, TEXT FROM RECORDS_DECODE " +
                        "WHERE ID=X'" + _SQLGetGuidStr(dataPack.PicId) + "' " +
                        "LIMIT 1";
                }


                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(selectSql, conn))
                {
                    DataSet ds = new DataSet();
                    DataTable dt;
                    DataRow dr;
                    if (dataPack.IsPicInTableRECORDS == true)
                    {
                        adapter.Fill(ds, "RECORDS");
                        dt = ds.Tables["RECORDS"];
                    }
                    else
                    {
                        SQLiteCommandBuilder commandBuilder = new SQLiteCommandBuilder(adapter);
                        //adapter.InsertCommand = commandBuilder.GetInsertCommand();
                        //adapter.DeleteCommand = commandBuilder.GetDeleteCommand();
                        adapter.UpdateCommand = commandBuilder.GetUpdateCommand();

                        adapter.Fill(ds, "RECORDS_DECODE");
                        dt = ds.Tables["RECORDS_DECODE"];
                    }

                    if (dataPack.IsPicInTableRECORDS == true)
                    {
                        #region 从 RECORDS 表中 获取图片并尝试解码
                        if (dt.Rows.Count > 0 && System.DBNull.Value != dt.Rows[0]["QRIMAGE"])
                        {
                            dr = dt.Rows[0];
                            result.DecodedString = _QRDecode_PicInRECORD(conn, (Guid)dt.Rows[0]["ID"], dr);
                            if (result.DecodedString == null)
                            {
                                result.DecodeSeccess = false;
                                result.DecodeFailMsg = "Decode Failed, check log file for more details!";
                            }
                            else
                            {
                                result.DecodeSeccess = true;
                            }
                        }
                        else
                        {
                            Exception newExcep = new Exception("No Record Found in Table[RECORDS], with ID[" + dataPack.PicId + "]");
                            ClassIO.Log(newExcep);
                            throw newExcep;
                        }
                        #endregion
                    }
                    else
                    {
                        #region 从表 RECORDS_DECODE 中尝试编码
                        if (dt.Rows.Count > 0 && System.DBNull.Value != dt.Rows[0]["QRIMAGE_TMP"])
                        {
                            result.DecodedString = _QRDecode_QRWork((byte[])dt.Rows[0]["QRIMAGE_TMP"]);
                            if (result.DecodedString == null)
                            {
                                result.DecodeSeccess = false;
                                result.DecodeFailMsg = "Decode Failed, check log file for more details!";
                            }
                            else
                            {
                                result.DecodeSeccess = true;
                                dt.Rows[0]["TEXT"] = result.DecodedString;
                                adapter.Update(ds, "RECORDS");
                                ds.AcceptChanges();
                            }
                        }
                        else
                        {
                            Exception newExcep = new Exception("No Record Found in Table[RECORDS_DECODE], with ID[" + dataPack.PicId + "]");
                            ClassIO.Log(newExcep);
                            throw newExcep;
                        }
                        #endregion
                    }
                }
                conn.Close();
            }
            return result;
        }
        private static string _QRDecode_PicInRECORD(SQLiteConnection conn, Guid rec_id, DataRow recDataRow)
        {
            string result = null;
            string selectSql_decode = "SELECT ID, REC_ID, QRIMAGE_TMP, TEXT, CREATE_TIME FROM RECORDS_DECODE " +
                "WHERE REC_ID=X'" + _SQLGetGuidStr((Guid)recDataRow["ID"]) + "'";
            using (SQLiteDataAdapter adapter_decode = new SQLiteDataAdapter(selectSql_decode, conn))
            {
                SQLiteCommandBuilder commandBuilder = new SQLiteCommandBuilder(adapter_decode);
                adapter_decode.InsertCommand = commandBuilder.GetInsertCommand();

                DataSet ds_de = new DataSet();
                adapter_decode.Fill(ds_de, "RECORDS_DECODE");
                DataTable dt_de = ds_de.Tables["RECORDS_DECODE"];

                DataRow dr_de;
                if (dt_de.Rows.Count > 0)
                {
                    dr_de = dt_de.Rows[0];
                    result = (string)dr_de["TEXT"];

                }
                else
                {
                    DataRow newRow = dt_de.NewRow();
                    newRow["ID"] = Guid.NewGuid();
                    newRow["REC_ID"] = rec_id;
                    newRow["CREATE_TIME"] = DateTime.Now;
                    result = _QRDecode_QRWork((byte[])recDataRow["QRIMAGE"]);
                    newRow["TEXT"] = result;
                    dt_de.Rows.Add(newRow);
                    adapter_decode.Update(ds_de, "RECORDS_DECODE");
                    ds_de.AcceptChanges();
                }

            }
            return result;
        }
        private static string _QRDecode_QRWork(byte[] picData)
        {
            string result = null;
            try
            {
                QRCodeDecoder decoder = new QRCodeDecoder();
                using (MemoryStream ms = new MemoryStream(picData))
                {
                    result = decoder.decode(new QRCodeBitmapImage(new Bitmap(ms)), System.Text.Encoding.UTF8);
                }
            }
            catch (Exception er)
            {
                ClassIO.Log(er);
            }
            return result;
        }

        private static string _SQLGetGuidStr(Guid id)
        {
            return BitConverter.ToString(id.ToByteArray()).Replace("-", string.Empty);
        }

        private static byte[] BitMap2Bytes(Bitmap source)
        {
            if (source == null)
            {
                return null;
            }
            MemoryStream ms = null;
            byte[] result = null;
            try
            {
                ms = new MemoryStream();
                source.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                result = new Byte[ms.Length];
                result = ms.ToArray();
            }
            catch (ArgumentNullException ex)
            {
                ClassIO.Log(ex);
            }
            finally
            {
                ms.Close();
            }
            return result;
        }
        private static Bitmap Bytes2BitMap(byte[] source)
        {
            Bitmap result;
            using (MemoryStream ms = new MemoryStream(source))
            {
                result = new Bitmap(ms);
            }
            return result;
        }

        private static QRCodeEncoder.ENCODE_MODE qrCodingMode;
        private static QRCodeEncoder.ERROR_CORRECTION qrCorrectLevel;
        private static int qrVersion;
        private static int qrScale;
        private static string qrText;
        private static Exception CheckAndSetParams(string coding, string cLevel, string version, string scale, string text)
        {
            if (coding.ToUpper() == QRCodeEncoder.ENCODE_MODE.BYTE.ToString().ToUpper())
            {
                qrCodingMode = QRCodeEncoder.ENCODE_MODE.BYTE;
            }
            else if (coding.ToUpper() == QRCodeEncoder.ENCODE_MODE.ALPHA_NUMERIC.ToString().ToUpper())
            {
                qrCodingMode = QRCodeEncoder.ENCODE_MODE.ALPHA_NUMERIC;
            }
            else if (coding.ToUpper() == QRCodeEncoder.ENCODE_MODE.NUMERIC.ToString().ToUpper())
            {
                qrCodingMode = QRCodeEncoder.ENCODE_MODE.NUMERIC;
            }
            else return new Exception("Invalid encode mode!");

            if (cLevel == QRCodeEncoder.ERROR_CORRECTION.H.ToString())
            {
                qrCorrectLevel = QRCodeEncoder.ERROR_CORRECTION.H;
            }
            else if (cLevel == QRCodeEncoder.ERROR_CORRECTION.L.ToString())
            {
                qrCorrectLevel = QRCodeEncoder.ERROR_CORRECTION.L;
            }
            else if (cLevel == QRCodeEncoder.ERROR_CORRECTION.M.ToString())
            {
                qrCorrectLevel = QRCodeEncoder.ERROR_CORRECTION.M;
            }
            else if (cLevel == QRCodeEncoder.ERROR_CORRECTION.Q.ToString())
            {
                qrCorrectLevel = QRCodeEncoder.ERROR_CORRECTION.Q;
            }
            else return new Exception("Invalid ErrorCorrect Level!");

            try
            {
                qrVersion = Int16.Parse(version);
            }
            catch (Exception er)
            {
                return new Exception("Invalid Version!", er);
            }

            try
            {
                qrScale = Int16.Parse(scale);
            }
            catch (Exception er)
            {
                return new Exception("Invalid Scale!", er);
            }

            qrText = text;
            if (qrText == null || qrText.Trim().Length == 0)
            {
                return new Exception("Invalid Text!");
            }

            return null;
        }

    }
}