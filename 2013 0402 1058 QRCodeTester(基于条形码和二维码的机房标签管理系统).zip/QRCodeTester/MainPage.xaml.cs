﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using System.Windows.Threading;
using System.Windows.Media.Imaging;
using CodeSharing.Entities;
using System.IO;
using System.Text;
using System.Windows.Browser;

namespace QRCodeTester
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
            timer = new DispatcherTimer();
            timer.Interval = new TimeSpan(0, 0, 0, 0, 100);
            timer.Stop();
            timer.Tick += timer_Tick;

            if (client == null)
            {
                client = new ServiceAllInOne.ServiceAllInOneClient();
                client.QREncodeCompleted += client_QREncodeCompleted;
                client.QRImageUploadCompleted += client_QRImageUploadCompleted;
                client.QRDecodeCompleted += client_QRDecodeCompleted;
            }
            border_encode.Visibility = System.Windows.Visibility.Visible;
            border_qrImage.Visibility = System.Windows.Visibility.Visible;
            border_image.Visibility = System.Windows.Visibility.Visible;
            border_decode.Visibility = System.Windows.Visibility.Visible;
        }

        ServiceAllInOne.ServiceAllInOneClient client;

        #region UI 辅助
        private void gridDecode_Loaded(object sender, RoutedEventArgs e)
        {
            ReSizeUI();
        }
        private void ReSizeUI()
        {
            stackPanel.Height
                = gridEncode.DesiredSize.Height
                + gridQR.DesiredSize.Height
                + gridDecode.DesiredSize.Height
                + 80;
        }

        int timer_Tick_showInfo = 0;
        int timer_Tick_showWarning = 0;
        int timer_Tick_showError = 0;
        void timer_Tick(object sender, EventArgs e)
        {
            _timer_Tick_CheckStop();
            _timer_Tick_Info();
        }
        private void _timer_Tick_CheckStop()
        {
            if (timer_Tick_showInfo == 0
                && timer_Tick_showWarning == 0
                && timer_Tick_showError == 0)
            {
                timer.Stop();
            }
        }
        private void _timer_Tick_Info()
        {
            if (timer_Tick_showInfo > 0)
            {
                int sw = timer_Tick_showInfo % 2;
                if (sw == 0)
                {
                    Brush br = new SolidColorBrush(Colors.Green);
                    textbox_status.Background = br;
                }
                else
                {
                    Brush br = new SolidColorBrush(Colors.White);
                    textbox_status.Background = br;
                }
                timer_Tick_showInfo--;
            }
            if (timer_Tick_showWarning > 0)
            {
                int sw = timer_Tick_showWarning % 2;
                if (sw == 0)
                {
                    Brush br = new SolidColorBrush(Colors.Orange);
                    textbox_status.Background = br;
                }
                else
                {
                    Brush br = new SolidColorBrush(Colors.White);
                    textbox_status.Background = br;
                }
                timer_Tick_showWarning--;
            }
            if (timer_Tick_showError > 0)
            {
                int sw = timer_Tick_showError % 2;
                if (sw == 0)
                {
                    Brush br = new SolidColorBrush(Colors.Red);
                    textbox_status.Background = br;
                }
                else
                {
                    Brush br = new SolidColorBrush(Colors.White);
                    textbox_status.Background = br;
                }
                timer_Tick_showError--;
            }
        }

        DispatcherTimer timer;
        private void _ShowInfo(string msg)
        {
            textbox_status.Text = msg;
            timer.Start();
            timer_Tick_showInfo = 2;
        }
        private void _ShowWarning(string msg)
        {
            textbox_status.Text = msg;
            timer.Start();
            timer_Tick_showWarning = 4;
        }
        private void _ShowError(Exception err)
        {
            textbox_status.Text = err.Message;
            timer.Start();
            timer_Tick_showError = 6;
        }


        private void SetBorder(int idx, bool normal, bool sucOrFld)
        {
            if (idx != 0) SetBorder_Normal(border_encode);
            if (idx != 1) SetBorder_Normal(border_qrImage);
            if (idx != 2) SetBorder_Normal(border_decode);
            if (idx != 4) SetBorder_Gray(border_decode);

            Border target;
            if (idx == 3)
            {
                target = border_image;
            }
            else
            {
                target = ((idx == 0) ? border_encode : ((idx == 1) ? border_qrImage : border_decode));
            }
            if (target == null) return;
            if (normal == true)
            {
                SetBorder_Normal(target);
            }
            else
            {
                if (sucOrFld == true)
                {
                    target.BorderBrush = new SolidColorBrush(Colors.Green);
                }
                else
                {
                    target.BorderBrush = new SolidColorBrush(Colors.Red);
                }
                target.BorderThickness = new Thickness(3);
                if (idx != 3)
                {
                    target.Margin = new Thickness(3);
                }
            }
        }
        private void SetBorder_Normal(Border target)
        {
            if (target == null) return;
            target.BorderBrush = new SolidColorBrush(Colors.Black);
            target.BorderThickness = new Thickness(1);
        }
        private void SetBorder_Normal(int idx)
        {
            if (idx == 0)
                SetBorder_Normal(border_encode);
            else if (idx == 1)
                SetBorder_Normal(border_qrImage);
            else if (idx == 2)
                SetBorder_Normal(border_decode);
            else if (idx == 3)
                SetBorder_Normal(border_image);
        }
        private void SetBorder_Gray(Border target)
        {
            if (target == null) return;
            target.BorderBrush = new SolidColorBrush(Colors.Gray);
            target.BorderThickness = new Thickness(1);
        }

        #endregion

        private void HyperlinkButton_viewQRHistory_Click(object sender, RoutedEventArgs e)
        {
            //HyperlinkButton target = (HyperlinkButton)sender;
            //target.TargetName = "_self";
            //target.NavigateUri
            //    = new Uri("QRCodeHisViewerTestPage.aspx", UriKind.Relative);
            HtmlPage.Window.Navigate(new Uri("QRCodeHisViewerTestPage.aspx", UriKind.Relative));
        }


        #region 编码UI
        private void button_encode_Click(object sender, RoutedEventArgs e)
        {
            #region 检查编码基本信息
            if (comboBox_encoding.SelectedItem.ToString().Contains("【"))
            {
                _ShowInfo("请选择 编码方式 ！");
                SetBorder(0, false, false);
                return;
            }
            else if (comboBox_CLevel.SelectedItem.ToString().Contains("【"))
            {
                _ShowInfo("请选择 容错等级 ！");
                SetBorder(0, false, false);
                return;
            }
            else if (comboBox_version.SelectedItem.ToString().Contains("【"))
            {
                _ShowInfo("请选择 版本等级 ！");
                SetBorder(0, false, false);
                return;
            }
            else if (comboBox_scale.SelectedItem.ToString().Contains("【"))
            {
                _ShowInfo("请选择 图片尺寸 ！ 越大，图片越粗糙 ！");
                SetBorder(0, false, false);
                return;
            }
            else if (textbox_input.Text.Trim().Length <= 0)
            {
                _ShowInfo("请输入明文！");
                SetBorder(0, false, false);
                return;
            }
            #endregion

            #region 变量转换
            string coding = ((ComboBoxItem)comboBox_encoding.SelectedItem).Content.ToString();
            if (coding.Contains("字母数字"))
            {
                coding = "ALPHA_NUMERIC";
            }
            else if (coding.Contains("数字"))
            {
                coding = "NUMERIC";
            }
            else
            {
                coding = "BYTE";
            }
            string clevel = ((ComboBoxItem)comboBox_CLevel.SelectedItem).Content.ToString();
            if (clevel.Contains("中高"))
            {
                clevel = "Q";
            }
            else if (clevel.Contains("中"))
            {
                clevel = "M";
            }
            else if (clevel.Contains("低"))
            {
                clevel = "L";
            }
            else
            {
                clevel = "H";
            }
            #endregion

            //byte[] strBytes = Encoding..GetBytes(textbox_input.Text);
            //Encoding.UTF8
            DataProcessing.QREncodeRequest QRER
                = new DataProcessing.QREncodeRequest(
                    coding,
                    clevel,
                    ((ComboBoxItem)comboBox_version.SelectedItem).Content.ToString(),
                    ((ComboBoxItem)comboBox_scale.SelectedItem).Content.ToString(),
                //Encoding.Unicode.GetString(strBytes, 0, strBytes.Length));
                    textbox_input.Text);

            picLocation = PictureLocation.None;
            SetBorder_Normal(0);
            _ShowInfo("正在尝试编码...");
            client.QREncodeAsync(QRER.IOContent);
        }


        private void comboBox_encoding_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SetBorder_Normal(1);
        }
        private void comboBox_CLevel_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SetBorder_Normal(1);
        }
        private void comboBox_version_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SetBorder_Normal(1);
        }
        private void comboBox_scale_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SetBorder_Normal(1);
        }
        private void textbox_input_TextChanged(object sender, TextChangedEventArgs e)
        {
            SetBorder_Normal(1);
        }


        #endregion

        #region QR UI

        public enum PictureLocation
        {
            None,
            Server,
            Local,
        }
        private PictureLocation picLocation = PictureLocation.None;

        MemoryStream msBitmapImg = null;
        Guid QREncode_idInDB;
        void client_QREncodeCompleted(object sender, ServiceAllInOne.QREncodeCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                if (e.Result != null
                    && e.Result.QRImage_Compressed != null
                    && e.Result.QRImage_Compressed.Length > 0)
                {
                    BitmapImage bitmapImg = new BitmapImage();
                    if (msBitmapImg != null)
                    {
                        msBitmapImg.Close();
                        msBitmapImg.Dispose();
                    }
                    msBitmapImg = new MemoryStream(DataProcessing.Compressor.DeCompress(e.Result.QRImage_Compressed));
                    bitmapImg.SetSource(msBitmapImg);
                    image_QR.Source = bitmapImg;
                    textblock_QRCreateTime.Text = e.Result.CreateTime.ToString("yyyy-MM-dd" + Environment.NewLine + "HH:mm:ss");
                    if (e.Result.IsErrorImage == false)
                    {
                        picLocation = PictureLocation.Server;
                    }
                    QREncode_idInDB = e.Result.id;
                    _ShowInfo("编码成功！！！");
                    SetBorder(1, false, true);
                    SetBorder(3, false, true);
                }
                else
                {
                    image_QR.Source = null;
                    _ShowWarning("空图片，可能编码不成功，请检查日志！！！");
                    SetBorder(1, false, false);
                    SetBorder(3, false, false);
                }
            }
            else
            {
                image_QR.Source = null;
                _ShowError(e.Error);
                SetBorder(1, false, false);
                SetBorder(3, false, false);
            }
        }

        private void button_zoomIn_Click(object sender, RoutedEventArgs e)
        {
            if (gridQR.DesiredSize.Height > gridQR.DesiredSize.Width - 35)
            {
                gridQR.Height = gridQR.DesiredSize.Width - 20;
                return;
            }
            gridQR.Height += 15;
            ReSizeUI();
            _ShowInfo("放大显示");
        }
        private void button_zoomOut_Click(object sender, RoutedEventArgs e)
        {
            if (gridQR.DesiredSize.Height < 190)
            {
                gridQR.Height = 175;
                return;
            }
            gridQR.Height -= 15;
            ReSizeUI();
            _ShowInfo("缩小显示");
        }

        private void button_QRDownload_Click(object sender, RoutedEventArgs e)
        {
            if (msBitmapImg == null)
            {
                _ShowError(new Exception("No Memory of Local Image !"));
                return;
            }
            SaveFileDialog saveFD = new SaveFileDialog()
            {
                DefaultExt = "jpg",
                Filter = "JPEG files (*.jpg)|*.jpg|All files (*.*)|*.*",
                FilterIndex = 1,
            };
            if (saveFD.ShowDialog() == true)
            {
                using (Stream stream = saveFD.OpenFile())
                {
                    Byte[] fileContent = msBitmapImg.ToArray();
                    stream.Write(fileContent, 0, fileContent.Length);
                    stream.Close();
                }
                _ShowInfo("下载完成！！");
            }
        }

        private void button_QRLoad_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFD = new OpenFileDialog()
            {
                Filter = "JPEG files (*.jpg)|*.jpg|All files (*.*)|*.*",
                FilterIndex = 1,
                Multiselect = false
            };
            if (openFD.ShowDialog() == true)
            {
                if (msBitmapImg != null)
                {
                    msBitmapImg.Close();
                    msBitmapImg.Dispose();
                }
                if (_UploadImage_fileStream != null)
                {
                    _UploadImage_fileStream.Close();
                    _UploadImage_fileStream.Dispose();
                }
                _UploadImage_fileStream = openFD.File.OpenRead();
                if (_UploadImage_fileStream.Length > (long)int.MaxValue)
                {
                    _ShowError(new Exception("图片过大，不能上传！！！"));
                    return;
                }


                try
                {
                    byte[] buf = new byte[_UploadImage_fileStream.Length];
                    _UploadImage_fileStream.Position = 0;
                    _UploadImage_fileStream.Read(buf, 0, buf.Length);
                    msBitmapImg = new MemoryStream(buf);
                    BitmapImage bitmapImg = new BitmapImage();
                    bitmapImg.SetSource(msBitmapImg);
                    image_QR.Source = bitmapImg;

                    SetBorder_Gray(border_image);
                    SetBorder_Normal(border_encode);
                    SetBorder_Normal(border_decode);
                    SetBorder_Normal(border_qrImage);

                    button_decode.IsEnabled = false;
                    _UploadImage(bitmapImg);
                }
                catch (Exception err)
                {
                    _ShowError(err);
                    if (msBitmapImg != null)
                    {
                        msBitmapImg.Close();
                        msBitmapImg.Dispose();
                    }
                    image_QR.Source = null;
                    SetBorder(3, false, false);
                    button_QRLoad.IsEnabled = true;
                }


                picLocation = PictureLocation.None;
                button_QRLoad.IsEnabled = false;
            }
        }

        ServiceAllInOne.QRImageUploadRequestData QRIURD = null;
        FileStream _UploadImage_fileStream;
        int _UploadImage_fileReadMaxLength = 512;
        private int _UploadImage_filePosi = 0;
        //byte[] _UploadImage_allBytes;
        Guid uploadedQRImageId;
        private void _UploadImage(BitmapImage bitmapImg)
        {
            QRIURD = new ServiceAllInOne.QRImageUploadRequestData()
            {
                FileOA = DateTime.Now.ToFileTime(),
                RetryCount = 0,
            };

            _UploadImage_filePosi = 0;
            byte[] buf;
            QRIURD.IsLastPackage = (_UploadImage_fileStream.Length <= _UploadImage_fileReadMaxLength);
            if (QRIURD.IsLastPackage == true)
            {
                _UploadImage_filePosi = (int)_UploadImage_fileStream.Length;
            }
            else
            {
                _UploadImage_filePosi = _UploadImage_fileReadMaxLength;
            }
            buf = new byte[_UploadImage_filePosi];
            _UploadImage_fileStream.Position = 0;
            _UploadImage_fileStream.Read(buf, 0, buf.Length);
            //_UploadImage_fileStream.Position = _UploadImage_filePosi;
            //QRIURD.CompressedBytes = DataProcessing.Compressor.Compress(buf);
            QRIURD.Bytes = buf;
            _ShowInfo("正在上载 " + _UploadImage_filePosi + " / " + _UploadImage_fileStream.Length);
            client.QRImageUploadAsync(QRIURD);
        }
        void client_QRImageUploadCompleted(object sender, ServiceAllInOne.QRImageUploadCompletedEventArgs e)
        {
            if (e.Error == null && e.Result.IsCurrentComplete == true)
            {
                if (e.Result.IsFinalComplete == true)
                {
                    if (_UploadImage_fileStream != null)
                    {
                        _UploadImage_fileStream.Close();
                        _UploadImage_fileStream.Dispose();
                    }
                    uploadedQRImageId = e.Result.CompleteDecodeRecID;
                    picLocation = PictureLocation.Local;
                    button_QRLoad.IsEnabled = true;
                    _ShowInfo("图片已成功上载至服务器！！");
                    button_decode.IsEnabled = true;
                    return;
                }
                QRIURD.RetryCount = 0;
                byte[] buf;
                int lastCounts = (int)_UploadImage_fileStream.Length - _UploadImage_filePosi;
                if (lastCounts > _UploadImage_fileReadMaxLength)
                {
                    QRIURD.IsLastPackage = false;
                    buf = new byte[_UploadImage_fileReadMaxLength];
                    _UploadImage_fileStream.Read(buf, 0, buf.Length);
                    _UploadImage_filePosi += _UploadImage_fileReadMaxLength;
                    //QRIURD.CompressedBytes = DataProcessing.Compressor.Compress(buf);
                    QRIURD.Bytes = buf;
                }
                else
                {
                    QRIURD.IsLastPackage = true;
                    buf = new byte[lastCounts];
                    _UploadImage_fileStream.Read(buf, 0, buf.Length);
                    //QRIURD.CompressedBytes = DataProcessing.Compressor.Compress(buf);
                    QRIURD.Bytes = buf;
                }
            }
            else
            {
                if (e.Error != null)
                {
                    _ShowError(e.Error);
                    picLocation = PictureLocation.None;
                    button_decode.IsEnabled = true;
                }
                QRIURD.RetryCount += 1;
            }
            _ShowInfo("正在上载 " + _UploadImage_filePosi + " / " + _UploadImage_fileStream.Length);
            client.QRImageUploadAsync(QRIURD);
        }

        #endregion

        #region 解码 UI

        private void button_decode_Click(object sender, RoutedEventArgs e)
        {
            ServiceAllInOne.QRImageDecodeRequestData QRIDRD
                = new ServiceAllInOne.QRImageDecodeRequestData();
            switch (picLocation)
            {
                case PictureLocation.Server:
                    QRIDRD.IsPicInTableRECORDS = true;
                    QRIDRD.PicId = QREncode_idInDB;
                    client.QRDecodeAsync(QRIDRD);
                    break;
                case PictureLocation.Local:
                    QRIDRD.IsPicInTableRECORDS = false;
                    QRIDRD.PicId = uploadedQRImageId;
                    client.QRDecodeAsync(QRIDRD);
                    break;
                default:
                    textbox_output.Text = "";
                    _ShowWarning("无图片！");
                    break;
            }
        }
        void client_QRDecodeCompleted(object sender, ServiceAllInOne.QRDecodeCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                if (e.Result.DecodeSeccess == true)
                {
                    textbox_output.Text = e.Result.DecodedString;
                    _ShowInfo("解码成功");
                    SetBorder(2, false, true);
                }
                else
                {
                    textbox_output.Text = "";
                    _ShowWarning("解码失败，原因是 " + e.Result.DecodeFailMsg);
                    SetBorder(2, false, false);
                }

            }
            else
            {
                textbox_output.Text = "";
                _ShowError(e.Error);
                SetBorder(2, false, false);
            }
        }

        #endregion

    }
}
