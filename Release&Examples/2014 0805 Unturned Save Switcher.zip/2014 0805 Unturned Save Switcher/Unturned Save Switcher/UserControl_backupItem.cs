﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Unturned_Save_Switcher
{
    public partial class UserControl_backupItem : UserControl
    {
        public UserControl_backupItem()
        {
            InitializeComponent();
        }

        private string _id;
        public string id
        {
            set
            {
                _id = value;
                label_dateTime.Text
                    = DateTime.FromFileTimeUtc(long.Parse(_id)).ToString("yyyy-MM-dd HH:mm");
            }
            get
            {
                return _id;
            }
        }
        public Color idClr
        {
            set
            {
                pictureBox_idClr.BackColor = value;
            }
            get
            {
                return pictureBox_idClr.BackColor;
            }
        }
        public string remarks
        {
            set
            {
                textBox_remarks.Text = value;
            }
            get
            {
                return textBox_remarks.Text;
            }
        }

        public bool isSelected
        {
            set
            {
                if (value == true)
                {
                    this.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
                }
                else this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;

            }
            get
            {
                if (this.BorderStyle == System.Windows.Forms.BorderStyle.Fixed3D)
                {
                    return true;
                }
                else return false;
            }
        }

        public event EventHandler Selected;
        public event EventHandler ChangeIdClr;
        public event EventHandler RemarksChanged;

        private void UserControl_backupItem_Select_Click(object sender, EventArgs e)
        {
            if (Selected != null)
            {
                Selected(this, e);
            }
        }

        private void pictureBox_idClr_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                if (ChangeIdClr != null)
                {
                    ChangeIdClr(this, new EventArgs());
                }
            }
        }

        private string remarksTmp;
        private void textBox_remarks_Enter(object sender, EventArgs e)
        {
            remarksTmp = textBox_remarks.Text;
            textBox_remarks.ReadOnly = false;
            textBox_remarks.Focus();
        }

        private void textBox_remarks_Leave(object sender, EventArgs e)
        {
            textBox_remarks.Text = remarksTmp;
            textBox_remarks.ReadOnly = true;
        }
        private void textBox_remarks_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                remarksTmp = textBox_remarks.Text;
                textBox_remarks.ReadOnly = true;
                CallRemarksChanged();
            }
        }
        private void CallRemarksChanged()
        {
            if (RemarksChanged != null)
            {
                RemarksChanged(this, new EventArgs());
            }
        }

    }
}
