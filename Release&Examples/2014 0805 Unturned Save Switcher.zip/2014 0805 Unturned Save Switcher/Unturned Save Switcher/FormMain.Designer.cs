﻿namespace Unturned_Save_Switcher
{
    partial class FormMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox_currentSave = new System.Windows.Forms.GroupBox();
            this.button_clearCur = new System.Windows.Forms.Button();
            this.button_curFromRegFile = new System.Windows.Forms.Button();
            this.button_backup = new System.Windows.Forms.Button();
            this.checkBox_saveExist = new System.Windows.Forms.CheckBox();
            this.radioButton_langZh = new System.Windows.Forms.RadioButton();
            this.radioButton_langEn = new System.Windows.Forms.RadioButton();
            this.openFileDialog_reg = new System.Windows.Forms.OpenFileDialog();
            this.groupBox_backups = new System.Windows.Forms.GroupBox();
            this.button_cleanBckAll = new System.Windows.Forms.Button();
            this.button_cleanBckItem = new System.Windows.Forms.Button();
            this.button_importFromRegFile = new System.Windows.Forms.Button();
            this.button_exportToRegFile = new System.Windows.Forms.Button();
            this.button_import = new System.Windows.Forms.Button();
            this.flowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.colorDialog = new System.Windows.Forms.ColorDialog();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.groupBox_currentSave.SuspendLayout();
            this.groupBox_backups.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox_currentSave
            // 
            this.groupBox_currentSave.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_currentSave.Controls.Add(this.button_clearCur);
            this.groupBox_currentSave.Controls.Add(this.button_curFromRegFile);
            this.groupBox_currentSave.Controls.Add(this.button_backup);
            this.groupBox_currentSave.Location = new System.Drawing.Point(12, 12);
            this.groupBox_currentSave.Name = "groupBox_currentSave";
            this.groupBox_currentSave.Size = new System.Drawing.Size(730, 51);
            this.groupBox_currentSave.TabIndex = 0;
            this.groupBox_currentSave.TabStop = false;
            this.groupBox_currentSave.Text = "groupBox_currentSave";
            // 
            // button_clearCur
            // 
            this.button_clearCur.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_clearCur.Location = new System.Drawing.Point(649, 20);
            this.button_clearCur.Name = "button_clearCur";
            this.button_clearCur.Size = new System.Drawing.Size(75, 23);
            this.button_clearCur.TabIndex = 0;
            this.button_clearCur.Text = "clean";
            this.button_clearCur.UseVisualStyleBackColor = true;
            this.button_clearCur.Click += new System.EventHandler(this.button_clearCur_Click);
            // 
            // button_curFromRegFile
            // 
            this.button_curFromRegFile.Location = new System.Drawing.Point(87, 20);
            this.button_curFromRegFile.Name = "button_curFromRegFile";
            this.button_curFromRegFile.Size = new System.Drawing.Size(187, 23);
            this.button_curFromRegFile.TabIndex = 0;
            this.button_curFromRegFile.Text = "FromRegFile";
            this.button_curFromRegFile.UseVisualStyleBackColor = true;
            this.button_curFromRegFile.Click += new System.EventHandler(this.button_curFromRegFile_Click);
            // 
            // button_backup
            // 
            this.button_backup.Location = new System.Drawing.Point(6, 20);
            this.button_backup.Name = "button_backup";
            this.button_backup.Size = new System.Drawing.Size(75, 23);
            this.button_backup.TabIndex = 0;
            this.button_backup.Text = "backup";
            this.button_backup.UseVisualStyleBackColor = true;
            this.button_backup.Click += new System.EventHandler(this.button_backup_Click);
            // 
            // checkBox_saveExist
            // 
            this.checkBox_saveExist.AutoSize = true;
            this.checkBox_saveExist.Enabled = false;
            this.checkBox_saveExist.Location = new System.Drawing.Point(149, 10);
            this.checkBox_saveExist.Name = "checkBox_saveExist";
            this.checkBox_saveExist.Size = new System.Drawing.Size(78, 16);
            this.checkBox_saveExist.TabIndex = 1;
            this.checkBox_saveExist.Text = "checkBox1";
            this.checkBox_saveExist.UseVisualStyleBackColor = true;
            // 
            // radioButton_langZh
            // 
            this.radioButton_langZh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radioButton_langZh.AutoSize = true;
            this.radioButton_langZh.Location = new System.Drawing.Point(627, 0);
            this.radioButton_langZh.Name = "radioButton_langZh";
            this.radioButton_langZh.Size = new System.Drawing.Size(47, 16);
            this.radioButton_langZh.TabIndex = 1;
            this.radioButton_langZh.TabStop = true;
            this.radioButton_langZh.Text = "中文";
            this.radioButton_langZh.UseVisualStyleBackColor = true;
            this.radioButton_langZh.CheckedChanged += new System.EventHandler(this.radioButton_langZh_CheckedChanged);
            // 
            // radioButton_langEn
            // 
            this.radioButton_langEn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radioButton_langEn.AutoSize = true;
            this.radioButton_langEn.Location = new System.Drawing.Point(681, 0);
            this.radioButton_langEn.Name = "radioButton_langEn";
            this.radioButton_langEn.Size = new System.Drawing.Size(65, 16);
            this.radioButton_langEn.TabIndex = 1;
            this.radioButton_langEn.TabStop = true;
            this.radioButton_langEn.Text = "English";
            this.radioButton_langEn.UseVisualStyleBackColor = true;
            this.radioButton_langEn.CheckedChanged += new System.EventHandler(this.radioButton_langEn_CheckedChanged);
            // 
            // openFileDialog_reg
            // 
            this.openFileDialog_reg.Filter = "Registry File|*.reg";
            // 
            // groupBox_backups
            // 
            this.groupBox_backups.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_backups.Controls.Add(this.button_cleanBckAll);
            this.groupBox_backups.Controls.Add(this.button_cleanBckItem);
            this.groupBox_backups.Controls.Add(this.button_importFromRegFile);
            this.groupBox_backups.Controls.Add(this.button_exportToRegFile);
            this.groupBox_backups.Controls.Add(this.button_import);
            this.groupBox_backups.Controls.Add(this.flowLayoutPanel);
            this.groupBox_backups.Location = new System.Drawing.Point(12, 69);
            this.groupBox_backups.Name = "groupBox_backups";
            this.groupBox_backups.Size = new System.Drawing.Size(730, 198);
            this.groupBox_backups.TabIndex = 2;
            this.groupBox_backups.TabStop = false;
            this.groupBox_backups.Text = "groupBox1";
            // 
            // button_cleanBckAll
            // 
            this.button_cleanBckAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_cleanBckAll.Location = new System.Drawing.Point(649, 169);
            this.button_cleanBckAll.Name = "button_cleanBckAll";
            this.button_cleanBckAll.Size = new System.Drawing.Size(75, 23);
            this.button_cleanBckAll.TabIndex = 5;
            this.button_cleanBckAll.Text = "clean all";
            this.button_cleanBckAll.UseVisualStyleBackColor = true;
            this.button_cleanBckAll.Click += new System.EventHandler(this.button_cleanBckAll_Click);
            // 
            // button_cleanBckItem
            // 
            this.button_cleanBckItem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_cleanBckItem.Enabled = false;
            this.button_cleanBckItem.Location = new System.Drawing.Point(568, 169);
            this.button_cleanBckItem.Name = "button_cleanBckItem";
            this.button_cleanBckItem.Size = new System.Drawing.Size(75, 23);
            this.button_cleanBckItem.TabIndex = 4;
            this.button_cleanBckItem.Text = "clean";
            this.button_cleanBckItem.UseVisualStyleBackColor = true;
            this.button_cleanBckItem.Click += new System.EventHandler(this.button_cleanBckItem_Click);
            // 
            // button_importFromRegFile
            // 
            this.button_importFromRegFile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button_importFromRegFile.Enabled = false;
            this.button_importFromRegFile.Location = new System.Drawing.Point(280, 169);
            this.button_importFromRegFile.Name = "button_importFromRegFile";
            this.button_importFromRegFile.Size = new System.Drawing.Size(187, 23);
            this.button_importFromRegFile.TabIndex = 3;
            this.button_importFromRegFile.Text = "importFromRegFile...";
            this.button_importFromRegFile.UseVisualStyleBackColor = true;
            this.button_importFromRegFile.Click += new System.EventHandler(this.button1_Click);
            // 
            // button_exportToRegFile
            // 
            this.button_exportToRegFile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button_exportToRegFile.Enabled = false;
            this.button_exportToRegFile.Location = new System.Drawing.Point(87, 169);
            this.button_exportToRegFile.Name = "button_exportToRegFile";
            this.button_exportToRegFile.Size = new System.Drawing.Size(187, 23);
            this.button_exportToRegFile.TabIndex = 2;
            this.button_exportToRegFile.Text = "exportToRegFile...";
            this.button_exportToRegFile.UseVisualStyleBackColor = true;
            this.button_exportToRegFile.Click += new System.EventHandler(this.button_exportToRegFile_Click);
            // 
            // button_import
            // 
            this.button_import.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button_import.Enabled = false;
            this.button_import.Location = new System.Drawing.Point(6, 169);
            this.button_import.Name = "button_import";
            this.button_import.Size = new System.Drawing.Size(75, 23);
            this.button_import.TabIndex = 1;
            this.button_import.Text = "import";
            this.button_import.UseVisualStyleBackColor = true;
            this.button_import.Click += new System.EventHandler(this.button_import_Click);
            // 
            // flowLayoutPanel
            // 
            this.flowLayoutPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel.AutoScroll = true;
            this.flowLayoutPanel.Location = new System.Drawing.Point(6, 20);
            this.flowLayoutPanel.Name = "flowLayoutPanel";
            this.flowLayoutPanel.Size = new System.Drawing.Size(718, 143);
            this.flowLayoutPanel.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 270);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(197, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "Create by longtombbj, 2014-08-05";
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.Filter = "Reg File|*.reg";
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(754, 291);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox_backups);
            this.Controls.Add(this.radioButton_langEn);
            this.Controls.Add(this.radioButton_langZh);
            this.Controls.Add(this.checkBox_saveExist);
            this.Controls.Add(this.groupBox_currentSave);
            this.Name = "FormMain";
            this.Text = "[Unturned] Save Switcher";
            this.Activated += new System.EventHandler(this.FormMain_Activated);
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.groupBox_currentSave.ResumeLayout(false);
            this.groupBox_backups.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_currentSave;
        private System.Windows.Forms.CheckBox checkBox_saveExist;
        private System.Windows.Forms.Button button_clearCur;
        private System.Windows.Forms.Button button_curFromRegFile;
        private System.Windows.Forms.Button button_backup;
        private System.Windows.Forms.RadioButton radioButton_langZh;
        private System.Windows.Forms.RadioButton radioButton_langEn;
        private System.Windows.Forms.OpenFileDialog openFileDialog_reg;
        private System.Windows.Forms.GroupBox groupBox_backups;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel;
        private System.Windows.Forms.ColorDialog colorDialog;
        private System.Windows.Forms.Button button_exportToRegFile;
        private System.Windows.Forms.Button button_import;
        private System.Windows.Forms.Button button_cleanBckAll;
        private System.Windows.Forms.Button button_cleanBckItem;
        private System.Windows.Forms.Button button_importFromRegFile;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
    }
}

