﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Microsoft.Win32;
using System.IO;
using System.Diagnostics;
using System.Media;

namespace Unturned_Save_Switcher
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        UITexts uiTexts = new UITexts();
        private void FormMain_Load(object sender, EventArgs e)
        {

            RegistryKey rk;
            if (USSCore.HasBackStore == false)
            {
                rk = Registry.CurrentUser.CreateSubKey(USSCore.UNTURNED_BACKUPDIR_PATH);
                uiTexts.langIdValue = UITexts.LangId.zh;
                rk.SetValue(USSCore.RegKey_UILang, uiTexts.langIdValue, RegistryValueKind.String);
            }
            rk = USSCore.UNTURNED_BACKUP;
            uiTexts.Init(rk.GetValue(USSCore.RegKey_UILang).ToString());

            openFileDialog_reg.InitialDirectory = USSCore.GetSavedRegFilePath();

            initing = true;
            UITextInit();
            initing = false;

            CheckUnturnedSaveExist();
            ReloadBackupItemInfoList();
            BackupUIStaRefresh();
        }
        private void FormMain_Activated(object sender, EventArgs e)
        {
            CheckUnturnedSaveExist();
        }

        #region 语言设定
        private bool initing = false;
        private void UITextInit()
        {
            if (uiTexts.langIdValue.ToLower() == "zh")
            {
                radioButton_langZh.Checked = true;
            }
            else if (uiTexts.langIdValue.ToLower() == "en")
            {
                radioButton_langEn.Checked = true;
            }
            groupBox_currentSave.Text = uiTexts.textData.CurrentSave;
            checkBox_saveExist.Text = uiTexts.textData.CurrentSaveCheck_Exist;
            button_backup.Text = uiTexts.textData.CurrentSave_Backup;
            button_curFromRegFile.Text = uiTexts.textData.CurrentSave_FromRegFile;
            button_clearCur.Text = uiTexts.textData.CurrentSave_Clean;

            groupBox_backups.Text = uiTexts.textData.Backups;
            button_import.Text = uiTexts.textData.Import;
            button_cleanBckItem.Text = uiTexts.textData.Delete;
            button_cleanBckAll.Text = uiTexts.textData.CleanAll;
        }

        private void CheckUnturnedSaveExist()
        {
            if (USSCore.HasUnturnedSave)
            {
                checkBox_saveExist.Checked = true;
                checkBox_saveExist.Text = uiTexts.textData.CurrentSaveCheck_Exist;
                //groupBox_currentSave.Enabled = true;
                button_backup.Enabled = true;
                button_clearCur.Enabled = true;
            }
            else
            {
                checkBox_saveExist.Checked = false;
                checkBox_saveExist.Text = uiTexts.textData.CurrentSaveCheck_NotExist;
                //groupBox_currentSave.Enabled = false;
                button_backup.Enabled = false;
                button_clearCur.Enabled = false;
            }
        }

        private void radioButton_langZh_CheckedChanged(object sender, EventArgs e)
        {
            if (initing == true) return;
            uiTexts.langIdValue = UITexts.LangId.zh;
            uiTexts.Init(uiTexts.langIdValue);
            USSCore.UNTURNED_BACKUP.SetValue(USSCore.RegKey_UILang, uiTexts.langIdValue);
            initing = true;
            UITextInit();
            initing = false;
        }
        private void radioButton_langEn_CheckedChanged(object sender, EventArgs e)
        {
            if (initing == true) return;
            uiTexts.langIdValue = UITexts.LangId.en;
            uiTexts.Init(uiTexts.langIdValue);
            USSCore.UNTURNED_BACKUP.SetValue(USSCore.RegKey_UILang, uiTexts.langIdValue);
            initing = true;
            UITextInit();
            initing = false;
        }
        #endregion

        #region 当前存档操作
        private void button_backup_Click(object sender, EventArgs e)
        {
            if (USSCore.HasUnturnedSave == true)
            {
                USSCore.BackupUnturnedSave();
            }
            CheckUnturnedSaveExist();
            ReloadBackupItemInfoList();
            SystemSounds.Asterisk.Play();
        }

        private void button_curFromRegFile_Click(object sender, EventArgs e)
        {
            openFileDialog_reg.InitialDirectory = USSCore.GetSavedRegFilePath();
            if (DialogResult.OK == openFileDialog_reg.ShowDialog())
            {
                //[HKEY_CURRENT_USER\Software\Smartly Dressed Games\Unturned]
                string content = File.ReadAllText(openFileDialog_reg.FileName);
                bool wrongRegFile = false;
                if (content.Contains(@"[HKEY_CURRENT_USER\Software\Smartly Dressed Games\Unturned]") == false)
                {
                    wrongRegFile = true;
                }
                else
                {
                    int bracketCount = 0;
                    int bracketIdx = 0;
                    do
                    {
                        bracketIdx = content.IndexOf('[', bracketIdx) + 1;
                        if (bracketIdx > 0) bracketCount++;
                    }
                    while (bracketIdx > 0);

                    if (bracketCount > 1)
                    {
                        wrongRegFile = true;
                    }
                }
                if (wrongRegFile == true)
                {
                    MessageBox.Show(this, uiTexts.textData.Alert, uiTexts.textData.WrongRegFile, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    // do import
                    Process.Start(openFileDialog_reg.FileName);
                    USSCore.SaveRegFilePath(openFileDialog_reg.FileName);
                }
            }
        }

        private void button_clearCur_Click(object sender, EventArgs e)
        {
            if (USSCore.HasUnturnedSave == true)
            {
                USSCore.DeleteUnturnedSave();
            }
            CheckUnturnedSaveExist();
        }
        #endregion

        #region 备份操作
        private List<UserControl_backupItem> bckItmeList
            = new List<UserControl_backupItem>();
        private void ReloadBackupItemInfoList()
        {
            flowLayoutPanel.Controls.Clear();
            bckItmeList.Clear();
            USSCore.StruBackupItem[] backups = USSCore.LoadBackupInfoList();
            if (backups != null)
            {
                UserControl_backupItem bkuItem;
                USSCore.StruBackupItem bukInfo;
                for (int i = 0; i < backups.Length; i++)
                {
                    bukInfo = backups[i];
                    bkuItem = new UserControl_backupItem()
                    {
                        id = bukInfo.id,
                        idClr = bukInfo.idClr,
                        remarks = bukInfo.remarks,
                    };
                    bkuItem.Width = flowLayoutPanel.Width - 30;
                    bkuItem.Anchor = AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Right;
                    flowLayoutPanel.Controls.Add(bkuItem);
                    bckItmeList.Add(bkuItem);

                    bkuItem.ChangeIdClr += bkuItem_ChangeIdClr;
                    bkuItem.Selected += bkuItem_Selected;
                    bkuItem.RemarksChanged += bkuItem_RemarksChanged;
                }
            }
            BackupUIStaRefresh();
        }
        private UserControl_backupItem selectedBckItemUI
        {
            get
            {
                foreach (UserControl_backupItem bckUICtrl in bckItmeList)
                {
                    if (bckUICtrl.isSelected == true)
                    {
                        return bckUICtrl;
                    }
                }
                return null;
            }
        }
        private void BackupUIStaRefresh()
        {
            bool selectedBckItemFound = false;
            foreach (UserControl_backupItem bckUICtrl in bckItmeList)
            {
                if (bckUICtrl.isSelected == true)
                {
                    selectedBckItemFound = true;
                    break;
                }
            }

            button_import.Enabled = selectedBckItemFound;
            //button_exportToRegFile.Enabled = selectedBckItemFound;
            button_exportToRegFile.Enabled = false;
            button_cleanBckItem.Enabled = selectedBckItemFound;

            button_cleanBckAll.Enabled = (bckItmeList.Count > 0);
        }

        void bkuItem_Selected(object sender, EventArgs e)
        {
            UserControl_backupItem ui = (UserControl_backupItem)sender;
            foreach (Control ctrl in flowLayoutPanel.Controls)
            {
                if (((UserControl_backupItem)ctrl).id == ui.id)
                {
                    ui.isSelected = true;
                }
                else ((UserControl_backupItem)ctrl).isSelected = false;
            }
            BackupUIStaRefresh();
        }

        #region 索引信息更新
        void bkuItem_RemarksChanged(object sender, EventArgs e)
        {
            UserControl_backupItem ui = (UserControl_backupItem)sender;
            //ui.remarks = colorDialog.Color;
            USSCore.UpdateBackupItemInfo(ui.id, ui.idClr, ui.remarks);
        }
        void bkuItem_ChangeIdClr(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            if (DialogResult.OK == colorDialog.ShowDialog())
            {
                UserControl_backupItem ui = (UserControl_backupItem)sender;
                ui.idClr = colorDialog.Color;
                USSCore.UpdateBackupItemInfo(ui.id, ui.idClr, ui.remarks);
            }
        }
        #endregion

        private void button_import_Click(object sender, EventArgs e)
        {
            UserControl_backupItem ui = selectedBckItemUI;
            if (ui != null)
            {
                USSCore.DeleteUnturnedSave();
                USSCore.RestoreBackup(ui.id);
                CheckUnturnedSaveExist();
            }
            BackupUIStaRefresh();
            SystemSounds.Asterisk.Play();
        }
        #endregion

        private void button_cleanBckItem_Click(object sender, EventArgs e)
        {
            UserControl_backupItem ui = selectedBckItemUI;
            if (ui != null)
            {
                USSCore.DeleteBackup(ui.id);
                bckItmeList.Remove(ui);
                flowLayoutPanel.Controls.Remove(ui);
            }
            BackupUIStaRefresh();
            SystemSounds.Beep.Play();
        }

        private void button_cleanBckAll_Click(object sender, EventArgs e)
        {
            if (bckItmeList.Count > 0)
            {
                if (DialogResult.Yes == MessageBox.Show(this, uiTexts.textData.Alert, uiTexts.textData.ToCleanAllBackups, MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2))
                {
                    USSCore.DeleteAllBackups();
                }
            }
            BackupUIStaRefresh();
            SystemSounds.Beep.Play();
        }





        private void button_exportToRegFile_Click(object sender, EventArgs e)
        {
            //UserControl_backupItem ui = selectedBckItemUI;
            //if (ui != null)
            //{
            //    saveFileDialog.InitialDirectory = USSCore.GetSavedRegFilePath();
            //    if (DialogResult.OK == saveFileDialog.ShowDialog())
            //    {
            //        File.WriteAllText(saveFileDialog.FileName,
            //            USSCore.MakeBackupItemRegFileContent(ui.id),
            //            Encoding.Unicode
            //            );

            //        USSCore.SaveRegFilePath(saveFileDialog.FileName);
            //    }
            //}
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

    }

    public class USSCore
    {
        public static string RegKey_UILang = "UILang";
        public static string RegKey_Index = "Index";
        public static string RegKey_RegFilePath = "RegFilePath";

        private static string INDEX_DATA_SPLITE = "||**||**||";

        public static RegistryKey HKEY_CURRENT_USER = Registry.CurrentUser;
        public static string UNTURNED_SAVE_PATH = @"Software\Smartly Dressed Games\Unturned";
        public static RegistryKey UNTURNED_SAVE
        {
            get
            {
                return HKEY_CURRENT_USER.OpenSubKey(UNTURNED_SAVE_PATH, false);
            }
        }
        public static string UNTURNED_BACKUPDIR_PATH = @"Software\Smartly Dressed Games\Unturned Backup by longtombbj";
        public static RegistryKey UNTURNED_BACKUP
        {
            get
            {
                return HKEY_CURRENT_USER.OpenSubKey(UNTURNED_BACKUPDIR_PATH, true);
            }
        }

        public static bool HasUnturnedSave
        {
            get
            {
                return (UNTURNED_SAVE != null);
            }
        }
        public static bool HasBackStore
        {
            get
            {
                return (UNTURNED_BACKUP != null);
            }
        }

        public static void SaveRegFilePath(string path)
        {
            UNTURNED_BACKUP.SetValue(RegKey_RegFilePath, path);
        }
        public static string GetSavedRegFilePath()
        {
            object tmp = UNTURNED_BACKUP.GetValue(RegKey_RegFilePath);
            if (tmp == null)
            {
                return null;
            }
            else return tmp.ToString();
        }

        public static void BackupUnturnedSave()
        {
            string backupId = "" + DateTime.UtcNow.ToFileTimeUtc();
            CopyKey(Registry.CurrentUser, UNTURNED_SAVE_PATH, UNTURNED_BACKUPDIR_PATH + "\\" + backupId);

            //OA_desp..... ||**||**||
            object tmp = UNTURNED_BACKUP.GetValue(RegKey_Index);
            string indexData;
            if (tmp == null || tmp.ToString().Length <= 0)
            {
                indexData = backupId + "_%%_" + Color.Black.ToArgb() + "_%%_";
            }
            else
            {
                indexData = tmp.ToString();
                indexData = backupId + "_%%_" + Color.Black.ToArgb() + "_%%_" + INDEX_DATA_SPLITE + indexData;
            }
            UNTURNED_BACKUP.SetValue(RegKey_Index, indexData, RegistryValueKind.String);
            UNTURNED_BACKUP.Flush();
        }
        public static void RestoreBackup(string bckItemId)
        {
            CopyKey(Registry.CurrentUser,
                UNTURNED_BACKUPDIR_PATH + "\\" + bckItemId,
                UNTURNED_SAVE_PATH
                );
        }
        public static void DeleteBackup(string bckItemId)
        {
            UNTURNED_BACKUP.DeleteSubKey(bckItemId);

            object tmp = UNTURNED_BACKUP.GetValue(RegKey_Index);
            if (tmp == null)
            {
            }
            else
            {
                string[] lines = tmp.ToString().Split(new string[] { INDEX_DATA_SPLITE }, StringSplitOptions.RemoveEmptyEntries);
                string result = "";
                for (int i = 0; i < lines.Length; i++)
                {
                    if (result.Length > 0) result += INDEX_DATA_SPLITE;

                    if (lines[i].StartsWith(bckItemId + "_%%_"))
                    {
                        continue;
                    }

                    result += lines[i];
                }
                UNTURNED_BACKUP.SetValue(RegKey_Index, result, RegistryValueKind.String);
                UNTURNED_BACKUP.Flush();
            }
        }
        public static void DeleteAllBackups()
        {
            object tmp = UNTURNED_BACKUP.GetValue(RegKey_Index);
            if (tmp == null)
            {
            }
            else
            {
                string[] lines = tmp.ToString().Split(new string[] { INDEX_DATA_SPLITE }, StringSplitOptions.RemoveEmptyEntries);
                string[] parts;
                for (int i = 0; i < lines.Length; i++)
                {
                    parts = lines[i].Split(new string[] { "_%%_" }, StringSplitOptions.RemoveEmptyEntries);

                    UNTURNED_BACKUP.DeleteSubKey(parts[0]);
                }

                UNTURNED_BACKUP.SetValue(RegKey_Index, "", RegistryValueKind.String);
                UNTURNED_BACKUP.Flush();
            }
        }

        //public static string MakeBackupItemRegFileContent(string bckItemId)
        //{
        //    string result
        //        = "Windows Registry Editor Version 5.00\r\n\r\n"
        //        + @"[HKEY_CURRENT_USER\Software\Smartly Dressed Games\Unturned]"
        //        + "\r\n";

        //    RegistryKey bckKey = USSCore.UNTURNED_BACKUP.OpenSubKey(bckItemId);

        //    foreach (string vName in bckKey.GetValueNames())
        //    {
        //        result += "\"" + vName + "\"";
        //        result += "=";
        //        switch (bckKey.GetValueKind(vName))
        //        {
        //            case RegistryValueKind.String:
        //                result += "\"" + bckKey.GetValue(vName) + "\"";
        //                break;
        //            case RegistryValueKind.DWord:
        //                result += "dword";
        //                result += ":";
        //                result += bckKey.GetValue(vName).ToString();
        //                break;
        //            case RegistryValueKind.Binary:
        //                result += "hex";
        //                result += ":";
        //                break;
        //            case RegistryValueKind.ExpandString:
        //                break;
        //            case RegistryValueKind.MultiString:
        //                break;
        //            case RegistryValueKind.QWord:
        //                break;
        //            case RegistryValueKind.Unknown:
        //                break;
        //            case RegistryValueKind.None:
        //                break;

        //        }
        //        result += "\r\n";
        //    }
        //    result += "\r\n";

        //    return result;
        //}


        public struct StruBackupItem
        {
            public string id;
            public Color idClr;
            public string remarks;
        }
        public static StruBackupItem[] LoadBackupInfoList()
        {
            StruBackupItem[] result = null;
            object tmp = UNTURNED_BACKUP.GetValue(RegKey_Index);
            if (tmp == null)
            {
            }
            else
            {
                string[] lines = tmp.ToString().Split(new string[] { INDEX_DATA_SPLITE }, StringSplitOptions.RemoveEmptyEntries);
                result = new StruBackupItem[lines.Length];
                string[] parts;
                for (int i = 0; i < lines.Length; i++)
                {
                    parts = lines[i].Split(new string[] { "_%%_" }, StringSplitOptions.None);
                    result[i] = new StruBackupItem
                    {
                        id = parts[0],
                        idClr = Color.FromArgb(int.Parse(parts[1])),
                        remarks = parts[2],
                    };
                }
            }
            return result;
        }

        public static void UpdateBackupItemInfo(string targetId, Color idClr, string remarks)
        {
            object tmp = UNTURNED_BACKUP.GetValue(RegKey_Index);
            if (tmp == null)
            {
            }
            else
            {
                string[] lines = tmp.ToString().Split(new string[] { INDEX_DATA_SPLITE }, StringSplitOptions.RemoveEmptyEntries);
                string result = "";
                for (int i = 0; i < lines.Length; i++)
                {
                    if (result.Length > 0) result += INDEX_DATA_SPLITE;

                    if (lines[i].StartsWith(targetId + "_%%_"))
                    {
                        lines[i] = targetId + "_%%_" + idClr.ToArgb() + "_%%_" + remarks;
                    }

                    result += lines[i];
                }
                UNTURNED_BACKUP.SetValue(RegKey_Index, result, RegistryValueKind.String);
                UNTURNED_BACKUP.Flush();
            }
        }

        public static void DeleteUnturnedSave()
        {
            Registry.CurrentUser.DeleteSubKey(UNTURNED_SAVE_PATH);
        }

        // from codeproject origin by drdandle, USA
        private static void CopyKey(RegistryKey parentKey,
            string sourceKeyPath, string destinationKeyPath)
        {
            //Create new key
            RegistryKey destinationKey = parentKey.CreateSubKey(destinationKeyPath);

            //Open the sourceKey we are copying from
            RegistryKey sourceKey = parentKey.OpenSubKey(sourceKeyPath);

            RecurseCopyKey(sourceKey, destinationKey);
            destinationKey.Flush();
        }
        private static void RecurseCopyKey(RegistryKey sourceKey, RegistryKey destinationKey)
        {
            //copy all the values
            foreach (string valueName in sourceKey.GetValueNames())
            {
                object objValue = sourceKey.GetValue(valueName);
                RegistryValueKind valKind = sourceKey.GetValueKind(valueName);
                try
                {
                    destinationKey.SetValue(valueName, objValue, valKind);
                }
                catch (Exception)
                {
                }
                finally
                {
                    try
                    {
                        destinationKey.SetValue(valueName, Convert.ToUInt32(objValue), valKind);
                    }
                    catch (Exception)
                    {
                    }
                }
            }

            //For Each subKey 
            //Create a new subKey in destinationKey 
            //Call myself 
            foreach (string sourceSubKeyName in sourceKey.GetSubKeyNames())
            {
                RegistryKey sourceSubKey = sourceKey.OpenSubKey(sourceSubKeyName);
                RegistryKey destSubKey = destinationKey.CreateSubKey(sourceSubKeyName);
                RecurseCopyKey(sourceSubKey, destSubKey);
            }
        }
    }

    public class UITexts
    {
        public string langIdValue;
        public class LangId
        {
            public static string en = "en";
            public static string zh = "zh";
        }

        public struct StruTextData
        {
            public string CurrentSave;
            public string CurrentSaveCheck_Exist;
            public string CurrentSaveCheck_NotExist;
            public string CurrentSave_Backup;
            public string CurrentSave_FromRegFile;
            public string CurrentSave_Clean;
            public string Alert;
            public string WrongRegFile;
            public string ToCleanAllBackups;
            public string Backups;
            public string Import;
            public string Delete;
            public string CleanAll;
        }

        public StruTextData textData;
        public void Init(string langIdValue)
        {
            this.langIdValue = langIdValue;
            textData = new StruTextData();
            if (langIdValue.ToLower() == "en")
            {
                textData.CurrentSave = CurrentSave.en;
                textData.CurrentSaveCheck_Exist = CurrentSaveCheck_Exist.en;
                textData.CurrentSaveCheck_NotExist = CurrentSaveCheck_NotExist.en;
                textData.CurrentSave_Backup = CurrentSave_Backup.en;
                textData.CurrentSave_FromRegFile = CurrentSave_FromRegFile.en;
                textData.CurrentSave_Clean = CurrentSave_Clean.en;
                textData.Alert = Alert.en;
                textData.WrongRegFile = WrongRegFile.en;
                textData.ToCleanAllBackups = ToCleanAllBackups.en;
                textData.Backups = Backups.en;
                textData.Import = Import.en;
                textData.Delete = Delete.en;
                textData.CleanAll = CleanAll.en;

            }
            else if (langIdValue.ToLower() == "zh")
            {
                textData.CurrentSave = CurrentSave.zh;
                textData.CurrentSaveCheck_Exist = CurrentSaveCheck_Exist.zh;
                textData.CurrentSaveCheck_NotExist = CurrentSaveCheck_NotExist.zh;
                textData.CurrentSave_Backup = CurrentSave_Backup.zh;
                textData.CurrentSave_FromRegFile = CurrentSave_FromRegFile.zh;
                textData.CurrentSave_Clean = CurrentSave_Clean.zh;
                textData.Alert = Alert.zh;
                textData.WrongRegFile = WrongRegFile.zh;
                textData.ToCleanAllBackups = ToCleanAllBackups.zh;
                textData.Backups = Backups.zh;
                textData.Import = Import.zh;
                textData.Delete = Delete.zh;
                textData.CleanAll = CleanAll.zh;
            }
            else throw new Exception("Unknow language!");
        }

        public class CurrentSave
        {
            public static string en = "Current Save";
            public static string zh = "当前存档";
        }
        public class CurrentSaveCheck_Exist
        {
            public static string en = "Check (Exist)";
            public static string zh = "检查（存在）";
        }
        public class CurrentSaveCheck_NotExist
        {
            public static string en = "Check (Not Exist)";
            public static string zh = "检查（不存在）";
        }

        public class CurrentSave_Backup
        {
            public static string en = "Backup";
            public static string zh = "备份";
        }
        public class CurrentSave_FromRegFile
        {
            public static string en = "From Reg File...";
            public static string zh = "从Reg文件导入...";
        }
        public class CurrentSave_Clean
        {
            public static string en = "Clean";
            public static string zh = "清除";
        }

        public class Alert
        {
            public static string en = "Alert";
            public static string zh = "警告";
        }
        public class WrongRegFile
        {
            public static string en = "Something wrong with Reg File, please check it out!";
            public static string zh = "选取的Reg文件有问题，请检查内容！";
        }

        public class Backups
        {
            public static string en = "Backups";
            public static string zh = "备份";
        }
        public class Import
        {
            public static string en = "Import";
            public static string zh = "导入";
        }
        public class Delete
        {
            public static string en = "Delete";
            public static string zh = "删除";
        }
        public class CleanAll
        {
            public static string en = "Clean All";
            public static string zh = "清空";
        }

        public class ToCleanAllBackups
        {
            public static string en = "Are you sure to Clean All Backups?";
            public static string zh = "你确定要删除所有备份吗？";
        }


        public class Question
        {
            public static string en = "Question";
            public static string zh = "请问";
        }
        public class NoBackupFound_CreateOne
        {
            public static string en = "No Backup found, do you want to create one?";
            public static string zh = "当前无备份，创建一个吗？";
        }
    }
}
