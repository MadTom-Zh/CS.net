﻿namespace Unturned_Save_Switcher
{
    partial class UserControl_backupItem
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox_idClr = new System.Windows.Forms.PictureBox();
            this.label_dateTime = new System.Windows.Forms.Label();
            this.textBox_remarks = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_idClr)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox_idClr
            // 
            this.pictureBox_idClr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox_idClr.Location = new System.Drawing.Point(3, 4);
            this.pictureBox_idClr.Name = "pictureBox_idClr";
            this.pictureBox_idClr.Size = new System.Drawing.Size(44, 21);
            this.pictureBox_idClr.TabIndex = 0;
            this.pictureBox_idClr.TabStop = false;
            this.pictureBox_idClr.Click += new System.EventHandler(this.UserControl_backupItem_Select_Click);
            this.pictureBox_idClr.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox_idClr_MouseUp);
            // 
            // label_dateTime
            // 
            this.label_dateTime.AutoSize = true;
            this.label_dateTime.Location = new System.Drawing.Point(55, 8);
            this.label_dateTime.Name = "label_dateTime";
            this.label_dateTime.Size = new System.Drawing.Size(101, 12);
            this.label_dateTime.TabIndex = 1;
            this.label_dateTime.Text = "yyyy-MM-dd HH:mm";
            this.label_dateTime.Click += new System.EventHandler(this.UserControl_backupItem_Select_Click);
            // 
            // textBox_remarks
            // 
            this.textBox_remarks.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_remarks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_remarks.Location = new System.Drawing.Point(171, 4);
            this.textBox_remarks.Name = "textBox_remarks";
            this.textBox_remarks.ReadOnly = true;
            this.textBox_remarks.Size = new System.Drawing.Size(311, 21);
            this.textBox_remarks.TabIndex = 2;
            this.textBox_remarks.Click += new System.EventHandler(this.UserControl_backupItem_Select_Click);
            this.textBox_remarks.Enter += new System.EventHandler(this.textBox_remarks_Enter);
            this.textBox_remarks.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_remarks_KeyDown);
            this.textBox_remarks.Leave += new System.EventHandler(this.textBox_remarks_Leave);
            // 
            // UserControl_backupItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.textBox_remarks);
            this.Controls.Add(this.label_dateTime);
            this.Controls.Add(this.pictureBox_idClr);
            this.Name = "UserControl_backupItem";
            this.Size = new System.Drawing.Size(485, 32);
            this.Click += new System.EventHandler(this.UserControl_backupItem_Select_Click);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_idClr)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox_idClr;
        private System.Windows.Forms.Label label_dateTime;
        private System.Windows.Forms.TextBox textBox_remarks;
    }
}
