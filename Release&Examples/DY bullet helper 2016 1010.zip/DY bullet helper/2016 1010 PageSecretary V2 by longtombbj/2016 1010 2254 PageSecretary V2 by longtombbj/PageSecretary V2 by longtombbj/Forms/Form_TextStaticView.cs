﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PageSecretary_V2_by_longtombbj.Forms
{
    public partial class Form_TextStaticView : Form
    {
        public Form_TextStaticView()
        {
            InitializeComponent();
        }
        public  void SetText(string text)
        {
            textBox.Text = text;
        }
    }
}
