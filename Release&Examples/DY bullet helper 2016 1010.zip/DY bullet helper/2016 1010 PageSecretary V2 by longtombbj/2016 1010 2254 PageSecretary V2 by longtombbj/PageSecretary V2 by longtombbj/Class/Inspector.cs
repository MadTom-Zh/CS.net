﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using System.Data;
using System.Drawing;

namespace PageSecretary_V2_by_longtombbj.Class
{
    /// <summary>
    /// 直接排除黑名单成员发出的消息
    /// 对文本进行处理和过滤，检查非法关键字等
    /// *** 调用T2S_Core的文本拆分功能
    /// 只支持 中文、英文 和 日文，其他语言不考虑
    /// </summary>
    class Inspector
    {
        public static Inspector instance;
        public static Inspector GetInstance()
        {
            if (instance == null)
            {
                instance = new Inspector();
            }
            return instance;
        }


        /*
        处理优先级，从上向下描述，从高到底：
        
        *预处理：
        全部全角空格，转化为半角空格；全角的！？， 改 半角的!?, 
        连续两个空格，替换为一个空格
        
        中文和日文，无例外:
        必去掉多余空格
        对重复出现的字，例如“噗噗噗噗噗噗噗”或“6666666”，大于等于5个字重复字的，直接拉黑
        对重复出现的词，例如“汤姆汤姆汤姆”，大于等于3次的，直接拉黑
        
        英文，无例外:
        连续两个空格，替换成一个空格
        
        
        *过滤匹配

        *过滤语音
        
        
        */

        public HashSet<string> hash_blackPinyin_starts = new HashSet<string>();
        public HashSet<string> hash_blackPinyin_contains = new HashSet<string>();
        public HashSet<string> hash_blackPinyin_ends = new HashSet<string>();

        public HashSet<string> hash_blackUsers = new HashSet<string>();
        public HashSet<string> hash_blackKeyWords = new HashSet<string>();
        public Dictionary<string, string> dict_wordReplace = new Dictionary<string, string>();



        private Config conf = Config.GetInstance();
        private T2S_HCore.Classes.MultiVoice multiVoice = T2S_HCore.Classes.MultiVoice.GetInstance();
        private Timer mainTimer = new Timer();
        public Inspector()
        {
            mainTimer.Interval = 1000;
            mainTimer.Tick += MainTimer_Tick;
            mainTimer.Enabled = true;
        }


        public void Refresh_blackPinyin_starts(DataGridView dgv)
        {
            hash_blackPinyin_starts.Clear();
            object tmp;
            foreach (DataGridViewRow row in dgv.Rows)
            {
                tmp = row.Cells[0].Value;
                if (tmp == null || tmp.GetType() == typeof(System.DBNull))
                {
                    continue;
                }
                hash_blackPinyin_starts.Add((string)tmp);
            }
        }
        public void Refresh_blackPinyin_contains(DataGridView dgv)
        {
            hash_blackPinyin_contains.Clear();
            object tmp;
            foreach (DataGridViewRow row in dgv.Rows)
            {
                tmp = row.Cells[0].Value;
                if (tmp == null || tmp.GetType() == typeof(System.DBNull))
                {
                    continue;
                }
                hash_blackPinyin_contains.Add((string)tmp);
            }
        }
        public void Refresh_blackPinyin_ends(DataGridView dgv)
        {
            hash_blackPinyin_ends.Clear();
            object tmp;
            foreach (DataGridViewRow row in dgv.Rows)
            {
                tmp = row.Cells[0].Value;
                if (tmp == null || tmp.GetType() == typeof(System.DBNull))
                {
                    continue;
                }
                hash_blackPinyin_ends.Add((string)tmp);
            }
        }

        public void Refresh_blackUsers(DataGridView dgv)
        {
            hash_blackUsers.Clear();
            object key;
            foreach (DataGridViewRow row in dgv.Rows)
            {
                key = row.Cells[0].Value;
                if (key == null || key.GetType() == typeof(System.DBNull))
                {
                    continue;
                }
                hash_blackUsers.Add((string)key);
            }
        }
        public void Refresh_blackKeyWords(DataGridView dgv)
        {
            hash_blackKeyWords.Clear();
            object key;
            foreach (DataGridViewRow row in dgv.Rows)
            {
                key = row.Cells[0].Value;
                if (key == null || key.GetType() == typeof(System.DBNull))
                {
                    continue;
                }
                hash_blackKeyWords.Add((string)key);
            }
        }
        public void Refresh_wordReplace(DataGridView dgv)
        {
            dict_wordReplace.Clear();
            object key, value;
            foreach (DataGridViewRow row in dgv.Rows)
            {
                key = row.Cells[0].Value;
                if (key == null || key.GetType() == typeof(System.DBNull))
                {
                    continue;
                }
                value = row.Cells[1].Value;
                if (value == null || value.GetType() == typeof(System.DBNull))
                {
                    continue;
                }
                dict_wordReplace.Add((string)key, (string)value);
            }
        }

        public class GiftRecorder
        {
            private class Rec
            {
                public string userName;
                public string giftName;
                public int giftCount = 0;
            }
            private List<Rec> list = new List<Rec>();
            public struct GiftInfo
            {
                public string id;
                public string name;
                public string description;
            }
            public List<GiftInfo> giftList = new List<GiftInfo>();

            public bool haveRecord
            {
                get
                {
                    return list.Count > 0;
                }
            }

            public void CheckIn(DYBullet.DyBulletHelper.Bullet bullet)
            {
                DYBullet.DyBulletHelper.Bullet.iStructedMsg structMsg = bullet.StructedMsg;
                switch (structMsg.Type)
                {
                    case DYBullet.DyBulletHelper.Bullet.iStructedMsg.iType.GiftDonated:
                        AddRec(
                            structMsg.GiftDonated.nn,
                            GetGiftNameDescri(structMsg.GiftDonated.gfid),
                            structMsg.GiftDonated.gfcnt == null ? 1 : int.Parse(structMsg.GiftDonated.gfcnt)
                            );
                        break;
                    case DYBullet.DyBulletHelper.Bullet.iStructedMsg.iType.DeserveBought:
                        AddRec(
                            structMsg.DeserveBought.sui.nick,
                            structMsg.DeserveBought.lev + "级酬勤",
                            int.Parse(structMsg.DeserveBought.cnt)
                            );
                        break;
                    case DYBullet.DyBulletHelper.Bullet.iStructedMsg.iType.Defiance:
                        if (structMsg.Defiance.dn == Config.GetInstance().User_NickName)
                        {
                            AddRec(
                                structMsg.Defiance.sn,
                                structMsg.Defiance.gn,
                                int.Parse(structMsg.Defiance.gc)
                                );
                        }
                        break;
                    case DYBullet.DyBulletHelper.Bullet.iStructedMsg.iType.RedPacket:
                        if (structMsg.RedPacket.dnk == Config.GetInstance().User_NickName)
                        {
                            AddRec(
                                structMsg.RedPacket.snk,
                                structMsg.RedPacket.rpt + "鱼丸",
                                int.Parse(structMsg.RedPacket.sl)
                                );
                        }
                        break;
                }
            }
            private string GetGiftNameDescri(string giftId)
            {
                foreach (GiftInfo giftItem in giftList)
                {
                    if (giftItem.id == giftId)
                        return giftItem.name + "(" + giftItem.description + ")";
                }
                return giftId + "号-礼品";
            }
            private void AddRec(string userName, string giftName, int giftCount)
            {
                int idx;
                Rec rec = null;
                bool found = false;
                for (idx = list.Count - 1; idx >= 0; idx--)
                {
                    rec = list[idx];
                    if (rec.userName == userName && rec.giftName == giftName)
                    {
                        found = true;
                        break;
                    }
                }
                if (found == true)
                {
                    rec.giftCount += giftCount;
                    list[idx] = rec;
                }
                else
                {
                    list.Add(
                        new Rec()
                        {
                            userName = userName,
                            giftName = giftName,
                            giftCount = giftCount
                        }
                        );
                }
            }
            public string CheckOut()
            {
                string tmp;
                string result = "";
                List<string> thankDescripts = new List<string>();
                List<string> giftDescripts;
                string userName;
                int count;
                while (list.Count > 0)
                {
                    userName = list[0].userName;
                    giftDescripts = GiftDescript(userName, ref list);

                    tmp = "感谢" + userName + "赠送的";
                    count = giftDescripts.Count;
                    for (int i = count - 1; i >= 0; i--)
                    {
                        if (count > 1 && i == 0)
                        {
                            tmp += "和";
                        }
                        else if (i < count - 1)
                        {
                            tmp += ",";
                        }
                        tmp += giftDescripts[i];
                    }
                    thankDescripts.Add(tmp);
                }

                count = thankDescripts.Count;
                for (int i = count - 1; i >= 0; i--)
                {
                    if (count > 2 && i == 0)
                    {
                        result += "以及";
                    }
                    else if (i < count - 1)
                    {
                        result += ",";
                    }
                    result += thankDescripts[i];
                }
                return result;
            }
            private List<string> GiftDescript(string userName, ref List<Rec> list)
            {
                List<string> result = new List<string>();
                Rec rec;
                for (int i = list.Count - 1; i >= 0; i--)
                {
                    rec = list[i];
                    if (rec.userName == userName)
                    {
                        result.Add(rec.giftCount + "个" + rec.giftName);
                        list.RemoveAt(i);
                    }
                }
                return result;
            }

            private static string KEY_GIFT_ID = "data-giftid=\"";
            private static string KEY_GIFT_NAME = "data-giftname=\"";
            private static string KEY_GIFT_DESCRIPT = "data-intro=\"";
            public void ReLoadGiftList_FromPageCode(string code)
            {
                giftList.Clear();
                bool found = true;
                string valueId, valueName, valueDescri;
                int idxGIK = -1;
                int idxGNK = -1;
                int idxGDK = -1;
                while (found)
                {
                    idxGIK = code.IndexOf(KEY_GIFT_ID);
                    if (idxGIK >= 0)
                    {
                        code = code.Substring(idxGIK + KEY_GIFT_ID.Length);
                        valueId = code.Substring(0, code.IndexOf('\"'));

                        idxGNK = code.IndexOf(KEY_GIFT_NAME);
                        if (idxGNK >= 0)
                        {
                            code = code.Substring(idxGNK + KEY_GIFT_NAME.Length);
                            valueName = code.Substring(0, code.IndexOf('\"'));

                            //data-intro="你远比嫦娥更加美丽！"
                            idxGDK = code.IndexOf(KEY_GIFT_DESCRIPT);
                            if (idxGDK >= 0)
                            {
                                code = code.Substring(idxGDK + KEY_GIFT_DESCRIPT.Length);
                                valueDescri = code.Substring(0, code.IndexOf('\"'));

                                giftList.Add(
                                    new GiftInfo()
                                    {
                                        id = valueId,
                                        name = valueName,
                                        description = valueDescri
                                    }
                                    );
                            }
                            else
                            {
                                found = false;
                            }
                        }
                        else
                        {
                            found = false;
                        }
                    }
                    else
                    {
                        found = false;
                    }
                }
            }

            public void SaveGiftList()
            {
                if (giftList.Count > 0)
                {
                    SQLiteDBHelper dbHelper = SQLiteDBHelper.GetInstance();
                    int listLeng = giftList.Count;
                    string[] idList = new string[listLeng];
                    string[] nameList = new string[listLeng];
                    string[] descriList = new string[listLeng];
                    GiftInfo gi;
                    for (int i = 0; i < listLeng; i++)
                    {
                        gi = giftList[i];
                        idList[i] = gi.id;
                        nameList[i] = gi.name;
                        descriList[i] = gi.description;
                    }
                    dbHelper.AddOrReplaceRow_GiftList(idList, nameList, descriList);
                }
            }
            public void LoadGiftList()
            {
                giftList.Clear();
                SQLiteDBHelper dbHelper = SQLiteDBHelper.GetInstance();
                DataTable dt = dbHelper.Reload_GiftList();
                foreach (DataRow dr in dt.Rows)
                {
                    giftList.Add(
                        new GiftInfo()
                        {
                            id = dr["ID"].ToString(),
                            name = dr["Name"].ToString(),
                            description = dr["Descri"].ToString()
                        }
                        );
                }
            }

            public string GetGiftListString()
            {
                string result = "";
                foreach (GiftInfo giftItem in giftList)
                {
                    result += giftItem.id + ":" + giftItem.name + ":" + giftItem.description + ", ";
                }
                result = result.TrimEnd().TrimEnd(',');
                return result;
            }
        }


        public GiftRecorder giftRecorder = new GiftRecorder();
        private DYBullet.DyBulletHelper.Bullet.iStructedMsg.iChat chat = null;
        public void InputMsg(DYBullet.DyBulletHelper.Bullet bullet)
        {
            //
            DYBullet.DyBulletHelper.Bullet.iStructedMsg sMsg = bullet.StructedMsg;
            switch (sMsg.Type)
            {
                case DYBullet.DyBulletHelper.Bullet.iStructedMsg.iType.Defiance:
                    // 还是不要限定了， 因为 ！ 如果有出现送礼的情况，也可以 增加人气，不是吗！？
                    //if (sMsg.Defiance.dn == conf.User_NickName)
                    //{
                    giftRecorder.CheckIn(bullet);
                    Timer_disCount_receivingGifts = 3;
                    //}
                    break;
                case DYBullet.DyBulletHelper.Bullet.iStructedMsg.iType.RedPacket:
                    // 还是不要限定了， 因为 ！ 如果有出现送礼的情况，也可以 增加人气，不是吗！？
                    //if (sMsg.RedPacket.dnk == conf.User_NickName)
                    //{
                    giftRecorder.CheckIn(bullet);
                    Timer_disCount_receivingGifts = 3;
                    //}
                    break;
                case DYBullet.DyBulletHelper.Bullet.iStructedMsg.iType.GiftDonated:
                case DYBullet.DyBulletHelper.Bullet.iStructedMsg.iType.DeserveBought:
                    giftRecorder.CheckIn(bullet);
                    Timer_disCount_receivingGifts = 3;
                    break;
                case DYBullet.DyBulletHelper.Bullet.iStructedMsg.iType.Chat:
                    chat = sMsg.Chat;
                    break;
            }


        }

        private Logger logger = Logger.GetInstance();

        private int Timer_disCount_cycleTime = 0;
        private int Timer_disCount_betweenVoices = 0;
        private int Timer_disCount_receivingGifts = 0;
        //private bool Timer_preBCBusy = false;
        //private bool Timer_curBCBusy = false;
        //private bool Timer_preFileExists = false;
        //private bool Timer_curFileExists = false;

        public event EventHandler RemoteDirNotFound;
        public event EventHandler RemoteDirReady;
        public class Voice2PlayArgs : EventArgs
        {
            public DYBullet.DyBulletHelper.Bullet.iStructedMsg.iChat chatData;
            public string voiceTxMsg;
        }
        public event EventHandler<Voice2PlayArgs> Voice2Play;
        private void MainTimer_Tick(object sender, EventArgs e)
        {
            if (conf.Voice_IsEnabled == false) return;

            #region 读完一句，进入 句间距 等待
            if (multiVoice.broadCaster.isBusy == true)
            {
                Timer_disCount_betweenVoices = conf.Voice_TimeBetweenVoices;
            }
            if (conf.Voice_IsRemote == true)
            {
                if (Directory.Exists(conf.Voice_RemoteDir))
                {
                    if (RemoteDirReady != null)
                    {
                        RemoteDirReady(this, null);
                    }
                    DirectoryInfo info = new DirectoryInfo(conf.Voice_RemoteDir);
                    try
                    {
                        if (info.GetFiles("*.wav").Count() > 0)
                        {
                            Timer_disCount_betweenVoices = conf.Voice_TimeBetweenVoices;
                        }
                    }
                    catch (Exception err)
                    {
                        if (RemoteDirNotFound != null)
                        {
                            RemoteDirNotFound(this, null);
                        }
                        return;
                    }
                }
                else
                {
                    if (RemoteDirNotFound != null)
                    {
                        RemoteDirNotFound(this, null);
                    }
                    return;
                }
            }

            #endregion


            // 保存当前状态，为下一个循环做准备
            Timer_disCount_cycleTime--;
            Timer_disCount_betweenVoices--;
            Timer_disCount_receivingGifts--;
            if (Timer_disCount_cycleTime < -100000)
            {
                Timer_disCount_cycleTime = 0;
            }
            if (Timer_disCount_betweenVoices < -100000)
            {
                Timer_disCount_betweenVoices = 0;
            }
            if (Timer_disCount_receivingGifts < -100000)
            {
                Timer_disCount_receivingGifts = 0;
            }

            // 时间未到，继续等待
            if (
                Timer_disCount_cycleTime > -1
                || Timer_disCount_betweenVoices > -1
                || Timer_disCount_receivingGifts > -1
                )
            {
                return;
            }

            if (multiVoice.broadCaster.isBusy == false && chat != null)
            {
                Timer_disCount_cycleTime = conf.Voice_CycleTime;
                // do the job

                string userName;
                string msg;
                string msgTmp = "";
                bool useVoice = true;
                string useVoice_falseDescript = "";
                T2S_HCore.Classes.MultiVoice.TextMultiFragments multiText
                    = new T2S_HCore.Classes.MultiVoice.TextMultiFragments();
                List<T2S_HCore.Classes.MultiVoice.TextMultiFragments.Fragment> fragments = null;
                if (conf.Voice_IfSpeechGift && giftRecorder.haveRecord == true)
                {
                    // 答谢礼物信息
                    msg = giftRecorder.CheckOut();
                    fragments = multiText.Detach(msg);
                }
                else if (conf.Voice_IfSpeechChat)
                {
                    // 聊天消息信息
                    userName = chat.nn;
                    msg = chat.txt;

                    if (conf.Voice_IsOnlyForTom == true)
                    {
                        // only for MadTom
                        if (
                            msg.StartsWith("Tom ")
                            || msg.StartsWith("Tom,")
                            || msg.StartsWith("tom ")
                            || msg.StartsWith("tom,")
                            )
                        {
                            msg = msg.Substring(4);
                        }
                        else if
                            (
                            msg.StartsWith("汤姆 ")
                            || msg.StartsWith("汤姆，")
                            )
                        {
                            msg = msg.Substring(3);
                        }
                        else if
                            (
                            msg.StartsWith("MadTom ")
                            || msg.StartsWith("MadTom,")
                            || msg.StartsWith("madtom ")
                            || msg.StartsWith("madtom,")
                            )
                        {
                            msg = msg.Substring(7);
                        }
                        else if
                            (
                            msg.StartsWith("疯汤姆 ")
                            || msg.StartsWith("疯汤姆，")
                            )
                        {
                            msg = msg.Substring(4);
                        }
                        else
                        {
                            useVoice_falseDescript = "not for TOM.";
                            useVoice = false;
                        }
                    }

                    if (Check_BlackUser(userName) == true)
                    {
                        if (conf.Txt_ToHalfwidthForms)
                        {
                            msg = msg.Replace("　", " ").Replace("？", "?").Replace("！", "!").Replace("，", ",");
                        }
                        msg = faceSymbHelper.ReplaceSymbolToTitle(msg);
                        msgTmp = multiVoice.broadCaster.Text_RemoveAllSymbols(msg);
                        fragments = multiText.Detach(msg);
                        TxtProc_Pre(ref fragments);
                    }
                    else
                    {
                        useVoice_falseDescript = "user in BlackList.";
                        useVoice = false;
                    }


                    if (useVoice == true)
                    {
                        if (conf.TxtInsp_isCheck_5SameChar_inChineser)
                        {
                            //if (Check_5SameChar(fragments) == false)
                            if (Check_5SameChar(msgTmp) == false)
                            {
                                useVoice_falseDescript = "5 SAME CHARS in a row.";
                                useVoice = false;
                            }
                        }
                    }

                    if (useVoice == true)
                    {
                        if (conf.TxtInsp_isCheck_3SameWord_inChineser)
                        {
                            //if (Check_3SameWord(fragments) == false)
                            if (Check_3SameWord(msgTmp) == false)
                            {
                                useVoice_falseDescript = "3 SAME WORDS in a row.";
                                useVoice = false;
                            }
                        }
                    }

                    if (useVoice == true)
                    {
                        // word replace
                        TxtProc_WordReplace(ref fragments);
                        msgTmp = TxtProc_WordReplace(msgTmp);
                    }

                    if (useVoice == true)
                    {
                        // check key word
                        //if (Check_BlackKeyWords(fragments) == false)
                        if (Check_BlackKeyWords(msgTmp) == false)
                        {
                            useVoice_falseDescript = "keyword found in BlackList.";
                            useVoice = false;
                        }
                    }

                    if (useVoice == true)
                    {
                        //check pinyin
                        List<string> pinyinList = new List<string>();
                        foreach (T2S_HCore.Classes.MultiVoice.TextMultiFragments.Fragment frag in fragments)
                        {
                            if (frag.fgLang == T2S_HCore.Classes.MultiVoice.LanguageType.ZH)
                            {
                                pinyinList.Add
                                    (
                                    Chinese2PINYIN.Convert(multiVoice.broadCaster.Text_RemoveAllSymbols(frag.fgValue))
                                    );
                            }
                        }

                        if (useVoice == true)
                        {
                            // ends
                            if (Check_BlackPinYin_Ends(pinyinList) == false)
                            {
                                useVoice_falseDescript = "endwidth pinyin found in BlackList.";
                                useVoice = false;
                            }
                        }
                        if (useVoice == true)
                        {
                            // contains
                            if (Check_BlackPinYin_Contains(pinyinList) == false)
                            {
                                useVoice_falseDescript = "contain pinyin found in BlackList.";
                                useVoice = false;
                            }
                        }
                        if (useVoice == true)
                        {
                            // starts
                            if (Check_BlackPinYin_Starts(pinyinList) == false)
                            {
                                useVoice_falseDescript = "startwidth pinyin found in BlackList.";
                                useVoice = false;
                            }
                        }
                    }
                }
                else
                {
                    useVoice_falseDescript = "conf.Voice_IfSpeechChat == false.";
                    useVoice = false;
                }


                // 最终，通过了消息处理和检查，开始读语音
                if (useVoice == true)
                {
                    string tmp = multiText.Assembly(fragments);
                    logger.Log(
                        "T2S: " + tmp + "\r\n"
                        + "Origin: " + "[" + chat.nn + "]" + chat.txt
                        );
                    if (conf.Voice_IsRemote == true)
                    {
                        //multiVoice.Speech2WaveFile(fragments, conf.Voice_RemoteDir + "\\" + conf.DateTimeNow_FullString_FileName + "_");

                        ////////   for debug
                        if (false)
                        {
                            Voice_SaveFileToLocal(fragments);
                            Voice_MoveLocalFileToRemoteDir();
                        }
                        else
                        {
                            Voice_SaveFileToRemote_Directly(fragments);
                        }
                    }
                    else
                    {
                        multiVoice.Speech(fragments);
                    }
                    if (Voice2Play != null)
                    {
                        Voice2Play(
                            this,
                            new Voice2PlayArgs()
                            {
                                voiceTxMsg = tmp,
                                chatData = chat,
                            }
                            );
                    }
                }
                else
                {
                    logger.Log(
                        "T2S: useVoice==false because: " + useVoice_falseDescript + "\r\n"
                        + "Origin: " + "[" + chat.nn + "]" + chat.txt
                        );
                }
                chat = null;
            }
        }

        private string _Voice_LocalDir = null;
        private string Voice_LocalDir
        {
            get
            {
                if (_Voice_LocalDir == null)
                {
                    _Voice_LocalDir = Application.StartupPath + "\\VoiceFiles";
                    if (Directory.Exists(_Voice_LocalDir) == false)
                    {
                        Directory.CreateDirectory(_Voice_LocalDir);
                    }
                }
                return _Voice_LocalDir;
            }
        }
        private void Voice_SaveFileToLocal(List<T2S_HCore.Classes.MultiVoice.TextMultiFragments.Fragment> fragments)
        {
            multiVoice.broadCaster.SaveWave_FStream_MultiLangInOne
                               (
                               fragments,
                               multiVoice.voiceLangLib,
                               Voice_LocalDir + "\\" + conf.DateTimeNow_FullString_FileName + ".wav"

                               );
        }
        private void Voice_MoveLocalFileToRemoteDir()
        {
            if (Directory.Exists(conf.Voice_RemoteDir) == false)
            {
                return;
            }
            DirectoryInfo di = new DirectoryInfo(Voice_LocalDir);
            foreach (FileInfo fi in di.GetFiles("*.wav"))
            {
                try
                {
                    File.Move(fi.FullName, conf.Voice_RemoteDir + "\\" + fi.Name);
                }
                catch
                {
                }
            }

        }

        private void Voice_SaveFileToRemote_Directly(List<T2S_HCore.Classes.MultiVoice.TextMultiFragments.Fragment> fragments)
        {
            if (Directory.Exists(conf.Voice_RemoteDir) == false)
            {
                logger.Log("ERROR: conf.Voice_RemoteDir NOT Exists!");
                System.Media.SystemSounds.Hand.Play();
                return;
            }
            multiVoice.broadCaster.SaveWave_FStream_MultiLangInOne
                               (
                               fragments,
                               multiVoice.voiceLangLib,
                               conf.Voice_RemoteDir + "\\" + conf.DateTimeNow_FullString_FileName + ".wav"

                               );
        }

        private bool Check_BlackUser(string userName)
        {
            foreach (string u in hash_blackUsers)
            {
                if (u == userName)
                {
                    return false;
                }
            }
            return true;
        }
        private void TxtProc_Pre(ref List<T2S_HCore.Classes.MultiVoice.TextMultiFragments.Fragment> fragments)
        {
            if (conf.TxtInsp_isRemoveSpace_inChinese == true)
            {
                T2S_HCore.Classes.MultiVoice.TextMultiFragments.Fragment fragment;
                for (int i = fragments.Count - 1; i >= 0; i--)
                {
                    fragment = fragments[i];
                    switch (fragment.fgLang)
                    {
                        case T2S_HCore.Classes.MultiVoice.LanguageType.ZH:
                        case T2S_HCore.Classes.MultiVoice.LanguageType.JA:
                            fragment.fgValue = fragment.fgValue.Replace(" ", "");
                            fragments[i] = fragment;
                            break;
                    }
                }
            }
        }
        private bool Check_5SameChar(List<T2S_HCore.Classes.MultiVoice.TextMultiFragments.Fragment> fragments)
        {
            string fragStr;
            bool pass = true;
            foreach (T2S_HCore.Classes.MultiVoice.TextMultiFragments.Fragment frag in fragments)
            {
                //fragStr = frag.fgValue.Replace(" ", "");
                pass = Check_5SameChar(frag.fgValue);
                if (pass == false)
                {
                    break;
                }
            }
            return pass;
        }
        private bool Check_5SameChar(string text)
        {
            bool pass = true;
            text = text.Replace(" ", "");
            if (text.Length < 5)
            { }
            else
            {
                string c = text.Substring(0, 1);
                pass = false;
                for (int i = 1; i < text.Length && i < 5; i++)
                {
                    if (c != text.Substring(i, 1))
                    {
                        pass = true;
                        break;
                    }
                }
            }
            return pass;
        }
        private bool Check_3SameWord(List<T2S_HCore.Classes.MultiVoice.TextMultiFragments.Fragment> fragments)
        {
            bool pass = true;
            foreach (T2S_HCore.Classes.MultiVoice.TextMultiFragments.Fragment frag in fragments)
            {
                pass = Check_3SameWord(frag.fgValue);
                if (pass == false)
                {
                    break;
                }
            }
            return pass;
        }
        private bool Check_3SameWord(string text)
        {
            string sub2, sub3;
            bool pass = true;

            text = text.Replace(" ", "");

            if (text.Length < 6)
            { }
            else
            {
                pass = false;
                sub2 = text.Substring(0, 2);
                for (int i = 2; i < text.Length && i < 6; i += 2)
                {
                    if (sub2 != text.Substring(i, 2))
                    {
                        pass = true;
                        break;
                    }
                }
                if (pass == false)
                {
                    return false;
                }

                if (text.Length < 9)
                { }
                else
                {
                    pass = false;
                    sub3 = text.Substring(0, 3);
                    for (int i = 3; i < text.Length && i < 9; i += 3)
                    {
                        if (sub3 != text.Substring(i, 3))
                        {
                            pass = true;
                            break;
                        }
                    }
                }
            }
            return pass;
        }
        private void TxtProc_WordReplace(ref List<T2S_HCore.Classes.MultiVoice.TextMultiFragments.Fragment> fragments)
        {
            T2S_HCore.Classes.MultiVoice.TextMultiFragments.Fragment frag;
            for (int i = fragments.Count - 1; i >= 0; i--)
            {
                frag = fragments[i];
                frag.fgValue = TxtProc_WordReplace(frag.fgValue);
                fragments[i] = frag;
            }
        }
        private string TxtProc_WordReplace(string text)
        {
            foreach (KeyValuePair<string, string> kv in dict_wordReplace)
            {
                while (text.Contains(kv.Key))
                {
                    text = text.Replace(kv.Key, kv.Value);
                }
            }
            return text;
        }
        private bool Check_BlackKeyWords(List<T2S_HCore.Classes.MultiVoice.TextMultiFragments.Fragment> fragments)
        {
            T2S_HCore.Classes.MultiVoice.TextMultiFragments.Fragment frag;
            for (int i = fragments.Count - 1; i >= 0; i--)
            {
                frag = fragments[i];
                if (Check_BlackKeyWords(frag.fgValue) == false)
                {
                    return false;
                }
            }
            return true;
        }
        private bool Check_BlackKeyWords(string text)
        {
            foreach (string k in hash_blackKeyWords)
            {
                if (text.Contains(k) == true)
                {
                    return false;
                }
            }
            return true;
        }
        private bool Check_BlackPinYin_Ends(List<string> pinyinList)
        {
            foreach (string py in pinyinList)
            {
                foreach (string k in hash_blackPinyin_ends)
                {
                    if (py.EndsWith(k))
                    {
                        return false;
                    }
                }
            }
            return true;
        }
        private bool Check_BlackPinYin_Contains(List<string> pinyinList)
        {
            foreach (string py in pinyinList)
            {
                foreach (string k in hash_blackPinyin_contains)
                {
                    if (py.Contains(k))
                    {
                        return false;
                    }
                }
            }
            return true;
        }
        private bool Check_BlackPinYin_Starts(List<string> pinyinList)
        {
            foreach (string py in pinyinList)
            {
                foreach (string k in hash_blackPinyin_starts)
                {
                    if (py.StartsWith(k))
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        public void RemoteTest(string txt)
        {
            Dictionary<string, object> dict = new Dictionary<string, object>();
            dict.Add("nn", "tester");
            dict.Add("txt", txt);
            chat = new DYBullet.DyBulletHelper.Bullet.iStructedMsg.iChat(dict);
        }

        public class FaceDescriptionHelper
        {
            private static string KEY_FACE_RELNAME = "relName:\"";
            private static string KEY_FACE_TITLE = "title:\"";
            public struct FaceInfo
            {
                public string id;
                public string name;
                public Image image;
            }
            public List<FaceInfo> faceList = new List<FaceInfo>();
            public void ReLoadFaceList_FromPageCode(string code)
            {
                //{className:"face_102",relName:"dy102",title:"发呆"},
                faceList.Clear();
                bool found = true;
                string valueId, valueName;
                int idxFRK = -1;
                int idxFTK = -1;
                while (found)
                {
                    idxFRK = code.IndexOf(KEY_FACE_RELNAME);
                    if (idxFRK >= 0)
                    {
                        code = code.Substring(idxFRK + KEY_FACE_RELNAME.Length);
                        valueId = code.Substring(0, code.IndexOf('\"'));

                        idxFTK = code.IndexOf(KEY_FACE_TITLE);
                        if (idxFTK >= 0)
                        {
                            code = code.Substring(idxFTK + KEY_FACE_TITLE.Length);
                            valueName = code.Substring(0, code.IndexOf('\"'));

                            //[emot:dy105]
                            faceList.Add(
                                new FaceInfo()
                                {
                                    id = valueId,
                                    name = valueName
                                }
                                );
                        }
                        else
                        {
                            found = false;
                        }
                    }
                    else
                    {
                        found = false;
                    }
                }
            }

            public void SaveFaceList_NoImage()
            {
                if (faceList.Count > 0)
                {
                    SQLiteDBHelper dbHelper = SQLiteDBHelper.GetInstance();
                    int listLeng = faceList.Count;
                    string[] idList = new string[listLeng];
                    string[] nameList = new string[listLeng];
                    FaceInfo fi;
                    for (int i = 0; i < listLeng; i++)
                    {
                        fi = faceList[i];
                        idList[i] = fi.id;
                        nameList[i] = fi.name;
                    }
                    dbHelper.AddOrReplaceRow_EmotList(idList, nameList);
                }
            }
            public void LoadFaceList()
            {
                faceList.Clear();
                SQLiteDBHelper dbHelper = SQLiteDBHelper.GetInstance();
                DataTable dt = dbHelper.Reload_EmotList();
                foreach (DataRow dr in dt.Rows)
                {
                    faceList.Add(
                        new FaceInfo()
                        {
                            id = (string)dr["ID"],
                            name = (string)dr["Name"],
                            //image = (dr["Image"] == null) ? null : (Image)dr["Image"]
                        }
                        );
                }
            }
            public string ReplaceSymbolToTitle(string sourceText)
            {
                //[emot:" + valueId + "]
                string tx;
                foreach (FaceInfo fi in faceList)
                {
                    tx = "[emot:" + fi.id + "]";
                    if (sourceText.Contains(tx))
                    {
                        sourceText = sourceText.Replace(tx, fi.name);
                    }
                }
                return sourceText;
            }

            public string GetFaceListString()
            {
                string result = "";
                foreach (FaceInfo faceItem in faceList)
                {
                    result += faceItem.id + ":" + faceItem.name + ", ";
                }
                result = result.TrimEnd().TrimEnd(',');
                return result;
            }
        }
        public FaceDescriptionHelper faceSymbHelper = new FaceDescriptionHelper();

        /// <summary>
        /// 汉字转拼音类
        /// </summary>
        public class Chinese2PINYIN
        {
            private static int[] pyValue = new int[]
                    {
                -20319,-20317,-20304,-20295,-20292,-20283,-20265,-20257,-20242,-20230,-20051,-20036,
                -20032,-20026,-20002,-19990,-19986,-19982,-19976,-19805,-19784,-19775,-19774,-19763,
                -19756,-19751,-19746,-19741,-19739,-19728,-19725,-19715,-19540,-19531,-19525,-19515,
                -19500,-19484,-19479,-19467,-19289,-19288,-19281,-19275,-19270,-19263,-19261,-19249,
                -19243,-19242,-19238,-19235,-19227,-19224,-19218,-19212,-19038,-19023,-19018,-19006,
                -19003,-18996,-18977,-18961,-18952,-18783,-18774,-18773,-18763,-18756,-18741,-18735,
                -18731,-18722,-18710,-18697,-18696,-18526,-18518,-18501,-18490,-18478,-18463,-18448,
                -18447,-18446,-18239,-18237,-18231,-18220,-18211,-18201,-18184,-18183, -18181,-18012,
                -17997,-17988,-17970,-17964,-17961,-17950,-17947,-17931,-17928,-17922,-17759,-17752,
                -17733,-17730,-17721,-17703,-17701,-17697,-17692,-17683,-17676,-17496,-17487,-17482,
                -17468,-17454,-17433,-17427,-17417,-17202,-17185,-16983,-16970,-16942,-16915,-16733,
                -16708,-16706,-16689,-16664,-16657,-16647,-16474,-16470,-16465,-16459,-16452,-16448,
                -16433,-16429,-16427,-16423,-16419,-16412,-16407,-16403,-16401,-16393,-16220,-16216,
                -16212,-16205,-16202,-16187,-16180,-16171,-16169,-16158,-16155,-15959,-15958,-15944,
                -15933,-15920,-15915,-15903,-15889,-15878,-15707,-15701,-15681,-15667,-15661,-15659,
                -15652,-15640,-15631,-15625,-15454,-15448,-15436,-15435,-15419,-15416,-15408,-15394,
                -15385,-15377,-15375,-15369,-15363,-15362,-15183,-15180,-15165,-15158,-15153,-15150,
                -15149,-15144,-15143,-15141,-15140,-15139,-15128,-15121,-15119,-15117,-15110,-15109,
                -14941,-14937,-14933,-14930,-14929,-14928,-14926,-14922,-14921,-14914,-14908,-14902,
                -14894,-14889,-14882,-14873,-14871,-14857,-14678,-14674,-14670,-14668,-14663,-14654,
                -14645,-14630,-14594,-14429,-14407,-14399,-14384,-14379,-14368,-14355,-14353,-14345,
                -14170,-14159,-14151,-14149,-14145,-14140,-14137,-14135,-14125,-14123,-14122,-14112,
                -14109,-14099,-14097,-14094,-14092,-14090,-14087,-14083,-13917,-13914,-13910,-13907,
                -13906,-13905,-13896,-13894,-13878,-13870,-13859,-13847,-13831,-13658,-13611,-13601,
                -13406,-13404,-13400,-13398,-13395,-13391,-13387,-13383,-13367,-13359,-13356,-13343,
                -13340,-13329,-13326,-13318,-13147,-13138,-13120,-13107,-13096,-13095,-13091,-13076,
                -13068,-13063,-13060,-12888,-12875,-12871,-12860,-12858,-12852,-12849,-12838,-12831,
                -12829,-12812,-12802,-12607,-12597,-12594,-12585,-12556,-12359,-12346,-12320,-12300,
                -12120,-12099,-12089,-12074,-12067,-12058,-12039,-11867,-11861,-11847,-11831,-11798,
                -11781,-11604,-11589,-11536,-11358,-11340,-11339,-11324,-11303,-11097,-11077,-11067,
                -11055,-11052,-11045,-11041,-11038,-11024,-11020,-11019,-11018,-11014,-10838,-10832,
                -10815,-10800,-10790,-10780,-10764,-10587,-10544,-10533,-10519,-10331,-10329,-10328,
                -10322,-10315,-10309,-10307,-10296,-10281,-10274,-10270,-10262,-10260,-10256,-10254
                    };

            private static string[] pyName = new string[]
                    {
                "A","Ai","An","Ang","Ao","Ba","Bai","Ban","Bang","Bao","Bei","Ben",
                "Beng","Bi","Bian","Biao","Bie","Bin","Bing","Bo","Bu","Ba","Cai","Can",
                "Cang","Cao","Ce","Ceng","Cha","Chai","Chan","Chang","Chao","Che","Chen","Cheng",
                "Chi","Chong","Chou","Chu","Chuai","Chuan","Chuang","Chui","Chun","Chuo","Ci","Cong",
                "Cou","Cu","Cuan","Cui","Cun","Cuo","Da","Dai","Dan","Dang","Dao","De",
                "Deng","Di","Dian","Diao","Die","Ding","Diu","Dong","Dou","Du","Duan","Dui",
                "Dun","Duo","E","En","Er","Fa","Fan","Fang","Fei","Fen","Feng","Fo",
                "Fou","Fu","Ga","Gai","Gan","Gang","Gao","Ge","Gei","Gen","Geng","Gong",
                "Gou","Gu","Gua","Guai","Guan","Guang","Gui","Gun","Guo","Ha","Hai","Han",
                "Hang","Hao","He","Hei","Hen","Heng","Hong","Hou","Hu","Hua","Huai","Huan",
                "Huang","Hui","Hun","Huo","Ji","Jia","Jian","Jiang","Jiao","Jie","Jin","Jing",
                "Jiong","Jiu","Ju","Juan","Jue","Jun","Ka","Kai","Kan","Kang","Kao","Ke",
                "Ken","Keng","Kong","Kou","Ku","Kua","Kuai","Kuan","Kuang","Kui","Kun","Kuo",
                "La","Lai","Lan","Lang","Lao","Le","Lei","Leng","Li","Lia","Lian","Liang",
                "Liao","Lie","Lin","Ling","Liu","Long","Lou","Lu","Lv","Luan","Lue","Lun",
                "Luo","Ma","Mai","Man","Mang","Mao","Me","Mei","Men","Meng","Mi","Mian",
                "Miao","Mie","Min","Ming","Miu","Mo","Mou","Mu","Na","Nai","Nan","Nang",
                "Nao","Ne","Nei","Nen","Neng","Ni","Nian","Niang","Niao","Nie","Nin","Ning",
                "Niu","Nong","Nu","Nv","Nuan","Nue","Nuo","O","Ou","Pa","Pai","Pan",
                "Pang","Pao","Pei","Pen","Peng","Pi","Pian","Piao","Pie","Pin","Ping","Po",
                "Pu","Qi","Qia","Qian","Qiang","Qiao","Qie","Qin","Qing","Qiong","Qiu","Qu",
                "Quan","Que","Qun","Ran","Rang","Rao","Re","Ren","Reng","Ri","Rong","Rou",
                "Ru","Ruan","Rui","Run","Ruo","Sa","Sai","San","Sang","Sao","Se","Sen",
                "Seng","Sha","Shai","Shan","Shang","Shao","She","Shen","Sheng","Shi","Shou","Shu",
                "Shua","Shuai","Shuan","Shuang","Shui","Shun","Shuo","Si","Song","Sou","Su","Suan",
                "Sui","Sun","Suo","Ta","Tai","Tan","Tang","Tao","Te","Teng","Ti","Tian",
                "Tiao","Tie","Ting","Tong","Tou","Tu","Tuan","Tui","Tun","Tuo","Wa","Wai",
                "Wan","Wang","Wei","Wen","Weng","Wo","Wu","Xi","Xia","Xian","Xiang","Xiao",
                "Xie","Xin","Xing","Xiong","Xiu","Xu","Xuan","Xue","Xun","Ya","Yan","Yang",
                "Yao","Ye","Yi","Yin","Ying","Yo","Yong","You","Yu","Yuan","Yue","Yun",
                "Za", "Zai","Zan","Zang","Zao","Ze","Zei","Zen","Zeng","Zha","Zhai","Zhan",
                "Zhang","Zhao","Zhe","Zhen","Zheng","Zhi","Zhong","Zhou","Zhu","Zhua","Zhuai","Zhuan",
                "Zhuang","Zhui","Zhun","Zhuo","Zi","Zong","Zou","Zu","Zuan","Zui","Zun","Zuo"
                    };

            /// <summary>
            /// 把汉字转换成拼音(全拼)
            /// </summary>
            /// <param name="hzString">汉字字符串</param>
            /// <returns>转换后的拼音(全拼)字符串</returns>
            public static string Convert(string hzString)
            {
                if (hzString == null)
                {
                    return null;
                }
                // 匹配中文字符
                Regex regex = new Regex("^[\u4e00-\u9fa5]$");
                byte[] array = new byte[2];
                string pyString = "";
                int chrAsc = 0;
                int i1 = 0;
                int i2 = 0;
                char[] noWChar = hzString.ToCharArray();

                for (int j = 0; j < noWChar.Length; j++)
                {
                    // 中文字符
                    if (regex.IsMatch(noWChar[j].ToString()))
                    {
                        array = System.Text.Encoding.Default.GetBytes(noWChar[j].ToString());
                        i1 = (short)(array[0]);
                        i2 = (short)(array[1]);
                        chrAsc = i1 * 256 + i2 - 65536;
                        if (chrAsc > 0 && chrAsc < 160)
                        {
                            pyString += noWChar[j];
                        }
                        else
                        {
                            // 修正部分文字
                            if (chrAsc == -9254)  // 修正“圳”字
                                pyString += "Zhen";
                            else
                            {
                                for (int i = (pyValue.Length - 1); i >= 0; i--)
                                {
                                    if (pyValue[i] <= chrAsc)
                                    {
                                        pyString += pyName[i];
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    // 非中文字符
                    else
                    {
                        pyString += noWChar[j].ToString();
                    }
                }
                return pyString;
            }

            ///   <summary> 
            ///   得到一个汉字的拼音第一个字母，如果是一个英文字母则直接返回大写字母 
            ///   </summary> 
            ///   <param   name="CnChar">单个汉字</param> 
            ///   <returns>单个大写字母</returns> 
            private static string GetCharSpellCode(string CnChar)
            {
                long iCnChar;

                byte[] ZW = System.Text.Encoding.Default.GetBytes(CnChar);

                //如果是字母，则直接返回 
                if (ZW.Length == 1)
                {
                    return CnChar.ToUpper();
                }
                else
                {
                    //   get   the     array   of   byte   from   the   single   char    
                    int i1 = (short)(ZW[0]);
                    int i2 = (short)(ZW[1]);
                    iCnChar = i1 * 256 + i2;
                }
                #region table   of   the   constant   list
                //expresstion 
                //table   of   the   constant   list 
                // 'A';           //45217..45252 
                // 'B';           //45253..45760 
                // 'C';           //45761..46317 
                // 'D';           //46318..46825 
                // 'E';           //46826..47009 
                // 'F';           //47010..47296 
                // 'G';           //47297..47613 

                // 'H';           //47614..48118 
                // 'J';           //48119..49061 
                // 'K';           //49062..49323 
                // 'L';           //49324..49895 
                // 'M';           //49896..50370 
                // 'N';           //50371..50613 
                // 'O';           //50614..50621 
                // 'P';           //50622..50905 
                // 'Q';           //50906..51386 

                // 'R';           //51387..51445 
                // 'S';           //51446..52217 
                // 'T';           //52218..52697 
                //没有U,V 
                // 'W';           //52698..52979 
                // 'X';           //52980..53640 
                // 'Y';           //53689..54480 
                // 'Z';           //54481..55289 
                #endregion
                //   iCnChar match     the   constant 
                if ((iCnChar >= 45217) && (iCnChar <= 45252))
                {
                    return "A";
                }
                else if ((iCnChar >= 45253) && (iCnChar <= 45760))
                {
                    return "B";
                }
                else if ((iCnChar >= 45761) && (iCnChar <= 46317))
                {
                    return "C";
                }
                else if ((iCnChar >= 46318) && (iCnChar <= 46825))
                {
                    return "D";
                }
                else if ((iCnChar >= 46826) && (iCnChar <= 47009))
                {
                    return "E";
                }
                else if ((iCnChar >= 47010) && (iCnChar <= 47296))
                {
                    return "F";
                }
                else if ((iCnChar >= 47297) && (iCnChar <= 47613))
                {
                    return "G";
                }
                else if ((iCnChar >= 47614) && (iCnChar <= 48118))
                {
                    return "H";
                }
                else if ((iCnChar >= 48119) && (iCnChar <= 49061))
                {
                    return "J";
                }
                else if ((iCnChar >= 49062) && (iCnChar <= 49323))
                {
                    return "K";
                }
                else if ((iCnChar >= 49324) && (iCnChar <= 49895))
                {
                    return "L";
                }
                else if ((iCnChar >= 49896) && (iCnChar <= 50370))
                {
                    return "M";
                }

                else if ((iCnChar >= 50371) && (iCnChar <= 50613))
                {
                    return "N";
                }
                else if ((iCnChar >= 50614) && (iCnChar <= 50621))
                {
                    return "O";
                }
                else if ((iCnChar >= 50622) && (iCnChar <= 50905))
                {
                    return "P";
                }
                else if ((iCnChar >= 50906) && (iCnChar <= .51386))
                {
                    return "Q";
                }
                else if ((iCnChar >= 51387) && (iCnChar <= 51445))
                {
                    return "R";
                }
                else if ((iCnChar >= 51446) && (iCnChar <= 52217))
                {
                    return "S";
                }
                else if ((iCnChar >= 52218) && (iCnChar <= 52697))
                {
                    return "T";
                }
                else if ((iCnChar >= 52698) && (iCnChar <= 52979))
                {
                    return "W";
                }
                else if ((iCnChar >= 52980) && (iCnChar <= 53640))
                {
                    return "X";
                }
                else if ((iCnChar >= 53689) && (iCnChar <= 54480))
                {
                    return "Y";
                }
                else if ((iCnChar >= 54481) && (iCnChar <= 55289))
                {
                    return "Z";
                }
                else return ("?");
            }
        }

    }
}
