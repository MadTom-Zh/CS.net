﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.IO;

namespace PageSecretary_V2_by_longtombbj.Class
{
    /// <summary>
    /// 将所有内容存入一个文件中
    /// 如果有需要，请再做一个日志查看器，专门用于筛选内容
    /// </summary>
    class Logger
    {
        public static Logger instance;
        public static Logger GetInstance()
        {
            if (instance == null)
            {
                instance = new Logger();
            }
            return instance;
        }
        public Logger()
        {
            conf = Config.GetInstance();
            _FileDirPath = FileDirPath;
            NewLogFileName();
        }
        private void NewLogFileName()
        {
            logFileName = conf.DateTimeNow_FullString_FileName + ".txt";
        }

        private Config conf;
        private string _FileDirPath = null;
        public string FileDirPath
        {
            get
            {
                string result = conf.LogFile_DirPath;
                if (Directory.Exists(result) == false)
                {
                    result = AppDomain.CurrentDomain.BaseDirectory + "\\Log";
                    if (Directory.Exists(result) == false)
                    {
                        Directory.CreateDirectory(result);
                    }
                    conf.LogFile_DirPath = result;
                }
                _FileDirPath = result;
                return result;
            }
            set
            {
                conf.LogFile_DirPath = value;
                _FileDirPath = value;
            }
        }

        private int logFileMaxLength = 2048000;
        private int logFileCurLength = 0;
        private string logFileName = null;
        public void Log(string line)
        {
            string content;
            logFileCurLength += line.Length + 4;
            if (logFileCurLength > logFileMaxLength)
            {
                NewLogFileName();
                logFileCurLength = line.Length + 4;
                content = line;
            }
            else
            {
                content = "\r\n\r\n" + line;
            }
            File.AppendAllText(_FileDirPath + "\\" + logFileName, content);
        }
    }
}
