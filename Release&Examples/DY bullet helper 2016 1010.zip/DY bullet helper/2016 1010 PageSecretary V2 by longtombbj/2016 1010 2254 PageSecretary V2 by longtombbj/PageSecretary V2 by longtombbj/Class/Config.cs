﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Configuration;
using System.Xml;
using System.Xml.Serialization;
using System.IO;

namespace PageSecretary_V2_by_longtombbj.Class
{
    public class Config
    {
        public static Config instance;
        public static Config GetInstance()
        {
            if (instance == null)
            {
                instance = new Config();
                instance.ReLoad();
            }
            return instance;
        }

        private static string saveFileFullPath
            = AppDomain.CurrentDomain.BaseDirectory + "\\config.xml";
        public void ReLoad()
        {
            using (FileStream fileStream = new FileStream(saveFileFullPath, FileMode.OpenOrCreate))
            {
                try
                {
                    XmlSerializer xmlFormatter = new XmlSerializer(typeof(SerializableDictionary<string, string>));
                    dict = (SerializableDictionary<string, string>)xmlFormatter.Deserialize(fileStream);
                }
                catch
                {
                    dict = new SerializableDictionary<string, string>();
                }
            }
        }
        public void Save()
        {
            using (FileStream fileStream = new FileStream(saveFileFullPath, FileMode.Create))
            {
                XmlSerializer xmlFormatter = new XmlSerializer(typeof(SerializableDictionary<string, string>));
                xmlFormatter.Serialize(fileStream, dict);
            }
        }

        private SerializableDictionary<string, string> dict = new SerializableDictionary<string, string>();
        private string ReadSetting(string key)
        {
            if (key == null) return null;
            if (dict.ContainsKey(key) == true)
            {
                return dict[key];
            }
            return null;
        }
        private void AddUpdateAppSettings(string key, string value)
        {
            if (dict.ContainsKey(key))
            {
                dict[key] = value;
            }
            else
            {
                dict.Add(key, value);
            }
        }

        private static string KEY_ROOM_ID = "RoomId";
        private static string KEY_LOGFILE_DIRPATH = "LogFile_DirPath";
        private static string KEY_USER_ID = "UserID";
        private static string KEY_USER_NICK_NAME = "UserNickName";

        private static string KEY_IS_REMOVE_SPACE_IN_CHINESE = "isRemoveSpaceInChinese";
        private static string KEY_IS_CHECK_5CHAR_IN_CHINESE = "isCheck5SameCharInChinese";
        private static string KEY_IS_CHECK_3WORD_IN_CHINESE = "isCheck3SameWordInChinese";

        private static string KEY_IS_ENABLE_VOICE = "isVoiceEnabled";
        private static string KEY_VOICE_CYCLE_TIME = "cycleTimeOfVoice";
        private static string KEY_VOICE_BETWEEN_TIME = "timeBetweenVoices";
        private static string KEY_IS_USING_REMOTE_VOICE = "isUsingRemoteVoice";
        private static string KEY_REMOTE_VOICE_DIR = "remoteVoiceDir";

        private static string KEY_ONLY_FOR_TOM = "only4Tom";
        private static string KEY_GIFT_LIST_PAGE_URL = "giftListPageURL";
        private static string KEY_FACE_LIST_PAGE_URL = "faceListPageURL";

        private static string KEY_VOICE_IF_SPEECH_GIFT = "ifSpeechGift";
        private static string KEY_VOICE_IF_SPEECH_CHAT = "ifSpeechChat";

        private static string KEY_TXT_TO_HALFWIDTH_FORMS = "changeCommaExcQueToHalfwidthForms";

        //private static string KEY_FACE_LIST = "faceList";
        //private static string KEY_GIFT_LIST = "giftList";


        private string _RoomId = null;
        public string RoomId
        {
            set
            {
                _RoomId = value;
                AddUpdateAppSettings(KEY_ROOM_ID, value);
            }
            get
            {
                if (_RoomId != null) return _RoomId;
                _RoomId = ReadSetting(KEY_ROOM_ID);
                if (_RoomId == "Not Found" || _RoomId == null || _RoomId.Length == 0)
                {
                    _RoomId = "315092";
                    AddUpdateAppSettings(KEY_ROOM_ID, _RoomId);
                }
                return _RoomId;
            }
        }

        public string DateTimeNow_FullString_FileName
        {
            get
            {
                return DateTime.Now.ToString("yyyy-MM-dd HH_mm_ss.fff");
            }
        }
        public string DateTimeNow_FullString
        {
            get
            {
                return DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
            }
        }

        private string _LogFile_DirPath = null;
        public string LogFile_DirPath
        {
            set
            {
                _LogFile_DirPath = value;
                AddUpdateAppSettings(KEY_LOGFILE_DIRPATH, value);
            }
            get
            {
                if (_LogFile_DirPath != null) return _LogFile_DirPath;
                return ReadSetting(_LogFile_DirPath);
            }
        }

        private string _User_Id = null;
        public string User_Id
        {
            set
            {
                _User_Id = value;
                AddUpdateAppSettings(KEY_USER_ID, value);
            }
            get
            {
                if (_User_Id != null) return _User_Id;
                _User_Id = ReadSetting(KEY_USER_ID);
                if (_User_Id == "Not Found" || _User_Id == null || _User_Id.Length == 0)
                {
                    _User_Id = "22101827";
                    AddUpdateAppSettings(KEY_USER_ID, _User_Id);
                }
                return _User_Id;
            }
        }
        private string _User_NickName = null;
        public string User_NickName
        {
            set
            {
                _User_NickName = value;
                AddUpdateAppSettings(KEY_USER_NICK_NAME, value);
            }
            get
            {
                if (_User_NickName != null) return _User_NickName;
                _User_NickName = ReadSetting(KEY_USER_NICK_NAME);
                if (_User_NickName == "Not Found" || _User_NickName == null || _User_NickName.Length == 0)
                {
                    _User_NickName = "longtombbj";
                    AddUpdateAppSettings(KEY_USER_NICK_NAME, _User_NickName);
                }
                return _User_NickName;
            }
        }

        private bool? _TxtInsp_isRemoveSpace_inChinese = null;
        public bool TxtInsp_isRemoveSpace_inChinese
        {
            set
            {
                _TxtInsp_isRemoveSpace_inChinese = value;
                AddUpdateAppSettings(KEY_IS_REMOVE_SPACE_IN_CHINESE, value.ToString());
            }
            get
            {
                if (_TxtInsp_isRemoveSpace_inChinese != null) return _TxtInsp_isRemoveSpace_inChinese == true;
                string resultStr = ReadSetting(KEY_IS_REMOVE_SPACE_IN_CHINESE);
                _TxtInsp_isRemoveSpace_inChinese = true;
                if (resultStr == "Not Found" || resultStr == null || resultStr.Length == 0)
                {
                    AddUpdateAppSettings(KEY_IS_REMOVE_SPACE_IN_CHINESE, true.ToString());
                }
                else
                {
                    _TxtInsp_isRemoveSpace_inChinese = bool.Parse(resultStr);
                }
                return _TxtInsp_isRemoveSpace_inChinese == true;
            }
        }
        private bool? _TxtInsp_isCheck_5SameChar_inChineser = null;
        public bool TxtInsp_isCheck_5SameChar_inChineser
        {
            set
            {
                _TxtInsp_isCheck_5SameChar_inChineser = value;
                AddUpdateAppSettings(KEY_IS_CHECK_5CHAR_IN_CHINESE, value.ToString());
            }
            get
            {
                if (_TxtInsp_isCheck_5SameChar_inChineser != null) return _TxtInsp_isCheck_5SameChar_inChineser == true;
                string resultStr = ReadSetting(KEY_IS_CHECK_5CHAR_IN_CHINESE);
                _TxtInsp_isCheck_5SameChar_inChineser = false;
                if (resultStr == "Not Found" || resultStr == null || resultStr.Length == 0)
                {
                    AddUpdateAppSettings(KEY_IS_CHECK_5CHAR_IN_CHINESE, false.ToString());
                }
                else
                {
                    _TxtInsp_isCheck_5SameChar_inChineser = bool.Parse(resultStr);
                }
                return _TxtInsp_isCheck_5SameChar_inChineser == true;
            }
        }
        private bool? _TxtInsp_isCheck_3SameWord_inChineser = null;
        public bool TxtInsp_isCheck_3SameWord_inChineser
        {
            set
            {
                _TxtInsp_isCheck_3SameWord_inChineser = value;
                AddUpdateAppSettings(KEY_IS_CHECK_3WORD_IN_CHINESE, value.ToString());
            }
            get
            {
                if (_TxtInsp_isCheck_3SameWord_inChineser != null) return _TxtInsp_isCheck_3SameWord_inChineser == true;
                string resultStr = ReadSetting(KEY_IS_CHECK_3WORD_IN_CHINESE);
                _TxtInsp_isCheck_3SameWord_inChineser = false;
                if (resultStr == "Not Found" || resultStr == null || resultStr.Length == 0)
                {
                    AddUpdateAppSettings(KEY_IS_CHECK_3WORD_IN_CHINESE, false.ToString());
                }
                else
                {
                    _TxtInsp_isCheck_3SameWord_inChineser = bool.Parse(resultStr);
                }
                return _TxtInsp_isCheck_3SameWord_inChineser == true;
            }
        }


        private bool? _Voice_IsEnabled = null;
        public bool Voice_IsEnabled
        {
            set
            {
                _Voice_IsEnabled = value;
                AddUpdateAppSettings(KEY_IS_ENABLE_VOICE, value.ToString());
            }
            get
            {
                if (_Voice_IsEnabled != null) return _Voice_IsEnabled == true;
                string resultStr = ReadSetting(KEY_IS_ENABLE_VOICE);
                _Voice_IsEnabled = true;
                if (resultStr == "Not Found" || resultStr == null || resultStr.Length == 0)
                {
                    AddUpdateAppSettings(KEY_IS_ENABLE_VOICE, true.ToString());
                }
                else
                {
                    _Voice_IsEnabled = bool.Parse(resultStr);
                }
                return _Voice_IsEnabled == true;
            }
        }
        private int _Voice_CycleTime = -99;
        public int Voice_CycleTime
        {
            set
            {
                _Voice_CycleTime = value;
                AddUpdateAppSettings(KEY_VOICE_CYCLE_TIME, value + "");
            }
            get
            {
                if (_Voice_CycleTime != -99) return _Voice_CycleTime;
                string resultStr = ReadSetting(KEY_VOICE_CYCLE_TIME);
                if (resultStr == "Not Found" || resultStr == null || resultStr.Length == 0)
                {
                    resultStr = "15";
                    AddUpdateAppSettings(KEY_VOICE_CYCLE_TIME, resultStr);
                }
                _Voice_CycleTime = int.Parse(resultStr);
                return _Voice_CycleTime;
            }
        }
        private int _Voice_TimeBetweenVoices = -99;
        public int Voice_TimeBetweenVoices
        {
            set
            {
                _Voice_TimeBetweenVoices = value;
                AddUpdateAppSettings(KEY_VOICE_BETWEEN_TIME, value + "");
            }
            get
            {
                if (_Voice_TimeBetweenVoices != -99) return _Voice_TimeBetweenVoices;
                string resultStr = ReadSetting(KEY_VOICE_BETWEEN_TIME);
                if (resultStr == "Not Found" || resultStr == null || resultStr.Length == 0)
                {
                    resultStr = "8";
                    AddUpdateAppSettings(KEY_VOICE_BETWEEN_TIME, resultStr);
                }
                _Voice_TimeBetweenVoices = int.Parse(resultStr);
                return _Voice_TimeBetweenVoices;
            }
        }
        private bool? _Voice_IsRemote = null;
        public bool Voice_IsRemote
        {
            set
            {
                _Voice_IsRemote = value;
                AddUpdateAppSettings(KEY_IS_USING_REMOTE_VOICE, value.ToString());
            }
            get
            {
                if (_Voice_IsRemote != null) return _Voice_IsRemote == true;
                string resultStr = ReadSetting(KEY_IS_USING_REMOTE_VOICE);
                _Voice_IsRemote = true;
                if (resultStr == "Not Found" || resultStr == null || resultStr.Length == 0)
                {
                    AddUpdateAppSettings(KEY_IS_USING_REMOTE_VOICE, true.ToString());
                }
                else
                {
                    _Voice_IsRemote = bool.Parse(resultStr);
                }
                return _Voice_IsRemote == true;
            }
        }
        private string _Voice_RemoteDir = null;
        public string Voice_RemoteDir
        {
            set
            {
                _Voice_RemoteDir = value;
                AddUpdateAppSettings(KEY_REMOTE_VOICE_DIR, value);
            }
            get
            {
                if (_Voice_RemoteDir != null) return _Voice_RemoteDir;
                _Voice_RemoteDir = ReadSetting(KEY_REMOTE_VOICE_DIR);
                if (_Voice_RemoteDir == "Not Found" || _Voice_RemoteDir == null || _Voice_RemoteDir.Length == 0)
                {
                    _Voice_RemoteDir = "Z:\\DouyuMsgSound";
                    AddUpdateAppSettings(KEY_REMOTE_VOICE_DIR, _Voice_RemoteDir);
                }
                return _Voice_RemoteDir;
            }
        }

        private bool? _Voice_IsOnlyForTom = null;
        public bool Voice_IsOnlyForTom
        {
            set
            {
                _Voice_IsOnlyForTom = value;
                AddUpdateAppSettings(KEY_ONLY_FOR_TOM, value.ToString());
            }
            get
            {
                if (_Voice_IsOnlyForTom != null) return _Voice_IsOnlyForTom == true;
                string resultStr = ReadSetting(KEY_ONLY_FOR_TOM);
                _Voice_IsOnlyForTom = true;
                if (resultStr == "Not Found" || resultStr == null || resultStr.Length == 0)
                {
                    AddUpdateAppSettings(KEY_ONLY_FOR_TOM, true.ToString());
                }
                else
                {
                    _Voice_IsOnlyForTom = bool.Parse(resultStr);
                }
                return _Voice_IsOnlyForTom == true;
            }
        }

        private string _GiftList_PageURL = null;
        public string GiftList_PageURL
        {
            set
            {
                _GiftList_PageURL = value;
                AddUpdateAppSettings(KEY_GIFT_LIST_PAGE_URL, value);
            }
            get
            {
                if (_GiftList_PageURL != null) return _GiftList_PageURL;
                _GiftList_PageURL = ReadSetting(KEY_GIFT_LIST_PAGE_URL);
                if (_GiftList_PageURL == "Not Found" || _GiftList_PageURL == null || _GiftList_PageURL.Length == 0)
                {
                    _GiftList_PageURL = "http://www.douyu.com/699689";
                    AddUpdateAppSettings(KEY_GIFT_LIST_PAGE_URL, _GiftList_PageURL);
                }
                return _GiftList_PageURL;
            }
        }

        private string _FaceList_PageURL = null;
        public string FaceList_PageURL
        {
            set
            {
                _FaceList_PageURL = value;
                AddUpdateAppSettings(KEY_FACE_LIST_PAGE_URL, value);
            }
            get
            {
                if (_FaceList_PageURL != null) return _FaceList_PageURL;
                _FaceList_PageURL = ReadSetting(KEY_FACE_LIST_PAGE_URL);
                if (_FaceList_PageURL == "Not Found" || _FaceList_PageURL == null || _FaceList_PageURL.Length == 0)
                {
                    _FaceList_PageURL = "https://shark.douyucdn.cn/app/douyu/js/page/room/normal/app-all.js";
                    AddUpdateAppSettings(KEY_FACE_LIST_PAGE_URL, _FaceList_PageURL);
                }
                return _FaceList_PageURL;
            }
        }

        private bool? _Voice_IfSpeechGift = null;
        public bool Voice_IfSpeechGift
        {
            set
            {
                _Voice_IfSpeechGift = value;
                AddUpdateAppSettings(KEY_VOICE_IF_SPEECH_GIFT, value.ToString());
            }
            get
            {
                if (_Voice_IfSpeechGift != null) return _Voice_IfSpeechGift == true;
                string resultStr = ReadSetting(KEY_VOICE_IF_SPEECH_GIFT);
                _Voice_IfSpeechGift = true;
                if (resultStr == "Not Found" || resultStr == null || resultStr.Length == 0)
                {
                    AddUpdateAppSettings(KEY_VOICE_IF_SPEECH_GIFT, true.ToString());
                }
                else
                {
                    _Voice_IfSpeechGift = bool.Parse(resultStr);
                }
                return _Voice_IfSpeechGift == true;
            }
        }
        private bool? _Voice_IfSpeechChat = null;
        public bool Voice_IfSpeechChat
        {
            set
            {
                _Voice_IfSpeechChat = value;
                AddUpdateAppSettings(KEY_VOICE_IF_SPEECH_CHAT, value.ToString());
            }
            get
            {
                if (_Voice_IfSpeechChat != null) return _Voice_IfSpeechChat == true;
                string resultStr = ReadSetting(KEY_VOICE_IF_SPEECH_CHAT);
                _Voice_IfSpeechChat = true;
                if (resultStr == "Not Found" || resultStr == null || resultStr.Length == 0)
                {
                    AddUpdateAppSettings(KEY_VOICE_IF_SPEECH_CHAT, true.ToString());
                }
                else
                {
                    _Voice_IfSpeechChat = bool.Parse(resultStr);
                }
                return _Voice_IfSpeechChat == true;
            }
        }

        private bool? _Txt_ToHalfwidthForms = null;
        public bool Txt_ToHalfwidthForms
        {
            set
            {
                _Txt_ToHalfwidthForms = value;
                AddUpdateAppSettings(KEY_TXT_TO_HALFWIDTH_FORMS, value.ToString());
            }
            get
            {
                if (_Txt_ToHalfwidthForms != null) return _Txt_ToHalfwidthForms == true;
                string resultStr = ReadSetting(KEY_TXT_TO_HALFWIDTH_FORMS);
                _Txt_ToHalfwidthForms = true;
                if (resultStr == "Not Found" || resultStr == null || resultStr.Length == 0)
                {
                    AddUpdateAppSettings(KEY_TXT_TO_HALFWIDTH_FORMS, true.ToString());
                }
                else
                {
                    _Txt_ToHalfwidthForms = bool.Parse(resultStr);
                }
                return _Txt_ToHalfwidthForms == true;
            }
        }

        //private string _FaceList = null;
        //public string FaceList
        //{
        //    set
        //    {
        //        _FaceList = value;
        //        AddUpdateAppSettings(KEY_FACE_LIST, value);
        //    }
        //    get
        //    {
        //        if (_FaceList != null) return _FaceList;
        //        _FaceList = ReadSetting(KEY_FACE_LIST);
        //        if (_FaceList == "Not Found" || _FaceList == null || _FaceList.Length == 0)
        //        {
        //            _FaceList = "";
        //            AddUpdateAppSettings(KEY_FACE_LIST, _FaceList);
        //        }
        //        return _FaceList;
        //    }
        //}

        //private string _GiftList = null;
        //public string GiftList
        //{
        //    set
        //    {
        //        _GiftList = value;
        //        AddUpdateAppSettings(KEY_GIFT_LIST, value);
        //    }
        //    get
        //    {
        //        if (_GiftList != null) return _GiftList;
        //        _GiftList = ReadSetting(KEY_GIFT_LIST);
        //        if (_GiftList == "Not Found" || _GiftList == null || _GiftList.Length == 0)
        //        {
        //            _GiftList = "";
        //            AddUpdateAppSettings(KEY_GIFT_LIST, _GiftList);
        //        }
        //        return _GiftList;
        //    }
        //}

        [Serializable]
        public class SerializableDictionary<TKey, TValue> : Dictionary<TKey, TValue>, IXmlSerializable
        {
            public SerializableDictionary() { }
            public void WriteXml(XmlWriter write)       // Serializer  
            {
                XmlSerializer KeySerializer = new XmlSerializer(typeof(TKey));
                XmlSerializer ValueSerializer = new XmlSerializer(typeof(TValue));

                foreach (KeyValuePair<TKey, TValue> kv in this)
                {
                    write.WriteStartElement("SerializableDictionary");
                    write.WriteStartElement("key");
                    KeySerializer.Serialize(write, kv.Key);
                    write.WriteEndElement();
                    write.WriteStartElement("value");
                    ValueSerializer.Serialize(write, kv.Value);
                    write.WriteEndElement();
                    write.WriteEndElement();
                }
            }
            public void ReadXml(XmlReader reader)       // Deserializer  
            {
                reader.Read();
                XmlSerializer KeySerializer = new XmlSerializer(typeof(TKey));
                XmlSerializer ValueSerializer = new XmlSerializer(typeof(TValue));

                while (reader.NodeType != XmlNodeType.EndElement)
                {
                    reader.ReadStartElement("SerializableDictionary");
                    reader.ReadStartElement("key");
                    TKey tk = (TKey)KeySerializer.Deserialize(reader);
                    reader.ReadEndElement();
                    reader.ReadStartElement("value");
                    TValue vl = (TValue)ValueSerializer.Deserialize(reader);
                    reader.ReadEndElement();
                    reader.ReadEndElement();
                    this.Add(tk, vl);
                    reader.MoveToContent();
                }
                reader.ReadEndElement();

            }
            public System.Xml.Schema.XmlSchema GetSchema()
            {
                return null;
            }
        }
    }
}
