﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SQLite;
using System.Data;

namespace PageSecretary_V2_by_longtombbj.Class
{
    class SQLiteDBHelper
    {
        public static SQLiteDBHelper instance;
        public static SQLiteDBHelper GetInstance()
        {
            if (instance == null)
            {
                instance = new SQLiteDBHelper();
            }
            return instance;
        }

        public void Dispose()
        {
            spliteDataAdapter.Dispose();
            dbConn.Close();
            dbConn.Dispose();
        }

        private string DB_File_FullName
            = AppDomain.CurrentDomain.BaseDirectory + "\\AllInOne.db";
        private SQLiteConnection dbConn;
        private SQLiteCommand dbCmd;
        public SQLiteDBHelper()
        {
            SQLiteConnectionStringBuilder conStrBuilder = new SQLiteConnectionStringBuilder();
            conStrBuilder.DataSource = DB_File_FullName;
            dbConn = new SQLiteConnection(conStrBuilder.ConnectionString);
            dbConn.Open();
            dbCmd = new SQLiteCommand(dbConn);
            spliteDataAdapter = new SQLiteDataAdapter();
            spliteDataAdapter.AcceptChangesDuringFill = true;
            spliteDataAdapter.AcceptChangesDuringUpdate = true;
        }

        private SQLiteDataAdapter spliteDataAdapter;
        public DataSet dataSet = new DataSet();


        public DataTable Reload_BlackPinYin_Starts()
        {
            string tableName = "BlackPinYin_Starts";
            dbCmd.CommandText = "Select * From [" + tableName + "]";
            spliteDataAdapter.SelectCommand = dbCmd;
            DataTable dt = dataSet.Tables[tableName];
            if (dt != null) dt.Clear();
            spliteDataAdapter.Fill(dataSet, tableName);
            dt = dataSet.Tables[tableName];
            return dt;
        }
        public DataTable Reload_BlackPinYin_Contains()
        {
            string tableName = "BlackPinYin_Contains";
            dbCmd.CommandText = "Select * From [" + tableName + "]";
            spliteDataAdapter.SelectCommand = dbCmd;
            DataTable dt = dataSet.Tables[tableName];
            if (dt != null) dt.Clear();
            spliteDataAdapter.Fill(dataSet, tableName);
            dt = dataSet.Tables[tableName];
            return dt;
        }
        public DataTable Reload_BlackPinYin_Ends()
        {
            string tableName = "BlackPinYin_Ends";
            dbCmd.CommandText = "Select * From [" + tableName + "]";
            spliteDataAdapter.SelectCommand = dbCmd;
            DataTable dt = dataSet.Tables[tableName];
            if (dt != null) dt.Clear();
            spliteDataAdapter.Fill(dataSet, tableName);
            dt = dataSet.Tables[tableName];
            return dt;
        }

        public DataTable Reload_BlackUsers()
        {
            string tableName = "BlackUsers";
            dbCmd.CommandText = "Select * From [" + tableName + "]";
            spliteDataAdapter.SelectCommand = dbCmd;
            DataTable dt = dataSet.Tables[tableName];
            if (dt != null) dt.Clear();
            spliteDataAdapter.Fill(dataSet, tableName);
            dt = dataSet.Tables[tableName];
            return dt;
        }
        public DataTable Reload_BlackKeyWords()
        {
            string tableName = "BlackKeyWords";
            dbCmd.CommandText = "Select * From [" + tableName + "]";
            spliteDataAdapter.SelectCommand = dbCmd;
            DataTable dt = dataSet.Tables[tableName];
            if (dt != null) dt.Clear();
            spliteDataAdapter.Fill(dataSet, tableName);
            dt = dataSet.Tables[tableName];
            return dt;
        }
        public DataTable Reload_WordReplace()
        {
            string tableName = "WordReplace";
            dbCmd.CommandText = "Select * From [" + tableName + "]";
            spliteDataAdapter.SelectCommand = dbCmd;
            DataTable dt = dataSet.Tables[tableName];
            if (dt != null) dt.Clear();
            spliteDataAdapter.Fill(dataSet, tableName);
            dt = dataSet.Tables[tableName];
            return dt;
        }

        public DataTable Reload_GiftList()
        {
            string tableName = "GiftList";
            dbCmd.CommandText = "Select * From [" + tableName + "]";
            spliteDataAdapter.SelectCommand = dbCmd;
            DataTable dt = dataSet.Tables[tableName];
            if (dt != null) dt.Clear();
            spliteDataAdapter.Fill(dataSet, tableName);
            dt = dataSet.Tables[tableName];
            return dt;
        }
        public DataTable Reload_EmotList()
        {
            string tableName = "EmotList";
            dbCmd.CommandText = "Select * From [" + tableName + "]";
            spliteDataAdapter.SelectCommand = dbCmd;
            DataTable dt = dataSet.Tables[tableName];
            if (dt != null) dt.Clear();
            spliteDataAdapter.Fill(dataSet, tableName);
            dt = dataSet.Tables[tableName];
            return dt;
        }


        public bool AddOrReplaceRow_BlackPinYin_Starts(string pinyin, string remark)
        {
            if (pinyin == null || pinyin.Trim().Length == 0) return false;
            string tableName = "BlackPinYin_Starts";
            dbCmd.CommandText = "Insert or Replace into [" + tableName + "] ([PINYIN], [Remark]) values ('" + pinyin + "', '" + remark + "')";
            if (dbCmd.ExecuteNonQuery() > 0)
            {
                return true;
            }
            return false;
        }
        public bool AddOrReplaceRow_BlackPinYin_Contains(string pinyin, string remark)
        {
            if (pinyin == null || pinyin.Trim().Length == 0) return false;
            string tableName = "BlackPinYin_Contains";
            dbCmd.CommandText = "Insert or Replace into [" + tableName + "] ([PINYIN], [Remark]) values ('" + pinyin + "', '" + remark + "')";
            if (dbCmd.ExecuteNonQuery() > 0)
            {
                return true;
            }
            return false;
        }
        public bool AddOrReplaceRow_BlackPinYin_Ends(string pinyin, string remark)
        {
            if (pinyin == null || pinyin.Trim().Length == 0) return false;
            string tableName = "BlackPinYin_Ends";
            dbCmd.CommandText = "Insert or Replace into [" + tableName + "] ([PINYIN], [Remark]) values ('" + pinyin + "', '" + remark + "')";
            if (dbCmd.ExecuteNonQuery() > 0)
            {
                return true;
            }
            return false;
        }

        public bool AddOrReplaceRow_BlackUsers(string user)
        {
            if (user == null || user.Trim().Length == 0) return false;
            string tableName = "BlackUsers";
            dbCmd.CommandText = "Insert or Replace into [" + tableName + "] ([User]) values ('" + user + "')";
            if (dbCmd.ExecuteNonQuery() > 0)
            {
                return true;
            }
            return false;
        }
        public bool AddOrReplaceRow_BlackKeyWords(string keyWord)
        {
            if (keyWord == null || keyWord.Trim().Length == 0) return false;
            string tableName = "BlackKeyWords";
            dbCmd.CommandText = "Insert or Replace into [" + tableName + "] ([KeyWord]) values ('" + keyWord + "')";
            if (dbCmd.ExecuteNonQuery() > 0)
            {
                return true;
            }
            return false;
        }
        public bool AddOrReplaceRow_WordReplace(string target, string result)
        {
            //if (target == null || target.Trim().Length == 0) return false;
            if (target == null || target.Length == 0) return false;
            string tableName = "WordReplace";
            dbCmd.CommandText = "Insert or Replace into [" + tableName + "] ([Target], [Result]) values ('" + target + "', '" + result + "')";
            if (dbCmd.ExecuteNonQuery() > 0)
            {
                return true;
            }
            return false;
        }


        /// <summary>
        /// 更新礼物信息
        /// </summary>
        /// <param name="id">非必须，如果缺失，则name和descri必须有值</param>
        /// <param name="name">必须，名称信息</param>
        /// <param name="descri">非必须，如果缺失，则id和name必须有值</param>
        /// <returns></returns>
        //public bool AddOrReplaceRow_GiftList(string id, string name, string descri)
        //{
        //    if (name == null || name.Length == 0) return false;
        //    if (id == null || id.Length == 0)
        //    {
        //        if (descri == null || descri.Length == 0)
        //        {
        //            return false;
        //        }
        //    }

        //    string tableName = "GiftList";
        //    if (id != null && descri != null && id.Length > 0 && descri.Length > 0)
        //    {
        //        dbCmd.CommandText
        //            = "Insert or Replace into [" + tableName + "] ([ID], [Name], [Descri]) "
        //            + "values ('" + id + "', '" + name + "', '" + descri + "')";
        //    }
        //    else if (id != null && id.Length > 0)
        //    {
        //        dbCmd.CommandText
        //            = "Insert or Replace into [" + tableName + "] ([ID], [Name]) "
        //            + "values ('" + id + "', '" + name + "')";
        //    }
        //    else if (descri != null && descri.Length > 0)
        //    {
        //        dbCmd.CommandText = "Select [ID] From [" + tableName + "] Where [Name]='" + name + "'";
        //        spliteDataAdapter.SelectCommand = dbCmd;
        //        DataTable dt = dataSet.Tables[tableName];
        //        if (dt != null) dt.Clear();
        //        spliteDataAdapter.Fill(dataSet, tableName);
        //        dt = dataSet.Tables[tableName];
        //        if (dt.Rows.Count > 0)
        //        {
        //            dbCmd.CommandText
        //                = "Insert or Replace into [" + tableName + "] ([ID], [Name], [Descri]) "
        //                + "values ('" + dt.Rows[0]["ID"] + "', '" + name + "', '" + descri + "')";
        //        }
        //        else
        //        {
        //            return false;
        //        }
        //    }
        //    if (dbCmd.ExecuteNonQuery() > 0)
        //    {
        //        return true;
        //    }
        //    return false;
        //}
        public int AddOrReplaceRow_GiftList(string[] idList, string[] nameList, string[] descriList)
        {
            if (idList.Length == 0) return 0;
            string tableName = "GiftList";
            dbCmd.CommandText = "Select [ID], [Name], [Descri] From [" + tableName + "]";
            spliteDataAdapter.SelectCommand = dbCmd;
            DataTable dt = dataSet.Tables[tableName];
            if (dt != null) dt.Clear();
            spliteDataAdapter.Fill(dataSet, tableName);
            dt = dataSet.Tables[tableName];
            List<string> newIdList = new List<string>();
            List<string> newNameList = new List<string>();
            List<string> newDescList = new List<string>();

            int listLeng = idList.Length;
            bool found;
            string tmpId, tmpName, tmpDesc, tmpNewId, tmpNewName, tmpNewDesc;
            for (int i = 0; i < listLeng; i++)
            {
                tmpNewId = idList[i];
                tmpNewName = nameList[i];
                tmpNewDesc = descriList[i];
                found = false;
                foreach (DataRow dr in dt.Rows)
                {
                    tmpId = dr["ID"].ToString();
                    tmpName = dr["Name"].ToString();
                    tmpDesc = dr["Descri"].ToString();
                    if (tmpNewId == tmpId && tmpNewName == tmpName && tmpNewDesc == tmpDesc)
                    {
                        found = true;
                        break;
                    }
                }
                if (found == false)
                {
                    newIdList.Add(tmpNewId);
                    newNameList.Add(tmpNewName);
                    newDescList.Add(tmpNewDesc);
                }
            }
            int result = 0;
            if (newIdList.Count > 0)
            {
                Logger logger = Logger.GetInstance();
                using (SQLiteTransaction tr = dbConn.BeginTransaction())
                {
                    SQLiteCommand cmd = new SQLiteCommand("", dbConn, tr);

                    listLeng = newIdList.Count;
                    for (int i = 0; i < listLeng; i++)
                    {
                        tmpNewId = newIdList[i];
                        tmpNewName = newNameList[i];
                        tmpNewDesc = newDescList[i];
                        dbCmd.CommandText
                            = "Insert or Replace into [" + tableName + "] ([ID], [Name], [Descri]) "
                            + "values ('" + tmpNewId + "', '" + tmpNewName + "', '" + tmpNewDesc + "')";
                        result += dbCmd.ExecuteNonQuery();
                        logger.Log("Insert Or Replace GiftInfo: (ID, Name, Descri) values (" + tmpNewId + ", " + tmpNewName + ", " + tmpNewDesc + ")");
                    }
                    tr.Commit();
                }
            }
            return result;
        }

        public int AddOrReplaceRow_EmotList(string[] idList, string[] nameList)
        {
            if (idList.Length == 0) return 0;
            string tableName = "EmotList";
            dbCmd.CommandText = "Select [ID], [Name] From [" + tableName + "]";
            spliteDataAdapter.SelectCommand = dbCmd;
            DataTable dt = dataSet.Tables[tableName];
            if (dt != null) dt.Clear();
            spliteDataAdapter.Fill(dataSet, tableName);
            dt = dataSet.Tables[tableName];

            List<string> newIdList = new List<string>();
            List<string> newNameList = new List<string>();

            int listLeng = idList.Length;
            bool found;
            string tmpId, tmpName, tmpNewId, tmpNewName;
            for (int i = 0; i < listLeng; i++)
            {
                tmpNewId = idList[i];
                tmpNewName = nameList[i];
                found = false;
                foreach (DataRow dr in dt.Rows)
                {
                    tmpId = dr["ID"].ToString();
                    tmpName = dr["Name"].ToString();
                    if (tmpNewId == tmpId && tmpNewName == tmpName)
                    {
                        found = true;
                        break;
                    }
                }
                if (found == false)
                {
                    newIdList.Add(tmpNewId);
                    newNameList.Add(tmpNewName);
                }
            }
            int result = 0;
            if (newIdList.Count > 0)
            {
                Logger logger = Logger.GetInstance();
                using (SQLiteTransaction tr = dbConn.BeginTransaction())
                {
                    SQLiteCommand cmd = new SQLiteCommand("", dbConn, tr);

                    listLeng = newIdList.Count;
                    for (int i = 0; i < listLeng; i++)
                    {
                        tmpNewId = newIdList[i];
                        tmpNewName = newNameList[i];
                        dbCmd.CommandText
                            = "Insert or Replace into [" + tableName + "] ([ID], [Name]) "
                            + "values ('" + tmpNewId + "', '" + tmpNewName + "')";
                        result += dbCmd.ExecuteNonQuery();
                        logger.Log("Insert Or Replace EmotInfo: (ID, Name) values (" + tmpNewId + ", " + tmpNewName + ")");
                    }
                    tr.Commit();
                }
            }
            return result;
        }
        public int AddOrReplaceRow_EmotList(Dictionary<string, string> emotDict)
        {
            int listLeng = emotDict.Count;
            string[] idList = new string[listLeng];
            string[] nameList = new string[listLeng];
            int idx = 0;
            foreach (KeyValuePair<string, string> pair in emotDict)
            {
                idList[idx] = pair.Key;
                nameList[idx] = pair.Value;
                idx++;
            }
            return AddOrReplaceRow_EmotList(idList, nameList);
        }

        public bool DelRow_BlackPinYin_Starts(string pinyin)
        {
            if (pinyin == null || pinyin.Trim().Length == 0) return false;
            string tableName = "BlackPinYin_Starts";
            dbCmd.CommandText = "Delete From [" + tableName + "] Where [PINYIN]='" + pinyin + "'";
            if (dbCmd.ExecuteNonQuery() > 0)
            {
                return true;
            }
            return false;
        }
        public bool DelRow_BlackPinYin_Contains(string pinyin)
        {
            if (pinyin == null || pinyin.Trim().Length == 0) return false;
            string tableName = "BlackPinYin_Contains";
            dbCmd.CommandText = "Delete From [" + tableName + "] Where [PINYIN]='" + pinyin + "'";
            if (dbCmd.ExecuteNonQuery() > 0)
            {
                return true;
            }
            return false;
        }
        public bool DelRow_BlackPinYin_Ends(string pinyin)
        {
            if (pinyin == null || pinyin.Trim().Length == 0) return false;
            string tableName = "BlackPinYin_Ends";
            dbCmd.CommandText = "Delete From [" + tableName + "] Where [PINYIN]='" + pinyin + "'";
            if (dbCmd.ExecuteNonQuery() > 0)
            {
                return true;
            }
            return false;
        }

        public bool DelRow_BlackUsers(string user)
        {
            if (user == null || user.Trim().Length == 0) return false;
            string tableName = "BlackUsers";
            dbCmd.CommandText = "Delete From [" + tableName + "] Where [User]='" + user + "'";
            if (dbCmd.ExecuteNonQuery() > 0)
            {
                return true;
            }
            return false;
        }
        public bool DelRow_BlackKeyWords(string keyWord)
        {
            if (keyWord == null || keyWord.Trim().Length == 0) return false;
            string tableName = "BlackKeyWords";
            dbCmd.CommandText = "Delete From [" + tableName + "] Where [KeyWord]='" + keyWord + "'";
            if (dbCmd.ExecuteNonQuery() > 0)
            {
                return true;
            }
            return false;
        }
        public bool DelRow_WordReplace(string target)
        {
            if (target == null || target.Trim().Length == 0) return false;
            string tableName = "WordReplace";
            dbCmd.CommandText = "Delete From [" + tableName + "] Where [Target]='" + target + "'";
            if (dbCmd.ExecuteNonQuery() > 0)
            {
                return true;
            }
            return false;
        }
    }
}
