﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using DYBullet;
using System.Media;

namespace PageSecretary_V2_by_longtombbj
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        Class.Config conf = Class.Config.GetInstance();
        Class.Logger logger = Class.Logger.GetInstance();
        Class.SQLiteDBHelper dbHelper = Class.SQLiteDBHelper.GetInstance();
        Class.Inspector inspector = Class.Inspector.GetInstance();
        T2S_HCore.Classes.MultiVoice multiVoice = T2S_HCore.Classes.MultiVoice.GetInstance();
        private void FormMain_Load(object sender, EventArgs e)
        {
            textBox_roomId.Text = conf.RoomId;
            textBox_userId.Text = conf.User_Id;
            textBox_userNickName.Text = conf.User_NickName;


            dataGridView_BlackPinYin_Starts.DataSource = dbHelper.Reload_BlackPinYin_Starts();
            inspector.Refresh_blackPinyin_starts(dataGridView_BlackPinYin_Starts);
            dataGridView_BlackPinYin_Contains.DataSource = dbHelper.Reload_BlackPinYin_Contains();
            inspector.Refresh_blackPinyin_contains(dataGridView_BlackPinYin_Contains);
            dataGridView_BlackPinYin_Ends.DataSource = dbHelper.Reload_BlackPinYin_Ends();
            inspector.Refresh_blackPinyin_ends(dataGridView_BlackPinYin_Ends);

            dataGridView_WordReplace.DataSource = dbHelper.Reload_WordReplace();
            inspector.Refresh_wordReplace(dataGridView_WordReplace);
            dataGridView_BlackKeyWord.DataSource = dbHelper.Reload_BlackKeyWords();
            inspector.Refresh_blackKeyWords(dataGridView_BlackKeyWord);
            dataGridView_BlackUser.DataSource = dbHelper.Reload_BlackUsers();
            inspector.Refresh_blackUsers(dataGridView_WordReplace);

            inspector.RemoteDirReady += Inspector_RemoteDirReady;
            inspector.RemoteDirNotFound += Inspector_RemoteDirNotFound;

            checkBox_isRemoveSpace_inChinese.Checked = conf.TxtInsp_isRemoveSpace_inChinese;
            checkBox_isCheck5SameChar_inChinese.Checked = conf.TxtInsp_isCheck_5SameChar_inChineser;
            checkBox_isCheck3SameWord_inChinese.Checked = conf.TxtInsp_isCheck_3SameWord_inChineser;
            checkBox_isRemoveSpace_inChinese.CheckedChanged += checkBox_isRemoveSpace_inChines_CheckedChanged;
            checkBox_isCheck5SameChar_inChinese.CheckedChanged += checkBox_isCheck5SameChar_inChinese_CheckedChanged;
            checkBox_isCheck3SameWord_inChinese.CheckedChanged += checkBox_isCheck3SameWord_inChinese_CheckedChanged;

            checkBox_enableVoice.Checked = conf.Voice_IsEnabled;
            checkBox_useRemoteVoice.Checked = conf.Voice_IsRemote;
            checkBox_enableVoice.CheckedChanged += CheckBox_enableVoice_CheckedChanged;
            checkBox_useRemoteVoice.CheckedChanged += CheckBox_useRemoteVoice_CheckedChanged;

            CheckBox_enableVoice_CheckedChanged(checkBox_enableVoice, null);

            numericUpDown_voiceCycleTime.Value = conf.Voice_CycleTime;
            numericUpDown_timeBetweenVoice.Value = conf.Voice_TimeBetweenVoices;
            numericUpDown_voiceCycleTime.ValueChanged += NumericUpDown_voiceCycleTime_ValueChanged;
            numericUpDown_timeBetweenVoice.ValueChanged += NumericUpDown_timeBetweenVoice_ValueChanged;

            textBox_remoteVoiceFileDir.Text = conf.Voice_RemoteDir;

            multiVoice.broadCaster.WorkingStateChanged += BroadCaster_WorkingStateChanged;

            checkBox_only4tom.Checked = conf.Voice_IsOnlyForTom;
            checkBox_only4tom.CheckedChanged += checkBox_only4tom_CheckedChanged;

            inspector.Voice2Play += Inspector_Voice2Play;

            textBox_loadGiftListURL.Text = conf.GiftList_PageURL;
            button_loadGiftList_Click(this, null);

            textBox_loadFaceListURL.Text = conf.FaceList_PageURL;
            button_loadFaceList_Click(this, null);

            multiVoice.broadCaster.OnException += BroadCaster_OnException;

            checkBox_voice_gift.Checked = conf.Voice_IfSpeechGift;
            checkBox_voice_gift.CheckedChanged += CheckBox_voice_gift_CheckedChanged;
            checkBox_voice_chat.Checked = conf.Voice_IfSpeechChat;
            checkBox_voice_chat.CheckedChanged += CheckBox_voice_chat_CheckedChanged;
            checkBox_TxtToHalfwidthForms.Checked = conf.Txt_ToHalfwidthForms;
            checkBox_TxtToHalfwidthForms.CheckedChanged += CheckBox_TxtToHalfwidthForms_CheckedChanged;
        }

        private void CheckBox_TxtToHalfwidthForms_CheckedChanged(object sender, EventArgs e)
        {
            conf.Txt_ToHalfwidthForms = checkBox_TxtToHalfwidthForms.Checked;
        }
        private void CheckBox_voice_chat_CheckedChanged(object sender, EventArgs e)
        {
            conf.Voice_IfSpeechChat = checkBox_voice_chat.Checked;
        }
        private void CheckBox_voice_gift_CheckedChanged(object sender, EventArgs e)
        {
            conf.Voice_IfSpeechGift = checkBox_voice_gift.Checked;
        }

        private void BroadCaster_OnException(object sender, T2S_HCore.Classes.BroadCaster.OnExceptionArgs e)
        {
            logger.Log(conf.DateTimeNow_FullString + " ERROR: " + e.err.ToString());
        }

        private void Inspector_RemoteDirReady(object sender, EventArgs e)
        {
            if (conf.Voice_IsRemote == true)
            {
                textBox_voiceState.Text = "RemoteVoice";
                pictureBox_isVoiceBusy.BackColor = Color.Yellow;
            }
        }
        private void Inspector_RemoteDirNotFound(object sender, EventArgs e)
        {
            if (conf.Voice_IsRemote == true)
            {
                textBox_voiceState.Text = "RDirNotFound";
                pictureBox_isVoiceBusy.BackColor = Color.Red;
            }
        }

        private void Inspector_Voice2Play(object sender, Class.Inspector.Voice2PlayArgs e)
        {
            textBox_voiceHistory.AppendText(e.voiceTxMsg + "\r\n" + e.chatData.ToString() + "\r\n\r\n");
        }

        private void CheckBox_enableVoice_CheckedChanged(object sender, EventArgs e)
        {
            conf.Voice_IsEnabled = ((CheckBox)sender).Checked;
            if (conf.Voice_IsEnabled == true)
            {
                if (textBox_remoteVoiceFileDir.Text.Length > 0)
                {
                    conf.Voice_RemoteDir = textBox_remoteVoiceFileDir.Text;
                }
                pictureBox_enableVoice.BackColor = Color.Lime;
                BroadCaster_WorkingStateChanged(
                    null,
                    new T2S_HCore.Classes.BroadCaster.WorkingStateChanged_args()
                    {
                        stateNew = T2S_HCore.Classes.BroadCaster.States.Ready_Stoped
                    }
                    );
            }
            else
            {
                pictureBox_enableVoice.BackColor = SystemColors.InactiveCaption;
                pictureBox_isVoiceBusy.BackColor = SystemColors.InactiveCaption;
            }
        }
        private void CheckBox_useRemoteVoice_CheckedChanged(object sender, EventArgs e)
        {
            conf.Voice_IsRemote = ((CheckBox)sender).Checked;
            if (conf.Voice_IsRemote == true)
            {
                textBox_voiceState.Text = "RemoteVoice";
                pictureBox_isVoiceBusy.BackColor = Color.Yellow;
            }
        }
        private void NumericUpDown_voiceCycleTime_ValueChanged(object sender, EventArgs e)
        {
            conf.Voice_CycleTime = (int)((NumericUpDown)sender).Value;
        }
        private void NumericUpDown_timeBetweenVoice_ValueChanged(object sender, EventArgs e)
        {
            conf.Voice_TimeBetweenVoices = (int)((NumericUpDown)sender).Value;
        }

        private void BroadCaster_WorkingStateChanged(object sender, T2S_HCore.Classes.BroadCaster.WorkingStateChanged_args e)
        {
            if (conf.Voice_IsRemote == false)
            {
                textBox_voiceState.Text = e.stateNew.ToString();
                if (checkBox_enableVoice.Checked == true)
                {
                    switch (e.stateNew)
                    {
                        case T2S_HCore.Classes.BroadCaster.States.Paused:
                            pictureBox_isVoiceBusy.BackColor = Color.Yellow;
                            break;
                        case T2S_HCore.Classes.BroadCaster.States.Playing:
                        case T2S_HCore.Classes.BroadCaster.States.SavingFile:
                            pictureBox_isVoiceBusy.BackColor = Color.OrangeRed;
                            break;
                        case T2S_HCore.Classes.BroadCaster.States.Ready_Stoped:
                            pictureBox_isVoiceBusy.BackColor = Color.Lime;
                            break;
                    }
                }
            }
        }



        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            conf.Save();
            dbHelper.Dispose();
        }


        private DyBulletHelper dyBulletHelper;

        /// <summary>
        /// 启动或停止 弹幕 监听
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void checkBox_startBulletListener_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_startBulletListener.Checked == true)
            {
                //start listening
                conf.RoomId = textBox_roomId.Text;
                conf.User_Id = textBox_userId.Text;
                conf.User_NickName = textBox_userNickName.Text;

                if (dyBulletHelper != null)
                {
                    dyBulletHelper.Dispose();
                    dyBulletHelper = null;
                }
                try
                {
                    dyBulletHelper = new DyBulletHelper(int.Parse(textBox_roomId.Text));
                    dyBulletHelper.DyBulletHelperEventArisen += DyBulletHelper_DyBulletHelperEventArisen;
                    dyBulletHelper.DyBulletShout += DyBulletHelper_DyBulletShout;
                    dyBulletHelper.DyBulletHelperError += DyBulletHelper_DyBulletHelperError;
                    if (dyBulletHelper.State == DyBulletHelper.iState.Ready)
                    {
                        pictureBox_bulletListener_states.BackColor = Color.Lime;
                        checkBox_startBulletListener.Text = "停止";
                    }
                    else
                    {
                        pictureBox_bulletListener_states.BackColor = SystemColors.InactiveCaption;
                        checkBox_startBulletListener.Text = "复位";
                    }
                }
                catch (Exception)
                {
                    checkBox_startBulletListener.Text = "复位";
                }
            }
            else
            {
                // stop listening
                if (dyBulletHelper != null)
                {
                    dyBulletHelper.Dispose();
                    dyBulletHelper = null;
                    pictureBox_bulletListener_states.BackColor = SystemColors.InactiveCaption;
                    checkBox_startBulletListener.Text = "启动";
                }
            }
        }

        private void DyBulletHelper_DyBulletHelperError(object sender, DyBulletHelper.DyBulletHelperErrorArgs e)
        {
            if (checkBox_startBulletListener.Checked == true)
            {
                checkBox_startBulletListener.Checked = false;
            }
            ReductTBText(ref textBox_eventLog);
            string msg = conf.DateTimeNow_FullString + " " + e.err.ToString();
            textBox_eventLog.AppendText("\r\n\r\n" + msg);
            logger.Log(msg);
            SystemSounds.Hand.Play();
        }

        /// <summary>
        /// 写入 弹幕监听 系统事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DyBulletHelper_DyBulletHelperEventArisen(object sender, DyBulletHelper.DyBulletHelperEventArisenArgs e)
        {
            ReductTBText(ref textBox_eventLog);
            string msg = conf.DateTimeNow_FullString + " " + e.msg;
            textBox_eventLog.AppendText("\r\n\r\n" + msg);
            logger.Log(msg);
        }
        private void ReductTBText(ref TextBox target)
        {
            if ((target.TextLength + 300) > target.MaxLength)
            {
                target.Clear();
                target.ClearUndo();
            }
        }

        /// <summary>
        /// 分类显示所有弹幕
        /// 只要是送礼物给主播（主播收益）的相关弹幕，都算作收到礼物
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DyBulletHelper_DyBulletShout(object sender, DyBulletHelper.DyBulletShoutArgs e)
        {
            inspector.InputMsg(e.bullet);

            int _case = 0; // 0 msg   1 gift   2 user in   3 other
            DyBulletHelper.Bullet.iStructedMsg struMsg = e.bullet.StructedMsg;
            string msg = null;
            switch (struMsg.Type)
            {
                case DyBulletHelper.Bullet.iStructedMsg.iType.Chat:
                    _case = 0; // msg
                    msg = struMsg.Chat.nn
                        + "(lv." + struMsg.Chat.level + ", gt." + struMsg.Chat.gt + ", dlv." + struMsg.Chat.dlv + " dc." + struMsg.Chat.dc + " bdlv." + struMsg.Chat.bdlv + ")"
                        + "(rg." + struMsg.Chat.rg + " pg." + struMsg.Chat.pg + "): \r\n"
                        + struMsg.Chat.txt;
                    break;
                case DyBulletHelper.Bullet.iStructedMsg.iType.DeserveBought:
                    _case = 1; // gift
                    msg = struMsg.DeserveBought.sui.nick + "赠送 (" + struMsg.DeserveBought.sui.cur_lev + "级)酬勤 " + struMsg.DeserveBought.sui.cq_cnt + " 个";
                    break;
                case DyBulletHelper.Bullet.iStructedMsg.iType.GiftDonated:
                    _case = 1; // gift
                    msg = struMsg.GiftDonated.nn
                        + "(lv." + struMsg.GiftDonated.level + ", str." + struMsg.GiftDonated.str + ", dlv." + struMsg.GiftDonated.dlv + ", dc." + struMsg.GiftDonated.dc + ", bdl." + struMsg.GiftDonated.bdl + ", rg." + struMsg.GiftDonated.rg + ", pg." + struMsg.GiftDonated.pg + ")\r\n"
                        + "赠送礼物 " + struMsg.GiftDonated.gs + " (个数." + struMsg.GiftDonated.gfcnt + ", 连击." + struMsg.GiftDonated.hits + ")\r\n"
                        + (struMsg.GiftDonated.rpid != "0" ?
                            ("有红包！(slt." + struMsg.GiftDonated.slt + ", elt." + struMsg.GiftDonated.elt + ")") : "");
                    break;
                case DyBulletHelper.Bullet.iStructedMsg.iType.AudienceSeatTaken:
                    _case = 2; // user in
                    msg = "用户进入: " + struMsg.AudienceSeatTaken.nn
                        + "(lv." + struMsg.AudienceSeatTaken.level + ", gt." + struMsg.AudienceSeatTaken.gt + ", dlv." + struMsg.AudienceSeatTaken.dlv + " dc." + struMsg.AudienceSeatTaken.dc + " bdlv." + struMsg.AudienceSeatTaken.bdlv + ", rg." + struMsg.AudienceSeatTaken.rg + ", pg." + struMsg.AudienceSeatTaken.pg + ")";
                    break;
                case DyBulletHelper.Bullet.iStructedMsg.iType.CameraOnOff:
                case DyBulletHelper.Bullet.iStructedMsg.iType.Error:
                    _case = 3; // other
                    break;
                case DyBulletHelper.Bullet.iStructedMsg.iType.GiftPickedUp:
                    _case = 3; // other
                    msg = struMsg.GiftPickedUp.nn + " 获取鱼丸(lv." + struMsg.GiftPickedUp._if + ") " + struMsg.GiftPickedUp.sil + " 个";
                    break;
                case DyBulletHelper.Bullet.iStructedMsg.iType.HeartBeat:
                case DyBulletHelper.Bullet.iStructedMsg.iType.Login:
                case DyBulletHelper.Bullet.iStructedMsg.iType.Logout:
                case DyBulletHelper.Bullet.iStructedMsg.iType.Ohter:
                case DyBulletHelper.Bullet.iStructedMsg.iType.RankList:
                case DyBulletHelper.Bullet.iStructedMsg.iType.RankUp:
                    _case = 3; // other
                    break;
                case DyBulletHelper.Bullet.iStructedMsg.iType.Defiance:
                    if (struMsg.Defiance.dn == conf.User_NickName)
                    {
                        _case = 1;
                        msg = struMsg.Defiance.sn + " 赠送给 " + struMsg.Defiance.dn + " " + struMsg.Defiance.gc + "个 " + struMsg.Defiance.gn + "";
                    }
                    else
                    {
                        _case = 3;
                    }
                    break;
                case DyBulletHelper.Bullet.iStructedMsg.iType.RedPacket:
                    if (struMsg.RedPacket.did == conf.User_Id)
                    {
                        _case = 1;
                        msg = struMsg.RedPacket.dnk + " 抢到 " + struMsg.RedPacket.snk + " 的" + struMsg.RedPacket.rpt + "！ 获得鱼丸 " + struMsg.RedPacket.sl + "个";
                    }
                    else
                    {
                        _case = 3;
                    }
                    break;
                case DyBulletHelper.Bullet.iStructedMsg.iType.SuperMsg:
                    if (struMsg.SuperMsg.trid == conf.RoomId)
                    {
                        _case = 0;
                    }
                    else
                    {
                        _case = 3;
                    }
                    break;
            }
            if (msg == null)
            {
                msg = e.bullet.MsgToString();
            }
            msg = conf.DateTimeNow_FullString + " " + msg;

            switch (_case)
            {
                case 0: // msg
                    ReductTBText(ref textBox_bullet_msg);
                    textBox_bullet_msg.AppendText("\r\n\r\n" + msg);
                    break;


                case 1: // gift
                    ReductTBText(ref textBox_bullet_gift);
                    textBox_bullet_gift.AppendText("\r\n\r\n" + msg);
                    break;


                case 2: // user in
                    ReductTBText(ref textBox_bullet_userIn);
                    textBox_bullet_userIn.AppendText("\r\n\r\n" + msg);
                    break;


                case 3: // other
                    ReductTBText(ref textBox_bullet_other);
                    textBox_bullet_other.AppendText("\r\n\r\n" + msg);
                    break;
            }
            logger.Log(conf.DateTimeNow_FullString + " " + e.bullet.MsgToString());
        }

        /// <summary>
        /// 清空 日志、消息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ToolStripMenuItem_clean_Click(object sender, EventArgs e)
        {
            TextBox target = (TextBox)contextMenuStrip_textBox.SourceControl;
            target.Clear();
        }

        /// <summary>
        /// 弹出窗口，防止新消息加入导致查看位置跳动
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ToolStripMenuItem_staticView_Click(object sender, EventArgs e)
        {
            TextBox target = (TextBox)contextMenuStrip_textBox.SourceControl;
            Forms.Form_TextStaticView win = new Forms.Form_TextStaticView();
            win.SetText(target.Text);
            target.Clear();
            win.Show(this);
        }






        #region all DataGridView functions
        private void ToolStripMenuItem_refresh_Click(object sender, EventArgs e)
        {
            DataGridView targetDGV = (DataGridView)contextMenuStrip_dataGridView.SourceControl;
            switch (targetDGV.Name)
            {
                case "dataGridView_BlackPinYin_Starts":
                    dbHelper.Reload_BlackPinYin_Starts();
                    inspector.Refresh_blackPinyin_starts(targetDGV);
                    break;
                case "dataGridView_BlackPinYin_Contains":
                    dbHelper.Reload_BlackPinYin_Contains();
                    inspector.Refresh_blackPinyin_contains(targetDGV);
                    break;
                case "dataGridView_BlackPinYin_Ends":
                    dbHelper.Reload_BlackPinYin_Ends();
                    inspector.Refresh_blackPinyin_ends(targetDGV);
                    break;

                case "dataGridView_WordReplace":
                    dbHelper.Reload_WordReplace();
                    inspector.Refresh_wordReplace(targetDGV);
                    break;
                case "dataGridView_BlackKeyWord":
                    dbHelper.Reload_BlackKeyWords();
                    inspector.Refresh_blackKeyWords(targetDGV);
                    break;
                case "dataGridView_BlackUser":
                    dbHelper.Reload_BlackUsers();
                    inspector.Refresh_blackUsers(targetDGV);
                    break;
            }
        }





        private void dataGridView_KeyDown(object sender, KeyEventArgs e)
        {
            DataGridView targetDGV = (DataGridView)sender;
            bool toDel = false;
            switch (e.KeyCode)
            {
                case Keys.Delete:
                    toDel = true;
                    break;
            }
            string key;
            if (toDel == true)
            {
                switch (targetDGV.Name)
                {
                    case "dataGridView_BlackPinYin_Starts":
                        foreach (DataGridViewRow row in targetDGV.SelectedRows)
                        {
                            key = (string)row.Cells[0].Value;
                            dbHelper.DelRow_BlackPinYin_Starts(key);
                        }
                        inspector.Refresh_blackPinyin_starts(targetDGV);
                        break;
                    case "dataGridView_BlackPinYin_Contains":
                        foreach (DataGridViewRow row in targetDGV.SelectedRows)
                        {
                            key = (string)row.Cells[0].Value;
                            dbHelper.DelRow_BlackPinYin_Contains(key);
                        }
                        inspector.Refresh_blackPinyin_contains(targetDGV);
                        break;
                    case "dataGridView_BlackPinYin_Ends":
                        foreach (DataGridViewRow row in targetDGV.SelectedRows)
                        {
                            key = (string)row.Cells[0].Value;
                            dbHelper.DelRow_BlackPinYin_Ends(key);
                        }
                        inspector.Refresh_blackPinyin_ends(targetDGV);
                        break;

                    case "dataGridView_WordReplace":
                        foreach (DataGridViewRow row in targetDGV.SelectedRows)
                        {
                            key = (string)row.Cells[0].Value;
                            dbHelper.DelRow_WordReplace(key);
                        }
                        inspector.Refresh_wordReplace(targetDGV);
                        break;
                    case "dataGridView_BlackKeyWord":
                        foreach (DataGridViewRow row in targetDGV.SelectedRows)
                        {
                            key = (string)row.Cells[0].Value;
                            dbHelper.DelRow_BlackKeyWords(key);
                        }
                        inspector.Refresh_blackKeyWords(targetDGV);
                        break;
                    case "dataGridView_BlackUser":
                        foreach (DataGridViewRow row in targetDGV.SelectedRows)
                        {
                            key = (string)row.Cells[0].Value;
                            dbHelper.DelRow_BlackUsers(key);
                        }
                        inspector.Refresh_blackUsers(targetDGV);
                        break;
                }
            }
        }






        /// <summary>
        /// 通用事件，如果尝试修改 key， 则直接取消
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGridView_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            DataGridView target = (DataGridView)sender;
            if (e.ColumnIndex == 0
                && target.Rows[e.RowIndex].Cells[0].Value.GetType() != typeof(System.DBNull)
                )
            {
                e.Cancel = true;
            }
        }






        private void dataGridView_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            DataGridView targetDGV = (DataGridView)sender;
            string key = null;
            string value = null;
            object tmp = targetDGV.Rows[e.RowIndex].Cells[0].Value;
            if (tmp != null && tmp.GetType() != typeof(System.DBNull))
            {
                key = (string)targetDGV.Rows[e.RowIndex].Cells[0].Value;
            }
            if (targetDGV.Columns.Count > 1)
            {
                tmp = targetDGV.Rows[e.RowIndex].Cells[1].Value;
                if (tmp != null && tmp.GetType() != typeof(System.DBNull))
                {
                    value = (string)targetDGV.Rows[e.RowIndex].Cells[1].Value;
                }
            }

            //if (key != null && key.Trim().Length > 0)
            if (key != null && key.Length > 0)
            {
                switch (targetDGV.Name)
                {
                    case "dataGridView_BlackPinYin_Starts":
                        dbHelper.AddOrReplaceRow_BlackPinYin_Starts(key, value);
                        inspector.Refresh_blackPinyin_starts(targetDGV);
                        break;
                    case "dataGridView_BlackPinYin_Contains":
                        dbHelper.AddOrReplaceRow_BlackPinYin_Contains(key, value);
                        inspector.Refresh_blackPinyin_contains(targetDGV);
                        break;
                    case "dataGridView_BlackPinYin_Ends":
                        dbHelper.AddOrReplaceRow_BlackPinYin_Ends(key, value);
                        inspector.Refresh_blackPinyin_ends(targetDGV);
                        break;

                    case "dataGridView_WordReplace":
                        if (value != null && value.Contains(key))
                        {
                            targetDGV.Rows[e.RowIndex].Cells[1].Value = "";
                            System.Media.SystemSounds.Exclamation.Play();
                        }
                        else
                        {
                            dbHelper.AddOrReplaceRow_WordReplace(key, value);
                            inspector.Refresh_wordReplace(targetDGV);
                        }
                        break;
                    case "dataGridView_BlackKeyWord":
                        dbHelper.AddOrReplaceRow_BlackKeyWords(key);
                        inspector.Refresh_blackKeyWords(targetDGV);
                        break;
                    case "dataGridView_BlackUser":
                        dbHelper.AddOrReplaceRow_BlackUsers(key);
                        inspector.Refresh_blackUsers(targetDGV);
                        break;
                }
            }
        }

        #endregion


        #region 预处理 - 其他
        private void checkBox_isRemoveSpace_inChines_CheckedChanged(object sender, EventArgs e)
        {
            conf.TxtInsp_isRemoveSpace_inChinese = checkBox_isRemoveSpace_inChinese.Checked;
        }

        private void checkBox_isCheck5SameChar_inChinese_CheckedChanged(object sender, EventArgs e)
        {
            conf.TxtInsp_isCheck_5SameChar_inChineser = checkBox_isCheck5SameChar_inChinese.Checked;
        }

        private void checkBox_isCheck3SameWord_inChinese_CheckedChanged(object sender, EventArgs e)
        {
            conf.TxtInsp_isCheck_3SameWord_inChineser = checkBox_isCheck3SameWord_inChinese.Checked;
        }
        #endregion



        #region voice config
        private void checkBox_enableVoice_CheckedChanged(object sender, EventArgs e)
        {

        }






        #endregion

        private void checkBox_only4tom_CheckedChanged(object sender, EventArgs e)
        {
            conf.Voice_IsOnlyForTom = checkBox_only4tom.Checked;
        }

        /// <summary>
        /// 获取礼物列表 giftid - name
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_loadGiftList_Click(object sender, EventArgs e)
        {
            conf.GiftList_PageURL = textBox_loadGiftListURL.Text;
            try
            {
                System.Net.WebClient wc = new System.Net.WebClient();
                Byte[] pageData = wc.DownloadData(conf.GiftList_PageURL);
                string pageCode = System.Text.Encoding.UTF8.GetString(pageData);
                inspector.giftRecorder.ReLoadGiftList_FromPageCode(pageCode);
                textBox_giftList.Text = inspector.giftRecorder.GetGiftListString();
                inspector.giftRecorder.SaveGiftList();
            }
            catch (Exception err)
            {
                MessageBox.Show("未能获取礼物信息。\r\nURL有问题！ 或发生了其他错误！\r\n\r\n" + err.ToString());
            }
            inspector.giftRecorder.LoadGiftList();
        }
        private void button_loadFaceList_Click(object sender, EventArgs e)
        {
            conf.FaceList_PageURL = textBox_loadFaceListURL.Text;
            try
            {
                System.Net.WebClient wc = new System.Net.WebClient();
                Byte[] pageData = wc.DownloadData(conf.FaceList_PageURL);
                string pageCode = System.Text.Encoding.UTF8.GetString(pageData);
                inspector.faceSymbHelper.ReLoadFaceList_FromPageCode(pageCode);
                textBox_faceList.Text = inspector.faceSymbHelper.GetFaceListString();
                inspector.faceSymbHelper.SaveFaceList_NoImage();
            }
            catch (Exception err)
            {
                MessageBox.Show("未能获取表情信息。\r\nURL有问题！ 或发生了其他错误！\r\n\r\n" + err.ToString());
            }
            inspector.faceSymbHelper.LoadFaceList();
        }

        private void button_RemoteTest_Click(object sender, EventArgs e)
        {
            inspector.RemoteTest(textBox_RemoteTest.Text);
        }
    }
}
