﻿namespace PageSecretary_V2_by_longtombbj
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox_bulletListener = new System.Windows.Forms.GroupBox();
            this.checkBox_only4tom = new System.Windows.Forms.CheckBox();
            this.textBox_userId = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_userNickName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox_bulletListener_states = new System.Windows.Forms.PictureBox();
            this.checkBox_startBulletListener = new System.Windows.Forms.CheckBox();
            this.textBox_roomId = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox_eventLog = new System.Windows.Forms.TextBox();
            this.contextMenuStrip_textBox = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ToolStripMenuItem_clean = new System.Windows.Forms.ToolStripMenuItem();
            this.VToolStripMenuItem_staticView = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.tabControl4 = new System.Windows.Forms.TabControl();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.textBox_bullet_msg = new System.Windows.Forms.TextBox();
            this.tabPage16 = new System.Windows.Forms.TabPage();
            this.textBox_voiceHistory = new System.Windows.Forms.TextBox();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.textBox_bullet_gift = new System.Windows.Forms.TextBox();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.textBox_bullet_userIn = new System.Windows.Forms.TextBox();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.textBox_bullet_other = new System.Windows.Forms.TextBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.dataGridView_BlackPinYin_Starts = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip_dataGridView = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ToolStripMenuItem_refresh = new System.Windows.Forms.ToolStripMenuItem();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.dataGridView_BlackPinYin_Contains = new System.Windows.Forms.DataGridView();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.dataGridView_BlackPinYin_Ends = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dataGridView_BlackKeyWord = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.dataGridView_WordReplace = new System.Windows.Forms.DataGridView();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button_loadGiftList = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox_giftList = new System.Windows.Forms.TextBox();
            this.textBox_loadGiftListURL = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox_TxtToHalfwidthForms = new System.Windows.Forms.CheckBox();
            this.checkBox_isCheck3SameWord_inChinese = new System.Windows.Forms.CheckBox();
            this.checkBox_isRemoveSpace_inChinese = new System.Windows.Forms.CheckBox();
            this.checkBox_isCheck5SameChar_inChinese = new System.Windows.Forms.CheckBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dataGridView_BlackUser = new System.Windows.Forms.DataGridView();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBox_RemoteTest = new System.Windows.Forms.TextBox();
            this.button_RemoteTest = new System.Windows.Forms.Button();
            this.checkBox_voice_chat = new System.Windows.Forms.CheckBox();
            this.checkBox_voice_gift = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox_remoteVoiceFileDir = new System.Windows.Forms.TextBox();
            this.checkBox_useRemoteVoice = new System.Windows.Forms.CheckBox();
            this.numericUpDown_timeBetweenVoice = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_voiceCycleTime = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_voiceState = new System.Windows.Forms.TextBox();
            this.pictureBox_isVoiceBusy = new System.Windows.Forms.PictureBox();
            this.checkBox_enableVoice = new System.Windows.Forms.CheckBox();
            this.pictureBox_enableVoice = new System.Windows.Forms.PictureBox();
            this.uC_MultiVoice1 = new T2S_HCore.UI.UC_MultiVoice();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button_loadFaceList = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox_faceList = new System.Windows.Forms.TextBox();
            this.textBox_loadFaceListURL = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox_bulletListener.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_bulletListener_states)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.contextMenuStrip_textBox.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.tabControl4.SuspendLayout();
            this.tabPage12.SuspendLayout();
            this.tabPage16.SuspendLayout();
            this.tabPage13.SuspendLayout();
            this.tabPage14.SuspendLayout();
            this.tabPage15.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_BlackPinYin_Starts)).BeginInit();
            this.contextMenuStrip_dataGridView.SuspendLayout();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_BlackPinYin_Contains)).BeginInit();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_BlackPinYin_Ends)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_BlackKeyWord)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_WordReplace)).BeginInit();
            this.tabPage10.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_BlackUser)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_timeBetweenVoice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_voiceCycleTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_isVoiceBusy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_enableVoice)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox_bulletListener
            // 
            this.groupBox_bulletListener.Controls.Add(this.checkBox_only4tom);
            this.groupBox_bulletListener.Controls.Add(this.textBox_userId);
            this.groupBox_bulletListener.Controls.Add(this.label3);
            this.groupBox_bulletListener.Controls.Add(this.textBox_userNickName);
            this.groupBox_bulletListener.Controls.Add(this.label2);
            this.groupBox_bulletListener.Controls.Add(this.pictureBox_bulletListener_states);
            this.groupBox_bulletListener.Controls.Add(this.checkBox_startBulletListener);
            this.groupBox_bulletListener.Controls.Add(this.textBox_roomId);
            this.groupBox_bulletListener.Controls.Add(this.label1);
            this.groupBox_bulletListener.Location = new System.Drawing.Point(12, 12);
            this.groupBox_bulletListener.Name = "groupBox_bulletListener";
            this.groupBox_bulletListener.Size = new System.Drawing.Size(168, 170);
            this.groupBox_bulletListener.TabIndex = 0;
            this.groupBox_bulletListener.TabStop = false;
            this.groupBox_bulletListener.Text = "监听弹幕";
            // 
            // checkBox_only4tom
            // 
            this.checkBox_only4tom.AutoSize = true;
            this.checkBox_only4tom.Location = new System.Drawing.Point(67, 143);
            this.checkBox_only4tom.Name = "checkBox_only4tom";
            this.checkBox_only4tom.Size = new System.Drawing.Size(78, 17);
            this.checkBox_only4tom.TabIndex = 8;
            this.checkBox_only4tom.Text = "only 4 Tom";
            this.checkBox_only4tom.UseVisualStyleBackColor = true;
            // 
            // textBox_userId
            // 
            this.textBox_userId.Location = new System.Drawing.Point(67, 91);
            this.textBox_userId.Name = "textBox_userId";
            this.textBox_userId.Size = new System.Drawing.Size(95, 20);
            this.textBox_userId.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 94);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "主播id";
            // 
            // textBox_userNickName
            // 
            this.textBox_userNickName.Location = new System.Drawing.Point(67, 117);
            this.textBox_userNickName.Name = "textBox_userNickName";
            this.textBox_userNickName.Size = new System.Drawing.Size(95, 20);
            this.textBox_userNickName.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "主播昵称";
            // 
            // pictureBox_bulletListener_states
            // 
            this.pictureBox_bulletListener_states.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.pictureBox_bulletListener_states.Location = new System.Drawing.Point(9, 45);
            this.pictureBox_bulletListener_states.Name = "pictureBox_bulletListener_states";
            this.pictureBox_bulletListener_states.Size = new System.Drawing.Size(40, 40);
            this.pictureBox_bulletListener_states.TabIndex = 3;
            this.pictureBox_bulletListener_states.TabStop = false;
            // 
            // checkBox_startBulletListener
            // 
            this.checkBox_startBulletListener.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox_startBulletListener.Location = new System.Drawing.Point(55, 45);
            this.checkBox_startBulletListener.Name = "checkBox_startBulletListener";
            this.checkBox_startBulletListener.Size = new System.Drawing.Size(107, 40);
            this.checkBox_startBulletListener.TabIndex = 2;
            this.checkBox_startBulletListener.Text = "启用监听";
            this.checkBox_startBulletListener.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox_startBulletListener.UseVisualStyleBackColor = true;
            this.checkBox_startBulletListener.CheckedChanged += new System.EventHandler(this.checkBox_startBulletListener_CheckedChanged);
            // 
            // textBox_roomId
            // 
            this.textBox_roomId.Location = new System.Drawing.Point(55, 19);
            this.textBox_roomId.Name = "textBox_roomId";
            this.textBox_roomId.Size = new System.Drawing.Size(107, 20);
            this.textBox_roomId.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "房间号";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox2.Controls.Add(this.textBox_eventLog);
            this.groupBox2.Location = new System.Drawing.Point(12, 188);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(168, 395);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "事件记录";
            // 
            // textBox_eventLog
            // 
            this.textBox_eventLog.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_eventLog.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_eventLog.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_eventLog.ContextMenuStrip = this.contextMenuStrip_textBox;
            this.textBox_eventLog.Location = new System.Drawing.Point(9, 19);
            this.textBox_eventLog.MaxLength = 10240;
            this.textBox_eventLog.Multiline = true;
            this.textBox_eventLog.Name = "textBox_eventLog";
            this.textBox_eventLog.ReadOnly = true;
            this.textBox_eventLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_eventLog.Size = new System.Drawing.Size(153, 370);
            this.textBox_eventLog.TabIndex = 0;
            // 
            // contextMenuStrip_textBox
            // 
            this.contextMenuStrip_textBox.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem_clean,
            this.VToolStripMenuItem_staticView});
            this.contextMenuStrip_textBox.Name = "contextMenuStrip_textBox";
            this.contextMenuStrip_textBox.Size = new System.Drawing.Size(137, 48);
            // 
            // ToolStripMenuItem_clean
            // 
            this.ToolStripMenuItem_clean.Name = "ToolStripMenuItem_clean";
            this.ToolStripMenuItem_clean.Size = new System.Drawing.Size(136, 22);
            this.ToolStripMenuItem_clean.Text = "清空(&C)";
            this.ToolStripMenuItem_clean.Click += new System.EventHandler(this.ToolStripMenuItem_clean_Click);
            // 
            // VToolStripMenuItem_staticView
            // 
            this.VToolStripMenuItem_staticView.Name = "VToolStripMenuItem_staticView";
            this.VToolStripMenuItem_staticView.Size = new System.Drawing.Size(136, 22);
            this.VToolStripMenuItem_staticView.Text = "静态查看(&V)";
            this.VToolStripMenuItem_staticView.Click += new System.EventHandler(this.ToolStripMenuItem_staticView_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage11);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(186, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(849, 571);
            this.tabControl1.TabIndex = 2;
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.tabControl4);
            this.tabPage11.Location = new System.Drawing.Point(4, 22);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(841, 545);
            this.tabPage11.TabIndex = 5;
            this.tabPage11.Text = "弹幕";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // tabControl4
            // 
            this.tabControl4.Controls.Add(this.tabPage12);
            this.tabControl4.Controls.Add(this.tabPage16);
            this.tabControl4.Controls.Add(this.tabPage13);
            this.tabControl4.Controls.Add(this.tabPage14);
            this.tabControl4.Controls.Add(this.tabPage15);
            this.tabControl4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl4.Location = new System.Drawing.Point(3, 3);
            this.tabControl4.Name = "tabControl4";
            this.tabControl4.SelectedIndex = 0;
            this.tabControl4.Size = new System.Drawing.Size(835, 539);
            this.tabControl4.TabIndex = 0;
            // 
            // tabPage12
            // 
            this.tabPage12.Controls.Add(this.textBox_bullet_msg);
            this.tabPage12.Location = new System.Drawing.Point(4, 22);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage12.Size = new System.Drawing.Size(827, 513);
            this.tabPage12.TabIndex = 0;
            this.tabPage12.Text = "消息";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // textBox_bullet_msg
            // 
            this.textBox_bullet_msg.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_bullet_msg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_bullet_msg.ContextMenuStrip = this.contextMenuStrip_textBox;
            this.textBox_bullet_msg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox_bullet_msg.Location = new System.Drawing.Point(3, 3);
            this.textBox_bullet_msg.MaxLength = 10240;
            this.textBox_bullet_msg.Multiline = true;
            this.textBox_bullet_msg.Name = "textBox_bullet_msg";
            this.textBox_bullet_msg.ReadOnly = true;
            this.textBox_bullet_msg.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_bullet_msg.Size = new System.Drawing.Size(821, 507);
            this.textBox_bullet_msg.TabIndex = 1;
            // 
            // tabPage16
            // 
            this.tabPage16.Controls.Add(this.textBox_voiceHistory);
            this.tabPage16.Location = new System.Drawing.Point(4, 22);
            this.tabPage16.Name = "tabPage16";
            this.tabPage16.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage16.Size = new System.Drawing.Size(827, 513);
            this.tabPage16.TabIndex = 4;
            this.tabPage16.Text = "语音";
            this.tabPage16.UseVisualStyleBackColor = true;
            // 
            // textBox_voiceHistory
            // 
            this.textBox_voiceHistory.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_voiceHistory.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_voiceHistory.ContextMenuStrip = this.contextMenuStrip_textBox;
            this.textBox_voiceHistory.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox_voiceHistory.Location = new System.Drawing.Point(3, 3);
            this.textBox_voiceHistory.MaxLength = 10240;
            this.textBox_voiceHistory.Multiline = true;
            this.textBox_voiceHistory.Name = "textBox_voiceHistory";
            this.textBox_voiceHistory.ReadOnly = true;
            this.textBox_voiceHistory.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_voiceHistory.Size = new System.Drawing.Size(821, 507);
            this.textBox_voiceHistory.TabIndex = 2;
            // 
            // tabPage13
            // 
            this.tabPage13.Controls.Add(this.textBox_bullet_gift);
            this.tabPage13.Location = new System.Drawing.Point(4, 22);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage13.Size = new System.Drawing.Size(827, 513);
            this.tabPage13.TabIndex = 1;
            this.tabPage13.Text = "礼物";
            this.tabPage13.UseVisualStyleBackColor = true;
            // 
            // textBox_bullet_gift
            // 
            this.textBox_bullet_gift.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_bullet_gift.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_bullet_gift.ContextMenuStrip = this.contextMenuStrip_textBox;
            this.textBox_bullet_gift.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox_bullet_gift.Location = new System.Drawing.Point(3, 3);
            this.textBox_bullet_gift.MaxLength = 10240;
            this.textBox_bullet_gift.Multiline = true;
            this.textBox_bullet_gift.Name = "textBox_bullet_gift";
            this.textBox_bullet_gift.ReadOnly = true;
            this.textBox_bullet_gift.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_bullet_gift.Size = new System.Drawing.Size(821, 507);
            this.textBox_bullet_gift.TabIndex = 2;
            // 
            // tabPage14
            // 
            this.tabPage14.Controls.Add(this.textBox_bullet_userIn);
            this.tabPage14.Location = new System.Drawing.Point(4, 22);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage14.Size = new System.Drawing.Size(827, 513);
            this.tabPage14.TabIndex = 2;
            this.tabPage14.Text = "进入";
            this.tabPage14.UseVisualStyleBackColor = true;
            // 
            // textBox_bullet_userIn
            // 
            this.textBox_bullet_userIn.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_bullet_userIn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_bullet_userIn.ContextMenuStrip = this.contextMenuStrip_textBox;
            this.textBox_bullet_userIn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox_bullet_userIn.Location = new System.Drawing.Point(3, 3);
            this.textBox_bullet_userIn.MaxLength = 10240;
            this.textBox_bullet_userIn.Multiline = true;
            this.textBox_bullet_userIn.Name = "textBox_bullet_userIn";
            this.textBox_bullet_userIn.ReadOnly = true;
            this.textBox_bullet_userIn.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_bullet_userIn.Size = new System.Drawing.Size(821, 507);
            this.textBox_bullet_userIn.TabIndex = 3;
            // 
            // tabPage15
            // 
            this.tabPage15.Controls.Add(this.textBox_bullet_other);
            this.tabPage15.Location = new System.Drawing.Point(4, 22);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage15.Size = new System.Drawing.Size(827, 513);
            this.tabPage15.TabIndex = 3;
            this.tabPage15.Text = "其他";
            this.tabPage15.UseVisualStyleBackColor = true;
            // 
            // textBox_bullet_other
            // 
            this.textBox_bullet_other.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_bullet_other.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_bullet_other.ContextMenuStrip = this.contextMenuStrip_textBox;
            this.textBox_bullet_other.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox_bullet_other.Location = new System.Drawing.Point(3, 3);
            this.textBox_bullet_other.MaxLength = 10240;
            this.textBox_bullet_other.Multiline = true;
            this.textBox_bullet_other.Name = "textBox_bullet_other";
            this.textBox_bullet_other.ReadOnly = true;
            this.textBox_bullet_other.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_bullet_other.Size = new System.Drawing.Size(821, 507);
            this.textBox_bullet_other.TabIndex = 4;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tabControl2);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(841, 545);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "过滤语音";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Controls.Add(this.tabPage8);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2.Location = new System.Drawing.Point(3, 3);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(835, 539);
            this.tabControl2.TabIndex = 1;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.dataGridView_BlackPinYin_Starts);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(827, 513);
            this.tabPage6.TabIndex = 0;
            this.tabPage6.Text = "起头";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // dataGridView_BlackPinYin_Starts
            // 
            this.dataGridView_BlackPinYin_Starts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_BlackPinYin_Starts.ContextMenuStrip = this.contextMenuStrip_dataGridView;
            this.dataGridView_BlackPinYin_Starts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_BlackPinYin_Starts.Location = new System.Drawing.Point(3, 3);
            this.dataGridView_BlackPinYin_Starts.Name = "dataGridView_BlackPinYin_Starts";
            this.dataGridView_BlackPinYin_Starts.Size = new System.Drawing.Size(821, 507);
            this.dataGridView_BlackPinYin_Starts.TabIndex = 1;
            this.dataGridView_BlackPinYin_Starts.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dataGridView_CellBeginEdit);
            this.dataGridView_BlackPinYin_Starts.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_CellEndEdit);
            this.dataGridView_BlackPinYin_Starts.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dataGridView_KeyDown);
            // 
            // contextMenuStrip_dataGridView
            // 
            this.contextMenuStrip_dataGridView.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem_refresh});
            this.contextMenuStrip_dataGridView.Name = "contextMenuStrip_dataGridView";
            this.contextMenuStrip_dataGridView.Size = new System.Drawing.Size(114, 26);
            // 
            // ToolStripMenuItem_refresh
            // 
            this.ToolStripMenuItem_refresh.Name = "ToolStripMenuItem_refresh";
            this.ToolStripMenuItem_refresh.Size = new System.Drawing.Size(113, 22);
            this.ToolStripMenuItem_refresh.Text = "刷新(&R)";
            this.ToolStripMenuItem_refresh.Click += new System.EventHandler(this.ToolStripMenuItem_refresh_Click);
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.dataGridView_BlackPinYin_Contains);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(827, 513);
            this.tabPage7.TabIndex = 1;
            this.tabPage7.Text = "包含";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // dataGridView_BlackPinYin_Contains
            // 
            this.dataGridView_BlackPinYin_Contains.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_BlackPinYin_Contains.ContextMenuStrip = this.contextMenuStrip_dataGridView;
            this.dataGridView_BlackPinYin_Contains.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_BlackPinYin_Contains.Location = new System.Drawing.Point(3, 3);
            this.dataGridView_BlackPinYin_Contains.Name = "dataGridView_BlackPinYin_Contains";
            this.dataGridView_BlackPinYin_Contains.Size = new System.Drawing.Size(821, 507);
            this.dataGridView_BlackPinYin_Contains.TabIndex = 1;
            this.dataGridView_BlackPinYin_Contains.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dataGridView_CellBeginEdit);
            this.dataGridView_BlackPinYin_Contains.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_CellEndEdit);
            this.dataGridView_BlackPinYin_Contains.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dataGridView_KeyDown);
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.dataGridView_BlackPinYin_Ends);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(827, 513);
            this.tabPage8.TabIndex = 2;
            this.tabPage8.Text = "结尾";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // dataGridView_BlackPinYin_Ends
            // 
            this.dataGridView_BlackPinYin_Ends.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_BlackPinYin_Ends.ContextMenuStrip = this.contextMenuStrip_dataGridView;
            this.dataGridView_BlackPinYin_Ends.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_BlackPinYin_Ends.Location = new System.Drawing.Point(3, 3);
            this.dataGridView_BlackPinYin_Ends.Name = "dataGridView_BlackPinYin_Ends";
            this.dataGridView_BlackPinYin_Ends.Size = new System.Drawing.Size(821, 507);
            this.dataGridView_BlackPinYin_Ends.TabIndex = 2;
            this.dataGridView_BlackPinYin_Ends.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dataGridView_CellBeginEdit);
            this.dataGridView_BlackPinYin_Ends.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_CellEndEdit);
            this.dataGridView_BlackPinYin_Ends.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dataGridView_KeyDown);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dataGridView_BlackKeyWord);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(841, 545);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "过滤匹配";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dataGridView_BlackKeyWord
            // 
            this.dataGridView_BlackKeyWord.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_BlackKeyWord.ContextMenuStrip = this.contextMenuStrip_dataGridView;
            this.dataGridView_BlackKeyWord.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_BlackKeyWord.Location = new System.Drawing.Point(3, 3);
            this.dataGridView_BlackKeyWord.Name = "dataGridView_BlackKeyWord";
            this.dataGridView_BlackKeyWord.Size = new System.Drawing.Size(835, 539);
            this.dataGridView_BlackKeyWord.TabIndex = 2;
            this.dataGridView_BlackKeyWord.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dataGridView_CellBeginEdit);
            this.dataGridView_BlackKeyWord.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_CellEndEdit);
            this.dataGridView_BlackKeyWord.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dataGridView_KeyDown);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.tabControl3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(841, 545);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "预处理";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage9);
            this.tabControl3.Controls.Add(this.tabPage10);
            this.tabControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl3.Location = new System.Drawing.Point(3, 3);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(835, 539);
            this.tabControl3.TabIndex = 0;
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.dataGridView_WordReplace);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(827, 513);
            this.tabPage9.TabIndex = 0;
            this.tabPage9.Text = "字符替换";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // dataGridView_WordReplace
            // 
            this.dataGridView_WordReplace.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_WordReplace.ContextMenuStrip = this.contextMenuStrip_dataGridView;
            this.dataGridView_WordReplace.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_WordReplace.Location = new System.Drawing.Point(3, 3);
            this.dataGridView_WordReplace.Name = "dataGridView_WordReplace";
            this.dataGridView_WordReplace.Size = new System.Drawing.Size(821, 507);
            this.dataGridView_WordReplace.TabIndex = 3;
            this.dataGridView_WordReplace.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dataGridView_CellBeginEdit);
            this.dataGridView_WordReplace.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_CellEndEdit);
            this.dataGridView_WordReplace.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dataGridView_KeyDown);
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.groupBox5);
            this.tabPage10.Controls.Add(this.groupBox4);
            this.tabPage10.Controls.Add(this.groupBox1);
            this.tabPage10.Location = new System.Drawing.Point(4, 22);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage10.Size = new System.Drawing.Size(827, 513);
            this.tabPage10.TabIndex = 1;
            this.tabPage10.Text = "其他";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.Controls.Add(this.button_loadGiftList);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.textBox_giftList);
            this.groupBox4.Controls.Add(this.textBox_loadGiftListURL);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Location = new System.Drawing.Point(264, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(557, 100);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "获取页面礼物列表";
            // 
            // button_loadGiftList
            // 
            this.button_loadGiftList.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_loadGiftList.Location = new System.Drawing.Point(476, 15);
            this.button_loadGiftList.Name = "button_loadGiftList";
            this.button_loadGiftList.Size = new System.Drawing.Size(75, 23);
            this.button_loadGiftList.TabIndex = 4;
            this.button_loadGiftList.Text = "获取";
            this.button_loadGiftList.UseVisualStyleBackColor = true;
            this.button_loadGiftList.Click += new System.EventHandler(this.button_loadGiftList_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 48);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "结果：";
            // 
            // textBox_giftList
            // 
            this.textBox_giftList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_giftList.Location = new System.Drawing.Point(55, 45);
            this.textBox_giftList.Name = "textBox_giftList";
            this.textBox_giftList.ReadOnly = true;
            this.textBox_giftList.Size = new System.Drawing.Size(496, 20);
            this.textBox_giftList.TabIndex = 2;
            // 
            // textBox_loadGiftListURL
            // 
            this.textBox_loadGiftListURL.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_loadGiftListURL.Location = new System.Drawing.Point(55, 19);
            this.textBox_loadGiftListURL.Name = "textBox_loadGiftListURL";
            this.textBox_loadGiftListURL.Size = new System.Drawing.Size(415, 20);
            this.textBox_loadGiftListURL.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 23);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "网址：";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBox_TxtToHalfwidthForms);
            this.groupBox1.Controls.Add(this.checkBox_isCheck3SameWord_inChinese);
            this.groupBox1.Controls.Add(this.checkBox_isRemoveSpace_inChinese);
            this.groupBox1.Controls.Add(this.checkBox_isCheck5SameChar_inChinese);
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(252, 100);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "通用";
            // 
            // checkBox_TxtToHalfwidthForms
            // 
            this.checkBox_TxtToHalfwidthForms.AutoSize = true;
            this.checkBox_TxtToHalfwidthForms.Location = new System.Drawing.Point(86, 19);
            this.checkBox_TxtToHalfwidthForms.Name = "checkBox_TxtToHalfwidthForms";
            this.checkBox_TxtToHalfwidthForms.Size = new System.Drawing.Size(104, 17);
            this.checkBox_TxtToHalfwidthForms.TabIndex = 4;
            this.checkBox_TxtToHalfwidthForms.Text = "，！？- 转半角";
            this.checkBox_TxtToHalfwidthForms.UseVisualStyleBackColor = true;
            // 
            // checkBox_isCheck3SameWord_inChinese
            // 
            this.checkBox_isCheck3SameWord_inChinese.AutoSize = true;
            this.checkBox_isCheck3SameWord_inChinese.Location = new System.Drawing.Point(6, 65);
            this.checkBox_isCheck3SameWord_inChinese.Name = "checkBox_isCheck3SameWord_inChinese";
            this.checkBox_isCheck3SameWord_inChinese.Size = new System.Drawing.Size(158, 17);
            this.checkBox_isCheck3SameWord_inChinese.TabIndex = 3;
            this.checkBox_isCheck3SameWord_inChinese.Text = "检查3连词（最大3字词）";
            this.checkBox_isCheck3SameWord_inChinese.UseVisualStyleBackColor = true;
            // 
            // checkBox_isRemoveSpace_inChinese
            // 
            this.checkBox_isRemoveSpace_inChinese.AutoSize = true;
            this.checkBox_isRemoveSpace_inChinese.Checked = true;
            this.checkBox_isRemoveSpace_inChinese.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_isRemoveSpace_inChinese.Location = new System.Drawing.Point(6, 19);
            this.checkBox_isRemoveSpace_inChinese.Name = "checkBox_isRemoveSpace_inChinese";
            this.checkBox_isRemoveSpace_inChinese.Size = new System.Drawing.Size(74, 17);
            this.checkBox_isRemoveSpace_inChinese.TabIndex = 2;
            this.checkBox_isRemoveSpace_inChinese.Text = "去掉空格";
            this.checkBox_isRemoveSpace_inChinese.UseVisualStyleBackColor = true;
            // 
            // checkBox_isCheck5SameChar_inChinese
            // 
            this.checkBox_isCheck5SameChar_inChinese.AutoSize = true;
            this.checkBox_isCheck5SameChar_inChinese.Location = new System.Drawing.Point(6, 42);
            this.checkBox_isCheck5SameChar_inChinese.Name = "checkBox_isCheck5SameChar_inChinese";
            this.checkBox_isCheck5SameChar_inChinese.Size = new System.Drawing.Size(80, 17);
            this.checkBox_isCheck5SameChar_inChinese.TabIndex = 0;
            this.checkBox_isCheck5SameChar_inChinese.Text = "检查5连字";
            this.checkBox_isCheck5SameChar_inChinese.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.dataGridView_BlackUser);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(841, 545);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "用户黑名单";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // dataGridView_BlackUser
            // 
            this.dataGridView_BlackUser.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_BlackUser.ContextMenuStrip = this.contextMenuStrip_dataGridView;
            this.dataGridView_BlackUser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_BlackUser.Location = new System.Drawing.Point(3, 3);
            this.dataGridView_BlackUser.Name = "dataGridView_BlackUser";
            this.dataGridView_BlackUser.Size = new System.Drawing.Size(835, 539);
            this.dataGridView_BlackUser.TabIndex = 4;
            this.dataGridView_BlackUser.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dataGridView_CellBeginEdit);
            this.dataGridView_BlackUser.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_CellEndEdit);
            this.dataGridView_BlackUser.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dataGridView_KeyDown);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox3);
            this.tabPage5.Controls.Add(this.uC_MultiVoice1);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(841, 545);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "语音配置";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.textBox_RemoteTest);
            this.groupBox3.Controls.Add(this.button_RemoteTest);
            this.groupBox3.Controls.Add(this.checkBox_voice_chat);
            this.groupBox3.Controls.Add(this.checkBox_voice_gift);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.textBox_remoteVoiceFileDir);
            this.groupBox3.Controls.Add(this.checkBox_useRemoteVoice);
            this.groupBox3.Controls.Add(this.numericUpDown_timeBetweenVoice);
            this.groupBox3.Controls.Add(this.numericUpDown_voiceCycleTime);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.textBox_voiceState);
            this.groupBox3.Controls.Add(this.pictureBox_isVoiceBusy);
            this.groupBox3.Controls.Add(this.checkBox_enableVoice);
            this.groupBox3.Controls.Add(this.pictureBox_enableVoice);
            this.groupBox3.Location = new System.Drawing.Point(6, 367);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(823, 102);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "工作方式";
            // 
            // textBox_RemoteTest
            // 
            this.textBox_RemoteTest.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_RemoteTest.Location = new System.Drawing.Point(650, 21);
            this.textBox_RemoteTest.Name = "textBox_RemoteTest";
            this.textBox_RemoteTest.Size = new System.Drawing.Size(104, 20);
            this.textBox_RemoteTest.TabIndex = 19;
            this.textBox_RemoteTest.Text = "试音试音，testing";
            // 
            // button_RemoteTest
            // 
            this.button_RemoteTest.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_RemoteTest.Location = new System.Drawing.Point(760, 19);
            this.button_RemoteTest.Name = "button_RemoteTest";
            this.button_RemoteTest.Size = new System.Drawing.Size(57, 23);
            this.button_RemoteTest.TabIndex = 18;
            this.button_RemoteTest.Text = "RTest";
            this.button_RemoteTest.UseVisualStyleBackColor = true;
            this.button_RemoteTest.Click += new System.EventHandler(this.button_RemoteTest_Click);
            // 
            // checkBox_voice_chat
            // 
            this.checkBox_voice_chat.AutoSize = true;
            this.checkBox_voice_chat.Location = new System.Drawing.Point(570, 40);
            this.checkBox_voice_chat.Name = "checkBox_voice_chat";
            this.checkBox_voice_chat.Size = new System.Drawing.Size(74, 17);
            this.checkBox_voice_chat.TabIndex = 17;
            this.checkBox_voice_chat.Text = "播报语音";
            this.checkBox_voice_chat.UseVisualStyleBackColor = true;
            // 
            // checkBox_voice_gift
            // 
            this.checkBox_voice_gift.AutoSize = true;
            this.checkBox_voice_gift.Location = new System.Drawing.Point(570, 19);
            this.checkBox_voice_gift.Name = "checkBox_voice_gift";
            this.checkBox_voice_gift.Size = new System.Drawing.Size(74, 17);
            this.checkBox_voice_gift.TabIndex = 16;
            this.checkBox_voice_gift.Text = "答谢礼物";
            this.checkBox_voice_gift.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(136, 76);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "存储地址：";
            // 
            // textBox_remoteVoiceFileDir
            // 
            this.textBox_remoteVoiceFileDir.Location = new System.Drawing.Point(211, 74);
            this.textBox_remoteVoiceFileDir.Name = "textBox_remoteVoiceFileDir";
            this.textBox_remoteVoiceFileDir.Size = new System.Drawing.Size(353, 20);
            this.textBox_remoteVoiceFileDir.TabIndex = 14;
            // 
            // checkBox_useRemoteVoice
            // 
            this.checkBox_useRemoteVoice.AutoSize = true;
            this.checkBox_useRemoteVoice.Location = new System.Drawing.Point(6, 74);
            this.checkBox_useRemoteVoice.Name = "checkBox_useRemoteVoice";
            this.checkBox_useRemoteVoice.Size = new System.Drawing.Size(98, 17);
            this.checkBox_useRemoteVoice.TabIndex = 13;
            this.checkBox_useRemoteVoice.Text = "使用远程语音";
            this.checkBox_useRemoteVoice.UseVisualStyleBackColor = true;
            this.checkBox_useRemoteVoice.CheckedChanged += new System.EventHandler(this.CheckBox_useRemoteVoice_CheckedChanged);
            // 
            // numericUpDown_timeBetweenVoice
            // 
            this.numericUpDown_timeBetweenVoice.Location = new System.Drawing.Point(444, 39);
            this.numericUpDown_timeBetweenVoice.Name = "numericUpDown_timeBetweenVoice";
            this.numericUpDown_timeBetweenVoice.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown_timeBetweenVoice.TabIndex = 12;
            // 
            // numericUpDown_voiceCycleTime
            // 
            this.numericUpDown_voiceCycleTime.Location = new System.Drawing.Point(318, 39);
            this.numericUpDown_voiceCycleTime.Name = "numericUpDown_voiceCycleTime";
            this.numericUpDown_voiceCycleTime.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown_voiceCycleTime.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(441, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "句间隔(s)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(315, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "语音周期（最小s）";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(211, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "工作状态";
            // 
            // textBox_voiceState
            // 
            this.textBox_voiceState.Location = new System.Drawing.Point(211, 39);
            this.textBox_voiceState.Name = "textBox_voiceState";
            this.textBox_voiceState.ReadOnly = true;
            this.textBox_voiceState.Size = new System.Drawing.Size(100, 20);
            this.textBox_voiceState.TabIndex = 7;
            // 
            // pictureBox_isVoiceBusy
            // 
            this.pictureBox_isVoiceBusy.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.pictureBox_isVoiceBusy.Location = new System.Drawing.Point(165, 19);
            this.pictureBox_isVoiceBusy.Name = "pictureBox_isVoiceBusy";
            this.pictureBox_isVoiceBusy.Size = new System.Drawing.Size(40, 40);
            this.pictureBox_isVoiceBusy.TabIndex = 6;
            this.pictureBox_isVoiceBusy.TabStop = false;
            // 
            // checkBox_enableVoice
            // 
            this.checkBox_enableVoice.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox_enableVoice.Location = new System.Drawing.Point(52, 19);
            this.checkBox_enableVoice.Name = "checkBox_enableVoice";
            this.checkBox_enableVoice.Size = new System.Drawing.Size(107, 40);
            this.checkBox_enableVoice.TabIndex = 5;
            this.checkBox_enableVoice.Text = "启用语音";
            this.checkBox_enableVoice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox_enableVoice.UseVisualStyleBackColor = true;
            this.checkBox_enableVoice.CheckedChanged += new System.EventHandler(this.checkBox_enableVoice_CheckedChanged);
            // 
            // pictureBox_enableVoice
            // 
            this.pictureBox_enableVoice.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.pictureBox_enableVoice.Location = new System.Drawing.Point(6, 19);
            this.pictureBox_enableVoice.Name = "pictureBox_enableVoice";
            this.pictureBox_enableVoice.Size = new System.Drawing.Size(40, 40);
            this.pictureBox_enableVoice.TabIndex = 4;
            this.pictureBox_enableVoice.TabStop = false;
            // 
            // uC_MultiVoice1
            // 
            this.uC_MultiVoice1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.uC_MultiVoice1.Location = new System.Drawing.Point(6, 6);
            this.uC_MultiVoice1.Name = "uC_MultiVoice1";
            this.uC_MultiVoice1.Size = new System.Drawing.Size(829, 355);
            this.uC_MultiVoice1.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox5.Controls.Add(this.button_loadFaceList);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.textBox_faceList);
            this.groupBox5.Controls.Add(this.textBox_loadFaceListURL);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Location = new System.Drawing.Point(264, 112);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(557, 100);
            this.groupBox5.TabIndex = 5;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "获取聊天表情列表";
            // 
            // button_loadFaceList
            // 
            this.button_loadFaceList.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_loadFaceList.Location = new System.Drawing.Point(476, 15);
            this.button_loadFaceList.Name = "button_loadFaceList";
            this.button_loadFaceList.Size = new System.Drawing.Size(75, 23);
            this.button_loadFaceList.TabIndex = 4;
            this.button_loadFaceList.Text = "获取";
            this.button_loadFaceList.UseVisualStyleBackColor = true;
            this.button_loadFaceList.Click += new System.EventHandler(this.button_loadFaceList_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 48);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(43, 13);
            this.label10.TabIndex = 3;
            this.label10.Text = "结果：";
            // 
            // textBox_faceList
            // 
            this.textBox_faceList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_faceList.Location = new System.Drawing.Point(55, 45);
            this.textBox_faceList.Name = "textBox_faceList";
            this.textBox_faceList.ReadOnly = true;
            this.textBox_faceList.Size = new System.Drawing.Size(496, 20);
            this.textBox_faceList.TabIndex = 2;
            // 
            // textBox_loadFaceListURL
            // 
            this.textBox_loadFaceListURL.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_loadFaceListURL.Location = new System.Drawing.Point(55, 19);
            this.textBox_loadFaceListURL.Name = "textBox_loadFaceListURL";
            this.textBox_loadFaceListURL.Size = new System.Drawing.Size(415, 20);
            this.textBox_loadFaceListURL.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 23);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(43, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "网址：";
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1047, 595);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox_bulletListener);
            this.Name = "FormMain";
            this.Text = "PageSecretary V2 by longtombbj 2016 0817";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormMain_FormClosing);
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.groupBox_bulletListener.ResumeLayout(false);
            this.groupBox_bulletListener.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_bulletListener_states)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.contextMenuStrip_textBox.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage11.ResumeLayout(false);
            this.tabControl4.ResumeLayout(false);
            this.tabPage12.ResumeLayout(false);
            this.tabPage12.PerformLayout();
            this.tabPage16.ResumeLayout(false);
            this.tabPage16.PerformLayout();
            this.tabPage13.ResumeLayout(false);
            this.tabPage13.PerformLayout();
            this.tabPage14.ResumeLayout(false);
            this.tabPage14.PerformLayout();
            this.tabPage15.ResumeLayout(false);
            this.tabPage15.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_BlackPinYin_Starts)).EndInit();
            this.contextMenuStrip_dataGridView.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_BlackPinYin_Contains)).EndInit();
            this.tabPage8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_BlackPinYin_Ends)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_BlackKeyWord)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_WordReplace)).EndInit();
            this.tabPage10.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_BlackUser)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_timeBetweenVoice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_voiceCycleTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_isVoiceBusy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_enableVoice)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_bulletListener;
        private System.Windows.Forms.PictureBox pictureBox_bulletListener_states;
        private System.Windows.Forms.CheckBox checkBox_startBulletListener;
        private System.Windows.Forms.TextBox textBox_roomId;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBox_eventLog;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.DataGridView dataGridView_BlackPinYin_Starts;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.DataGridView dataGridView_BlackPinYin_Contains;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridView_BlackKeyWord;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.TabPage tabPage15;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip_textBox;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_clean;
        private System.Windows.Forms.TextBox textBox_bullet_msg;
        private System.Windows.Forms.TextBox textBox_bullet_gift;
        private System.Windows.Forms.TextBox textBox_bullet_userIn;
        private System.Windows.Forms.TextBox textBox_bullet_other;
        private System.Windows.Forms.TextBox textBox_userNickName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_userId;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ToolStripMenuItem VToolStripMenuItem_staticView;
        private System.Windows.Forms.DataGridView dataGridView_BlackUser;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip_dataGridView;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_refresh;
        private System.Windows.Forms.DataGridView dataGridView_WordReplace;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBox_isCheck3SameWord_inChinese;
        private System.Windows.Forms.CheckBox checkBox_isRemoveSpace_inChinese;
        private System.Windows.Forms.CheckBox checkBox_isCheck5SameChar_inChinese;
        private System.Windows.Forms.DataGridView dataGridView_BlackPinYin_Ends;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_remoteVoiceFileDir;
        private System.Windows.Forms.CheckBox checkBox_useRemoteVoice;
        private System.Windows.Forms.NumericUpDown numericUpDown_timeBetweenVoice;
        private System.Windows.Forms.NumericUpDown numericUpDown_voiceCycleTime;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_voiceState;
        private System.Windows.Forms.PictureBox pictureBox_isVoiceBusy;
        private System.Windows.Forms.CheckBox checkBox_enableVoice;
        private System.Windows.Forms.PictureBox pictureBox_enableVoice;
        private T2S_HCore.UI.UC_MultiVoice uC_MultiVoice1;
        private System.Windows.Forms.CheckBox checkBox_only4tom;
        private System.Windows.Forms.TabPage tabPage16;
        private System.Windows.Forms.TextBox textBox_voiceHistory;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button button_loadGiftList;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox_giftList;
        private System.Windows.Forms.TextBox textBox_loadGiftListURL;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox checkBox_voice_chat;
        private System.Windows.Forms.CheckBox checkBox_voice_gift;
        private System.Windows.Forms.CheckBox checkBox_TxtToHalfwidthForms;
        private System.Windows.Forms.Button button_RemoteTest;
        private System.Windows.Forms.TextBox textBox_RemoteTest;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button_loadFaceList;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox_faceList;
        private System.Windows.Forms.TextBox textBox_loadFaceListURL;
        private System.Windows.Forms.Label label11;
    }
}

