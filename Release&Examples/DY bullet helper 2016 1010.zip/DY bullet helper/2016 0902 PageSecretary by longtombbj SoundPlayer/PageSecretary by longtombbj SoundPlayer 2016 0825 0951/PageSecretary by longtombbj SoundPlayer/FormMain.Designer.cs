﻿namespace PageSecretary_by_longtombbj_SoundPlayer
{
    partial class FormMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.checkBox_startWatching = new System.Windows.Forms.CheckBox();
            this.textBox_watchDir = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.fileSystemWatcher = new System.IO.FileSystemWatcher();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher)).BeginInit();
            this.SuspendLayout();
            // 
            // checkBox_startWatching
            // 
            this.checkBox_startWatching.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBox_startWatching.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBox_startWatching.Location = new System.Drawing.Point(12, 12);
            this.checkBox_startWatching.Name = "checkBox_startWatching";
            this.checkBox_startWatching.Size = new System.Drawing.Size(217, 96);
            this.checkBox_startWatching.TabIndex = 0;
            this.checkBox_startWatching.Text = "Start Watching";
            this.checkBox_startWatching.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox_startWatching.UseVisualStyleBackColor = true;
            this.checkBox_startWatching.CheckedChanged += new System.EventHandler(this.checkBox_startWatching_CheckedChanged);
            // 
            // textBox_watchDir
            // 
            this.textBox_watchDir.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_watchDir.Location = new System.Drawing.Point(12, 114);
            this.textBox_watchDir.Multiline = true;
            this.textBox_watchDir.Name = "textBox_watchDir";
            this.textBox_watchDir.Size = new System.Drawing.Size(217, 43);
            this.textBox_watchDir.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 160);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 52);
            this.label1.TabIndex = 2;
            this.label1.Text = "If the directory exists,\r\nstart watching will save it.\r\n\r\nSound that\'s played wil" +
    "l be delete.";
            // 
            // timer
            // 
            this.timer.Enabled = true;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // fileSystemWatcher
            // 
            this.fileSystemWatcher.EnableRaisingEvents = true;
            this.fileSystemWatcher.Filter = "*.wav";
            this.fileSystemWatcher.NotifyFilter = System.IO.NotifyFilters.LastWrite;
            this.fileSystemWatcher.SynchronizingObject = this;
            this.fileSystemWatcher.Changed += new System.IO.FileSystemEventHandler(this.fileSystemWatcher_Changed);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(241, 232);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox_watchDir);
            this.Controls.Add(this.checkBox_startWatching);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "FormMain";
            this.Text = "Play Once";
            this.Load += new System.EventHandler(this.FormMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox checkBox_startWatching;
        private System.Windows.Forms.TextBox textBox_watchDir;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer;
        private System.IO.FileSystemWatcher fileSystemWatcher;
    }
}

