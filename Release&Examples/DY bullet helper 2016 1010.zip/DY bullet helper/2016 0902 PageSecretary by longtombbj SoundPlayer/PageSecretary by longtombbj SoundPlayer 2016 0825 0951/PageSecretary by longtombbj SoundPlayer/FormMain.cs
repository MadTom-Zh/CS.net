﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;

namespace PageSecretary_by_longtombbj_SoundPlayer
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private static string DirPath_Sound = Application.StartupPath + "\\SoundDir.txt";
        private string DirPath_Sound_tmp;
        private void FormMain_Load(object sender, EventArgs e)
        {
            if (File.Exists(DirPath_Sound))
            {
                textBox_watchDir.Text = File.ReadAllText(DirPath_Sound);
            }
            else
            {
                textBox_watchDir.Text = @"C:\";
            }
            DirPath_Sound_tmp = textBox_watchDir.Text;

            mediaPlayer.settings.volume = 100;
            mediaPlayer.settings.autoStart = false;
            mediaPlayer.PlayStateChange += MediaPlayer_PlayStateChange;

            //backgroundWorker.RunWorkerAsync(mediaPlayer);
        }


        private void MediaPlayer_PlayStateChange(int NewState)
        {
            if (NewState == (int)WMPLib.WMPPlayState.wmppsStopped)
            {
                // stoped
                Sound2Delete.Enqueue(mediaPlayer.URL);

                if (SoundQueue.Count > 0
                    && CheckFilesContinuous(mediaPlayer.URL, SoundQueue[0]) == true
                    )
                {
                    mediaPlayer.URL = SoundQueue[0];
                    SoundQueue.RemoveAt(0);
                    waitTimeDecount = 4;
                }
                else
                {
                    mediaPlayer.URL = "";
                    waitTimeDecount = 4;
                }

                timer.Enabled = true;
            }
        }

        private List<string> SoundQueue = new List<string>();
        private void checkBox_startWatching_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_startWatching.Checked == true)
            {
                if (SaveDirPath_Sound() == true)
                {
                    LoadExistWavFilesNInqueue();
                    fileSystemWatcher.Path = textBox_watchDir.Text;
                    fileSystemWatcher.EnableRaisingEvents = true;
                    timer.Enabled = true;
                }
                else
                {
                    checkBox_startWatching.Checked = false;
                    timer.Enabled = false;
                    fileSystemWatcher.EnableRaisingEvents = false;
                    MessageBox.Show("Something wrong with the path.");
                }
            }
            else
            {
                timer.Enabled = false;
                fileSystemWatcher.EnableRaisingEvents = false;
            }
        }
        private bool SaveDirPath_Sound()
        {
            if (DirPath_Sound_tmp != textBox_watchDir.Text)
            {
                if (Directory.Exists(textBox_watchDir.Text))
                {
                    //string playingDir = textBox_watchDir.Text + "\\playing";
                    //if (Directory.Exists(playingDir) == false)
                    //{
                    //    Directory.CreateDirectory(playingDir);
                    //}
                    File.WriteAllText(DirPath_Sound, textBox_watchDir.Text);
                    return true;
                }
                return false;
            }
            return true;
        }

        private void LoadExistWavFilesNInqueue()
        {
            DirectoryInfo dir = new DirectoryInfo(textBox_watchDir.Text);
            foreach (FileInfo fi in dir.GetFiles("*.wav"))
            {
                InqueueSoundFile(fi.FullName);
            }
        }
        private void InqueueSoundFile(string soundFileFullName)
        {
            foreach (string fi in SoundQueue)
            {
                if (fi == soundFileFullName)
                {
                    return;
                }
            }
            SoundQueue.Add(soundFileFullName);
        }
        private void fileSystemWatcher_Changed(object sender, FileSystemEventArgs e)
        {
            if (e.ChangeType == WatcherChangeTypes.Deleted)
            {
                return;
            }
            InqueueSoundFile(e.FullPath);
        }

        int waitTimeDecount = 0;
        WMPLib.WindowsMediaPlayer mediaPlayer = new WMPLib.WindowsMediaPlayer();
        Queue<string> Sound2Delete = new Queue<string>();
        private void timer_Tick(object sender, EventArgs e)
        {
            if (waitTimeDecount > 0)
            {
                waitTimeDecount--;
                return;
            }

            TryDeleteOldFiles();


            if (mediaPlayer.URL != null && mediaPlayer.URL != "")
            {
                timer.Enabled = false;
                mediaPlayer.controls.play();
                return;
            }
            else if (SoundQueue.Count > 0)
            {
                mediaPlayer.URL = SoundQueue[0];
                SoundQueue.RemoveAt(0);
            }
            else if (SoundQueue.Count == 0)
            {
                waitTimeDecount = 4;
                return;
            }
        }
        private bool CheckFilesContinuous(string preWavFullName, string curWavFullName)
        {
            if (preWavFullName == null && curWavFullName != null)
            {
                return true;
            }
            if (curWavFullName == null)
            {
                return false;
            }

            try
            {
                string strPre = preWavFullName;
                strPre = strPre.Substring(0, strPre.Length - 4);
                strPre = strPre.Substring(strPre.Length - 4);
                int intPre = int.Parse(strPre);

                string strCur = curWavFullName;
                strCur = strCur.Substring(0, strCur.Length - 4);
                strCur = strCur.Substring(strCur.Length - 4);
                int intCur = int.Parse(strCur);

                if ((intCur - 1) == intPre)
                {
                    return true;
                }
                return false;
            }
            catch
            {
                return false;
            }

        }
        private void TryDeleteOldFiles()
        {
            if (Sound2Delete.Count > 0)
            {
                string fn = Sound2Delete.First();
                try
                {
                    File.Delete(fn);
                    Sound2Delete.Dequeue();
                }
                catch
                {
                }
            }
        }
    }
}
