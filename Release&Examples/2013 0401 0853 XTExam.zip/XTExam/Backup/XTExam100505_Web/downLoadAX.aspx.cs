﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace XTExam100505_Web
{
    public partial class downLoadAX : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Clear();

            Response.AddHeader("Content-Disposition", "attachment; filename=Silverlight.exe");

            //Response.AddHeader("Content-Length"

            Response.ContentType = "application/octet-stream";

            Response.WriteFile("SL_Setup/Silverlight.exe");

            Response.End();
        }
    }
}