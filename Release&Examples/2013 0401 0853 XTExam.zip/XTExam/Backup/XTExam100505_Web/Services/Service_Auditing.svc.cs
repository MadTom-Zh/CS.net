﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

using XTExam100505.CodeSharing.Entities;

namespace XTExam100505_Web.Services
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service_Auditing" in code, svc and config file together.
    public class Service_Auditing : IService_Auditing
    {
        public List<string> GetMyExamerList(string op)
        {
            return IOWorks.AuditPaper.GetMyExamerList(op);
        }
        public List<string> GetMyAuditingExamerList(string op)
        {
            return IOWorks.AuditPaper.GetMyAuditingExamerList(op);
        }

        public void AuditingSet(string op, string examerPath)
        {
            IOWorks.AuditPaper.Auditing_Set(op, examerPath);
        }
        public void AuditingDrop(string op, string examerPath)
        {
            IOWorks.AuditPaper.Auditing_Drop(op, examerPath);
        }

        public void AuditingSetComplete(string op, string examerPath)
        {
            IOWorks.AuditPaper.Auditing_SetComplete(op, examerPath);
        }
    }
}
