﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace XTExam100505_Web.Services
{
    public partial class image : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //string path = Request.Params["path"];
            string name = Request.Params["name"];
            Response.Clear();
            //if (path == null || path.Length == 0 || name == null) return;
            //path = HttpUtility.UrlDecode(path);
            name = HttpUtility.UrlDecode(name);
            string imageType = name.Substring(name.LastIndexOf('.') + 1).ToLower();
            if (imageType == "jpg") imageType = "jpeg";
            Response.ContentType = "image/" + imageType;

            //string depotSign = "depot-of-";
            //while (path.EndsWith("\\")) path = path.Substring(0, path.Length - 1);
            //if (path.Contains('\\')) path = path.Substring(0, path.LastIndexOf('\\')) + "\\" + depotSign + path.Substring(path.LastIndexOf('\\') + 1);
            //else path = depotSign + path;

            string fileFullPath = "..\\App_Data\\DepotImages\\" + name;
            Response.WriteFile(fileFullPath);
        }
    }
}