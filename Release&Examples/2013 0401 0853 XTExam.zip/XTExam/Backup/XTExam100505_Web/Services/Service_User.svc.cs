﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

using System.IO;

using XTExam100505.CodeSharing.Entities;

namespace XTExam100505_Web.Services
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service_User" in code, svc and config file together.
    public class Service_User : IService_User
    {
        #region 存储设置
        // root stor path is "User"
        private static string USER = "User";
        public bool AddStorPath(string Relate_Path)
        {
            string target = IOWorks.WebSite.Path_App_Data + "\\" + USER + "\\" + Relate_Path;
            target = target.Replace("\\\\", "\\");
            if (File.Exists(target + SUFFIX_HEAD) || File.Exists(target + SUFFIX_BODY))
            {
                return false;
            }
            if (!Directory.Exists(target))
            {
                Directory.CreateDirectory(target);
                return true;
            }
            return false;
        }


        // header file using suffix "_hea.txt" or body ".txt"
        private static string SUFFIX_HEAD = "_hea.txt";
        private static string SUFFIX_BODY = ".txt";
        public bool AddStorFile(string Relate_Path, string op)
        {
            string target = IOWorks.WebSite.Path_App_Data + "\\" + USER + "\\" + Relate_Path;
            target = target.Replace("\\\\", "\\");
            if (Directory.Exists(target))
            {
                return false;
            }
            string targetHead = target + SUFFIX_HEAD;
            if (!File.Exists(targetHead))
            {
                string title = Relate_Path.Contains('\\') ? Relate_Path.Substring(Relate_Path.LastIndexOf('\\') + 1) : Relate_Path;
                DataProcessing.UserList.Header helper = new DataProcessing.UserList.Header(title, op, DateTime.Now);
                File.WriteAllText(targetHead, helper.IOContent);
                StreamWriter sw = File.CreateText(target + SUFFIX_BODY);
                sw.Close();
                return true;
            }
            return false;
        }

        public bool DelStorNode(string Relate_Path, string op)
        {
            string target = IOWorks.WebSite.Path_App_Data + "\\" + USER + "\\" + Relate_Path;
            string backupPath = IOWorks.WebSite.Path_App_Data + "\\" + "User.Backup";
            if (!Directory.Exists(backupPath))
            {
                Directory.CreateDirectory(backupPath);
            }
            string backItem;
            int count;
            if (Directory.Exists(target))
            {
                backItem = backupPath + target.Substring(target.LastIndexOf('\\'));
                count = 0;
                if (Directory.Exists(backItem))
                {
                    count = 1;
                    backItem += "-" + count;
                    while (Directory.Exists(backItem))
                    {
                        count++;
                        backItem = backItem.Substring(0, backItem.Length - 1) + count;
                    }
                }
                Directory.Move(target, backItem);
                IOWorks.WebSite.WriteLog("User[" + op + "] delete User Storage(withFile)[" + Relate_Path + "]");
                return true;
            }
            string header = target + SUFFIX_HEAD;
            string body = target + SUFFIX_BODY;
            if (File.Exists(body))
            {
                count = 0;
                backItem = backupPath + "\\" + body.Substring(body.LastIndexOf('\\'));
                if (File.Exists(backItem))
                {
                    count = 1;
                    backItem = backupPath + "\\" + target.Substring(target.LastIndexOf('\\')) + "-" + count + SUFFIX_BODY;
                    while (File.Exists(backItem))
                    {
                        count++;
                        backItem = backupPath + "\\" + target.Substring(target.LastIndexOf('\\')) + "-" + count + SUFFIX_BODY;
                    }
                }
                File.Move(body, backItem);
            }
            else
            {
                return false;
            }
            if (File.Exists(header))
            {
                if (count > 0)
                {
                    backItem = backupPath + "\\" + target.Substring(target.LastIndexOf('\\')) + "-" + count + SUFFIX_HEAD;
                }
                else
                {
                    backItem = backupPath + "\\" + header.Substring(header.LastIndexOf('\\'));
                }
                File.Move(header, backItem);
            }
            else
            {
                return false;
            }
            IOWorks.WebSite.WriteLog("User[" + op + "] delete User Storage(file)[" + Relate_Path + "]" + ((count > 0) ? (", backCount[" + count + "]") : ""));
            return true;
        }

        public bool CopyStorNode(string Relate_sourcePath, string Relate_targetPath, string op)
        {
            string source = IOWorks.WebSite.Path_App_Data + "\\" + USER + "\\";
            string target = source;
            source += Relate_sourcePath;
            target += Relate_targetPath;
            if (Directory.Exists(source))
            {
                if (CopyWholeDir(source, target))
                {
                    return true;
                }
            }
            string sHeadFile = source + SUFFIX_HEAD;
            string sBodyFile = source + SUFFIX_BODY;
            if (File.Exists(sHeadFile) && File.Exists(sBodyFile))
            {
                File.Copy(sHeadFile, target + SUFFIX_HEAD);
                File.Copy(sBodyFile, target + SUFFIX_BODY);
                return true;
            }
            return false;
        }
        private bool CopyWholeDir(string source, string target)
        {
            if (!Directory.Exists(source)) return false;
            if (!Directory.Exists(target)) Directory.CreateDirectory(target);
            DirectoryInfo dirInfo = new DirectoryInfo(source);
            foreach (DirectoryInfo subDir in dirInfo.GetDirectories())
            {
                if (!CopyWholeDir(subDir.FullName, target + "\\" + subDir.Name))
                {
                    return false;
                }
            }
            foreach (FileInfo subFile in dirInfo.GetFiles())
            {
                File.Copy(subFile.FullName, target + "\\" + subFile.Name);
            }
            return true;
        }
        #endregion

        private string rootUserPath;
        /// <summary>
        /// Load User List Data
        /// use "F->" or "D->" to sign file or directory
        /// </summary>
        /// <returns></returns>
        public List<string> LoadAllStorItems()
        {
            rootUserPath = IOWorks.WebSite.Path_App_Data + "\\" + USER + "\\";
            List<string> result = new List<string>();
            DirectoryInfo dirInfo = new DirectoryInfo(rootUserPath);
            LoadAllStorItems_LoadDirItem(dirInfo, ref result);
            return result;
        }
        private void LoadAllStorItems_LoadDirItem(DirectoryInfo dir, ref List<string> list)
        {
            bool haveSubDirs = false;
            foreach (DirectoryInfo subDir in dir.GetDirectories())
            {
                LoadAllStorItems_LoadDirItem(subDir, ref list);
                haveSubDirs = true;
            }
            bool haveSubFiles = false;
            foreach (FileInfo file in dir.GetFiles())
            {
                string fileItem = (file.FullName).Substring(rootUserPath.Length);
                if (fileItem.EndsWith(SUFFIX_HEAD))
                {
                    fileItem = fileItem.Substring(0, fileItem.Length - SUFFIX_HEAD.Length);
                    list.Add("F->" + fileItem);
                    haveSubFiles = true;
                }
            }
            if (!haveSubFiles && !haveSubDirs)
            {
                if (dir.FullName.Length > rootUserPath.Length)
                {
                    list.Add("D->" + (dir.FullName).Substring(rootUserPath.Length));
                }
            }
        }


        #region 设置单个用户列表
        public bool SetFileHeader(string Relate_Path, List<string> headerLine, string op)
        {
            string headerFile = IOWorks.WebSite.Path_App_Data + "\\" + USER + "\\" + Relate_Path + SUFFIX_HEAD;
            if (File.Exists(headerFile))
            {
                DataProcessing.UserList.Header helper = new DataProcessing.UserList.Header(null);
                helper.LineContent = GetFileHeader(Relate_Path);
                helper.LineContent = headerLine;
                helper.modifier = op;
                helper.modifyTime = DateTime.Now;
                File.WriteAllText(headerFile, helper.IOContent, Encoding.UTF8);
                return true;
            }
            return false;
        }
        public List<string> GetFileHeader(string Relate_Path)
        {
            string headerFile = IOWorks.WebSite.Path_App_Data + "\\" + USER + "\\" + Relate_Path + SUFFIX_HEAD;
            DataProcessing.UserList.Header header = new DataProcessing.UserList.Header(null);
            header.IOContent = File.ReadAllText(headerFile);
            return header.LineContent;
        }
        public bool SetFileBody(string Relate_Path, List<string> uListBody, string op)
        {

            string headerFile = IOWorks.WebSite.Path_App_Data + "\\" + USER + "\\" + Relate_Path + SUFFIX_BODY;
            if (File.Exists(headerFile))
            {
                List<string> headerContent = GetFileHeader(Relate_Path);
                DataProcessing.UserList.Header header = new DataProcessing.UserList.Header(null);
                header.LineContent = headerContent;
                header.modifier = op;
                header.modifyTime = DateTime.Now;
                SetFileHeader(Relate_Path, header.LineContent, op);

                string content = "";
                foreach (string line in uListBody)
                {
                    content += line + "\r\n";
                }
                IOWorks.UserRegister.UserInfo.SetUsers(uListBody, op);
                File.WriteAllText(headerFile, content, Encoding.UTF8);
                ReSync(uListBody, op);
                return true;
            }
            return false;
        }
        public List<string> GetFileBody(string Relate_Path)
        {
            string bodyFile = IOWorks.WebSite.Path_App_Data + "\\" + USER + "\\" + Relate_Path + SUFFIX_BODY;
            string[] lines = File.ReadAllLines(bodyFile);
            List<string> result = new List<string>();
            for (int i = 0; i < lines.Length; i++)
            {
                if (lines.Length != 0)
                {
                    result.Add(lines[i]);
                }
            }
            return result;
        }
        //public bool SetFile(string Relate_Path, List<string> headerLine, List<string> uListBody, string op)
        //{
        //    if (!SetFileHeader(Relate_Path, headerLine, op)) return false;
        //    if (!SetFileBody(Relate_Path, uListBody, op)) return false;
        //    return true;
        //}

        public bool ChangeUserBaseInfo(string op, string targetUserId, string userName, string userOrgPath)
        {
            return IOWorks.UserRegister.UserInfo.ChangeUserBaseInfo(op, targetUserId, userName, userOrgPath);
        }
        public bool ChangeUserInnerPWD(string op, string targetUserId, string oldPwd, string newPwd)
        {
            return IOWorks.UserRegister.UserInfo.ChangeUserInnerPassword(op, targetUserId, oldPwd, newPwd);
        }
        #endregion


        public string GetMyId(string acc, string exPwd, string inPwd)
        {
            List<string> result = new List<string>();
            DataProcessing.UserRegister.UserInfo user = IOWorks.UserRegister.UserInfo.GetUser(acc, exPwd, inPwd);
            if (user == null) return null;
            return user.IOContent;
        }

        #region 大量用户操作
        public void ReSyncAll(string op)
        {
            List<string> allUserId = IOWorks.UserRegister.UserInfo.GetAllUserId(op);
            ReSync(allUserId, op);
        }
        public void ReSync(List<string> userIdList, string op)
        {
            //throw new Exception("Function Limitition!");
            List<string> userOrgs;
            string orgStr = "";
            foreach (string uId in userIdList)
            {
                try
                {
                    userOrgs = SGCC_NX_UUMP.GetUserFullPath(uId);
                    orgStr = "";
                    for (int i = 0; i < userOrgs.Count - 1; i++)
                    {
                        if (orgStr.Length > 0) orgStr += "\\";
                        orgStr += userOrgs[i];
                    }
                    IOWorks.UserRegister.UserInfo.ChangeUserBaseInfo(op, uId, userOrgs[userOrgs.Count - 1], orgStr);
                }
                catch (Exception) { }
            }
        }
        public List<List<string>> GetUsers(List<string> userIdList)
        {
            List<List<string>> userFList = new List<List<string>>();
            List<DataProcessing.UserRegister.UserInfo> userList = IOWorks.UserRegister.UserInfo.GetUsers(userIdList);
            for (int i = 0; i < userList.Count; i++)
            {
                userFList.Add(userList[i].LineContent);
            }
            return userFList;
        }

        public List<string> SetPro2AdminUser(List<string> userIdList, bool canThey)
        {
            return IOWorks.UserRegister.UserInfo.SetPro(userIdList, true, canThey, false, false, false, false, false, false);
        }
        public List<string> SetPro2CheckResult(List<string> userIdList, bool canThey)
        {
            return IOWorks.UserRegister.UserInfo.SetPro(userIdList, false, false, true, canThey, false, false, false, false);
        }
        public List<string> SetPro2MakePaper(List<string> userIdList, bool canThey)
        {
            return IOWorks.UserRegister.UserInfo.SetPro(userIdList, false, false, false, false, true, canThey, false, false);
        }
        public List<string> SetPro2AuditPaper(List<string> userIdList, bool canThey)
        {
            return IOWorks.UserRegister.UserInfo.SetPro(userIdList, false, false, false, false, false, false, true, canThey);
        }

        #endregion


        public bool IsUser_inPlant(string id)
        {
            //throw new Exception("Function Limitition!");
            return SGCC_NX_UUMP.IsUserExists(id);
        }

        public bool IsUser_inPlantPass(string id, string pwd)
        {
            //throw new Exception("Function Limitition!");
            return SGCC_NX_UUMP.IsUserPass(id, pwd);
        }

        public List<string> GetUserFullPath(string id)
        {
            //throw new Exception("Function Limitition!");
            return SGCC_NX_UUMP.GetUserFullPath(id);
        }

        public string Get_UserOrganiNode(string orgFullName)
        {
            return IOWorks.UserRegister.OrganFrame.Get_OrganiNode(orgFullName).IOContent_onMyLevel;
        }
    }
}
