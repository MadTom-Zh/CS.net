﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

using XTExam100505.CodeSharing.Entities;

namespace XTExam100505_Web.Services
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service_HallExam" in code, svc and config file together.
    public class Service_HallExam : IService_HallExam
    {
        public void DoWork()
        {
        }

        public List<string> GetAllHallInfo()
        {
            List<string> result = new List<string>();
            foreach (DataProcessing.ExamHall.HallInfo info in IOWorks.ExamHall.HallInfo.GetAllHallInfo())
            {
                result.Add(info.IOContent);
            }
            return result;
        }

        public List<string> GetAllMyExamInfos_IOContent(string examerName)
        {
            return IOWorks.ExamHall.HallInfo.GetAllMyExam_HallInfos_IOContent(examerName);
        }

        public string GetExamInfo_IOContent(string hallName, string examerName)
        {
            DataProcessing.ExamHall.UserExam.Info userExamInfo = new IOWorks.ExamHall.UserExam.Info(hallName, examerName).data;
            return userExamInfo.IOContent;
        }

        public void SetExamStart(string hallName, string examerName)
        {
            IOWorks.ExamHall.UserExam.Info userExamInfoOper = new IOWorks.ExamHall.UserExam.Info(hallName, examerName);
            userExamInfoOper.SetStart();
        }
        public void SetExamPause(string hallName, string examerName)
        {
            IOWorks.ExamHall.UserExam.Info userExamInfoOper = new IOWorks.ExamHall.UserExam.Info(hallName, examerName);
            userExamInfoOper.SetPause();
        }
        public void SetExamEnd(string hallName, string examerName)
        {
            IOWorks.ExamHall.UserExam.Info userExamInfoOper = new IOWorks.ExamHall.UserExam.Info(hallName, examerName);
            userExamInfoOper.SetEnd();
        }

        public string GetUserPaper_IOContent(string hallName, string examerName, string op)
        {
            DataProcessing.ExamHall.UserExam.UserPaper paper = new IOWorks.ExamHall.UserExam.UserPaper(hallName, examerName, op).data;
            return paper.IOContent;
        }
        public void SaveUserPaperAnswers(List<string> answerLines, string hallName, string examerName, string op)
        {
            IOWorks.ExamHall.UserExam.UserPaper paperOper = new IOWorks.ExamHall.UserExam.UserPaper(hallName, examerName, op);
            paperOper.SaveUserAnswer(answerLines);
        }
        public void SaveUserPaperData(List<string> userDataLines, string hallName, string examerName, string op)
        {
            IOWorks.ExamHall.UserExam.UserPaper paperOper = new IOWorks.ExamHall.UserExam.UserPaper(hallName, examerName, op);
            paperOper.SaveUserData(userDataLines);
        }

        public void AuditAndSavePaper(string hallName, string examerName, string op)
        {
            IOWorks.ExamHall.UserExam.UserPaper paperOper = new IOWorks.ExamHall.UserExam.UserPaper(hallName, examerName, op);
            paperOper.AuditAndSavePaper();
        }
    }
}
