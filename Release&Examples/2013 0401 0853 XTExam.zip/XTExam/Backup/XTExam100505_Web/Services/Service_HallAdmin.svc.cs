﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

using XTExam100505.CodeSharing.Entities;

namespace XTExam100505_Web.Services
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service_HallAdmin" in code, svc and config file together.
    public class Service_HallAdmin : IService_HallAdmin
    {

        public void AddHall(string hallInfoIOString)
        {
            IOWorks.ExamHall.HallInfo hallInfoOper = new IOWorks.ExamHall.HallInfo();
            DataProcessing.ExamHall.HallInfo newHall = new DataProcessing.ExamHall.HallInfo();
            newHall.IOContent = hallInfoIOString;
            hallInfoOper.data = newHall;
            hallInfoOper.Save();
        }

        public void UploadExtraFile(string op, string hallName, string fileName, byte[] data, bool isAppend)
        {
            IOWorks.ExamHall.Admin.AddWrite_ExtraFile(op, hallName, fileName, data, isAppend);
        }
    }
}
