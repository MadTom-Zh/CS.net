﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

using System.IO;

namespace XTExam100505_Web.Services
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService_Depot" in both code and config file together.
    [ServiceContract]
    public interface IService_Depot
    {
        [OperationContract]
        bool AddDir(string relatePath, string op);
        [OperationContract]
        bool AddPot(string relatePath, string op);
        [OperationContract]
        List<string> GetAllStorItems();

        [OperationContract]
        bool DropStorItem(string relatePath, string op);

        [OperationContract]
        List<string> LoadDepotDetail(string relatePath);
        [OperationContract]
        List<List<List<string>>> LoadDepot(string relatePath, string op);

        [OperationContract]
        bool SaveDepotDetail(string relatePath, List<string> content, string op);
        [OperationContract]
        bool SaveDepot(string relatePath, List<List<List<string>>> content, string op);


        [OperationContract]
        List<string> GetImageList();
        [OperationContract]
        bool UploadImage(string fileName, byte[] data, bool isAppend, string op);


        [OperationContract]
        List<int> GetDepotSubjectCounts(string depotRelatePath, string op);

    }
}
