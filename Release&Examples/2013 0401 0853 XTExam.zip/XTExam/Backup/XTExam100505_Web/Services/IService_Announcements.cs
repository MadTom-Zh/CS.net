﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace XTExam100505_Web.Services
{
    // 注意: 使用“重构”菜单上的“重命名”命令，可以同时更改代码和配置文件中的接口名“IService_Announcements”。
    [ServiceContract]
    public interface IService_Announcements
    {
        [OperationContract]
        List<string> Get_AllAnnouncementInfo(string op);
        [OperationContract]
        List<string> Get_AllMyAnnouncementInfo(string op);
        [OperationContract]
        List<string> Get_AllMyHadVotedAnumNames(string op);
        [OperationContract]
        bool Check_HaveAnums2Vote(string op);
        [OperationContract]
        bool Check_AnnouncementExists(string op, string anumName);
        [OperationContract]
        void Create_Announcement(string op, string anumName);
        [OperationContract]
        string Load_InvitationList(string anumName);
        [OperationContract]
        string Load_MyAnnouncementPaper(string op, string anumName);

        [OperationContract]
        string Load_Content(string anumName);
        [OperationContract]
        void Save_Content(string op, string anumName, string anumContentIO);
        [OperationContract]
        void Publish(string op, string anumName);
        [OperationContract]
        void User_Submit(string op, string anumName, string userPaperIOContent);
    }
}
