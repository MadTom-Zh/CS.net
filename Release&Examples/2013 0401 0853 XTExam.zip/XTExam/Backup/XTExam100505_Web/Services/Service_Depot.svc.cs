﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

using System.IO;
using XTExam100505.CodeSharing.Entities;

namespace XTExam100505_Web.Services
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service_Depot" in code, svc and config file together.
    public class Service_Depot : IService_Depot
    {

        public bool AddDir(string relatePath, string op)
        {
            return IOWorks.Depot.Storage.SetDir(relatePath, op);
        }
        public bool AddPot(string relatePath, string op)
        {
            return IOWorks.Depot.Storage.SetDepot(relatePath, op);
        }
        public List<string> GetAllStorItems()
        {
            return IOWorks.Depot.Storage.GetAllStorItems();
        }
        public bool DropStorItem(string relatePath, string op)
        {
            return IOWorks.Depot.Storage.DelStorItem(relatePath, op);
        }


        public List<List<List<string>>> LoadDepot(string relatePath, string op)
        {
            //string text = Class_Depot.Subject.Type.Caption.ToString();
            return IOWorks.Depot.Load_Depot(relatePath, op);
        }
        public bool SaveDepot(string relatePath, List<List<List<string>>> content, string op)
        {
            return IOWorks.Depot.Save_Depot(relatePath, content, op);
        }
        //public bool AppendDepot(string relatePath, List<List<List<string>>> content, string op)
        //{
        //    return Class_Depot.AppendDepot(relatePath, content, op);
        //}

        public List<string> LoadDepotDetail(string relatePath)
        {
            return IOWorks.Depot.LoadDepotDetail(relatePath);
        }
        public bool SaveDepotDetail(string relatePath, List<string> content, string op)
        {
            DataProcessing.Depot.Detail header = new DataProcessing.Depot.Detail();
            List<string> orgContent = LoadDepotDetail(relatePath);
            if (orgContent != null)
            {
                header.LineContent = orgContent;
            }
            else
            {
                header.creater = op;
                header.createTime = DateTime.Now;
            }
            header.LineContent = content;
            header.modifier = op;
            header.modifyTime = DateTime.Now;
            return IOWorks.Depot.SaveDepotDetail(relatePath, header);
        }

        public List<string> GetImageList()
        {
            return IOWorks.Depot.Get_DepotImageList();
        }

        public bool UploadImage(string fileName, byte[] data, bool isAppend, string op)
        {
            return IOWorks.Depot.Save_DepotImage(fileName, data, isAppend, op);
        }

        public List<int> GetDepotSubjectCounts(string depotRelatePath, string op)
        {
            List<int> result = new List<int>();
            DataProcessing.Depot helper = new IOWorks.Depot(depotRelatePath, op).data;
            result.Add(helper.CountSingle);
            result.Add(helper.CountMuti);
            result.Add(helper.CountJudge);
            result.Add(helper.CountBlanks);
            result.Add(helper.CountQAnswer);
            return result;
        }

    }
}
