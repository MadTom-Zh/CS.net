﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

using XTExam100505.CodeSharing.Entities;

namespace XTExam100505_Web.Services
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService_User" in both code and config file together.
    [ServiceContract]
    public interface IService_User
    {
        [OperationContract]
        bool AddStorPath(string Relate_Path);
        [OperationContract]
        bool AddStorFile(string Relate_Path, string op);
        [OperationContract]
        bool CopyStorNode(string Relate_sourcePath, string Relate_targetPath, string op);

        [OperationContract]
        bool DelStorNode(string Relate_Path, string op);


        [OperationContract]
        List<string> LoadAllStorItems();


        [OperationContract]
        bool SetFileHeader(string Relate_Path, List<string> lineContent, string op);
        [OperationContract]
        List<string> GetFileHeader(string Relate_Path);
        [OperationContract]
        bool SetFileBody(string Relate_Path, List<string> uListBody, string op);
        [OperationContract]
        List<string> GetFileBody(string Relate_Path);
        //[OperationContract]
        //bool SetFile(string Relate_Path, List<string> headerLine, List<string> uListBody, string op);

        [OperationContract]
        string GetMyId(string acc, string exPwd, string inPwd);

        [OperationContract]
        void ReSync(List<string> userIdList, string op);
        [OperationContract]
        void ReSyncAll(string op);
        [OperationContract]
        List<List<string>> GetUsers(List<string> userIdList);

        [OperationContract]
        bool ChangeUserBaseInfo(string op, string targetUserId, string userName, string userOrgPath);
        [OperationContract]
        bool ChangeUserInnerPWD(string op, string targetUserId, string oldPwd, string newPwd);

        [OperationContract]
        List<string> SetPro2AdminUser(List<string> userIdList, bool canThey);
        [OperationContract]
        List<string> SetPro2CheckResult(List<string> userIdList, bool canThey);
        [OperationContract]
        List<string> SetPro2MakePaper(List<string> userIdList, bool canThey);
        [OperationContract]
        List<string> SetPro2AuditPaper(List<string> userIdList, bool canThey);

        [OperationContract]
        bool IsUser_inPlant(string id);
        [OperationContract]
        bool IsUser_inPlantPass(string id, string pwd);
        [OperationContract]
        List<string> GetUserFullPath(string id);

        [OperationContract]
        string Get_UserOrganiNode(string orgFullName);
    }
}
