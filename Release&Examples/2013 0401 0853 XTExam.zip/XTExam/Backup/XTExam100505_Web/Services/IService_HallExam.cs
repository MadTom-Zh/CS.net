﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace XTExam100505_Web.Services
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService_HallExam" in both code and config file together.
    [ServiceContract]
    public interface IService_HallExam
    {
        [OperationContract]
        List<string> GetAllHallInfo();

        [OperationContract]
        List<string> GetAllMyExamInfos_IOContent(string examerName);
        [OperationContract]
        string GetExamInfo_IOContent(string hallName, string examerName);

        [OperationContract]
        void SetExamStart(string hallName, string examerName);
        [OperationContract]
        void SetExamPause(string hallName, string examerName);
        [OperationContract]
        void SetExamEnd(string hallName, string examerName);

        [OperationContract]
        string GetUserPaper_IOContent(string hallName, string examerName, string op);
        [OperationContract]
        void SaveUserPaperAnswers(List<string> answerLines, string hallName, string examerName, string op);
        [OperationContract]
        void SaveUserPaperData(List<string> userDataLines, string hallName, string examerName, string op);

        [OperationContract]
        void AuditAndSavePaper(string hallName, string examerName, string op);
    }
}
