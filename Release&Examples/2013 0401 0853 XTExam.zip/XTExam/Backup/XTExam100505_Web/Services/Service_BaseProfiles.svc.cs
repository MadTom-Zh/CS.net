﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace XTExam100505_Web.Services
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service_BaseProfiles" in code, svc and config file together.
    public class Service_BaseProfiles : IService_BaseProfiles
    {
        public void DoWork()
        {
        }
    }
}
