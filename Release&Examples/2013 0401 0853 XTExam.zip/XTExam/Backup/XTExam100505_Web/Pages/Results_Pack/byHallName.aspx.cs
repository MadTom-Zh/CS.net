﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using XTExam100505.CodeSharing.Entities;

namespace XTExam100505_Web.Pages.Results_Pack
{
    public partial class byHallName : System.Web.UI.Page
    {
        private static string RESULTS = "results";
        private static string HALL_NAME = "hallName";
        private static string EXAMER_COUNT = "examerCount";
        private static string ORG_COUNT = "orgCount";
        private string selectedHallName;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["results"] == null)
            {
                results = IOWorks.Results.GetAllResults();
                Session.Add(RESULTS, results);
            }
            results = (List<DataProcessing.Results.ResultData>)Session[RESULTS];
            treeView_Build();
            Label_examerCount.Text = (Session[EXAMER_COUNT] == null) ? "?" : Session[EXAMER_COUNT].ToString();
            Label_orgCount.Text = (Session[ORG_COUNT] == null) ? "?" : Session[ORG_COUNT].ToString();
            Label_hallName.Text = (Session[HALL_NAME] == null) ? "?" : Session[HALL_NAME].ToString();
            table.Rows.Clear();
            table_AddRow(true, "组织单位", "考生账号", "考生姓名", "得分");
            if (Session[HALL_NAME] != null)
            {
                selectedHallName = Session[HALL_NAME].ToString();
                List<string> orgs = new List<string>();
                foreach (DataProcessing.Results.ResultData oneRes in results)
                {
                    if (oneRes.hallName == selectedHallName)
                    {
                        table_AddRow(false, oneRes.userOrgPath, oneRes.userName, oneRes.userNickName, (oneRes.isPaperAudited) ? oneRes.grades.ToString("##0.00") : "未完成批阅");

                        bool orgFound = false;
                        foreach (string org in orgs)
                        {
                            if (org == oneRes.userOrgPath)
                            {
                                orgFound = true;
                                break;
                            }
                        }
                        if (!orgFound) orgs.Add(oneRes.userOrgPath);
                    }
                }
                Label_examerCount.Text = results.Count + "";
                Session[EXAMER_COUNT] = (object)Label_examerCount.Text;
                Label_orgCount.Text = orgs.Count + "";
                Session[ORG_COUNT] = (object)Label_orgCount.Text;
                Label_hallName.Text = selectedHallName;
                Session[HALL_NAME] = (object)Label_hallName.Text;
            }
        }
        List<DataProcessing.Results.ResultData> results;

        private void treeView_Build()
        {
            treeView.Nodes.Clear();
            List<string> hallNames = new List<string>();
            foreach (DataProcessing.Results.ResultData oneRes in results)
            {
                bool hallFound = false;
                foreach (string hall in hallNames)
                {
                    if (hall == oneRes.hallName)
                    {
                        hallFound = true;
                        break;
                    }
                }
                if (!hallFound) hallNames.Add(oneRes.hallName);
            }
            foreach (string hallName in hallNames)
            {
                TreeNode newNode = new TreeNode(hallName);
                treeView.Nodes.Add(newNode);
            }
        }

        private void table_AddRow(bool isBold, string org, string user, string userNick, string grade)
        {
            TableRow newRow = new TableRow();
            TableCell newCell = new TableCell();
            Label text = new Label();
            text.Font.Bold = isBold;
            text.Text = org;
            newCell.Controls.Add(text);
            newRow.Cells.Add(newCell);

            newCell = new TableCell();
            text = new Label();
            text.Font.Bold = isBold;
            text.Text = user;
            newCell.Controls.Add(text);
            newRow.Cells.Add(newCell);

            newCell = new TableCell();
            text = new Label();
            text.Font.Bold = isBold;
            text.Text = userNick;
            newCell.Controls.Add(text);
            newRow.Cells.Add(newCell);

            newCell = new TableCell();
            text = new Label();
            text.Font.Bold = isBold;
            text.Text = grade;
            newCell.Controls.Add(text);
            newRow.Cells.Add(newCell);

            table.Rows.Add(newRow);
        }

        protected void treeView_SelectedNodeChanged(object sender, EventArgs e)
        {
            Session[HALL_NAME] = treeView.SelectedNode.Text;
            Page_Load(sender, e);
        }
    }
}