﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace XTExam100505_Web.Pages
{
    public partial class Results : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            bool isOK = true;
            string op = Request.Params["op"];
            string flag = Request.Params["flag"];
            if (op == null || flag == null) isOK = false;
            if (isOK)
            {
                long fileTime = long.Parse(flag, System.Globalization.NumberStyles.HexNumber);
                DateTime flagDT = DateTime.FromFileTime(fileTime);
                DateTime now = DateTime.Now;
                if (flagDT > now && (flagDT - now).TotalMinutes > 30) isOK = false;
                if (now > flagDT && (now - flagDT).TotalMinutes > 30) isOK = false;
            }
            if (isOK)
            {
                Session.Add("op", op);
            }
        }
    }
}