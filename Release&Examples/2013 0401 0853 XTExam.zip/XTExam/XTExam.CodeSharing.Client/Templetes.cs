﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace XTExam.CodeSharing.Entities
{
    public class Templetes
    {
        public class UI
        {
            /// <summary>
            /// Create a V StackPanel with 2 TextBlocks, topOne fontSize 8, buttomOne fontSize 11
            /// </summary>
            /// <param name="type">top textBlock text, usually show subject type</param>
            /// <param name="subj">buttom textBlock text, usually show subject main text</param>
            /// <returns>V StackPanel with 2 TextBlocks</returns>
            public static StackPanel ListViewItem_Subject(DataProcessing.Depot.Subject.Type type, string subj)
            {
                StackPanel result = new StackPanel();
                TextBlock typeText = new TextBlock();
                typeText.FontSize = 8;
                //typeText.
                //FontWeight fontWeight  = new FontWeight();
                //fontWeight = 
                //typeText.FontWeight = fontWeight;
                typeText.Text = type.ToString();
                result.Children.Add(typeText);
                TextBlock subJText = new TextBlock();
                subJText.FontSize = 11;
                subJText.Text = subj;
                result.Children.Add(subJText);
                return result;
            }
        }
        public class IEventArgs
        {
            public class Message : EventArgs
            {
                private string _message;
                public string message
                {
                    get { return _message; }
                }
                public Message(string msg)
                {
                    _message = msg;
                }
            }
            public class Subject : EventArgs
            {
                private DataProcessing.Depot.Subject _subjectData;
                public DataProcessing.Depot.Subject subjectData
                {
                    get { return _subjectData; }
                }
                public Subject(DataProcessing.Depot.Subject subjectData)
                {
                    _subjectData = subjectData;
                }
            }
        }

    }
}
