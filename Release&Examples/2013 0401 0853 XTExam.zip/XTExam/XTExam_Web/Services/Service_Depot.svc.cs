﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;

using System.Collections.Generic;
using XTExam.CodeSharing.Entities;

namespace XTExam_Web.Services
{
    [ServiceContract(Namespace = "")]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class Service_Depot
    {
        [OperationContract]
        public bool AddDir(string relatePath, string op)
        {
            return IOWorks.Depot.Storage.SetDir(relatePath, op);
        }
        [OperationContract]
        public bool AddPot(string relatePath, string op)
        {
            return IOWorks.Depot.Storage.SetDepot(relatePath, op);
        }
        [OperationContract]
        public List<string> GetAllStorItems()
        {
            return IOWorks.Depot.Storage.GetAllStorItems();
        }
        [OperationContract]
        public bool DropStorItem(string relatePath, string op)
        {
            return IOWorks.Depot.Storage.DelStorItem(relatePath, op);
        }


        [OperationContract]
        public string LoadDepot(string relatePath, string op)
        {
            //string text = Class_Depot.Subject.Type.Caption.ToString();
            return IOWorks.Depot.Load_Depot(relatePath, op);
        }
        [OperationContract]
        public bool SaveDepot(string relatePath, string ioContent_subjects, string op)
        {
            return IOWorks.Depot.Save_Depot(relatePath, ioContent_subjects, op);
        }
        //[OperationContract]
        //public bool AppendDepot(string relatePath, List<List<List<string>>> content, string op)
        //{
        //    return Class_Depot.AppendDepot(relatePath, content, op);
        //}

        [OperationContract]
        public List<string> LoadDepotDetail(string relatePath)
        {
            return IOWorks.Depot.LoadDepotDetail(relatePath);
        }
        [OperationContract]
        public bool SaveDepotDetail(string relatePath, List<string> content, string op)
        {
            DataProcessing.Depot.Detail header = new DataProcessing.Depot.Detail();
            List<string> orgContent = LoadDepotDetail(relatePath);
            if (orgContent != null)
            {
                header.LineContent = orgContent;
            }
            else
            {
                header.creater = op;
                header.createTime = DateTime.Now;
            }
            header.LineContent = content;
            header.modifier = op;
            header.modifyTime = DateTime.Now;
            return IOWorks.Depot.SaveDepotDetail(relatePath, header);
        }

        [OperationContract]
        public List<string> GetImageList()
        {
            return IOWorks.Depot.Get_DepotImageList();
        }

        [OperationContract]
        public bool UploadImage(string fileName, byte[] data, bool isAppend, string op)
        {
            return IOWorks.Depot.Save_DepotImage(fileName, data, isAppend, op);
        }

        [OperationContract]
        public List<int> GetDepotSubjectCounts(string depotRelatePath, string op)
        {
            List<int> result = new List<int>();
            DataProcessing.Depot helper = new IOWorks.Depot(depotRelatePath, op).data;
            result.Add(helper.CountSingle);
            result.Add(helper.CountMuti);
            result.Add(helper.CountJudge);
            result.Add(helper.CountBlanks);
            result.Add(helper.CountQAnswer);
            return result;
        }
    }
}
