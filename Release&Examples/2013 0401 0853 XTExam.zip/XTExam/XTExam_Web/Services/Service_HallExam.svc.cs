﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;

using System.Collections.Generic;
using XTExam.CodeSharing.Entities;

namespace XTExam_Web.Services
{
    [ServiceContract(Namespace = "")]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class Service_HallExam
    {
        [OperationContract]
        public List<string> GetAllHallInfo()
        {
            List<string> result = new List<string>();
            foreach (DataProcessing.ExamHall.HallInfo info in IOWorks.ExamHall.HallInfo.GetAllHallInfo())
            {
                result.Add(info.IOContent);
            }
            return result;
        }

        [OperationContract]
        public List<string> GetAllMyExamInfos_IOContent(string examerName)
        {
            return IOWorks.ExamHall.HallInfo.GetAllMyExam_HallInfos_IOContent(examerName);
        }

        [OperationContract]
        public string GetExamInfo_IOContent(string hallName, string examerName)
        {
            DataProcessing.ExamHall.UserExam.Info userExamInfo = new IOWorks.ExamHall.UserExam.Info(hallName, examerName).data;
            return userExamInfo.IOContent;
        }

        [OperationContract]
        public void SetExamStart(string hallName, string examerName)
        {
            IOWorks.ExamHall.UserExam.Info userExamInfoOper = new IOWorks.ExamHall.UserExam.Info(hallName, examerName);
            userExamInfoOper.SetStart();
        }
        [OperationContract]
        public void SetExamPause(string hallName, string examerName)
        {
            IOWorks.ExamHall.UserExam.Info userExamInfoOper = new IOWorks.ExamHall.UserExam.Info(hallName, examerName);
            userExamInfoOper.SetPause();
        }
        [OperationContract]
        public void SetExamEnd(string hallName, string examerName, bool needAudi)
        {
            IOWorks.ExamHall.UserExam.Info userExamInfoOper = new IOWorks.ExamHall.UserExam.Info(hallName, examerName);
            userExamInfoOper.data.isAudited = (needAudi == false);
            userExamInfoOper.SetEnd();
        }

        [OperationContract]
        public string GetUserPaper_IOContent(string hallName, string examerName, string op)
        {
            DataProcessing.ExamHall.UserExam.UserPaper paper = new IOWorks.ExamHall.UserExam.UserPaper(hallName, examerName, op).data;
            return paper.IOContent;
        }
        [OperationContract]
        public void SaveUserPaperAnswers(List<string> answerLines, string hallName, string examerName, string op)
        {
            IOWorks.ExamHall.UserExam.UserPaper paperOper = new IOWorks.ExamHall.UserExam.UserPaper(hallName, examerName, op);
            paperOper.SaveUserAnswer(answerLines);
        }
        [OperationContract]
        public void SaveUserPaperData(List<string> userDataLines, string hallName, string examerName, string op)
        {
            IOWorks.ExamHall.UserExam.UserPaper paperOper = new IOWorks.ExamHall.UserExam.UserPaper(hallName, examerName, op);
            paperOper.SaveUserData(userDataLines);
        }

        [OperationContract]
        public void AuditAndSavePaper(string hallName, string examerName, string op)
        {
            IOWorks.ExamHall.UserExam.UserPaper paperOper = new IOWorks.ExamHall.UserExam.UserPaper(hallName, examerName, op);
            paperOper.AuditAndSavePaper();
        }
    }
}
