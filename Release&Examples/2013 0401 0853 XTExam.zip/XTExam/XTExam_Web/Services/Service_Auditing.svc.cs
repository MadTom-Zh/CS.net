﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;

using System.Collections.Generic;
using XTExam.CodeSharing.Entities;

namespace XTExam_Web.Services
{
    [ServiceContract(Namespace = "")]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class Service_Auditing
    {
        [OperationContract]
        public List<string> GetMyExamerList(string op)
        {
            return IOWorks.AuditPaper.GetMyExamerList(op);
        }
        [OperationContract]
        public List<string> GetMyAuditingExamerList(string op)
        {
            return IOWorks.AuditPaper.GetMyAuditingExamerList(op);
        }

        [OperationContract]
        public void AuditingSet(string op, string examerPath)
        {
            IOWorks.AuditPaper.Auditing_Set(op, examerPath);
        }
        [OperationContract]
        public void AuditingDrop(string op, string examerPath)
        {
            IOWorks.AuditPaper.Auditing_Drop(op, examerPath);
        }

        [OperationContract]
        public void AuditingSetComplete(string op, string examerPath)
        {
            IOWorks.AuditPaper.Auditing_SetComplete(op, examerPath);
        }
    }
}
