﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;

using XTExam.CodeSharing.Entities;

namespace XTExam_Web.Services
{
    [ServiceContract(Namespace = "")]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class Service_Announcements
    {
        //[OperationContract]
        //public List<string> Get_AllAnnouncementInfo(string op)
        //{
        //    List<string> result = new List<string>();
        //    foreach (DataProcessing.Announcement.Info info in IOWorks.Announcement.Get_AllAnnouncementInfo(op))
        //    {
        //        result.Add(info.IOContent);
        //    }
        //    return result;
        //}
        //public List<string> Get_AllMyAnnouncementInfo(string op)
        //{
        //    List<string> result = new List<string>();
        //    foreach (DataProcessing.Announcement.Info info in IOWorks.Announcement.Get_AllMyAnnouncementInfo(op))
        //    {
        //        result.Add(info.IOContent);
        //    }
        //    return result;
        //}
        //public List<string> Get_AllMyHadVotedAnumNames(string op)
        //{
        //    return IOWorks.Announcement.Get_AllMyHadVotedAnumNames(op);
        //}

        //public bool Check_HaveAnums2Vote(string op)
        //{
        //    return IOWorks.Announcement.Check_HaveAnums2Vote(op);
        //}

        //public bool Check_AnnouncementExists(string op, string anumName)
        //{
        //    return IOWorks.Announcement.CheckExists(op, anumName);
        //}

        //public void Create_Announcement(string op, string anumName)
        //{
        //    IOWorks.Announcement.Create(op, anumName);
        //}

        //public string Load_InvitationList(string anumName)
        //{
        //    return IOWorks.Announcement.Load_InvitionList(anumName).IOContent;
        //}
        //public string Load_Content(string anumName)
        //{
        //    return IOWorks.Announcement.Load_Content(anumName).IOContent;
        //}
        //public void Save_Content(string op, string anumName, string anumContentIO)
        //{
        //    IOWorks.Announcement.Modify(op, anumName, new DataProcessing.Announcement.Content(anumContentIO));

        //}
        //public void Publish(string op, string anumName)
        //{
        //    IOWorks.Announcement.Publish(op, anumName);
        //}
        //public string Load_MyAnnouncementPaper(string op, string anumName)
        //{
        //    return IOWorks.Announcement.Load_MyAnnouncementPaper(op, anumName).IOContent;
        //}
        //public void User_Submit(string op, string anumName, string userPaperIOContent)
        //{
        //    IOWorks.Announcement.User_Submit(op, anumName, new DataProcessing.ExamHall.UserExam.UserPaper(userPaperIOContent));
        //}
    }
}
