﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;

using XTExam.CodeSharing.Entities;

namespace XTExam_Web.Services
{
    [ServiceContract(Namespace = "")]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class Service_HallAdmin
    {
        [OperationContract]
        public void AddHall(string hallInfoIOString)
        {
            IOWorks.ExamHall.HallInfo hallInfoOper = new IOWorks.ExamHall.HallInfo();
            DataProcessing.ExamHall.HallInfo newHall = new DataProcessing.ExamHall.HallInfo();
            newHall.IOContent = hallInfoIOString;
            hallInfoOper.data = newHall;
            hallInfoOper.Save();
        }

        [OperationContract]
        public void UploadExtraFile(string op, string hallName, string fileName, byte[] data, bool isAppend)
        {
            IOWorks.ExamHall.Admin.AddWrite_ExtraFile(op, hallName, fileName, data, isAppend);
        }
    }
}
