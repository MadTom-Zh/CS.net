﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;

using XTExam.CodeSharing.Entities;

namespace XTExam_Web.Services
{
    [ServiceContract(Namespace = "")]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class Service_Result
    {
        [OperationContract]
        public int CheckGraphDataStatus_Ex2013()
        {
            return IOWorks.Results.CheckGraphDataStatus();
        }

        [OperationContract]
        public bool ReGatherAll()
        {
            return IOWorks.Results.ReGatherAll();
        }

        [OperationContract]
        public string GetGraphData_Ex2013()
        {
            return IOWorks.Results.GetGraphData_Ex2013();
        }

        [OperationContract]
        public string GetGraphInfo_Ex2013()
        {
            return IOWorks.Results.GetGraphInfo_Ex2013();
        }
    }
}
