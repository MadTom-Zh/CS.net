﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

using SGCC_NX_UUMP;

namespace SGCC_NX_UUMP_Tester
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new SGCC_NX_UUMP.WinForm_config());
            if (MessageBox.Show("启动测试吗？", "请问", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
            {
                Application.Run(new SGCC_NX_UUMP.WinForm_test());
            }
        }
    }
}
