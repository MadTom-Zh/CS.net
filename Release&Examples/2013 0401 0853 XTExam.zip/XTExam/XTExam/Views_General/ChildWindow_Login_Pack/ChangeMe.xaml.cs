﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.CodeSharing.Entities;
using XTExam.ServiceReference_User;

namespace XTExam.Views_General.ChildWindow_Login_Pack
{
    public partial class ChangeMe : ChildWindow
    {
        public DataProcessing.UserRegister.UserInfo myId
        {
            set;
            get;
        }
        public ChangeMe(DataProcessing.UserRegister.UserInfo myID)
        {
            this.myId = myID;
            InitializeComponent();
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
        Service_UserClient serviceClient;
        private void ChildWindow_Loaded(object sender, RoutedEventArgs e)
        {
            if (myId == null || !myId.hasId)
            {
                this.DialogResult = false;
            }
            infoPanel.ProcessingStart += new EventHandler(infoPanel_ProcessingStart);
            infoPanel.ProcessingComplete += new EventHandler(infoPanel_ProcessingComplete);

            serviceClient = new Service_UserClient();
            serviceClient.ChangeUserBaseInfoCompleted += new EventHandler<ChangeUserBaseInfoCompletedEventArgs>(serviceClient_ChangeUserBaseInfoCompleted);
            serviceClient.ChangeUserInnerPWDCompleted += new EventHandler<ChangeUserInnerPWDCompletedEventArgs>(serviceClient_ChangeUserInnerPWDCompleted);
            textBox_id.Text = myId.id;
            textBox_name.Text = myId.name;
            textBox_orgPath.Text = myId.orgPath;
        }

        void infoPanel_ProcessingComplete(object sender, EventArgs e)
        {
            this.Cursor = Cursors.Arrow;
        }
        void infoPanel_ProcessingStart(object sender, EventArgs e)
        {
            this.Cursor = Cursors.Wait;
            UpdateLayout();
        }

        private void button_changeBase_Click(object sender, RoutedEventArgs e)
        {
            string newName = textBox_name.Text.Trim();
            string newOrgPath = textBox_orgPath.Text.Trim();
            if (newName.Length > 0)
            {
                infoPanel.ShowInfo("正在修改基本信息……", true);
                serviceClient.ChangeUserBaseInfoAsync(myId.id, myId.id, newName, newOrgPath);
            }
            else
            {
                infoPanel.ShowInfo("请不要使用空信息名称", false);
            }
        }
        void serviceClient_ChangeUserBaseInfoCompleted(object sender, ChangeUserBaseInfoCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result)
                {
                    infoPanel.ShowInfo("修改[基本信息]完毕", false);
                }
                else
                {
                    infoPanel.ShowInfo("未能成功修改，请稍候再试", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }

        private void button_changePassword_Click(object sender, RoutedEventArgs e)
        {
            if (passwordBox_new.Password != passwordBox_new2.Password)
            {
                infoPanel.ShowInfo("您填写的确认密码和第一次输入的不符！", false);
                return;
            }
            else if (myId.inPwd != passwordBox_org.Password)
            {
                infoPanel.ShowInfo("您输入的原始密码不正确！", false);
                return;
            }
            infoPanel.ShowInfo("正在修改密码……", true);
            serviceClient.ChangeUserInnerPWDAsync(myId.id, myId.id, passwordBox_org.Password, passwordBox_new2.Password);
        }
        void serviceClient_ChangeUserInnerPWDCompleted(object sender, ChangeUserInnerPWDCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                if (e.Result)
                {
                    infoPanel.ShowInfo("修改[密码]完毕", false);
                }
                else
                {
                    infoPanel.ShowInfo("未能成功修改，请稍候再试", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }
    }
}

