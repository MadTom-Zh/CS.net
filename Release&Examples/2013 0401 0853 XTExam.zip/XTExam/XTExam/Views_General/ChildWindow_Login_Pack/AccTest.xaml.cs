﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.ServiceReference_User;
using System.Collections.ObjectModel;

namespace XTExam.Views_General.ChildWindow_Login_Pack
{
    public partial class AccTest : ChildWindow
    {
        public AccTest()
        {
            InitializeComponent();

            serviceClient = new Service_UserClient();
            serviceClient.IsUser_inPlantCompleted += new EventHandler<IsUser_inPlantCompletedEventArgs>(serviceClient_IsUser_inPlantCompleted);
            serviceClient.IsUser_inPlantPassCompleted += new EventHandler<IsUser_inPlantPassCompletedEventArgs>(serviceClient_IsUser_inPlantPassCompleted);
            serviceClient.GetUserFullPathCompleted += new EventHandler<GetUserFullPathCompletedEventArgs>(serviceClient_GetUserFullPathCompleted);

            infoPanel.ProcessingStart += new EventHandler(infoPanel_ProcessingStart);
            infoPanel.ProcessingComplete += new EventHandler(infoPanel_ProcessingComplete);
        }

        void infoPanel_ProcessingComplete(object sender, EventArgs e)
        {
            this.Cursor = Cursors.Arrow;
            button_testAcc.IsEnabled = button_testPWD.IsEnabled = true;
        }
        void infoPanel_ProcessingStart(object sender, EventArgs e)
        {
            this.Cursor = Cursors.Wait;
            button_testAcc.IsEnabled = button_testPWD.IsEnabled = false;
        }



        Service_UserClient serviceClient;

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }


        private void button_testAcc_Click(object sender, RoutedEventArgs e)
        {
            infoPanel.ShowInfo("正在测试账号……", true);
            serviceClient.IsUser_inPlantAsync(textBox_acc.Text);
        }
        void serviceClient_IsUser_inPlantCompleted(object sender, IsUser_inPlantCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result == true)
                {
                    infoPanel.ShowInfo("已找到，正在读取组织信息……", true);
                    serviceClient.GetUserFullPathAsync(textBox_acc.Text);
                }
                else
                {
                    infoPanel.ShowInfo("未找到账号", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }
        void serviceClient_GetUserFullPathCompleted(object sender, GetUserFullPathCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result != null)
                {
                    textBox_info.Text = "\r\n\r\n您的组织全路径是：\r\n\t";
                    for (int i = 0; i < e.Result.Count; i++)
                    {
                        textBox_info.Text += e.Result[i];
                        if (i < (e.Result.Count - 1)) textBox_info.Text += "\\";
                    }
                    infoPanel.ShowInfo("完成！", false);
                }
                else
                {
                    infoPanel.ShowInfo("读取组织信息失败！", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }

        private void button_testPWD_Click(object sender, RoutedEventArgs e)
        {
            infoPanel.ShowInfo("正在测试账号+密码……", true);
            serviceClient.IsUser_inPlantPassAsync(textBox_acc.Text,passwordBox.Password);
        }
        void serviceClient_IsUser_inPlantPassCompleted(object sender, IsUser_inPlantPassCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result == true)
                {
                    infoPanel.ShowInfo("您是正确的用户，谢谢使用！", false);
                }
                else
                {
                    infoPanel.ShowInfo("密码错误！",false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }
    }
}

