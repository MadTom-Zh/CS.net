﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.CodeSharing.Entities;
//using XTExam.ServiceReference_Announcements;

namespace XTExam.Views_General.Announcement
{
    public partial class Announcements : UserControl
    {
        private DataProcessing.UserRegister.UserInfo _myId;
        public DataProcessing.UserRegister.UserInfo myId
        {
            set
            {
                _myId = value;
                if (_myId != null && _myId.hasId)
                {
                    this.IsEnabled = true;
                    dataGrid_Announcements.myUserMode = Controls.DataGrid_Announcements.UserMode.Customer;
                    dataGrid_Announcements.myId = _myId;
                    panel_Paper.myId = _myId;
                }
            }
            get
            {
                return _myId;
            }
        }
        public Announcements()
        {
            InitializeComponent();
            this.IsEnabled = false;
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            dataGrid_Announcements.LoadVotedAnumNameListComplete += new EventHandler(dataGrid_Announcements_LoadVotedAnumNameListComplete);


            panel_Paper.InformatingStart += new EventHandler<Templetes.IEventArgs.Message>(panel_Paper_InformatingStart);
            panel_Paper.InformatingEnd += new EventHandler<Templetes.IEventArgs.Message>(panel_Paper_InformatingEnd);

            panel_Paper.LoadingPaperStart += new EventHandler(panel_Paper_LoadingPaperStart);
            panel_Paper.LoadingPaperError += new EventHandler(panel_Paper_LoadingPaperError);
            panel_Paper.LoadingPaperComplete += new EventHandler(panel_Paper_LoadingPaperComplete);

            infoPanel.ProcessingStart += new EventHandler(infoPanel_ProcessingStart);
            infoPanel.ProcessingComplete += new EventHandler(infoPanel_ProcessingComplete);
        }



        void infoPanel_ProcessingStart(object sender, EventArgs e)
        {
            this.Cursor = Cursors.Wait;
        }
        void infoPanel_ProcessingComplete(object sender, EventArgs e)
        {
            this.Cursor = Cursors.Arrow;
        }


        void panel_Paper_InformatingStart(object sender, Templetes.IEventArgs.Message e)
        {
            //throw new NotImplementedException();
        }
        void panel_Paper_InformatingEnd(object sender, Templetes.IEventArgs.Message e)
        {
            //throw new NotImplementedException();
        }

        private void dataGrid_Announcements_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count != 1)
            {
                textBox_anumName.Text
                    = textBox_anumEndTime.Text
                    = "";
                panel_Paper.ClearPaper();
                button_submit.IsEnabled = false;
            }
            else
            {
                string anumName = dataGrid_Announcements.Selection[0].name;
                textBox_anumName.Text = anumName;
                textBox_anumEndTime.Text = dataGrid_Announcements.Selection[0].endTime;
                panel_Paper.Reload_Paper(Controls.Panel_Paper.PaperType.Announcement, anumName);
                //button_submit.IsEnabled = !dataGrid_Announcements.Selection[0].isVoted;
            }
        }

        void panel_Paper_LoadingPaperStart(object sender, EventArgs e)
        {
            button_submit.IsEnabled = false;
        }
        void panel_Paper_LoadingPaperComplete(object sender, EventArgs e)
        {
            if (dataGrid_Announcements.Selection.Count == 1
                && !dataGrid_Announcements.Selection[0].isVoted)
            {
                button_submit.IsEnabled = true;
            }
            else
            {
                button_submit.IsEnabled = false;
            }
        }
        void panel_Paper_LoadingPaperError(object sender, EventArgs e)
        {
            button_submit.IsEnabled = false;
        }

        private string _justSubmitAnumName;
        //private Service_AnnouncementsClient anumClient;
        private void button_submit_Click(object sender, RoutedEventArgs e)
        {
            //if (panel_Paper.isPaperReady && textBox_anumName.Text == panel_Paper.anumName)
            //{
            //    infoPanel.ShowInfo("正在提交……", true);
            //    if (anumClient == null)
            //    {
            //        anumClient = new Service_AnnouncementsClient();
            //        anumClient.User_SubmitCompleted += new EventHandler<System.ComponentModel.AsyncCompletedEventArgs>(anumClient_User_SubmitCompleted);
            //    }
            //    _justSubmitAnumName = panel_Paper.anumName;
            //    anumClient.User_SubmitAsync(myId.id, panel_Paper.anumName, panel_Paper.userPaper.IOContent);
            //}
        }
        void anumClient_User_SubmitCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                dataGrid_Announcements.Refresh();
                infoPanel.ShowInfo("公告[" + panel_Paper.anumName + "]已阅！", false);
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }
        void dataGrid_Announcements_LoadVotedAnumNameListComplete(object sender, EventArgs e)
        {
            if (_justSubmitAnumName != null)
            {
                dataGrid_Announcements.dataGrid_SelectAnum(_justSubmitAnumName);
            }
        }
    }
}
