﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;

using XTExam.CodeSharing.Entities;

namespace XTExam.Views_General.Examination
{
    public partial class Exam_Guide : Page
    {
        public DataProcessing.UserRegister.UserInfo myId
        {
            set;
            get;
        }
        public Exam_Guide(DataProcessing.UserRegister.UserInfo myID)
        {
            this.myId = myID;
            InitializeComponent();
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (myId == null || !myId.hasId)
            {
                this.IsEnabled = false;
                return;
            }
            Sub_GuideEntry entry = new Sub_GuideEntry(myId);
            tabItem_Entry.Content = entry;
            entry.BtnEntryClicked += new EventHandler(entry_BtnEntryClicked);

        }
        //private string selectedHallName = null;
        void entry_BtnEntryClicked(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            Sub_GuideEntry target = (Sub_GuideEntry)sender;
            Sub_ExamPaper paper = new Sub_ExamPaper(myId, target.clickedToEntry_hallInfo, target.clickedToEnter_userExamInfo, myId.id);
            tabItem_Hall.Content = paper;
            tabItem_Hall.Focus();
            tabItem_Hall.IsSelected = true;
        }

    }
}
