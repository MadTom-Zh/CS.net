﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.CodeSharing.Entities;

namespace XTExam.Views_General.Examination.Sub_GuideEntry_Pack
{
    public partial class EntryLine : UserControl
    {
        public EntryLine()
        {
            InitializeComponent();
        }
        public DataProcessing.ExamHall.HallInfo hallInfo;
        public DataProcessing.ExamHall.UserExam.Info userExamInfo;
        public void SetInfo(DataProcessing.ExamHall.HallInfo hallInfo, DataProcessing.ExamHall.UserExam.Info userExamInfo)
        {
            this.hallInfo = hallInfo;
            this.userExamInfo = userExamInfo;

            SetText();
        }

        private void SetText()
        {
            textBlock_title1.Text = "使用时间";
            if (userExamInfo != null)
            {
                textBlock_content1.Text = userExamInfo.examTimeUsed.ToString("##0.0")
                    + " / " + hallInfo.examinatingTimeLength.ToString("##0.0");
            }

            textBlock_title2.Text = "【开始时间" + hallInfo.startTime.ToString("yyyy-MM-dd") + "】"
                + "【结束时间" + hallInfo.endTime.ToString("yyyy-MM-dd") + "】"
                + ((hallInfo.isOneTimeExam == true) ? "，一次性考试！" : "");

            textBlock_content2.Text = hallInfo.hallName;

            DataProcessing.ExamHall.StatusAnalysis analysiser = null;
            //if(userExamInfo != null)
            //{
                analysiser = new DataProcessing.ExamHall.StatusAnalysis(hallInfo, userExamInfo);
            //}

            if (analysiser.CouldShowPaper == false)
            {
                button.IsEnabled = false;
                button.Content = "封闭";
            }
            else if (analysiser != null && analysiser.CouldWritePaper)
            {
                button.Content = "进入";
            }
            else
            {
                button.Content = "查看";
            }
        }

        public event EventHandler BtnClicked;

        private void button_Click(object sender, RoutedEventArgs e)
        {
            if (BtnClicked != null) BtnClicked(this, new EventArgs());
        }
    }
}
