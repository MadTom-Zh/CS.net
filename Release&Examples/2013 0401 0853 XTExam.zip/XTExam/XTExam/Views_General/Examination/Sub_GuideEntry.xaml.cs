﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.ServiceReference_HallExam;
using System.Collections.ObjectModel;
using XTExam.Views_General.Examination.Sub_GuideEntry_Pack;
using XTExam.CodeSharing.Entities;

namespace XTExam.Views_General.Examination
{
    public partial class Sub_GuideEntry : UserControl
    {
        public DataProcessing.UserRegister.UserInfo myId;
        public Sub_GuideEntry(DataProcessing.UserRegister.UserInfo myID)
        {
            this.myId = myID;
            InitializeComponent();
        }

        Service_HallExamClient serviceClient;
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            if (myId == null || !myId.hasId)
            {
                this.IsEnabled = false;
                return;
            }
            infoPanel.ProcessingStart += new EventHandler(infoPanel_ProcessingStart);
            infoPanel.ProcessingComplete += new EventHandler(infoPanel_ProcessingComplete);

            serviceClient = new Service_HallExamClient();
            serviceClient.GetAllMyExamInfos_IOContentCompleted += new EventHandler<GetAllMyExamInfos_IOContentCompletedEventArgs>(serviceClient_GetAllMyExamInfos_IOContentCompleted);
            serviceClient.GetExamInfo_IOContentCompleted += new EventHandler<GetExamInfo_IOContentCompletedEventArgs>(serviceClient_GetExamInfo_IOContentCompleted);
            infoPanel.ShowInfo("正在读取考场信息，请稍候……", true);
            serviceClient.GetAllMyExamInfos_IOContentAsync(myId.id);
        }

        void infoPanel_ProcessingStart(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            this.Cursor = Cursors.Wait;
        }
        void infoPanel_ProcessingComplete(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            this.Cursor = Cursors.Arrow;
        }

        List<DataProcessing.ExamHall.HallInfo> hallInfoList;
        List<EntryLine> uiItemlist;
        void serviceClient_GetAllMyExamInfos_IOContentCompleted(object sender, GetAllMyExamInfos_IOContentCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result != null)
                {
                    hallInfoList = new List<DataProcessing.ExamHall.HallInfo>();
                    DataProcessing.ExamHall.HallInfo newHall;
                    foreach (string ioHInfo in e.Result)
                    {
                        newHall = new DataProcessing.ExamHall.HallInfo();
                        newHall.IOContent = ioHInfo;
                        hallInfoList.Add(newHall);
                    }
                    //listBox_examList.Items.Clear();
                    uiItemlist = new List<EntryLine>();
                    FillExamList(hallInfoList);
                    FillResultList(hallInfoList);
                    serviceClient_StartGetExanInfo2FillUserTimeLength();
                    infoPanel.ShowInfo("载入完成", false);
                }
                else
                {
                    infoPanel.ShowInfo("未能完成信息读取，请重新进入", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }

        //string FORMAT_DATE = "yy-MM-dd";

        #region 填充可进行考试列表项目
        private void FillExamList(List<DataProcessing.ExamHall.HallInfo> hallInfoList)
        {
            stackPanel_examList.Children.Clear();
            EntryLine item;
            foreach (DataProcessing.ExamHall.HallInfo hallInfo in hallInfoList)
            {
                if (hallInfo.endTime > DateTime.Now)
                {
                    item = new EntryLine();
                    item.Tag = hallInfo;
                    item.SetInfo(hallInfo, null);
                    //item.SetText(" 进入 "
                    //    , "剩余时间", "?? / " + hallInfo.examinatingTimeLength.ToString("##.00")
                    //    , "开始时间【" + hallInfo.startTime.ToString(FORMAT_DATE) + "】，结束时间【" + hallInfo.endTime.ToString(FORMAT_DATE) + "】", hallInfo.hallName);
                    item.BtnClicked += new EventHandler(item_BtnClicked);
                    item.Name = hallInfo.hallName;

                    stackPanel_examList.Children.Add(item);
                    uiItemlist.Add(item);
                }
            }
        }


        #endregion


        #region 填充已结束考试列表项目
        private void FillResultList(List<DataProcessing.ExamHall.HallInfo> hallInfoList)
        {
            stackPanel_resultList.Children.Clear();
            EntryLine item;
            foreach (DataProcessing.ExamHall.HallInfo hallInfo in hallInfoList)
            {
                if (hallInfo.endTime < DateTime.Now)
                {
                    item = new EntryLine();
                    item.SetInfo(hallInfo, null);
                    //item.SetText(" 查看 "
                    //    , "使用时间", "?? / " + hallInfo.examinatingTimeLength.ToString("##.00")
                    //    , "开始时间【" + hallInfo.startTime.ToString(FORMAT_DATE) + "】，结束时间【" + hallInfo.endTime.ToString(FORMAT_DATE) + "】", hallInfo.hallName);
                    item.BtnClicked += new EventHandler(item_BtnClicked);
                    item.Name = hallInfo.hallName;
                    stackPanel_resultList.Children.Add(item);
                    uiItemlist.Add(item);
                }
            }
        }

        #endregion

        #region 填充用户考试剩余时间、完成考试使用时间
        int serviceClient_timeLength_NextIndex;
        private List<DataProcessing.ExamHall.UserExam.Info> userExamInfoList = new List<DataProcessing.ExamHall.UserExam.Info>();
        private void serviceClient_StartGetExanInfo2FillUserTimeLength()
        {
            userExamInfoList.Clear();
            serviceClient_timeLength_NextIndex = -1;
            serviceClient_StartGetExanInfo2FillUserTimeLength_loadNext();
        }
        private void serviceClient_StartGetExanInfo2FillUserTimeLength_loadNext()
        {
            serviceClient_timeLength_NextIndex++;
            //// name is hallname, tag is "剩余" or "用时"
            if (uiItemlist.Count == 0 || uiItemlist.Count == serviceClient_timeLength_NextIndex) return;
            serviceClient.GetExamInfo_IOContentAsync(uiItemlist[serviceClient_timeLength_NextIndex].Name, myId.id);
        }
        void serviceClient_GetExamInfo_IOContentCompleted(object sender, GetExamInfo_IOContentCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result != null)
                {
                    DataProcessing.ExamHall.UserExam.Info eInfo = new DataProcessing.ExamHall.UserExam.Info();
                    eInfo.IOContent = e.Result;
                    userExamInfoList.Add(eInfo);
                    uiItemlist[serviceClient_timeLength_NextIndex].SetInfo(FindHallInfo(eInfo.hallName), eInfo);
                    //DataProcessing.ExamHall.HallInfo hallInfo = FindExamHallInfo(eInfo.hallName);
                    //uiItemlist[serviceClient_timeLength_NextIndex].SetBtnText((eInfo.isAudited || eInfo.lastEndTime.ToOADate() > 0 || (hallInfo.isOneTimeExam == true && eInfo.lastStartTime > hallInfo.startTime)) ? "查看" : "进入");
                    serviceClient_StartGetExanInfo2FillUserTimeLength_loadNext();
                }
                else
                {
                    infoPanel.ShowInfo("未能获取您的时间用量，请重新进入", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }
        private DataProcessing.ExamHall.HallInfo FindHallInfo(string hallName)
        {
            foreach (DataProcessing.ExamHall.HallInfo hall in hallInfoList)
            {
                if (hall.hallName == hallName)
                {
                    return hall;
                }
            }
            return null;
        }
        #endregion


        public event EventHandler BtnEntryClicked;
        public DataProcessing.ExamHall.HallInfo clickedToEntry_hallInfo;
        public DataProcessing.ExamHall.UserExam.Info clickedToEnter_userExamInfo;
        void item_BtnClicked(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            string hallName = ((EntryLine)sender).hallInfo.hallName;
            clickedToEntry_hallInfo = FindExamHallInfo(hallName);
            clickedToEnter_userExamInfo = FindUserExamInfo(hallName);
            if (BtnEntryClicked != null) BtnEntryClicked(this, new EventArgs());
        }

        private DataProcessing.ExamHall.HallInfo FindExamHallInfo(string hallName)
        {
            for (int i = hallInfoList.Count - 1; i >= 0; i--)
            {
                if (hallInfoList[i].hallName == hallName)
                {
                    return hallInfoList[i];
                }
            }
            return null;
        }
        private DataProcessing.ExamHall.UserExam.Info FindUserExamInfo(string hallName)
        {
            for (int i = userExamInfoList.Count - 1; i >= 0; i--)
            {
                if (userExamInfoList[i].hallName == hallName)
                {
                    return userExamInfoList[i];
                }
            }
            return null;
        }
    }
}
