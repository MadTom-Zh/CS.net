﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.ServiceReference_HallExam;
using XTExam.Views_General.Examination.Sub_ExamPaper_Pack;
using XTExam.Controls;
using System.Collections.ObjectModel;
using XTExam.CodeSharing.Entities;

namespace XTExam.Views_General.Examination
{
    public partial class Sub_ExamPaper : UserControl
    {
        public DataProcessing.UserRegister.UserInfo myId;
        DataProcessing.ExamHall.HallInfo hallInfo;
        bool isManualAuditNeed;
        DataProcessing.ExamHall.UserExam.Info myUserExamInfo;
        string examerName;
        public Sub_ExamPaper(DataProcessing.UserRegister.UserInfo myID, DataProcessing.ExamHall.HallInfo hallInfo, DataProcessing.ExamHall.UserExam.Info userExamInfo, string examerName)
        {
            this.myId = myID;
            this.hallInfo = hallInfo;
            isManualAuditNeed = this.hallInfo.IsManualAuditNeed;
            this.myUserExamInfo = userExamInfo;
            this.examerName = examerName;
            InitializeComponent();
        }

        Service_HallExamClient serviceClient;
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            if (myId == null || !myId.hasId)
            {
                this.IsEnabled = false;
                return;
            }
            if (hallInfo.hallName == null || hallInfo.hallName.Length == 0)
            {
                this.IsEnabled = false;
                return;
            }

            if (hallInfo.isOneTimeExam == true && myUserExamInfo.lastStartTime.ToOADate() > 0)
            {
                isOneTimeExamOutDated = true;
            }

            infoPanel.ProcessingStart += new EventHandler(infoPanel_ProcessingStart);
            infoPanel.ProcessingComplete += new EventHandler(infoPanel_ProcessingComplete);

            serviceClient = new Service_HallExamClient();
            //serviceClient.GetExamInfo_IOContentCompleted += new EventHandler<GetExamInfo_IOContentCompletedEventArgs>(serviceClient_GetExamInfo_IOContentCompleted);
            serviceClient.GetUserPaper_IOContentCompleted += new EventHandler<GetUserPaper_IOContentCompletedEventArgs>(serviceClient_GetUserPaper_IOContentCompleted);
            serviceClient.SetExamEndCompleted += new EventHandler<System.ComponentModel.AsyncCompletedEventArgs>(serviceClient_SetExamEndCompleted);
            serviceClient.SaveUserPaperAnswersCompleted += new EventHandler<System.ComponentModel.AsyncCompletedEventArgs>(serviceClient_SaveUserPaperAnswersCompleted);

            RefreshPaper();
        }

        #region 消息 和 等待状态
        void infoPanel_ProcessingStart(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            this.Cursor = Cursors.Wait;
        }
        void infoPanel_ProcessingComplete(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            this.Cursor = Cursors.Arrow;
        }
        #endregion

        // 是否在“一次性考试”中二次进入？？？
        bool isOneTimeExamOutDated = false;

        DataProcessing.ExamHall.StatusAnalysis statusAnalysiser;
        private void RefreshPaper()
        {
            //infoPanel.ShowInfo("正在获取用户考试基本信息……", true);
            //serviceClient.GetExamInfo_IOContentAsync(hallInfo.hallName, examerName);

            statusAnalysiser = new DataProcessing.ExamHall.StatusAnalysis(hallInfo, myUserExamInfo);
            infoPanel.ShowInfo("正在提取试卷……", true);
            serviceClient.GetUserPaper_IOContentAsync(hallInfo.hallName, examerName, myId.id);
        }
        //void serviceClient_GetExamInfo_IOContentCompleted(object sender, GetExamInfo_IOContentCompletedEventArgs e)
        //{
        //    //throw new NotImplementedException();
        //    if (e.Error == null)
        //    {
        //        if (e.Result != null)
        //        {
        //            myExamInfo = new DataProcessing.ExamHall.UserExam.Info();
        //            myExamInfo.IOContent = e.Result;
        //            isMyExamFinished = (myExamInfo.lastEndTime.ToOADate() != 0 || myExamInfo.examTimeUsed >= myExamInfo.examTimeLength);
        //            if (isMyExamFinished)
        //            {
        //                SetHeaderBtnVisible(false);
        //            }
        //            infoPanel.ShowInfo("正在提取试卷……", true);
        //            serviceClient.GetUserPaper_IOContentAsync(hallInfo.hallName, examerName, myId.id);
        //        }
        //        else
        //        {
        //            infoPanel.ShowInfo("未能获取用户考试信息", false);
        //        }
        //    }
        //    else
        //    {
        //        infoPanel.ShowInfo(e.Error);
        //    }
        //}



        void serviceClient_GetUserPaper_IOContentCompleted(object sender, GetUserPaper_IOContentCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result != null)
                {
                    infoPanel.ShowInfo("已成功获取试卷，正在填充……", true);
                    ReFillPaper(e.Result);
                    SetHeaderInfo();
                    SetHeaderBtnVisible();
                    SetPauseAfterReload();
                }
                else
                {
                    infoPanel.ShowInfo("未能获取试卷，请重新进入此结界", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }

        List<SubjectUI> myPaperUIs;
        private void ReFillPaper(string paperIOData)
        {

            DataProcessing.ExamHall.UserExam.UserPaper myPaperData
                = new DataProcessing.ExamHall.UserExam.UserPaper();
            myPaperData.IOContent = paperIOData;
            myPaperUIs = new List<SubjectUI>();
            SubjectUI newUI;
            int subNo = 1;
            DataProcessing.ExamHall.UserExam.UserPaper.Element elm;

            Class_SubjUIHelper.ShowType showType;
            bool uiEnabled = true;
            if (statusAnalysiser.CouldShowAnswer == true)
            {
                showType = Class_SubjUIHelper.ShowType.SubjectWithUserAnswerAndRemark;
            }
            else
            {
                showType = Class_SubjUIHelper.ShowType.SubjectWithUserAnswer;
            }
            if (statusAnalysiser.CouldWritePaper == true)
            {
                uiEnabled = true;
            }
            else
            {
                uiEnabled = false;
            }

            for (int i = 0; i < myPaperData.elements.Count; i++)
            {
                elm = myPaperData.elements[i];
                if (elm.subject.subject == null || elm.subject.subject.Length <= 0) continue;
                if (elm.subject.type == DataProcessing.Depot.Subject.Type.Caption) subNo = 0;
                newUI = new SubjectUI(myId
                    , subNo
                    , elm.subject
                    , showType
                    , elm.userData);
                myPaperUIs.Add(newUI);
                newUI.IsEnabled = uiEnabled;
                subNo++;
            }


            //if (myPaperUIs == null) return;
            stackPanel_container.Children.Clear();
            for (int i = 0; i < myPaperUIs.Count; i++)
            {
                stackPanel_container.Children.Add(myPaperUIs[i]);
            }
            infoPanel.ShowInfo("试卷填充完成", false);
        }

        private void SetHeaderInfo()
        {
            textBlock_header.Text = "";
            if (myUserExamInfo.isAudited || isManualAuditNeed == false)
            {
                if (statusAnalysiser.CouldShowGrade)
                {
                    double grades = 0;
                    for (int i = myPaperUIs.Count - 1; i >= 0; i--)
                    {
                        grades += myPaperUIs[i].GetGrade();
                    }
                    textBlock_header.Text = "此试卷已被批阅，最终成绩 " + grades.ToString("#,###,###.00") + " 分!";
                }
                else
                {
                    textBlock_header.Text = "试卷成绩和答案将在考试结束期限后公布，请耐心等候。";
                }
            }
            else if (hallInfo.endTime > DateTime.Now)
            {
                // 仍在考试期间内
                if (hallInfo.isOneTimeExam == true && myUserExamInfo.lastStartTime > hallInfo.startTime
                    && myUserExamInfo.lastEndTime.ToOADate() == 0)
                {
                    textBlock_header.Text = "已提交最后一次保存结果，等待批阅……";
                }
                //else if (myUserExamInfo.lastEndTime.ToOADate() == 0)
                //{
                //    textBlock_header.Text = "";
                //}
                else
                {
                    textBlock_header.Text = "此试卷已在[" + myUserExamInfo.lastEndTime.ToString("yyyy-MM-dd HH:mm:ss") + "]提交，等待批阅……";
                }
            }
            else
            {
                // 已经超过考试期间，但还未批卷！
                if (hallInfo.endTime.AddDays(3) > DateTime.Now)
                {
                    // 考试结束期限后3天之内
                    textBlock_header.Text = "此试卷的人工部分还在批阅中，如果您有任何疑问，请联系管理员！";
                }
                else
                {
                    textBlock_header.Text = "此试卷仍未完成人工批阅，为不影响您的成绩，建议立即联系管理员！";
                }
            }
        }
        private void SetHeaderBtnVisible()
        {
            bool isVisible = statusAnalysiser.CouldWritePaper;

            if (isVisible)
            {
                button_saveAndPause.Visibility = System.Windows.Visibility.Visible;
                button_submit.Visibility = System.Windows.Visibility.Visible;
            }
            else
            {
                button_saveAndPause.Visibility = System.Windows.Visibility.Collapsed;
                button_submit.Visibility = System.Windows.Visibility.Collapsed;
            }
        }

        private void SetPauseAfterReload()
        {
            bool showPause = statusAnalysiser.CouldWritePaper || isOneTimeExamOutDated;
            //if (myUserExamInfo.lastEndTime > DateTime.Now)
            //{
            //    // 已交卷
            //    showPause = false;
            //}
            //else if (myUserExamInfo.examTimeUsed >= hallInfo.examinatingTimeLength)
            //{
            //    // 时间用尽
            //    showPause = false;
            //}
            //else if (hallInfo.endTime < DateTime.Now)
            //{
            //    // 已超过考试日期
            //    showPause = false;
            //}
            //else if (isOneTimeExamOutDated)
            //{
            //    // “一次性考试”尝试二次答题
            //    showPause = false;
            //}
            //else
            //{
            //    showPause = true;
            //}

            if (showPause == true)
            {
                pauseWin = new PauseInfo(hallInfo.hallName, examerName);
                pauseWin.Closed += new EventHandler(pauseWin_Closed);
                pauseWin.Show();
            }
        }

        void pauseWin_Closed(object sender, EventArgs e)
        {
            this.myUserExamInfo = ((Sub_ExamPaper_Pack.PauseInfo)sender).reFreshedExamInfo;
            statusAnalysiser = new DataProcessing.ExamHall.StatusAnalysis(hallInfo, myUserExamInfo);
            if (statusAnalysiser.CouldWritePaper == false)
            {
                for (int i = myPaperUIs.Count - 1; i >= 0; i--)
                {
                    myPaperUIs[i].IsEnabled = false;
                }
            }
            SetHeaderInfo();
            SetHeaderBtnVisible();
            //SetPauseAfterReload();
        }

        PauseInfo pauseWin;

        private void button_saveAndPause_Click(object sender, RoutedEventArgs e)
        {
            SavePaperUserAnswerData();
        }
        private void SavePaperUserAnswerData()
        {
            infoPanel.ShowInfo("保存试卷……", true);
            ObservableCollection<string> userDataLine = new ObservableCollection<string>();
            for (int i = 0; i < myPaperUIs.Count; i++)
            {
                userDataLine.Add(myPaperUIs[i].GetUserAnswer().answer);
            }
            serviceClient.SaveUserPaperAnswersAsync(userDataLine, hallInfo.hallName, examerName, myId.id);
        }
        void serviceClient_SaveUserPaperAnswersCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (userEndExamAction)
                {
                    userEndExamAction = false;
                    serviceClient.SetExamEndAsync(hallInfo.hallName, examerName, isManualAuditNeed);
                }
                else
                {
                    RefreshPaper();
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }

        private void button_submit_Click(object sender, RoutedEventArgs e)
        {
            EndInfo endWin = new EndInfo();
            endWin.Closed += new EventHandler(endWin_Closed);
            endWin.Show();
        }
        private bool userEndExamAction = false;
        void endWin_Closed(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            if (((EndInfo)sender).DialogResult == true)
            {
                userEndExamAction = true;
                SavePaperUserAnswerData();
            }
        }

        void serviceClient_SetExamEndCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                myUserExamInfo.lastEndTime = DateTime.Now;
                RefreshPaper();
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }
    }
}
