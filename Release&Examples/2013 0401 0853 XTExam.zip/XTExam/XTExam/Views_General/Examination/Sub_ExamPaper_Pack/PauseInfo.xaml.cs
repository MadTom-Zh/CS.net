﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.ServiceReference_HallExam;
using XTExam.CodeSharing.Entities;

namespace XTExam.Views_General.Examination.Sub_ExamPaper_Pack
{
    public partial class PauseInfo : ChildWindow
    {
        string hallName, examerName;
        public DataProcessing.ExamHall.UserExam.Info reFreshedExamInfo;
        Service_HallExamClient serviceClient;
        public PauseInfo(string hallName, string examerName)
        {
            this.hallName = hallName;
            this.examerName = examerName;
            InitializeComponent();
        }
        private void ChildWindow_Loaded(object sender, RoutedEventArgs e)
        {
            infoPanel.ProcessingComplete += new EventHandler(infoPanel_ProcessingComplete);
            infoPanel.ProcessingStart += new EventHandler(infoPanel_ProcessingStart);

            serviceClient = new Service_HallExamClient();
            //获取用户考试信息
            serviceClient.GetExamInfo_IOContentCompleted += new EventHandler<GetExamInfo_IOContentCompletedEventArgs>(serviceClient_GetExamInfo_IOContentCompleted);
            //设置暂停
            serviceClient.SetExamPauseCompleted += new EventHandler<System.ComponentModel.AsyncCompletedEventArgs>(serviceClient_SetExamPauseCompleted);
            //设置开始
            serviceClient.SetExamStartCompleted += new EventHandler<System.ComponentModel.AsyncCompletedEventArgs>(serviceClient_SetExamStartCompleted);
            infoPanel.ShowInfo("正在读取用户考试信息……", true);
            serviceClient.GetExamInfo_IOContentAsync(hallName, examerName);
            OKButton.IsEnabled = false;
        }
        void infoPanel_ProcessingStart(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            this.Cursor = Cursors.Wait;
        }
        void infoPanel_ProcessingComplete(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            this.Cursor = Cursors.Arrow;
        }

        bool badResult = false;
        void serviceClient_GetExamInfo_IOContentCompleted(object sender, GetExamInfo_IOContentCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result != null)
                {
                    reFreshedExamInfo = new DataProcessing.ExamHall.UserExam.Info();
                    reFreshedExamInfo.IOContent = e.Result;
                    textBox_hallName.Text = reFreshedExamInfo.hallName;
                    textBox_timeExamini.Text = "考试总时长[" + reFreshedExamInfo.examTimeLength.ToString("##0.00") + "]小时";
                    textBox_timeLeft.Text = "剩余时长[" + (reFreshedExamInfo.examTimeLength - reFreshedExamInfo.examTimeUsed).ToString("##0.00") + "]小时";
                    if (reFreshedExamInfo.examTimeLength <= reFreshedExamInfo.examTimeUsed)
                    {
                        infoPanel.ShowInfo("本次考试时长已经用完！！", false);
                    }
                    else if (reFreshedExamInfo.lastEndTime.ToOADate() != 0)
                    {
                        infoPanel.ShowInfo("此次考试已经由用户终止", false);
                    }
                    else if (reFreshedExamInfo.lastPauseTime.ToOADate() != 0)
                    {
                        infoPanel.ShowInfo("此次考试已处于暂停状态", false);
                    }
                    else if (reFreshedExamInfo.lastStartTime.ToOADate() != 0)
                    {
                        OKButton.IsEnabled = false;
                        infoPanel.ShowInfo("正在尝试暂停考试……", true);
                        Pause();
                    }
                    else if (reFreshedExamInfo.lastStartTime.ToOADate() == 0
                        && reFreshedExamInfo.lastPauseTime.ToOADate() == 0
                        && reFreshedExamInfo.lastEndTime.ToOADate() == 0)
                    {
                        infoPanel.ShowInfo("您是第一次进入考场，点击“OK”开始考试", false);
                    }
                    OKButton.IsEnabled = true;
                }
                else
                {
                    badResult = true;
                    infoPanel.ShowInfo("未能获取考试信息，请关闭后重新进入", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }
        private void Pause()
        {
            serviceClient.SetExamPauseAsync(hallName, examerName);
        }
        void serviceClient_SetExamPauseCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                infoPanel.ShowInfo("已经完成考试暂停，正在重新读取考试信息……", true);
                serviceClient.GetExamInfo_IOContentAsync(hallName, examerName);
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            infoPanel.ShowInfo("准备...", true);
            serviceClient.SetExamStartAsync(hallName, examerName);
        }
        void serviceClient_SetExamStartCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                infoPanel.ShowInfo("计时开始！！", false);
                this.DialogResult = !badResult;
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }
    }
}

