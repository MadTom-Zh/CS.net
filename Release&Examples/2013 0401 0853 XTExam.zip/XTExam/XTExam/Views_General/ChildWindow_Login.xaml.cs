﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.ServiceReference_User;
using XTExam.CodeSharing.Entities;
using XTExam.Views_General.ChildWindow_Login_Pack;

namespace XTExam.Views_General
{
    public partial class ChildWindow_Login : ChildWindow
    {
        public ChildWindow_Login()
        {
            InitializeComponent();
        }

        private DataProcessing.UserRegister.UserInfo _myId;
        public DataProcessing.UserRegister.UserInfo myId
        {
            get { return _myId; }
        }
        private Service_UserClient client_GetID;
        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            //if (_serviceClientClosing == true) return;
            if (!CheckInput()) return;
            infoPanel.ShowInfo("正在尝试……", true);
            if (client_GetID == null)
            {
                client_GetID = new Service_UserClient();
                client_GetID.GetMyIdCompleted += new EventHandler<GetMyIdCompletedEventArgs>(client_GetID_GetMyIdCompleted);
                //client_GetID.CloseCompleted += client_GetID_CloseCompleted;
            }
            string acc = (tabControl_main.SelectedIndex == 0) ? textBox_exAcc.Text : textBox_inAcc.Text;
            client_GetID.GetMyIdAsync(acc, passwordBox_exAcc.Password, passwordBox_inPwd.Password);
            OKButton.IsEnabled = false;
        }

        //private bool _serviceClientClosing = false;
        //void client_GetID_CloseCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        //{
        //    _serviceClientClosing = false;
        //}
        void client_GetID_GetMyIdCompleted(object sender, GetMyIdCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result != null && e.Result.Length > 0)
                {
                    _myId = new DataProcessing.UserRegister.UserInfo(null, null);
                    _myId.IOContent = e.Result;
                    if (isChangeMode)
                    {
                        ChangeMe changeWin = new ChangeMe(myId);
                        changeWin.Show();
                        infoPanel.ShowInfo("已启动账号修改", false);
                    }
                    else this.DialogResult = true;
                }
                else
                {
                    infoPanel.ShowInfo("账号或密码不正确，请重试", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error.ToString(), false);
            }
            OKButton.IsEnabled = true;
            isChangeMode = false;
            //client_GetID.CloseAsync();
            //_serviceClientClosing = true;
        }
        private bool CheckInput()
        {
            if (tabControl_main.SelectedIndex == 0)
            {
                if (textBox_exAcc.Text.Length == 0 || passwordBox_exAcc.Password.Length == 0)
                {
                    infoPanel.ShowInfo("请输入账号和密码", false);
                    return false;
                }
            }
            else
            {
                if (textBox_inAcc.Text.Length == 0)
                {
                    infoPanel.ShowInfo("请至少输入账号", false);
                    return false;
                }
            }
            return true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private void button_testAcc_Click(object sender, RoutedEventArgs e)
        {
            //if (tabControl_main.SelectedIndex != 1)
            //{
            //    tabControl_main.SelectedIndex = 1;
            //}
            //else
            //{
            //    textBox_inAcc.Text = "Admin";
            //    passwordBox_inPwd.Password = "xtgs_examination_system";
            //}
            //if (textBox_inAcc.Text == "Admin" && passwordBox_inPwd.Password == "xtgs_examination_system")
            //{
            //    OKButton_Click(OKButton, e);
            //}

            AccTest atWin = new AccTest();
            atWin.Show();
        }

        bool isChangeMode = false;
        private void button_change_Click(object sender, RoutedEventArgs e)
        {
            if (!CheckInput()) return;
            isChangeMode = true;
            OKButton_Click(OKButton, e);
        }

        private void textBox_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.Key == Key.Enter)
            {
                OKButton_Click(OKButton, new RoutedEventArgs());
            }
        }
    }
}

