﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace XTExam.Views_General.ChildWindow_RegAndLogin_usingIDNO_Pack
{
    public partial class ChildWindow_Graph : ChildWindow
    {
        public ChildWindow_Graph()
        {
            InitializeComponent();
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {

            this.Close();
        }

        private void ChildWindow_Loaded_1(object sender, RoutedEventArgs e)
        {
        }
    }
}

