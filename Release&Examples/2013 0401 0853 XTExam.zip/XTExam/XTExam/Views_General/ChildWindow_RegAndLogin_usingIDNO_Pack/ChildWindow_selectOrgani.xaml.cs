﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace XTExam.Views_General.ChildWindow_RegAndLogin_usingIDNO_Pack
{
    public partial class ChildWindow_selectOrgani : ChildWindow
    {
        public ChildWindow_selectOrgani()
        {
            InitializeComponent();
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            if (selectedOriganiName == null)
            {
                return;
            }
            this.DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        public void SetOriganiList(string[] list)
        {
            listBox_origani.Items.Clear();
            listBox_origani.ItemsSource = list;
        }

        public string selectedOriganiName = null;
        private void ListBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
            if (listBox_origani.SelectedItems.Count != 0)
            {
                selectedOriganiName = listBox_origani.SelectedItems[0].ToString();
                infoPanel.ShowInfo("已选择：" + selectedOriganiName, false);
            }
        }
    }
}

