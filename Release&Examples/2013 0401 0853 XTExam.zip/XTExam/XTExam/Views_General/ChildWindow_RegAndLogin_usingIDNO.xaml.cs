﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.CodeSharing.Entities;
using XTExam.ServiceReference_User;

namespace XTExam.Views_General
{
    public partial class ChildWindow_RegAndLogin_usingIDNO : ChildWindow
    {
        public ChildWindow_RegAndLogin_usingIDNO()
        {
            InitializeComponent();

            infoPanel.ProcessingStart += infoPanel_ProcessingStart;
            infoPanel.ProcessingComplete += infoPanel_ProcessingComplete;
        }


        void infoPanel_ProcessingStart(object sender, EventArgs e)
        {
            this.IsEnabled = false;
        }
        void infoPanel_ProcessingComplete(object sender, EventArgs e)
        {
            this.IsEnabled = true;
        }

        private DataProcessing.UserRegister.UserInfo _myId = null;
        public DataProcessing.UserRegister.UserInfo myId
        {
            get { return _myId; }
        }

        private Service_UserClient client_userService;

        bool? isPaMem = null;
        //string failInfo = "注册失败，请核对您的注册信息！！";
        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            // 检查用户信息

            // 检查用户身份证号，是否正确
            if (textBox_userName.Text.Trim().Length == 0
                || CheckUserIdNo() == false
                || selectedOriganiOk == false)
            {
                infoPanel.ShowInfo("请检查姓名、身份证号和单位", false);
                return;
            }

            ListBoxItem selectedLBItem = (ListBoxItem)comboBox_isPaMem.SelectedItem;
            if (selectedLBItem.Content.ToString().Contains("选择"))
            {
                infoPanel.ShowInfo("请选择 是否 党员！", false);
                return;
            }
            else
            {
                if (selectedLBItem.Content.ToString().Contains("是"))
                {
                    isPaMem = true;
                }
                else
                {
                    isPaMem = false;
                }
            }

            if (client_userService == null)
            {
                client_userService = new Service_UserClient();
                client_userService.CheckIfIdOrNOExtCompleted += client_userService_CheckIfIdOrNOExtCompleted;
                client_userService.GetMyId_usingOnlyIdCompleted += client_userService_GetMyId_usingOnlyIdCompleted;
                client_userService.RegExUserInfoCompleted += client_userService_RegExUserInfoCompleted;
            }
            infoPanel.ShowInfo("正在执行检查……", true);
            client_userService.CheckIfIdOrNOExtAsync(textBox_userID.Text.Trim(), textBox_userIDNO.Text.Trim().ToUpper());
        }



        void client_userService_CheckIfIdOrNOExtCompleted(object sender, CheckIfIdOrNOExtCompletedEventArgs e)
        {
            // 如果已经有相同工号记录 或 身份证号记录，则返回提示；
            if (e.Error == null)
            {
                if (e.Result == false)
                {
                    // 未找到注册信息，可以进行注册
                    client_userService.GetMyId_usingOnlyIdAsync(textBox_userID.Text.Trim());

                    return;
                }
                infoPanel.ShowInfo("您的工号或身份证号已经注册过了", false);
            }
            else
            {
                infoPanel.ShowInfo(e.Error.Message, false);
            }
        }
        void client_userService_GetMyId_usingOnlyIdCompleted(object sender, GetMyId_usingOnlyIdCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                if (e.Result != null && e.Result.Length > 0)
                {
                    _myId = new DataProcessing.UserRegister.UserInfo(e.Result);
                    _myId.name = textBox_userName.Text.Trim();
                    // 工号正确，保存用户信息，用户登录成功
                    DataProcessing.UserRegister.UserInfoEx helper
                        = new DataProcessing.UserRegister.UserInfoEx()
                        {
                            id = textBox_userID.Text.Trim(),
                            idNo = textBox_userIDNO.Text.Trim().ToUpper(),
                            isPaMem = (this.isPaMem == true) ? true : false,
                            name = textBox_userName.Text.Trim(),
                            orgPath = textBox_organi.Text,
                        };
                    client_userService.RegExUserInfoAsync(helper.IOContent);

                    return;
                }
            }
            _myId = null;
            infoPanel.ShowInfo("您的工号无法查证", false);
        }
        void client_userService_RegExUserInfoCompleted(object sender, RegExUserInfoCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                if (e.Result == true)
                {
                    this.DialogResult = true;
                    return;
                }
            }
            _myId = null;
            infoPanel.ShowInfo("注册失败", false);
        }


        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            // do nothing
            //this.DialogResult = false;
        }


        private void textBox_userID_LostFocus(object sender, RoutedEventArgs e)
        {
            // 检查用户工号
            // 算了，点 ok 的时候再判断
        }

        private void textBox_userIDNO_LostFocus(object sender, RoutedEventArgs e)
        {
            // 检查身份证格式
            textBox_userIDNO.Text = textBox_userIDNO.Text.Trim().ToUpper();
            if (CheckUserIdNo() == false)
            {
                infoPanel.ShowInfo("身份证错误！！", false);
            }
            else
            {
                infoPanel.ShowInfo("", false);
            }
        }
        private bool CheckUserIdNo()
        {
            string value = textBox_userIDNO.Text;
            if (value.Length != 18)
            {
                return false;
            }
            for (int i = 0; i < 17; i++)
            {
                if (value[i] < '0' || value[i] > '9')
                {
                    return false;
                }
            }
            if (value[17] < '0' || value[17] > '9')
            {
                if (value[17] != 'X')
                {
                    return false;
                }
            }
            return true;
        }

        private void button_selectOrgani_Click(object sender, RoutedEventArgs e)
        {
            // 选择所在组织
            ChildWindow_RegAndLogin_usingIDNO_Pack.ChildWindow_selectOrgani selectOriWin
                = new ChildWindow_RegAndLogin_usingIDNO_Pack.ChildWindow_selectOrgani();
            selectOriWin.SetOriganiList(organiList);
            selectOriWin.Closed += selectOriWin_Closed;
            selectOriWin.Show();
        }

        private bool selectedOriganiOk = false;
        void selectOriWin_Closed(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            ChildWindow_RegAndLogin_usingIDNO_Pack.ChildWindow_selectOrgani target
                = (ChildWindow_RegAndLogin_usingIDNO_Pack.ChildWindow_selectOrgani)sender;
            if (target.DialogResult == true && target.selectedOriganiName.Length > 0)
            {
                textBox_organi.Text = target.selectedOriganiName;
                selectedOriganiOk = true;
            }
        }

        string[] organiList = new string[] { "宁夏电力公司本部",
            "宁夏电力建设监理咨询有限公司","宁夏电力公司银川供电局",
            "宁夏电力公司吴忠供电局", "宁夏电力公司石嘴山供电局",
            "宁夏电力公司中卫供电局", "宁夏电力公司宁东供电局",
            "宁夏电力公司固原供电局", "宁夏电力公司检修公司",
            "宁夏电力公司电力科学研究院", "宁夏电力公司经济技术研究院",
            "宁夏电力公司信息通信分公司", "宁夏电力公司教育培训中心",
            "宁夏送变电工程公司", "宁夏电力公司物资供应公司",
            "宁夏电力公司综合服务中心", "宁夏电力集体资产投资集团有限公司" };

        public event EventHandler CallBackToNormalLoginUI;
        private void button_changeToNormalLoginUI_Click(object sender, RoutedEventArgs e)
        {
            // 切换回普通登录模式
            if (CallBackToNormalLoginUI != null)
            {
                CallBackToNormalLoginUI(this, new EventArgs());
            }
        }

        private void btn_graph_Click(object sender, RoutedEventArgs e)
        {
            ChildWindow_RegAndLogin_usingIDNO_Pack.ChildWindow_Graph graphWin
                = new ChildWindow_RegAndLogin_usingIDNO_Pack.ChildWindow_Graph();
            graphWin.Width = this.Width;
            graphWin.Height = this.Height;
            graphWin.Show();
        }
    }
}

