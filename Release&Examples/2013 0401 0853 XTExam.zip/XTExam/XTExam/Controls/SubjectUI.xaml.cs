﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using System.Collections.ObjectModel;
using System.Windows.Media.Imaging;
using XTExam.CodeSharing.Entities;

namespace XTExam.Controls
{
    public partial class SubjectUI : UserControl
    {
        public DataProcessing.UserRegister.UserInfo myId
        {
            set;
            get;
        }
        private int _NO;
        private DataProcessing.Depot.Subject _subject;
        private Class_SubjUIHelper.ShowType _showType;
        //private string _depotPath;
        DataProcessing.ExamHall.UserExam.UserPaper.Element.UserData _userData;
        public SubjectUI(DataProcessing.UserRegister.UserInfo myID, int NO, DataProcessing.Depot.Subject subject, Class_SubjUIHelper.ShowType showType, DataProcessing.ExamHall.UserExam.UserPaper.Element.UserData userData)
        {
            this.myId = myID;
            _subject = subject;
            if (_subject == null) throw new Exception("构成一道题的数据不允许为空");
            _NO = NO;
            _showType = showType;
            //_depotPath = depotPath;
            _userData = userData;
            InitializeComponent();
            if (myID == null || !myID.hasId)
            {
                this.IsEnabled = false;
                return;
            }
            subjUIHelper = new Class_SubjUIHelper(_NO, _subject, _userData, _showType);
            subjUIHelper.FillData2UI(ref this.stackPanel_rootStack);
        }

        Class_SubjUIHelper subjUIHelper;
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
        }
        public DataProcessing.ExamHall.UserExam.UserPaper.Element.UserData GetUserAnswer()
        {
            return subjUIHelper.GetUserAnswer();
        }
        public double GetGrade()
        {
            return subjUIHelper.GetGrade();
        }



        private void LayoutRoot_Loaded(object sender, RoutedEventArgs e)
        {

        }
    }
}
