﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace XTExam.Controls
{
    public partial class InfoPanel : UserControl
    {
        public InfoPanel()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            textBox_info.Text = "";
            progressBar.Visibility = System.Windows.Visibility.Collapsed;
        }
        public event EventHandler ProcessingStart;
        public event EventHandler ProcessingComplete;
        public void ShowInfo(string msg, bool showProcessBar)
        {
            if (ProcessingStart != null && progressBar.Visibility == System.Windows.Visibility.Collapsed && showProcessBar)
            {
                ProcessingStart(this, new EventArgs());
            }
            else if (ProcessingComplete != null && progressBar.Visibility == System.Windows.Visibility.Visible && !showProcessBar)
            {
                ProcessingComplete(this, new EventArgs());
            }
            textBox_info.Text = msg;
            progressBar.Visibility = showProcessBar ? System.Windows.Visibility.Visible : System.Windows.Visibility.Collapsed;
        }
        public void ShowInfo(Exception stopError)
        {
            ShowInfo(stopError.Message, false);
        }
    }
}
