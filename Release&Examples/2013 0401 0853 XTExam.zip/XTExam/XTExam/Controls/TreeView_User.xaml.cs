﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.Views_Admin.User.SubPack;
using System.Collections.ObjectModel;
using System.Windows.Media.Imaging;
using XTExam.CodeSharing.Entities;

namespace XTExam.Controls
{
    public partial class TreeView_User : UserControl
    {
        public TreeView_User()
        {
            InitializeComponent();
        }


        private Image treeViewMain_folder;
        private Image treeViewMain_file;

        private DataProcessing.UserRegister.UserInfo _myId;
        public DataProcessing.UserRegister.UserInfo myID
        {
            set
            {
                _myId = value;
                UserControl_Loaded(this, new RoutedEventArgs());
            }
        }
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            if (_myId == null || !_myId.hasId)
            {
                this.IsEnabled = false;
                return;
            }
            this.IsEnabled = true;

            treeViewMain_folder = new Image();
            BitmapImage bitmap = new BitmapImage();
            bitmap.UriSource = new Uri("/image/folder_16.PNG", UriKind.Relative);
            treeViewMain_folder.Source = bitmap;

            treeViewMain_file = new Image();
            bitmap = new BitmapImage();
            bitmap.UriSource = new Uri("/image/file_16.PNG", UriKind.Relative);
            treeViewMain_file.Source = bitmap;

            ReloadTree();
        }

        public string Informating;
        public event EventHandler InformatingStart;
        public event EventHandler InformatingEnd;

        public event EventHandler LoadTreeComplete;
        public event EventHandler LoadTreeFailed;
        public void ReloadTree()
        {
            button_reloadTree_Click(button_reloadTree, new RoutedEventArgs());
        }
        private void button_reloadTree_Click(object sender, RoutedEventArgs e)
        {
            Informating = "Reloading...";
            if (InformatingStart != null) InformatingStart(this, new EventArgs());
            treeViewMain.Items.Clear();
            ServiceReference_User.Service_UserClient client = new ServiceReference_User.Service_UserClient();
            client.LoadAllStorItemsCompleted += new EventHandler<ServiceReference_User.LoadAllStorItemsCompletedEventArgs>(serviceClient_LoadAllStorItemsCompleted);
            client.LoadAllStorItemsAsync();
        }
        void serviceClient_LoadAllStorItemsCompleted(object sender, ServiceReference_User.LoadAllStorItemsCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result != null)
                {
                    treeViewMain.Items.Clear();
                    List<string> items = new List<string>();
                    foreach (string item in e.Result)
                    {
                        items.Add(item);
                    }
                    items.Sort();
                    string line;
                    for (int i = 0; i < items.Count; i++)
                    {
                        line = items[i];
                        treeViewMain_SetItem(line.Substring(3), line.Substring(0, 1));
                    }
                    treeView_ExpandAll(treeViewMain);
                    Informating = "Done of Reload";
                    if (InformatingEnd != null) InformatingEnd(this, new EventArgs());
                    if (LoadTreeComplete != null) LoadTreeComplete(this, new EventArgs());
                }
                else
                {
                    Informating = "Load Result is Null";
                    if (InformatingEnd != null) InformatingEnd(this, new EventArgs());
                    if (LoadTreeFailed != null) LoadTreeFailed(this, new EventArgs());
                }
            }
            else
            {
                Informating = e.Error.Message;
                if (InformatingEnd != null) InformatingEnd(this, new EventArgs());
                if (LoadTreeFailed != null) LoadTreeFailed(this, new EventArgs());
            }
        }
        private void treeViewMain_SetItem(string fullPath, string type)
        {
            string[] parts = fullPath.Split(new string[] { "\\" }, StringSplitOptions.RemoveEmptyEntries);
            TreeViewItem rootTNode = null;
            TreeViewItem subTNode = null, subTNode2 = null;
            bool rootNodeFound;
            for (int i = 0; i < parts.Length; i++)
            {
                rootNodeFound = false;
                if (i == 0)
                {
                    for (int j = treeViewMain.Items.Count - 1; j >= 0; j--)
                    {
                        rootTNode = (TreeViewItem)treeViewMain.Items[j];
                        if (((string[])rootTNode.Tag)[1] == parts[i])
                        {
                            rootNodeFound = true;
                            break;
                        }
                    }
                    if (!rootNodeFound)
                    {
                        TreeViewItem newTVItem = new TreeViewItem();
                        newTVItem.Tag = new string[] { type.Substring(0, 1), parts[i] };
                        if (type.StartsWith("D") || i < (parts.Length - 1)) newTVItem.Header = treeViewMain_MakeHeader(treeViewMain_folder, parts[i]);
                        else newTVItem.Header = treeViewMain_MakeHeader(treeViewMain_file, parts[i]);
                        treeViewMain.Items.Add(newTVItem);
                        rootTNode = newTVItem;
                    }
                    subTNode = rootTNode;
                }
                else
                {
                    for (int j = subTNode.Items.Count - 1; j >= 0; j--)
                    {
                        subTNode2 = (TreeViewItem)subTNode.Items[j];
                        if (((string[])subTNode2.Tag)[1] == parts[i])
                        {
                            rootNodeFound = true;
                            break;
                        }
                    }
                    if (!rootNodeFound)
                    {
                        TreeViewItem newTVItem = new TreeViewItem();
                        newTVItem.Tag = new string[] { type.Substring(0, 1), parts[i] };
                        if (type.StartsWith("D") || i < (parts.Length - 1)) newTVItem.Header = treeViewMain_MakeHeader(treeViewMain_folder, parts[i]);
                        else newTVItem.Header = treeViewMain_MakeHeader(treeViewMain_file, parts[i]);
                        subTNode.Items.Add(newTVItem);
                        //treeViewMain.Items.Add(newTVItem);
                        subTNode2 = newTVItem;
                    }
                    subTNode = subTNode2;
                }
            }
        }
        private StackPanel treeViewMain_MakeHeader(Image icon, string text)
        {
            StackPanel result = new StackPanel();
            result.Orientation = Orientation.Horizontal;
            Image newIcon = new Image();
            newIcon.Source = icon.Source;
            result.Children.Add(newIcon);
            Label innerText = new Label();
            innerText.Content = text;
            result.Children.Add(innerText);
            return result;
        }

        private void treeView_ExpandAll(TreeView target)
        {
            for (int i = target.Items.Count - 1; i >= 0; i--)
            {
                treeView_ExpandNode((TreeViewItem)target.Items[i]);
            }
        }
        private void treeView_ExpandNode(TreeViewItem node)
        {
            node.IsExpanded = true;
            for (int i = node.Items.Count - 1; i >= 0; i--)
            {
                treeView_ExpandNode((TreeViewItem)node.Items[i]);
            }
        }

        public event EventHandler SelectedNodeChanged;
        public string selectedFilePath;
        public string selectedDirPath;
        private void treeViewMain_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            selectedFilePath = selectedDirPath = null;
            TreeViewItem selectedTNode = (TreeViewItem)treeViewMain.SelectedItem;
            if (selectedTNode == null) return;
            string path = treeViewMain_GetItemFullPath(selectedTNode);
            if (((string[])selectedTNode.Tag)[0] == "F" && !selectedTNode.HasItems)
            {
                selectedFilePath = path;
            }
            else
            {
                selectedDirPath = path;
            }
            if (SelectedNodeChanged != null) SelectedNodeChanged(treeViewMain, new EventArgs());
        }
        private string treeViewMain_GetItemFullPath(TreeViewItem tvNode)
        {
            if (tvNode == null) return "";
            string result = ((string[])tvNode.Tag)[1];
            while (tvNode.Parent != null)
            {
                try
                {
                    tvNode = (TreeViewItem)tvNode.Parent;
                    result = ((string[])tvNode.Tag)[1] + "\\" + result;
                }
                catch (Exception)
                {
                    break;
                }
            }
            return result;
        }


        private void treeViewMain_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (selectedFilePath != null)
                {
                    ChildWindow_UserListDetail userDetailWin = new ChildWindow_UserListDetail(_myId);
                    userDetailWin.Show(selectedFilePath);
                }
            }
        }
    }
}
