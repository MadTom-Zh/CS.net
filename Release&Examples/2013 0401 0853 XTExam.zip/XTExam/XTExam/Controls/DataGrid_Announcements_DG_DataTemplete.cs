﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.CodeSharing.Entities;

namespace XTExam.Controls
{
    public class DataGrid_Announcements_DG_DataTemplete
    {
        public class DataGrid_Announcements_Binding
        {
            public bool isVoted { set; get; }
            public bool isDated { set; get; }
            public string name { set; get; }
            public string publicTime { set; get; }
            public string startTime { set; get; }
            public string endTime { set; get; }
            public string creator { set; get; }
            public string createTime { set; get; }
            public string modifier { set; get; }
            public string modifyTime { set; get; }

            private DataProcessing.Announcement.Info _baseInfo = null;
            public DataProcessing.Announcement.Info baseInfo
            {
                get { return _baseInfo; }
            }
            public DataGrid_Announcements_Binding(DataProcessing.Announcement.Info info)
            {
                _baseInfo = info;
                string DATATIME_LONGSTR_FORMAT = "yyyy-MM-dd HH:mm";
                isVoted = false;
                isDated = info.isDated;
                name = info.name;
                publicTime = info.publicTime.ToString(DATATIME_LONGSTR_FORMAT);
                startTime = info.startTime.ToString(DATATIME_LONGSTR_FORMAT);
                endTime = info.endTime.ToString(DATATIME_LONGSTR_FORMAT);
                creator = info.op;
                createTime = info.createTime.ToString(DATATIME_LONGSTR_FORMAT);
                modifier = info.modifier;
                modifyTime = info.modifyTime.ToString(DATATIME_LONGSTR_FORMAT);
            }
        }
    }
}
