﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using System.Windows.Media.Imaging;
using XTExam.CodeSharing.Entities;
using XTExam.ServiceReference_User;

namespace XTExam.Controls
{
    public partial class TreeView_UserOrganization : UserControl
    {
        public DataProcessing.UserRegister.UserInfo _myId;
        public DataProcessing.UserRegister.UserInfo myId
        {
            set
            {
                _myId = value;
                if (_myId == null || !_myId.hasId)
                {
                    this.IsEnabled = false;
                }
            }
            get { return _myId; }
        }
        public TreeView_UserOrganization()
        {
            InitializeComponent();
            this.IsEnabled = false;
        }

        private Image treeViewMain_iconOrgani;
        private Image treeViewMain_iconUser;
        private Service_UserClient userClient;
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            if (!this.IsEnabled) return;

            treeViewMain_iconOrgani = new Image();
            BitmapImage bitmap = new BitmapImage();
            bitmap.UriSource = new Uri("/image/organi_16.png", UriKind.Relative);
            treeViewMain_iconOrgani.Source = bitmap;

            treeViewMain_iconUser = new Image();
            bitmap = new BitmapImage();
            bitmap.UriSource = new Uri("/image/user_16.png", UriKind.Relative);
            treeViewMain_iconUser.Source = bitmap;

            _orgFrame = new DataProcessing.UserRegister.OrganFrame(null, null);
            userClient = new Service_UserClient();
            userClient.Get_UserOrganiNodeCompleted += new EventHandler<Get_UserOrganiNodeCompletedEventArgs>(userClient_Get_UserOrganiNodeCompleted);
            button_collapse_Click(button_collapse, e);
        }

        public void Clear()
        {
            treeViewMain.Items.Clear();
        }

        public event EventHandler<Templetes.IEventArgs.Message> InfomatingStart;
        public event EventHandler<Templetes.IEventArgs.Message> InfomatingStop;

        private DataProcessing.UserRegister.OrganFrame _orgFrame;
        public DataProcessing.UserRegister.OrganFrame orgFrame
        {
            get { return _orgFrame; }
        }
        private string _requestOrganiFullPath;
        private void button_collapse_Click(object sender, RoutedEventArgs e)
        {
            if (InfomatingStart != null) InfomatingStart(this, new Templetes.IEventArgs.Message("正在获取组织信息……"));
            treeViewMain.Items.Clear();
            _requestOrganiFullPath = "";
            userClient.Get_UserOrganiNodeAsync(_requestOrganiFullPath);
        }
        void userClient_Get_UserOrganiNodeCompleted(object sender, Get_UserOrganiNodeCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                if (e.Result != null)
                {
                    DataProcessing.UserRegister.OrganFrame data = new DataProcessing.UserRegister.OrganFrame(e.Result);
                    Fill_treeViewMain_Up(data);
                    if (InfomatingStop != null) InfomatingStop(this, new Templetes.IEventArgs.Message("就绪"));
                }
                else
                {
                    if (InfomatingStop != null) InfomatingStop(this, new Templetes.IEventArgs.Message("数据为空！"));
                }
            }
            else
            {
                if (InfomatingStop != null) InfomatingStop(this, new Templetes.IEventArgs.Message(e.Error.Message));
            }
        }
        private void Fill_treeViewMain_Up(DataProcessing.UserRegister.OrganFrame data)
        {
            string path = data.givenPath;
            path = (path == null) ? "" : path;
            TreeViewItem targetTVNode, newTVNode;
            TreeViewTag tvTag;
            if (path.Length <= 0)
            {
                for (int i = 0; i < data.subOrgs.Count; i++)
                {
                    // should create function to make tvItems...
                    newTVNode = new TreeViewItem();
                    newTVNode.Header = Make_treeViewMain_Node(data.subOrgs[i]);
                    tvTag = new TreeViewTag();
                    tvTag.nodeName = data.subOrgs[i].name;
                    tvTag.nodeType = TreeViewTag.NodeType.organi;
                    newTVNode.Tag = tvTag;
                    treeViewMain.Items.Add(newTVNode);
                }
                for (int i = 0; i < data.members.Count; i++)
                {
                    newTVNode = new TreeViewItem();
                    newTVNode.Header = Make_treeViewMain_Node(data.members[i]);
                    tvTag = new TreeViewTag();
                    tvTag.nodeName = data.subOrgs[i].name;
                    tvTag.nodeType = TreeViewTag.NodeType.organi;
                    newTVNode.Tag = tvTag;
                    treeViewMain.Items.Add(newTVNode);
                }
            }
            else
            {
                targetTVNode = Get_treeViewMain_Node(path);
                for (int i = 0; i < data.subOrgs.Count; i++)
                {
                    newTVNode = new TreeViewItem();
                    newTVNode.Header = Make_treeViewMain_Node(data.subOrgs[i]);
                    tvTag = new TreeViewTag();
                    tvTag.nodeName = data.subOrgs[i].name;
                    tvTag.nodeType = TreeViewTag.NodeType.organi;
                    newTVNode.Tag = tvTag;
                    targetTVNode.Items.Add(newTVNode);
                }
                for (int i = 0; i < data.members.Count; i++)
                {
                    newTVNode = new TreeViewItem();
                    newTVNode.Header = Make_treeViewMain_Node(data.members[i]);
                    tvTag = new TreeViewTag();
                    tvTag.nodeName = data.subOrgs[i].name;
                    tvTag.nodeType = TreeViewTag.NodeType.organi;
                    newTVNode.Tag = tvTag;
                    targetTVNode.Items.Add(newTVNode);
                }
            }
        }
        private TreeViewItem Get_treeViewMain_Node(string path)
        {
            if (path == null || path.Length <= 0) return null;
            string[] pathParts = path.Split(new string[] { "\\" }, StringSplitOptions.RemoveEmptyEntries);
            TreeViewItem workTVNode = null;
            TreeViewItem targetTVNode = null;
            TreeViewTag workTVNodeTag;
            string onePathPart = pathParts[0];
            for (int i = treeViewMain.Items.Count - 1; i >= 0; i--)
            {
                workTVNode = (TreeViewItem)treeViewMain.Items[i];
                workTVNodeTag = (TreeViewTag)workTVNode.Tag;
                if (workTVNodeTag.nodeType == TreeViewTag.NodeType.organi && workTVNodeTag.nodeName == onePathPart)
                {
                    targetTVNode = workTVNode;
                    break;
                }
            }
            if (targetTVNode == null) throw new Exception("Root Node [" + onePathPart + "] Not Found!");
            string tracePath = onePathPart;
            bool nodeNotFound;
            for (int i = 1; i < pathParts.Length; i++)
            {
                nodeNotFound = true;
                onePathPart = pathParts[i];
                for (int j = targetTVNode.Items.Count - 1; j >= 0; j--)
                {
                    workTVNode = (TreeViewItem)targetTVNode.Items[j];
                    workTVNodeTag = (TreeViewTag)workTVNode.Tag;
                    if (workTVNodeTag.nodeType == TreeViewTag.NodeType.organi && workTVNodeTag.nodeName == onePathPart)
                    {
                        targetTVNode = workTVNode;
                        tracePath += "\\" + workTVNodeTag.nodeName;
                        nodeNotFound = false;
                        break;
                    }
                }
                if (nodeNotFound) throw new Exception("Cann't Find Node [" + onePathPart + "] in Path [" + tracePath + "]!");
            }
            return targetTVNode;
        }
        private StackPanel Make_treeViewMain_Node(DataProcessing.UserRegister.OrganFrame org)
        {
            StackPanel dataResult = new StackPanel();
            dataResult.Orientation = Orientation.Horizontal;

            CheckBox cBox = new CheckBox();
            cBox.IsThreeState = true;
            cBox.IsChecked = false;
            cBox.Click += new RoutedEventHandler(cBox_Click);

            //Image newImage = new Image();
            //newImage.Source = treeViewMain_iconOrgani.Source;
            //dataResult.Children.Add(newImage);
            dataResult.Children.Add(treeViewMain_iconOrgani);
            Label iText = new Label();
            iText.Content = org.name;
            dataResult.Children.Add(iText);
            return dataResult;
        }
        private StackPanel Make_treeViewMain_Node(DataProcessing.UserRegister.UserInfo user)
        {
            StackPanel dataResult = new StackPanel();
            dataResult.Orientation = Orientation.Horizontal;

            CheckBox cBox = new CheckBox();
            cBox.IsThreeState = true;
            cBox.IsChecked = false;
            cBox.Click += new RoutedEventHandler(cBox_Click);

            dataResult.Children.Add(treeViewMain_iconUser);
            Label iText = new Label();
            iText.Content = user.id;
            dataResult.Children.Add(iText);
            return dataResult;
        }

        private bool _cBoxCheckChanging = false;
        void cBox_Click(object sender, RoutedEventArgs e)
        {
            if (_cBoxCheckChanging) return;
            if (InfomatingStart != null) InfomatingStart(this, new Templetes.IEventArgs.Message("正在重新选取……"));
            _cBoxCheckChanging = true;

            CheckBox cBox = (CheckBox)sender;
            TreeViewItem tvItem = (TreeViewItem)(((StackPanel)cBox.Parent).Parent);
            if (cBox.IsChecked == false)
            {
                // un check all sub nodes
                Change_treeViewMain_allSubNodes(tvItem, false);
            }
            else
            {
                // set this checked
                cBox.IsChecked = true;
                // check all sub nodes
                Change_treeViewMain_allSubNodes(tvItem, true);
            }
            // reset up level nodes
            CheckChange_treeviewMain_upLevelNodes(tvItem);
            _cBoxCheckChanging = false;




            // should radio events here
            throw new Exception("Coding, to be continued!");
        }
        private void Change_treeViewMain_allSubNodes(TreeViewItem node, bool isChecked)
        {
            CheckBox cBox;
            foreach (TreeViewItem subNode in node.Items)
            {
                cBox = (CheckBox)((StackPanel)subNode.Header).Children[0];
                cBox.IsChecked = isChecked;
                Change_treeViewMain_allSubNodes(subNode, isChecked);
            }
        }
        private void CheckChange_treeviewMain_upLevelNodes(TreeViewItem node)
        {
            if (node.Parent == null) return;
            TreeViewItem parentNode = (TreeViewItem)node.Parent;
            // check state, 0 false, 1 true, 2 null
            List<int> checkStateList = new List<int>();
            StackPanel templete;
            CheckBox cBox;
            foreach (TreeViewItem subNode in parentNode.Items)
            {
                templete = (StackPanel)subNode.Header;
                cBox = (CheckBox)templete.Children[0];
                if (cBox.IsChecked == null) checkStateList.Add(2);
                else if (cBox.IsChecked == true) checkStateList.Add(1);
                else checkStateList.Add(0);
            }
            checkStateList.Sort();
            for (int i = checkStateList.Count - 1; i > 0; i--)
            {
                if (checkStateList[i] == checkStateList[i - 1])
                {
                    checkStateList.RemoveAt(i);
                }
            }
            templete = (StackPanel)parentNode.Header;
            cBox = (CheckBox)templete.Children[0];
            if (checkStateList.Count > 1)
            {
                cBox.IsChecked = null;
            }
            else if (checkStateList.Count == 1)
            {
                if (checkStateList[0] == 0)
                {
                    cBox.IsChecked = false;
                }
                else cBox.IsChecked = true;
            }
            else cBox.IsChecked = false;
            CheckChange_treeviewMain_upLevelNodes(parentNode);
        }

        private class TreeViewTag
        {
            public string nodeName;
            public NodeType nodeType;
            public enum NodeType
            {
                organi,
                user,
            }
        }
    }
}
