﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.CodeSharing.Entities;

namespace XTExam.Controls
{
    public class Class_DataTempletes
    {
        public class IDataGrid
        {
            public class DataTemplete_voted_userId_userName_orgPath
            {
                public bool isVoted { set; get; }
                public string userId { set; get; }
                public string userName { set; get; }
                public string orgPath { set; get; }

                public DataTemplete_voted_userId_userName_orgPath()
                {
                }
                public DataTemplete_voted_userId_userName_orgPath(DataProcessing.Announcement.InvitedUserList.Invitation invitation)
                {
                    isVoted = invitation.isVoted;
                    userId = invitation.userId;
                    userName = invitation.userName;
                    orgPath = invitation.orgPath;
                }
            }
        }
    }
}
