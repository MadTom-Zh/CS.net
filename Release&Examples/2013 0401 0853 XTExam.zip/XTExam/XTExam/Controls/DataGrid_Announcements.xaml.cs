﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.CodeSharing.Entities;
//using XTExam.ServiceReference_Announcements;

namespace XTExam.Controls
{
    public partial class DataGrid_Announcements : UserControl
    {
        public DataGrid_Announcements()
        {
            InitializeComponent();
        }

        private DataProcessing.UserRegister.UserInfo _myId;
        public DataProcessing.UserRegister.UserInfo myId
        {
            set
            {
                _myId = value;
                if (_myId == null || !_myId.hasId)
                {
                    this.IsEnabled = false;
                }
                else
                {
                    this.IsEnabled = true;
                    //anumClient = new Service_AnnouncementsClient();
                    //anumClient.Get_AllAnnouncementInfoCompleted += new EventHandler<Get_AllAnnouncementInfoCompletedEventArgs>(anumClient_Get_AllAnnouncementInfoCompleted);
                    //anumClient.Get_AllMyAnnouncementInfoCompleted += new EventHandler<Get_AllMyAnnouncementInfoCompletedEventArgs>(anumClient_Get_AllMyAnnouncementInfoCompleted);
                    //anumClient.Get_AllMyHadVotedAnumNamesCompleted += new EventHandler<Get_AllMyHadVotedAnumNamesCompletedEventArgs>(anumClient_Get_AllMyHadVotedAnumNamesCompleted);

                    dataGrid.UpdateLayout();
                    myUserMode = _myUserMode;
                    //Init();
                    button_refresh_Click(button_refresh, new RoutedEventArgs());
                }
            }
        }

        public enum UserMode
        {
            Administrator = 0,
            Customer = 1,
        }
        private UserMode _myUserMode = UserMode.Administrator;
        public UserMode myUserMode
        {
            set
            {
                if (_myUserMode == value) return;
                _myUserMode = value;
                AutoHide_DataGridColumns();
                AutoHide_DataGridRows();
                myId = _myId;
            }
            get
            {
                return _myUserMode;
            }
        }
        private void AutoHide_DataGridColumns()
        {
            switch (_myUserMode)
            {
                case UserMode.Administrator:
                    dataGrid.Columns[0].Visibility = System.Windows.Visibility.Collapsed;
                    dataGrid.Columns[1].Visibility = System.Windows.Visibility.Visible;
                    dataGrid.Columns[2].Visibility = System.Windows.Visibility.Visible;
                    dataGrid.Columns[3].Visibility = System.Windows.Visibility.Visible;
                    dataGrid.Columns[4].Visibility = System.Windows.Visibility.Visible;
                    dataGrid.Columns[5].Visibility = System.Windows.Visibility.Visible;
                    dataGrid.Columns[6].Visibility = System.Windows.Visibility.Visible;
                    dataGrid.Columns[7].Visibility = System.Windows.Visibility.Visible;
                    dataGrid.Columns[8].Visibility = System.Windows.Visibility.Visible;
                    dataGrid.Columns[9].Visibility = System.Windows.Visibility.Visible;
                    break;
                case UserMode.Customer:
                    dataGrid.Columns[0].Visibility = System.Windows.Visibility.Visible;
                    dataGrid.Columns[1].Visibility = System.Windows.Visibility.Collapsed;
                    dataGrid.Columns[2].Visibility = System.Windows.Visibility.Visible;
                    dataGrid.Columns[3].Visibility = System.Windows.Visibility.Collapsed;
                    dataGrid.Columns[4].Visibility = System.Windows.Visibility.Collapsed;
                    dataGrid.Columns[5].Visibility = System.Windows.Visibility.Visible;
                    dataGrid.Columns[6].Visibility = System.Windows.Visibility.Visible;
                    dataGrid.Columns[7].Visibility = System.Windows.Visibility.Collapsed;
                    dataGrid.Columns[8].Visibility = System.Windows.Visibility.Collapsed;
                    dataGrid.Columns[9].Visibility = System.Windows.Visibility.Collapsed;
                    break;
            }
        }
        private void AutoHide_DataGridRows()
        {
            switch (_myUserMode)
            {
                case UserMode.Administrator:
                    break;
                case UserMode.Customer:
                    List<DataGrid_Announcements_DG_DataTemplete.DataGrid_Announcements_Binding> tmpData
                        = new List<DataGrid_Announcements_DG_DataTemplete.DataGrid_Announcements_Binding>();
                    DataGrid_Announcements_DG_DataTemplete.DataGrid_Announcements_Binding tmpDataItem;
                    for (int i = 0; i < _dataGrid_bindingData.Count; i++)
                    {
                        tmpDataItem = _dataGrid_bindingData[i];
                        if (tmpDataItem.baseInfo.isPublished
                            && tmpDataItem.baseInfo.startTime <= DateTime.Now
                            && tmpDataItem.baseInfo.endTime >= DateTime.Now)
                        {
                            tmpData.Add(_dataGrid_bindingData[i]);
                        }
                    }
                    _dataGrid_bindingData = tmpData;
                    dataGrid.ItemsSource = _dataGrid_bindingData;
                    break;
            }
        }

        public event EventHandler<Templetes.IEventArgs.Message> InformatingStart;
        public event EventHandler<Templetes.IEventArgs.Message> InformatingEnd;

        public event EventHandler LoadInfoListComplete;
        public event EventHandler LoadInfoListFailed;
        public event EventHandler LoadVotedAnumNameListComplete;
        public event EventHandler LoadVotedAnumNameListFailed;

        private List<DataProcessing.Announcement.Info> _data;
        public List<DataProcessing.Announcement.Info> data
        {
            get
            {
                return _data;
            }
        }
        private List<string> _myVotedAnums;
        public List<string> myVotedAnums
        {
            get { return _myVotedAnums; }
        }

        //Service_AnnouncementsClient anumClient;
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
        }


        public void Refresh()
        {
            button_refresh_Click(button_refresh, new RoutedEventArgs());
        }
        private void button_refresh_Click(object sender, RoutedEventArgs e)
        {
            if (InformatingStart != null) InformatingStart(this, new Templetes.IEventArgs.Message("正在下载公告清单数据……"));
            //if (myUserMode == UserMode.Administrator)
            //{
            //    anumClient.Get_AllAnnouncementInfoAsync(_myId.id);
            //}
            //else
            //{
            //    anumClient.Get_AllMyAnnouncementInfoAsync(_myId.id);
            //}
        }
        //void anumClient_Get_AllAnnouncementInfoCompleted(object sender, Get_AllAnnouncementInfoCompletedEventArgs e)
        //{
        //    Handle_AnnouncementsInfoReturns((object)e);
        //}
        //void anumClient_Get_AllMyAnnouncementInfoCompleted(object sender, Get_AllMyAnnouncementInfoCompletedEventArgs e)
        //{
        //    Handle_AnnouncementsInfoReturns((object)e);
        //}
        //private void Handle_AnnouncementsInfoReturns(object e)
        //{
        //    Exception err;
        //    System.Collections.ObjectModel.ObservableCollection<string> result;
        //    if (myUserMode == UserMode.Administrator)
        //    {
        //        Get_AllAnnouncementInfoCompletedEventArgs data = (Get_AllAnnouncementInfoCompletedEventArgs)e;
        //        err = data.Error;
        //        result = data.Result;
        //    }
        //    else if (myUserMode == UserMode.Customer)
        //    {
        //        Get_AllMyAnnouncementInfoCompletedEventArgs data = (Get_AllMyAnnouncementInfoCompletedEventArgs)e;
        //        err = data.Error;
        //        result = data.Result;
        //    }
        //    else
        //    {
        //        throw new Exception("User Mode [" + myUserMode.ToString() + "] Unknow!");
        //    }

        //    _data = new List<DataProcessing.Announcement.Info>();
        //    _dataGrid_bindingData = new List<DataGrid_Announcements_DG_DataTemplete.DataGrid_Announcements_Binding>();
        //    if (err == null)
        //    {
        //        if (result != null)
        //        {
        //            foreach (string ioItem in result)
        //            {
        //                _data.Add(new DataProcessing.Announcement.Info(ioItem));
        //            }
        //            foreach (DataProcessing.Announcement.Info info in _data)
        //            {
        //                _dataGrid_bindingData.Add(new DataGrid_Announcements_DG_DataTemplete.DataGrid_Announcements_Binding(info));
        //            }
        //            if (InformatingEnd != null) InformatingEnd(this, new Templetes.IEventArgs.Message("Done of Reload"));
        //            if (LoadInfoListComplete != null) LoadInfoListComplete(this, new EventArgs());
        //            if (myUserMode == UserMode.Customer)
        //            {
        //                anumClient.Get_AllMyHadVotedAnumNamesAsync(_myId.id);
        //            }
        //            else
        //            {
        //                dataGrid.ItemsSource = _dataGrid_bindingData;
        //                AutoHide_DataGridColumns();
        //                AutoHide_DataGridRows();

        //                if (InformatingEnd != null) InformatingEnd(this, new Templetes.IEventArgs.Message("Done of Reload"));
        //                if (LoadVotedAnumNameListComplete != null) LoadVotedAnumNameListComplete(this, new EventArgs());

        //                DataGrid_Anum_SelectFirstRow();
        //            }
        //        }
        //        else
        //        {
        //            if (InformatingEnd != null) InformatingEnd(this, new Templetes.IEventArgs.Message("Load Result is Null"));
        //            if (LoadInfoListFailed != null) LoadInfoListFailed(this, new EventArgs());
        //        }
        //    }
        //    else
        //    {
        //        if (InformatingEnd != null) InformatingEnd(this, new Templetes.IEventArgs.Message(err.Message));
        //        if (LoadInfoListFailed != null) LoadInfoListFailed(this, new EventArgs());
        //    }
        //}
        //void anumClient_Get_AllMyHadVotedAnumNamesCompleted(object sender, Get_AllMyHadVotedAnumNamesCompletedEventArgs e)
        //{
        //    //throw new NotImplementedException();
        //    _myVotedAnums = new List<string>();
        //    if (e.Error == null)
        //    {
        //        if (e.Result != null)
        //        {
        //            foreach (string anumName in e.Result)
        //            {
        //                _myVotedAnums.Add(anumName);
        //            }
        //            for (int i = _dataGrid_bindingData.Count - 1; i >= 0; i--)
        //            {
        //                foreach (string votedAnumName in _myVotedAnums)
        //                {
        //                    if (_dataGrid_bindingData[i].name == votedAnumName)
        //                    {
        //                        _dataGrid_bindingData[i].isVoted = true;
        //                        break;
        //                    }
        //                }
        //            }
        //            dataGrid.ItemsSource = _dataGrid_bindingData;
        //            AutoHide_DataGridColumns();
        //            AutoHide_DataGridRows();

        //            if (InformatingEnd != null) InformatingEnd(this, new Templetes.IEventArgs.Message("Done of Reload"));
        //            if (LoadVotedAnumNameListComplete != null) LoadVotedAnumNameListComplete(this, new EventArgs());

        //            DataGrid_Anum_SelectFirstRow();
        //        }
        //        else
        //        {
        //            if (InformatingEnd != null) InformatingEnd(this, new Templetes.IEventArgs.Message("Load Result is Null"));
        //            if (LoadVotedAnumNameListFailed != null) LoadVotedAnumNameListFailed(this, new EventArgs());
        //        }
        //    }
        //    else
        //    {
        //        if (InformatingEnd != null) InformatingEnd(this, new Templetes.IEventArgs.Message(e.Error.Message));
        //        if (LoadInfoListFailed != null) LoadInfoListFailed(this, new EventArgs());
        //    }
        //}
        private void DataGrid_Anum_SelectFirstRow()
        {
            if(_dataGrid_bindingData.Count >0)
            {
                dataGrid.SelectedIndex = 0;
            }
        }

        private List<DataGrid_Announcements_DG_DataTemplete.DataGrid_Announcements_Binding> _dataGrid_bindingData = new List<DataGrid_Announcements_DG_DataTemplete.DataGrid_Announcements_Binding>();


        private List<DataGrid_Announcements_DG_DataTemplete.DataGrid_Announcements_Binding> _selection
            = new List<DataGrid_Announcements_DG_DataTemplete.DataGrid_Announcements_Binding>();
        public List<DataGrid_Announcements_DG_DataTemplete.DataGrid_Announcements_Binding> Selection
        {
            get { return _selection; }
        }
        public event EventHandler<SelectionChangedEventArgs> SelectionChanged;
        private void dataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            _selection.Clear();
            foreach (DataGrid_Announcements_DG_DataTemplete.DataGrid_Announcements_Binding item in e.AddedItems)
            {
                _selection.Add(item);
            }
            if (SelectionChanged != null)
            {
                SelectionChanged(sender, e);
            }
        }

        public void dataGrid_SelectAnum(string anumName)
        {
            for (int i = _dataGrid_bindingData.Count - 1; i >= 0;i-- )
            {
                if (_dataGrid_bindingData[i].name == anumName)
                {
                    dataGrid.SelectedItem = _dataGrid_bindingData[i];
                    break;
                }
            }
        }
    }
}
