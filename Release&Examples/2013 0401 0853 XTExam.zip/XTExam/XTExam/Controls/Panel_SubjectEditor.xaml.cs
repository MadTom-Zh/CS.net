﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.Views_Admin.Paper.SubPack;
using XTExam.Views_Admin.Paper.SubPack.controls;
using XTExam.CodeSharing.Entities;

namespace XTExam.Controls
{
    public partial class Panel_SubjectEditor : UserControl
    {
        private DataProcessing.UserRegister.UserInfo _myId;
        public DataProcessing.UserRegister.UserInfo myId
        {
            set
            {
                _myId = value;
                if (_myId == null || !_myId.hasId)
                {
                    this.IsEnabled = false;
                    return;
                }
                if (!_myId.couldAdminAnnouncement && !_myId.couldMakePaper)
                {
                    this.IsEnabled = false;
                    return;
                }
                if (uiSetSingle == null)
                {
                    uiSetSingle = new UISetSingle(myId);
                    uiSetMuti = new UISetMuti(myId);
                    uiSetJudge = new UISetJudge(myId);
                    uiSetBlanks = new UISetBlanks(myId);
                    uiSetQAnswer = new UISetQAnswer(myId);

                    uiSetBlanks.UI_Set_BlankComplete += new EventHandler(uiSetBlanks_UI_Set_BlankComplete);
                    uiSetBlanks.UI_EnSet_BlankComplete += new EventHandler(uiSetBlanks_UI_EnSet_BlankComplete);
                }
                radioButton_single_Checked(radioButton_sSingle, new RoutedEventArgs());
            }
            get
            {
                return _myId;
            }
        }
        public Panel_SubjectEditor()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
        }

        private UISetSingle uiSetSingle;
        private UISetMuti uiSetMuti;
        private UISetJudge uiSetJudge;
        private UISetBlanks uiSetBlanks;
        private UISetQAnswer uiSetQAnswer;

        private DataProcessing.Depot.Subject.Type _subjectType;
        public DataProcessing.Depot.Subject.Type subjectType
        {
            get { return _subjectType; }
        }
        public string subjectScript
        {
            get
            {
                double grands = Get_Grands();
                if (grands < 0) return null;
                string result = null;
                DataProcessing.Depot.Subject subjHelper = new DataProcessing.Depot.Subject();
                subjHelper.subject = textBox_subject.Text;
                subjHelper.imageFileName = textBox_image.Text;

                subjHelper.grades = grands;
                if (radioButton_sSingle.IsChecked == true)
                {
                    uiSetSingle.SetData2Subject(ref subjHelper);
                    result = subjHelper.ScriptSingle;
                }
                else if (radioButton_sMuti.IsChecked == true)
                {
                    uiSetMuti.SetData2Subject(ref subjHelper);
                    result = subjHelper.ScriptMuti;
                }
                else if (radioButton_sJudge.IsChecked == true)
                {
                    uiSetJudge.SetData2Subject(ref subjHelper);
                    result = subjHelper.ScriptJudge;
                }
                else if (radioButton_sBlanks.IsChecked == true)
                {
                    uiSetBlanks.SetData2Subject(ref subjHelper);
                    result = subjHelper.ScriptBlanks;
                }
                else if (radioButton_sQAnswer.IsChecked == true)
                {
                    uiSetQAnswer.SetData2Subject(ref subjHelper);
                    result = subjHelper.ScriptQAnswer;
                }
                return result;
            }
        }
        private double Get_Grands()
        {
            double grands;
            try
            {
                grands = double.Parse(textBox_grades.Text);
                if (grands <= 0 || grands > 100) throw new Exception("分数在预想范围之外");
                return grands;
            }
            catch (Exception err)
            {
                if (InformatingEnd != null) InformatingEnd(this, new Templetes.IEventArgs.Message(err.Message));
                return -1;
            }
        }
        private void radioButton_single_Checked(object sender, RoutedEventArgs e)
        {
            if (grid_UISites == null || uiSetSingle == null) return;
            button_blanks_SetBlanks.IsEnabled = false;
            grid_UISites.Children.Clear();
            RadioButton tar = (RadioButton)sender;
            string btnName = tar.Name.ToLower();
            if (btnName.Contains("single"))
            {
                grid_UISites.Children.Add(uiSetSingle);
                _subjectType = DataProcessing.Depot.Subject.Type.Single;
            }
            else if (btnName.Contains("muti"))
            {
                grid_UISites.Children.Add(uiSetMuti);
                _subjectType = DataProcessing.Depot.Subject.Type.Muti;
            }
            else if (btnName.Contains("judge"))
            {
                grid_UISites.Children.Add(uiSetJudge);
                _subjectType = DataProcessing.Depot.Subject.Type.Judge;
            }
            else if (btnName.Contains("blank"))
            {
                grid_UISites.Children.Add(uiSetBlanks);
                _subjectType = DataProcessing.Depot.Subject.Type.Blanks;
                button_blanks_SetBlanks.IsEnabled = true;
            }
            else if (btnName.Contains("qanswer"))
            {
                grid_UISites.Children.Add(uiSetQAnswer);
                _subjectType = DataProcessing.Depot.Subject.Type.QAnswer;
            }
        }
        private void button_blanks_SetBlanks_Click(object sender, RoutedEventArgs e)
        {
            uiSetBlanks.UI_SetBlanks(textBox_subject.Text, textBox_subject.SelectionStart, textBox_subject.SelectionStart + textBox_subject.SelectionLength);
        }
        void uiSetBlanks_UI_Set_BlankComplete(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            textBox_subject.SelectedText = "【空缺】";
        }
        void uiSetBlanks_UI_EnSet_BlankComplete(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            textBox_subject.SelectedText = uiSetBlanks.UI_EnSet_BlankComplete_Value;
        }

        private void button_image_Click(object sender, RoutedEventArgs e)
        {
            SelectImage selectImgWin = new SelectImage(myId);
            selectImgWin.Closed += new EventHandler(selectImgWin_Closed);
            selectImgWin.Show();
        }
        void selectImgWin_Closed(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            SelectImage target = (SelectImage)sender;
            if (target.DialogResult == true && target.selectedImageName != null)
            {
                textBox_image.Text = target.selectedImageName;
            }
        }
        private void button_imageRemove_Click(object sender, RoutedEventArgs e)
        {
            textBox_image.Text = "";
        }

        public event EventHandler<Templetes.IEventArgs.Message> InformatingStart;
        public event EventHandler<Templetes.IEventArgs.Message> InformatingEnd;

        public event EventHandler<Templetes.IEventArgs.Subject> SubjectData_Generated;
        public void ReSet_BtnGenerateText(string text)
        {
            button_generate.Content = text;
        }

        public DataProcessing.Depot.Subject subjectData
        {
            get
            {
                double grands = Get_Grands();
                if (grands < 0) grands = 1;
                DataProcessing.Depot.Subject result = null;
                DataProcessing.Depot.Subject subjHelper = new DataProcessing.Depot.Subject();

                switch (_subjectType)
                {
                    case DataProcessing.Depot.Subject.Type.Single:
                        uiSetSingle.SetData2Subject(ref subjHelper);
                        result = new DataProcessing.Depot.Subject(subjHelper.IOContent);
                        result.type = DataProcessing.Depot.Subject.Type.Single;
                        break;
                    case DataProcessing.Depot.Subject.Type.Muti:
                        uiSetMuti.SetData2Subject(ref subjHelper);
                        result = new DataProcessing.Depot.Subject(subjHelper.IOContent);
                        result.type = DataProcessing.Depot.Subject.Type.Muti;
                        break;
                    case DataProcessing.Depot.Subject.Type.Judge:
                        uiSetJudge.SetData2Subject(ref subjHelper);
                        result = new DataProcessing.Depot.Subject(subjHelper.IOContent);
                        result.type = DataProcessing.Depot.Subject.Type.Judge;
                        break;
                    case DataProcessing.Depot.Subject.Type.Blanks:
                        uiSetBlanks.SetData2Subject(ref subjHelper);
                        result = new DataProcessing.Depot.Subject(subjHelper.IOContent);
                        result.type = DataProcessing.Depot.Subject.Type.Blanks;
                        break;
                    case DataProcessing.Depot.Subject.Type.QAnswer:
                        uiSetQAnswer.SetData2Subject(ref subjHelper);
                        result = new DataProcessing.Depot.Subject(subjHelper.IOContent);
                        result.type = DataProcessing.Depot.Subject.Type.QAnswer;
                        break;
                }
                result.subject = textBox_subject.Text;
                result.imageFileName = textBox_image.Text;
                result.grades = grands;
                return result;
            }
        }
        private void button_generate_Click(object sender, RoutedEventArgs e)
        {
            if (SubjectData_Generated != null) SubjectData_Generated(this, new Templetes.IEventArgs.Subject(this.subjectData));
        }


        private void button_view_Click(object sender, RoutedEventArgs e)
        {
            ChildWindow_SubjectViewer viewerWin = new ChildWindow_SubjectViewer();
            viewerWin.myId = _myId;
            viewerWin.SetSubject(this.subjectData.IOContent);
            viewerWin.Show();
        }

    }
}
