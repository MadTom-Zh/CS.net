﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.CodeSharing.Entities;
using XTExam.Views_Admin.Paper.SubPack.controls;

namespace XTExam.Controls
{
    public partial class ChildWindow_SubjectViewer : ChildWindow
    {
        private DataProcessing.UserRegister.UserInfo _myId;
        public DataProcessing.UserRegister.UserInfo myId
        {
            set
            {
                _myId = value;
                if (_myId == null || !_myId.hasId)
                {
                    gridMain.Visibility = System.Windows.Visibility.Collapsed;
                    return;
                }
                if (!_myId.couldAdminAnnouncement && !_myId.couldMakePaper)
                {
                    gridMain.Visibility = System.Windows.Visibility.Collapsed;
                    return;
                }
            }
            get { return _myId; }
        }
        public ChildWindow_SubjectViewer()
        {
            InitializeComponent();
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        public void SetSubject(string ioContent)
        {
            gridMain.Children.Clear();
            SubjectUI ui;
            ui = new SubjectUI(_myId, 1, new DataProcessing.Depot.Subject(ioContent), Class_SubjUIHelper.ShowType.SubjectOnly, null);
            gridMain.Children.Add(ui);
        }
    }
}

