﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows.Media.Imaging;
using System.Windows.Browser;
using XTExam.CodeSharing.Entities;

namespace XTExam.Controls
{
    public class Class_SubjUIHelper
    {
        public enum ShowType
        {
            SubjectOnly = 0,
            SubjectWithAnswer = 1,
            SubjectWithUserAnswer = 2,
            SubjectWithUserAnswerAndRemark = 3
        }

        private int _NO;
        private DataProcessing.Depot.Subject _subject;
        //private string _depotPath;
        private DataProcessing.ExamHall.UserExam.UserPaper.Element.UserData _userData;
        private ShowType _showType;
        public Class_SubjUIHelper(int NO, DataProcessing.Depot.Subject subject, DataProcessing.ExamHall.UserExam.UserPaper.Element.UserData userData, ShowType showType)
        {
            _NO = NO;
            _subject = subject;
            //_depotPath = depotPath;
            _userData = userData;
            _showType = showType;
        }
        #region 基本辅助函数
        private TextBlock MakeSubjectText(string text)
        {
            return MakeSubjectText(text, DataProcessing.Depot.Subject.SubjectAlign.Left, 19);
        }
        private TextBlock MakeSubjectText(string text, DataProcessing.Depot.Subject.SubjectAlign align, int fontSize)
        {
            TextBlock result = new TextBlock();
            result.TextWrapping = TextWrapping.Wrap;
            result.Text = text;
            if (align == DataProcessing.Depot.Subject.SubjectAlign.Left) result.TextAlignment = TextAlignment.Left;
            else if (align == DataProcessing.Depot.Subject.SubjectAlign.Middle) result.TextAlignment = TextAlignment.Center;
            else if (align == DataProcessing.Depot.Subject.SubjectAlign.Right) result.TextAlignment = TextAlignment.Right;
            if (fontSize <= 0) fontSize = 11;
            result.FontSize = fontSize;
            return result;
        }
        #endregion

        public void FillData2UI(ref StackPanel container)
        {
            switch (_subject.type)
            {
                default:
                case DataProcessing.Depot.Subject.Type.Caption:
                    BuildCaption(ref container, _subject.subjectAligh, _subject.subjectWeight);
                    break;
                case DataProcessing.Depot.Subject.Type.Single:
                    BuildSingle(ref container);
                    break;
                case DataProcessing.Depot.Subject.Type.Muti:
                    BuildMuti(ref container);
                    break;
                case DataProcessing.Depot.Subject.Type.Judge:
                    BuildJudge(ref container);
                    break;
                case DataProcessing.Depot.Subject.Type.Blanks:
                    BuildBlanks(ref container);
                    break;
                case DataProcessing.Depot.Subject.Type.QAnswer:
                    BuildQAnswer(ref container);
                    break;
            }

            switch (_showType)
            {
                default:
                case ShowType.SubjectOnly:
                    break;
                case ShowType.SubjectWithAnswer:
                    FillCurAnswer();
                    break;
                case ShowType.SubjectWithUserAnswerAndRemark:
                    if (_subject.type == DataProcessing.Depot.Subject.Type.Caption) break;
                    remark = new RichTextBox();
                    container.Children.Add(remark);
                    FillUserAnswer();
                    FillRemark();
                    break;
                case ShowType.SubjectWithUserAnswer:
                    FillUserAnswer();
                    break;
            }
        }
        private void BuildCaption(ref StackPanel container, DataProcessing.Depot.Subject.SubjectAlign align, int fontSize)
        {
            container.Children.Clear();
            container.Children.Add(MakeSubjectText(_subject.subject, align, fontSize));
        }

        private Image img;
        private void DownLoadImg()
        {
            img = new Image();
            WebClient imgDownLoader = new WebClient();
            imgDownLoader.OpenReadCompleted += new OpenReadCompletedEventHandler(imgDownLoader_OpenReadCompleted);
            string uriStr = "../Services/subjectImage.aspx?name=" + HttpUtility.UrlEncode(_subject.imageFileName);
            imgDownLoader.OpenReadAsync(new Uri(uriStr, UriKind.Relative));
        }
        void imgDownLoader_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Result != null)
            {
                BitmapImage bitmap = new BitmapImage();
                bitmap.SetSource(e.Result);
                img.MaxHeight = 300;
                img.Stretch = Stretch.Uniform;
                img.Source = bitmap;
            }
        }

        private List<RadioButton> singleOptions;
        private void BuildSingle(ref StackPanel container)
        {
            container.Children.Clear();
            container.Children.Add(MakeSubjectText(_NO + "、" + _subject.subject));

            if (_subject.imageFileName != null && _subject.imageFileName.Length > 0)
            {
                DownLoadImg();
                container.Children.Add(img);
            }

            StackPanel opts = new StackPanel();
            singleOptions = new List<RadioButton>();
            RadioButton newRB;
            for (int i = 0; i < _subject.singleOptions.Count; i++)
            {
                newRB = new RadioButton();
                newRB.GroupName = _NO + _subject.subject;
                newRB.Content = _subject.singleOptions[i];
                newRB.FontSize = 19;
                singleOptions.Add(newRB);
                opts.Children.Add(newRB);
            }
            container.Children.Add(opts);
        }


        private List<CheckBox> mutiOptions;
        private void BuildMuti(ref StackPanel container)
        {
            container.Children.Clear();
            container.Children.Add(MakeSubjectText(_NO + "、" + _subject.subject));

            if (_subject.imageFileName != null && _subject.imageFileName.Length > 0)
            {
                DownLoadImg();
                container.Children.Add(img);
            }

            StackPanel opts = new StackPanel();
            mutiOptions = new List<CheckBox>();
            CheckBox newCB;
            for (int i = 0; i < _subject.mutiOptions.Count; i++)
            {
                newCB = new CheckBox();
                newCB.Content = _subject.mutiOptions[i];
                newCB.FontSize = 19;
                mutiOptions.Add(newCB);
                opts.Children.Add(newCB);
            }
            container.Children.Add(opts);
        }

        private List<RadioButton> judgeOptions;
        private void BuildJudge(ref StackPanel container)
        {
            container.Children.Clear();
            container.Children.Add(MakeSubjectText(_NO + "、" + _subject.subject));

            if (_subject.imageFileName != null && _subject.imageFileName.Length > 0)
            {
                DownLoadImg();
                container.Children.Add(img);
            }

            StackPanel opts = new StackPanel();
            judgeOptions = new List<RadioButton>();
            RadioButton newRB;
            for (int i = 0; i < _subject.judgeOptions.Count; i++)
            {
                newRB = new RadioButton();
                newRB.GroupName = _NO + _subject.subject;
                newRB.FontSize = 19;
                newRB.Content = _subject.judgeOptions[i];
                judgeOptions.Add(newRB);
                opts.Children.Add(newRB);
            }
            container.Children.Add(opts);
        }

        private RichTextBox blanksSubject;
        private List<TextBox> blanks;
        private void BuildBlanks(ref StackPanel container)
        {
            container.Children.Clear();
            blanks = new List<TextBox>();
            TextBox tb;
            blanksSubject = new RichTextBox();
            blanksSubject.IsReadOnly = true;
            blanksSubject.BorderThickness = new Thickness(0);

            Paragraph block = new Paragraph();
            block.Inlines.Add(_NO + "、");
            string[] textChips = _subject.subject.Split(new string[] { DataProcessing.Depot.Subject.JOIN_SEPARATOR_4UITEXT }, StringSplitOptions.None);
            for (int i = 0; i < textChips.Length; i++)
            {
                block.Inlines.Add(textChips[i]);
                if (i < _subject.blanksAnswers.Count)
                {
                    InlineUIContainer iUIC = new InlineUIContainer();
                    tb = new TextBox();
                    tb.Width = 100;
                    iUIC.Child = tb;
                    blanks.Add(tb);
                    block.Inlines.Add(iUIC);
                }
            }
            blanksSubject.Blocks.Add(block);
            container.Children.Add(blanksSubject);

            if (_subject.imageFileName != null && _subject.imageFileName.Length > 0)
            {
                DownLoadImg();
            }
        }

        private TextBox qAnswer;
        private void BuildQAnswer(ref StackPanel container)
        {
            container.Children.Clear();
            container.Children.Add(MakeSubjectText(_NO + "、" + _subject.subject));

            if (_subject.imageFileName != null && _subject.imageFileName.Length > 0)
            {
                DownLoadImg();
                container.Children.Add(img);
            }

            qAnswer = new TextBox();
            qAnswer.Height = 70;
            container.Children.Add(qAnswer);
        }


        private void FillCurAnswer()
        {
            switch (_subject.type)
            {
                default:
                case DataProcessing.Depot.Subject.Type.Caption:
                    break;
                case DataProcessing.Depot.Subject.Type.Single:
                    singleOptions[_subject.singleAnswer_curIndex].IsChecked = true;
                    break;
                case DataProcessing.Depot.Subject.Type.Muti:
                    for (int i = 0; i < _subject.mutiAnswers.Count; i++)
                    {
                        mutiOptions[i].IsChecked = _subject.mutiAnswers[i];
                    }
                    break;
                case DataProcessing.Depot.Subject.Type.Judge:
                    if (_subject.judgeAnswer_leftIsRight) judgeOptions[0].IsChecked = true;
                    else judgeOptions[1].IsChecked = true;
                    break;
                case DataProcessing.Depot.Subject.Type.Blanks:
                    for (int i = 0; i < _subject.blanksAnswers.Count; i++)
                    {
                        //double tmp = blanks[i].Width;
                        blanks[i].ClearValue(TextBox.WidthProperty);
                        blanks[i].Text = _subject.blanksAnswers[i];
                    }
                    break;
                case DataProcessing.Depot.Subject.Type.QAnswer:
                    qAnswer.ClearValue(TextBox.HeightProperty);
                    qAnswer.Text = _subject.qAnswer;
                    //if (qAnswer.Height < 70) qAnswer.Height = 70;
                    break;
            }
        }
        private void FillUserAnswer()
        {
            switch (_subject.type)
            {
                default:
                case DataProcessing.Depot.Subject.Type.Caption:
                    break;
                case DataProcessing.Depot.Subject.Type.Single:
                    try
                    {
                        singleOptions[int.Parse(_userData.answer)].IsChecked = true;
                    }
                    catch (Exception)
                    {
                    }
                    break;
                case DataProcessing.Depot.Subject.Type.Muti:
                    for (int i = 0; i < _userData.answer.Length; i++)
                    {
                        try
                        {
                            mutiOptions[i].IsChecked = (_userData.answer[i] == '-') ? false : true;
                        }
                        catch (Exception) { }
                    }
                    break;
                case DataProcessing.Depot.Subject.Type.Judge:
                    if (_userData.answer == null || _userData.answer.Length == 0) break;
                    if (bool.Parse(_userData.answer)) judgeOptions[0].IsChecked = true;
                    else judgeOptions[1].IsChecked = true;
                    break;
                case DataProcessing.Depot.Subject.Type.Blanks:
                    string[] bks = _userData.answer.Split(new string[] { DataProcessing.Depot.Subject.JOIN_SEPARATOR }, StringSplitOptions.None);
                    for (int i = 0; i < bks.Length; i++)
                    {
                        blanks[i].Text = bks[i];
                    }
                    break;
                case DataProcessing.Depot.Subject.Type.QAnswer:
                    qAnswer.Text = _userData.answer.Replace("\\r", "\r");
                    break;
            }
        }
        public DataProcessing.ExamHall.UserExam.UserPaper.Element.UserData GetUserAnswer()
        {
            _userData = new DataProcessing.ExamHall.UserExam.UserPaper.Element.UserData();
            switch (_subject.type)
            {
                default:
                case DataProcessing.Depot.Subject.Type.Caption:
                    break;
                case DataProcessing.Depot.Subject.Type.Single:
                    for (int i = singleOptions.Count - 1; i >= 0; i--)
                    {
                        if (singleOptions[i].IsChecked == true)
                        {
                            _userData.answer = i + "";
                            break;
                        }
                    }
                    break;
                case DataProcessing.Depot.Subject.Type.Muti:
                    _userData.answer = "";
                    for (int i = 0; i < mutiOptions.Count; i++)
                    {
                        _userData.answer += (mutiOptions[i].IsChecked == true) ? "R" : "-";
                    }
                    break;
                case DataProcessing.Depot.Subject.Type.Judge:
                    if (judgeOptions[0].IsChecked == judgeOptions[1].IsChecked && judgeOptions[0].IsChecked == false) _userData.answer = "";
                    else _userData.answer = (judgeOptions[0].IsChecked == true).ToString();
                    break;
                case DataProcessing.Depot.Subject.Type.Blanks:
                    _userData.answer = "";
                    for (int i = 0; i < blanks.Count; i++)
                    {
                        if (_userData.answer.Length > 0) _userData.answer += DataProcessing .Depot.Subject.JOIN_SEPARATOR;
                        _userData.answer += blanks[i].Text;
                    }
                    break;
                case DataProcessing.Depot.Subject.Type.QAnswer:
                    _userData.answer = qAnswer.Text.Replace("\n", "").Replace("\r", "\\r");
                    break;
            }
            return _userData;
        }
        public double GetGrade()
        {
            if (_subject.type == DataProcessing.Depot.Subject.Type.Caption) return 0;
            return _userData.grade;
        }
        private RichTextBox remark;
        private void FillRemark()
        {
            string CURIGHT = "完全正确！";
            string CURANS_IS = "标准答案是：";
            string WRONG = "错误！";
            remark.BorderThickness = new Thickness(0);
            Paragraph curNote = new Paragraph();
            //Run text = new Run();
            switch (_subject.type)
            {
                default:
                case DataProcessing.Depot.Subject.Type.Caption:
                    break;
                case DataProcessing.Depot.Subject.Type.Single:
                    //text.Text = (_userData.answer == _subject.singleAnswer_curIndex.ToString()) ? CURIGHT : WRONG;
                    curNote.Inlines.Add((_userData.answer == _subject.singleAnswer_curIndex.ToString()) ? CURIGHT : WRONG);
                    curNote.Inlines.Add(CURANS_IS + "第[" + (_subject.singleAnswer_curIndex + 1) + "]项");
                    break;
                case DataProcessing.Depot.Subject.Type.Muti:
                    curNote.Inlines.Add((_userData.answer == _subject.IOMutiAnswers) ? CURIGHT : WRONG);
                    curNote.Inlines.Add(CURANS_IS + "第[");
                    string indesStr = "";
                    for (int i = 0; i < _subject.mutiAnswers.Count; i++)
                    {
                        if (_subject.mutiAnswers[i])
                        {
                            if (indesStr.Length > 0) indesStr += "、";
                            indesStr += "" + (i + 1);
                        }
                    }
                    curNote.Inlines.Add(indesStr + "]项");
                    break;
                case DataProcessing.Depot.Subject.Type.Judge:
                    curNote.Inlines.Add((_userData.answer == _subject.judgeAnswer_leftIsRight.ToString()) ? CURIGHT : WRONG);
                    curNote.Inlines.Add(CURANS_IS + "第[" + ((_subject.judgeAnswer_leftIsRight) ? 1 : 2) + "]项");
                    break;
                case DataProcessing.Depot.Subject.Type.Blanks:
                    curNote.Inlines.Add((_userData.answer == _subject.IOBlanksAnswers) ? CURIGHT : WRONG);
                    curNote.Inlines.Add(CURANS_IS + _subject.IOBlanksAnswers.Replace(DataProcessing.Depot.Subject.JOIN_SEPARATOR, "；"));
                    break;
                case DataProcessing.Depot.Subject.Type.QAnswer:
                    curNote.Inlines.Add((_userData.answer == _subject.qAnswer) ? CURIGHT : WRONG);
                    curNote.Inlines.Add(CURANS_IS + _subject.qAnswer.Replace("\\r", "\r"));
                    break;
            }
            SolidColorBrush brush;
            remark.Blocks.Add(curNote);
            remark.SelectAll();
            if (remark.Selection.Text.StartsWith(CURIGHT))
            {
                brush = new SolidColorBrush(Color.FromArgb(
                    (byte)255,
                    (byte)50,
                    (byte)255,
                    (byte)100));
            }
            else
            {
                brush = new SolidColorBrush(Color.FromArgb(
                    (byte)255,
                    (byte)250,
                    (byte)150,
                    (byte)50));
            }
            remark.SelectAll();
            remark.Selection.ApplyPropertyValue(Run.ForegroundProperty, brush);
            if (_userData.singleRemark != null && _userData.singleRemark.Length > 0)
            {
                Paragraph remarkblk = new Paragraph();
                remarkblk.Inlines.Add("专家批复：" + _userData.singleRemark);
                remark.Blocks.Add(remarkblk);
            }
        }
    }
}
