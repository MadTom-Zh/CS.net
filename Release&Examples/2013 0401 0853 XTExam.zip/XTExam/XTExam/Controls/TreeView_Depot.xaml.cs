﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.ServiceReference_Depot;
using System.Collections.ObjectModel;
using System.Windows.Media.Imaging;
using XTExam.Views_Admin.Paper.SubPack;
using XTExam.CodeSharing.Entities;

namespace XTExam.Controls
{
    public partial class TreeView_Depot : UserControl
    {
        public TreeView_Depot()
        {
            InitializeComponent();
        }

        public string Infomating;
        public event EventHandler InfomatingStart;
        public event EventHandler InfomatingStop;

        private Image treeViewMain_iconDir;
        private Image treeViewMain_iconPot;
        private Service_DepotClient serviceClient;

        private DataProcessing.UserRegister.UserInfo _myId;
        public DataProcessing.UserRegister.UserInfo myID
        {
            set
            {
                _myId = value;
                if (_myId == null || !_myId.hasId)
                {
                }
                else UserControl_Loaded(this, new RoutedEventArgs());
            }
        }
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            if (_myId == null || !_myId.hasId)
            {
                this.IsEnabled = false;
                return;
            }
            this.IsEnabled = true;
            serviceClient = new Service_DepotClient();
            serviceClient.GetAllStorItemsCompleted += new EventHandler<GetAllStorItemsCompletedEventArgs>(serviceClient_GetAllStorItemsCompleted);

            treeViewMain_iconDir = new Image();
            BitmapImage bitmap = new BitmapImage();
            bitmap.UriSource = new Uri("/image/folder_16.PNG", UriKind.Relative);
            treeViewMain_iconDir.Source = bitmap;
            treeViewMain_iconPot = new Image();
            bitmap = new BitmapImage();
            bitmap.UriSource = new Uri("/image/depot_16.PNG", UriKind.Relative);
            treeViewMain_iconPot.Source = bitmap;

            button_reloadTree_Click(button_reloadTree, e);
        }

        public event EventHandler LoadTreeStart;
        public event EventHandler LoadTreeComplete;
        public event EventHandler LoadTreeFailed;
        public void ReloadTree()
        {
            button_reloadTree_Click(button_reloadTree, new RoutedEventArgs());
        }
        private void button_reloadTree_Click(object sender, RoutedEventArgs e)
        {
            treeViewMain.Items.Clear();
            Infomating = "正在加载存储树……";
            if (InfomatingStart != null) InfomatingStart(this, new EventArgs());
            if (LoadTreeStart != null) LoadTreeStart(this, new EventArgs());
            serviceClient.GetAllStorItemsAsync();
        }
        void serviceClient_GetAllStorItemsCompleted(object sender, GetAllStorItemsCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result != null)
                {
                    foreach (string item in e.Result)
                    {
                        if (item.Length <= 3) continue;
                        treeViewMain_addItem(item.Substring(0, 1), item.Substring(3));
                    }
                    treeView_ExpandAll(treeViewMain);
                    Infomating = "已重新加载树";
                    if (InfomatingStop != null) InfomatingStop(this, new EventArgs());
                    if (LoadTreeComplete != null) LoadTreeComplete(this, new EventArgs());
                }
                else
                {
                    Infomating = "未能获取树，请重试……";
                    if (InfomatingStop != null) InfomatingStop(this, new EventArgs());
                    if (LoadTreeFailed != null) LoadTreeFailed(this, new EventArgs());
                }
            }
            else
            {
                Infomating = e.Error.Message;
                if (InfomatingStop != null) InfomatingStop(this, new EventArgs());
                if (LoadTreeFailed != null) LoadTreeFailed(this, new EventArgs());
            }
        }

        private void treeViewMain_addItem(string type, string path)
        {
            TreeViewItem rootNode = null, subNode = null, newTNode;
            string[] iTag;
            bool nodeFound;
            string[] pathParts = path.Split(new string[] { "\\" }, StringSplitOptions.RemoveEmptyEntries);
            for (int j = 0; j < pathParts.Length; j++)
            {
                nodeFound = false;
                if (j == 0)
                {
                    for (int i = treeViewMain.Items.Count - 1; i >= 0; i--)
                    {
                        rootNode = (TreeViewItem)treeViewMain.Items[i];
                        iTag = (string[])rootNode.Tag;
                        if (iTag[1] == pathParts[j])
                        {
                            nodeFound = true;
                            break;
                        }
                    }
                }
                if (j > 0)
                {
                    for (int i = rootNode.Items.Count - 1; i >= 0; i--)
                    {
                        subNode = (TreeViewItem)rootNode.Items[i];
                        iTag = (string[])subNode.Tag;
                        if (iTag[1] == pathParts[j])
                        {
                            rootNode = subNode;
                            nodeFound = true;
                            break;
                        }
                    }
                }
                if (!nodeFound)
                {
                    newTNode = new TreeViewItem();
                    newTNode.Tag = new string[] { type, pathParts[j] };
                    newTNode.Header = treeViewMain_makeTNodeHead((type == "P" && j == (pathParts.Length - 1)) ? treeViewMain_iconPot : treeViewMain_iconDir, pathParts[j]);
                    if (j == 0)
                    {
                        treeViewMain.Items.Add(newTNode);
                        rootNode = newTNode;
                    }
                    else
                    {
                        rootNode.Items.Add(newTNode);
                        rootNode = newTNode;
                    }
                }
            }
        }
        private StackPanel treeViewMain_makeTNodeHead(Image icon, string text)
        {
            StackPanel result = new StackPanel();
            result.Orientation = Orientation.Horizontal;
            Image newImage = new Image();
            newImage.Source = icon.Source;
            result.Children.Add(newImage);
            Label iText = new Label();
            iText.Content = text;
            result.Children.Add(iText);
            return result;
        }
        private void treeView_ExpandAll(TreeView target)
        {
            for (int i = target.Items.Count - 1; i >= 0; i--)
            {
                treeView_ExpandNode((TreeViewItem)target.Items[i]);
            }
        }
        private void treeView_ExpandNode(TreeViewItem node)
        {
            node.IsExpanded = true;
            for (int i = node.Items.Count - 1; i >= 0; i--)
            {
                treeView_ExpandNode((TreeViewItem)node.Items[i]);
            }
        }

        public event EventHandler SelectedNodeChanged;
        public string selectedNodeFullPath;
        public bool selectedNodeFullPath_isDepot;

        private void treeViewMain_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            selectedNodeFullPath_isDepot = false;
            if (treeViewMain.SelectedItem == null)
            {
                selectedNodeFullPath = null;
            }
            else
            {
                TreeViewItem selectedTNode = (TreeViewItem)treeViewMain.SelectedItem;
                selectedNodeFullPath = treeViewMain_GetTNodeFullPath((TreeViewItem)treeViewMain.SelectedItem);
                string[] tag = (string[])selectedTNode.Tag;
                if (tag[0] == "P")
                {
                    selectedNodeFullPath_isDepot = true;
                }
            }
            if (SelectedNodeChanged != null) SelectedNodeChanged(this.treeViewMain, new EventArgs());
        }
        private string treeViewMain_GetTNodeFullPath(TreeViewItem tNode)
        {
            string result = "";
            while (tNode != null)
            {
                if (result.Length > 0) result = "\\" + result;
                result = ((string[])tNode.Tag)[1] + result;
                try
                {
                    tNode = (TreeViewItem)tNode.Parent;
                }
                catch (Exception) { break; }
            }
            return result;
        }
        private void treeViewMain_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (selectedNodeFullPath != null && selectedNodeFullPath_isDepot)
                {
                    ViewDepotDetal vdWin = new ViewDepotDetal(selectedNodeFullPath, _myId);
                    vdWin.Show();
                }
            }
        }

    }
}
