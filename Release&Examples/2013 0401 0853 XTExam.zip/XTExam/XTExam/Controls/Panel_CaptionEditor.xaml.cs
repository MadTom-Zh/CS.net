﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.CodeSharing.Entities;

namespace XTExam.Controls
{
    public partial class Panel_CaptionEditor : UserControl
    {
        public Panel_CaptionEditor()
        {
            InitializeComponent();
        }

        private string judgedCaption = "";
        private void textBox_caption_TextChanged(object sender, TextChangedEventArgs e)
        {
            judgedCaption = textBox_caption.Text.Trim();
            ReBuildSample();
        }
        private void slider_fontSize_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (textBox_fontSize == null) return;
            textBox_fontSize.Text = (int)slider_fontSize.Value + "";
            ReBuildSample();
        }
        private void radioButton_L_Checked(object sender, RoutedEventArgs e)
        {
            ReBuildSample();
        }
        private void radioButton_M_Checked(object sender, RoutedEventArgs e)
        {
            ReBuildSample();
        }
        private void radioButton_R_Checked(object sender, RoutedEventArgs e)
        {
            ReBuildSample();
        }

        private void ReBuildSample()
        {
            if (textBox_caption == null) return;
            Paragraph block = new Paragraph();
            block.Inlines.Add(textBox_caption.Text);
            block.FontSize = (int)slider_fontSize.Value;
            if (radioButton_L.IsChecked == true) block.TextAlignment = TextAlignment.Left;
            else if (radioButton_M.IsChecked == true) block.TextAlignment = TextAlignment.Center;
            else if (radioButton_R.IsChecked == true) block.TextAlignment = TextAlignment.Right;
            richTextBox_sample.Blocks.Clear();
            richTextBox_sample.Blocks.Add(block);
        }

        public DataProcessing.Depot.Subject captionData
        {
            get
            {
                DataProcessing.Depot.Subject result = new DataProcessing.Depot.Subject();
                result.type = DataProcessing.Depot.Subject.Type.Caption;
                result.subject = judgedCaption;
                result.subjectWeight = (int)slider_fontSize.Value;
                if (radioButton_L.IsChecked == true) result.subjectAligh = DataProcessing.Depot.Subject.SubjectAlign.Left;
                else if (radioButton_M.IsChecked == true) result.subjectAligh = DataProcessing.Depot.Subject.SubjectAlign.Middle;
                else if (radioButton_R.IsChecked == true) result.subjectAligh = DataProcessing.Depot.Subject.SubjectAlign.Right;
                return result;
            }
        }
    }
}
