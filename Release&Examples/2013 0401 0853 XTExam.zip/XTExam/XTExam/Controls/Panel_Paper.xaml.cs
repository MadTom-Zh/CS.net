﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.CodeSharing.Entities;
//using XTExam.ServiceReference_Announcements;

namespace XTExam.Controls
{
    public partial class Panel_Paper : UserControl
    {
        private DataProcessing.UserRegister.UserInfo _myId;
        public DataProcessing.UserRegister.UserInfo myId
        {
            set
            {
                _myId = value;
                if (_myId != null && _myId.hasId)
                {
                    this.IsEnabled = true;
                }
            }
            get { return _myId; }
        }
        public Panel_Paper()
        {
            InitializeComponent();
            this.IsEnabled = false;
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {

        }

        public enum PaperType
        {
            None,
            Exam,
            Announcement,
        }
        private PaperType _paperType = PaperType.None;
        public PaperType paperType
        {
            get { return _paperType; }
        }

        public event EventHandler<Templetes.IEventArgs.Message> InformatingStart;
        public event EventHandler<Templetes.IEventArgs.Message> InformatingEnd;

        public event EventHandler LoadingPaperStart;
        public event EventHandler LoadingPaperComplete;
        public event EventHandler LoadingPaperError;

        private bool _isPaperReady = true;
        public bool isPaperReady
        {
            get { return _isPaperReady; }
        }
        private string _anumName;
        public string anumName
        {
            get { return _anumName; }
        }

        //Service_AnnouncementsClient anumClient;
        public void Reload_Paper(PaperType paperType, string anumName_or_examHallName)
        {
            if (!this.IsEnabled)
            {
                if (InformatingEnd != null) InformatingEnd(this, new Templetes.IEventArgs.Message("您未被授权！"));
                return;
            }
            if (LoadingPaperStart != null) LoadingPaperStart(this, new EventArgs());
            _isPaperReady = false;
            stackPanel_container.Children.Clear();
            if (InformatingStart != null) InformatingStart(this, new Templetes.IEventArgs.Message("正在下载页面数据……"));
            switch (paperType)
            {
                case PaperType.Announcement:
                    //_anumName = anumName_or_examHallName;
                    //if (anumClient == null)
                    //{
                    //    anumClient = new Service_AnnouncementsClient();
                    //    anumClient.Load_MyAnnouncementPaperCompleted += new EventHandler<Load_MyAnnouncementPaperCompletedEventArgs>(anumClient_Load_MyAnnouncementPaperCompleted);
                    //}
                    //anumClient.Load_MyAnnouncementPaperAsync(myId.id, anumName_or_examHallName);
                    break;
                case PaperType.Exam:
                    throw new Exception("Coding to be continue!");
                //break;
            }
        }
        //void anumClient_Load_MyAnnouncementPaperCompleted(object sender, Load_MyAnnouncementPaperCompletedEventArgs e)
        //{
        //    if (e.Error == null)
        //    {
        //        if (e.Result != null)
        //        {
        //            _userPaper = new DataProcessing.ExamHall.UserExam.UserPaper(e.Result);
        //            Fill_Paper_Up(_userPaper);
        //            if (LoadingPaperComplete != null) LoadingPaperComplete(this, new EventArgs());
        //            if (InformatingEnd != null) InformatingEnd(this, new Templetes.IEventArgs.Message("就绪"));
        //        }
        //        else
        //        {
        //            if (LoadingPaperError != null) LoadingPaperError(this, new EventArgs());
        //            if (InformatingEnd != null) InformatingEnd(this, new Templetes.IEventArgs.Message("页面数据为空！"));
        //        }
        //    }
        //    else
        //    {
        //        if (LoadingPaperError != null) LoadingPaperError(this, new EventArgs());
        //        if (InformatingEnd != null) InformatingEnd(this, new Templetes.IEventArgs.Message(e.Error.Message));
        //    }
        //    _isPaperReady = true;
        //}

        private void Fill_Paper_Up(DataProcessing.ExamHall.UserExam.UserPaper paperData)
        {
            stackPanel_container.Children.Clear();

            DataProcessing.ExamHall.UserExam.UserPaper.Element elm;
            SubjectUI newUI;
            for (int i = 0; i < paperData.elements.Count; i++)
            {
                elm = paperData.elements[i];
                newUI = new SubjectUI(myId
                    , 0
                    , elm.subject
                    , Class_SubjUIHelper.ShowType.SubjectWithUserAnswer
                    , elm.userData);
                stackPanel_container.Children.Add(newUI);
            }

        }
        private DataProcessing.ExamHall.UserExam.UserPaper _userPaper;
        public DataProcessing.ExamHall.UserExam.UserPaper userPaper
        {
            get
            {
                DataProcessing.ExamHall.UserExam.UserPaper result
                    = new DataProcessing.ExamHall.UserExam.UserPaper();
                SubjectUI subUI;
                for (int i = 0; i < _userPaper.elements.Count; i++)
                {
                    subUI = (SubjectUI)stackPanel_container.Children[i];
                    result.elements.Add(new DataProcessing.ExamHall.UserExam.UserPaper.Element(_userPaper.elements[i].subject, subUI.GetUserAnswer()));
                }
                _userPaper = result;
                return _userPaper;
            }
        }
        public void ClearPaper()
        {
            _anumName = null;
            stackPanel_container.Children.Clear();
        }
    }
}
