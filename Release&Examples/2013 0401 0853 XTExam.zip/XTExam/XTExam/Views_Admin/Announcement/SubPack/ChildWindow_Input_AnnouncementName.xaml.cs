﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.CodeSharing.Entities;
//using XTExam.ServiceReference_Announcements;

namespace XTExam.Views_Admin.Announcement.SubPack
{
    public partial class ChildWindow_Input_AnnouncementName : ChildWindow
    {
        private DataProcessing.UserRegister.UserInfo _myId;
        public ChildWindow_Input_AnnouncementName(DataProcessing.UserRegister.UserInfo myId)
        {
            InitializeComponent();
            _myId = myId;
            if (_myId == null || !_myId.hasId || !_myId.couldAdminAnnouncement)
            {
                this.IsEnabled = false;
                return;
            }
            //anumClient = new Service_AnnouncementsClient();
            //anumClient.Check_AnnouncementExistsCompleted += new EventHandler<Check_AnnouncementExistsCompletedEventArgs>(anumClient_Check_AnnouncementExistsCompleted);
            //anumClient.Create_AnnouncementCompleted += new EventHandler<System.ComponentModel.AsyncCompletedEventArgs>(anumClient_Create_AnnouncementCompleted);
        }



        //Service_AnnouncementsClient anumClient;
        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            //infoPanel.ShowInfo("正在验证公告名称……", true);
            //anumClient.Check_AnnouncementExistsAsync(_myId.id, textBox.Text);
            //OKButton.IsEnabled = false;
        }
        //void anumClient_Check_AnnouncementExistsCompleted(object sender, Check_AnnouncementExistsCompletedEventArgs e)
        //{
        //    if (e.Error == null)
        //    {
        //        if (!e.Result)
        //        {
        //            // create new anum
        //            anumClient.Create_AnnouncementAsync(_myId.id, textBox.Text);
        //        }
        //        else
        //        {
        //            infoPanel.ShowInfo("这个公告名称已经存在！",false);
        //        }
        //    }
        //    else
        //    {
        //        infoPanel.ShowInfo(e.Error);
        //    }
        //}
        //void anumClient_Create_AnnouncementCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        //{
        //    if (e.Error == null)
        //    {
        //        this.DialogResult = true;
        //    }
        //    else
        //    {
        //        infoPanel.ShowInfo(e.Error);
        //    }
        //}

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}

