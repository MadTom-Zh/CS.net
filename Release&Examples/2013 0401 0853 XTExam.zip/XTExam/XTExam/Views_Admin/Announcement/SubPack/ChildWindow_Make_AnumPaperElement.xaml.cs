﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.CodeSharing.Entities;

namespace XTExam.Views_Admin.Announcement.SubPack
{
    public partial class ChildWindow_Make_AnumPaperElement : ChildWindow
    {
        private DataProcessing.UserRegister.UserInfo _myId;
        public DataProcessing.UserRegister.UserInfo myId
        {
            set
            {
                _myId = value;
                if ((_myId == null || !_myId.hasId)
                    || (!_myId.couldAdminAnnouncement && !_myId.couldMakePaper))
                {
                    panel_SubjectEditor.IsEnabled = false;
                    return;
                }
                panel_SubjectEditor.myId = _myId;
            }
            get { return _myId; }
        }
        public ChildWindow_Make_AnumPaperElement()
        {
            InitializeComponent();
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            string selectedTabName = ((TabItem)tabControl.SelectedItem).Name;
            selectedTabName = selectedTabName.ToLower();
            if (selectedTabName.Contains("text"))
            {
                _subjectData = panel_CaptionEditor.captionData;
                this.DialogResult = true;
            }
            else if (selectedTabName.Contains("subject"))
            {
                _subjectData = panel_SubjectEditor.subjectData;
                this.DialogResult = true;
            }
            else
            {
                // do nothing
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private void ChildWindow_Loaded(object sender, RoutedEventArgs e)
        {
            panel_SubjectEditor.SubjectData_Generated += new EventHandler<CodeSharing.Entities.Templetes.IEventArgs.Subject>(panel_SubjectEditor_SubjectData_Generated);
        }
        private DataProcessing.Depot.Subject _subjectData;
        public DataProcessing.Depot.Subject subjectData
        {
            get { return _subjectData; }
        }
        void panel_SubjectEditor_SubjectData_Generated(object sender, CodeSharing.Entities.Templetes.IEventArgs.Subject e)
        {
            OKButton_Click(OKButton, new RoutedEventArgs());
        }
    }
}

