﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;

using XTExam.CodeSharing.Entities;
using XTExam.Controls;
//using XTExam.ServiceReference_Announcements;
using XTExam.Views_Admin.Announcement.SubPack;

namespace XTExam.Views_Admin.Announcement
{
    public partial class Admin_Announcement : Page
    {
        private DataProcessing.UserRegister.UserInfo _myId;
        public DataProcessing.UserRegister.UserInfo myId
        {
            set
            {
                _myId = value;
                if (_myId == null || !_myId.hasId || !_myId.couldAdminAnnouncement)
                {
                    this.IsEnabled = false;
                }
            }
        }
        public Admin_Announcement(DataProcessing.UserRegister.UserInfo myId)
        {
            InitializeComponent();
            this.myId = myId;
        }

        // 当用户导航到此页面时执行。
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            dataGrid_Announcements.SelectionChanged += new EventHandler<SelectionChangedEventArgs>(dataGrid_Announcements_SelectionChanged);

            dataGrid_Announcements.myUserMode = Controls.DataGrid_Announcements.UserMode.Administrator;
            dataGrid_Announcements.myId = _myId;
        }

        void dataGrid_Announcements_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //throw new NotImplementedException();
            object tmp = e.AddedItems;

            // if nothing selected, deleteBtn disabled
            foreach (DataGrid_Announcements_DG_DataTemplete.DataGrid_Announcements_Binding row in e.AddedItems)
            {
                foreach (DataProcessing.Announcement.Info info in dataGrid_Announcements.data)
                {
                    if (row.name == info.name)
                    {
                        if (info.isPublished && !info.isDated)
                        {
                            button_anumDelete.IsEnabled = false;
                            return;
                        }
                        break;
                    }
                }
            }
            button_anumDelete.IsEnabled = (e.AddedItems.Count > 0);
            //Reload_SubTabContent();
        }

        SubPack.ChildWindow_Input_AnnouncementName newAnumWin;
        private void button_create_Click(object sender, RoutedEventArgs e)
        {
            newAnumWin = new SubPack.ChildWindow_Input_AnnouncementName(_myId);
            newAnumWin.Closed += new EventHandler(newAnumWin_Closed);
            newAnumWin.Show();
        }
        void newAnumWin_Closed(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            if (newAnumWin.DialogResult == true)
            {
                dataGrid_Announcements.Refresh();
            }
        }

        private void button_delete_Click(object sender, RoutedEventArgs e)
        {

        }

        private Selected_SubTab _selected_tabControlPage = Selected_SubTab.BaseInfo;
        private enum Selected_SubTab
        {
            BaseInfo,
            Invatations,
            Content,
            Publish,
        }

        //private Service_AnnouncementsClient anumClient;
        private void tabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // don't worry, just one and only one tab could be selected
            string selectedTabName = ((TabItem)e.AddedItems[0]).Name;
            selectedTabName = selectedTabName.ToLower();

            if (selectedTabName.Contains("baseinfo")) _selected_tabControlPage = Selected_SubTab.BaseInfo;
            else if (selectedTabName.Contains("invatations")) _selected_tabControlPage = Selected_SubTab.Invatations;
            else if (selectedTabName.Contains("content")) _selected_tabControlPage = Selected_SubTab.Content;
            else if (selectedTabName.Contains("publish")) _selected_tabControlPage = Selected_SubTab.Publish;

            //Reload_SubTabContent();
        }
        //private void Reload_SubTabContent()
        //{
        //    if (anumClient == null)
        //    {
        //        anumClient = new Service_AnnouncementsClient();
        //        anumClient.Load_InvitationListCompleted += new EventHandler<Load_InvitationListCompletedEventArgs>(anumClient_Load_InvitationListCompleted);
        //        anumClient.Load_ContentCompleted += new EventHandler<Load_ContentCompletedEventArgs>(anumClient_Load_ContentCompleted);
        //        anumClient.Save_ContentCompleted += new EventHandler<System.ComponentModel.AsyncCompletedEventArgs>(anumClient_Save_ContentCompleted);
        //        anumClient.PublishCompleted += new EventHandler<System.ComponentModel.AsyncCompletedEventArgs>(anumClient_PublishCompleted);
        //    }
        //    if (dataGrid_Announcements == null) return;
        //    switch (_selected_tabControlPage)
        //    {
        //        case Selected_SubTab.BaseInfo:
        //            if (dataGrid_Announcements.Selection.Count <= 0)
        //            {
        //                textBox_publicAt.Text = "";
        //                textBox_name.Text = "";
        //                textBox_createBy.Text = "";
        //                textBox_createAt.Text = "";
        //                textBox_modifyBy.Text = "";
        //                textBox_modifyAt.Text = "";
        //            }
        //            else
        //            {
        //                DataGrid_Announcements_DG_DataTemplete.DataGrid_Announcements_Binding slt
        //                    = dataGrid_Announcements.Selection[0];
        //                textBox_publicAt.Text = slt.baseInfo.isPublished ? slt.publicTime : "";
        //                textBox_name.Text = slt.name;
        //                textBox_createBy.Text = slt.creator;
        //                textBox_createAt.Text = slt.createTime;
        //                textBox_modifyBy.Text = slt.modifier;
        //                textBox_modifyAt.Text = slt.modifyTime;
        //            }
        //            break;
        //        case Selected_SubTab.Invatations:
        //            if (dataGrid_Announcements.Selection.Count <= 0)
        //            {
        //                // clear invitations infoPanel
        //                dataGrid_invitationList.ItemsSource = null;
        //            }
        //            else
        //            {
        //                infoPanel.ShowInfo("正在获取邀请人员清单……", true);
        //                anumClient.Load_InvitationListAsync(dataGrid_Announcements.Selection[0].name);
        //            }
        //            break;
        //        case Selected_SubTab.Content:
        //            if (dataGrid_Announcements.Selection.Count <= 0)
        //            {
        //                listBox_anumContent.Items.Clear();
        //                grid_anumContent.Visibility = System.Windows.Visibility.Collapsed;
        //            }
        //            else
        //            {
        //                grid_anumContent.Visibility = System.Windows.Visibility.Visible;
        //                infoPanel.ShowInfo("正在获取公告内容……", true);
        //                anumClient.Load_ContentAsync(dataGrid_Announcements.Selection[0].name);
        //            }
        //            break;
        //        case Selected_SubTab.Publish:
        //            if (dataGrid_Announcements.Selection.Count != 1)
        //            {
        //                button_publish.IsEnabled = false;
        //            }
        //            else
        //            {
        //                DataGrid_Announcements_DG_DataTemplete.DataGrid_Announcements_Binding slct = dataGrid_Announcements.Selection[0];
        //                button_publish.IsEnabled = !slct.baseInfo.isPublished;
        //            }
        //            break;
        //    }
        //}

        //private DataProcessing.Announcement.Content _anumContent;
        //void anumClient_Load_ContentCompleted(object sender, Load_ContentCompletedEventArgs e)
        //{
        //    if (e.Error == null)
        //    {
        //        if (e.Result != null)
        //        {
        //            _anumContent = new DataProcessing.Announcement.Content(e.Result);
        //            ReFill_listBox_anumContent(_anumContent);
        //            infoPanel.ShowInfo("公告内容读取完成", false);
        //        }
        //        else
        //        {
        //            infoPanel.ShowInfo("Load Result is Null!", false);
        //        }
        //    }
        //    else
        //    {
        //        infoPanel.ShowInfo(e.Error);
        //    }
        //}
        private void ReFill_listBox_anumContent(DataProcessing.Announcement.Content anumContent)
        {
            listBox_anumContent.Items.Clear();
            DataProcessing.Depot.Subject elm;
            for (int i = 0; i < anumContent.paperContent.Count; i++)
            {
                elm = anumContent.paperContent[i];
                listBox_anumContent.Items.Add(Templetes.UI.ListViewItem_Subject(elm.type, elm.subject));
            }
            ReSet_btns_anumContent();
        }
        private int Get_listBoxItemIndex_anumContent(object anumContentListBoxItem)
        {
            string sourceText = Get_listBoxItemLongStr_anumContent(anumContentListBoxItem);
            for (int i = listBox_anumContent.Items.Count - 1; i >= 0; i--)
            {
                if (sourceText == Get_listBoxItemLongStr_anumContent(listBox_anumContent.Items[i]))
                {
                    return i;
                }
            }
            return -1;
        }
        private string Get_listBoxItemLongStr_anumContent(object anumContentListBoxItem)
        {
            StackPanel item = (StackPanel)anumContentListBoxItem;
            TextBlock tBox = (TextBlock)item.Children[0];
            string result = tBox.Text + "\t";
            tBox = (TextBlock)item.Children[1];
            return result + tBox.Text;
        }

        private void listBox_anumContent_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ReSet_btns_anumContent();
        }
        private void ReSet_btns_anumContent()
        {
            if (listBox_anumContent.SelectedItems.Count <= 0)
            {
                button_anumContentDelete.IsEnabled = false;
                button_anumContentMoveUp.IsEnabled = false;
                button_anumContentMoveDown.IsEnabled = false;
            }
            else
            {
                button_anumContentDelete.IsEnabled = true;
                if (listBox_anumContent.SelectedItems.Count == 1)
                {
                    button_anumContentMoveUp.IsEnabled
                        = (Get_listBoxItemIndex_anumContent(listBox_anumContent.SelectedItems[0]) >= 0);
                    button_anumContentMoveDown.IsEnabled
                        = (Get_listBoxItemIndex_anumContent(listBox_anumContent.SelectedItems[0]) <= (listBox_anumContent.Items.Count - 1));
                }
                else
                {
                    button_anumContentMoveUp.IsEnabled = false;
                    button_anumContentMoveDown.IsEnabled = false;
                }
            }
        }

        private DataProcessing.Announcement.InvitedUserList _invitationList = new DataProcessing.Announcement.InvitedUserList();
        //void anumClient_Load_InvitationListCompleted(object sender, Load_InvitationListCompletedEventArgs e)
        //{
        //    // load invations, with [user id] and [vote states]
        //    if (e.Error == null)
        //    {
        //        if (e.Result != null)
        //        {
        //            _invitationList.IOContent = e.Result;
        //            List<Class_DataTempletes.IDataGrid.DataTemplete_voted_userId_userName_orgPath> dgData
        //                = new List<Class_DataTempletes.IDataGrid.DataTemplete_voted_userId_userName_orgPath>();
        //            foreach (DataProcessing.Announcement.InvitedUserList.Invitation ivt in _invitationList.data)
        //            {
        //                dgData.Add(new Class_DataTempletes.IDataGrid.DataTemplete_voted_userId_userName_orgPath(ivt));
        //            }
        //            dataGrid_invitationList.ItemsSource = dgData;
        //            infoPanel.ShowInfo("就绪", false);
        //        }
        //        else
        //        {
        //            _invitationList = new DataProcessing.Announcement.InvitedUserList();
        //            infoPanel.ShowInfo("邀请人员清单数据为空！", false);
        //        }
        //    }
        //    else
        //    {
        //        infoPanel.ShowInfo(e.Error);
        //    }
        //}


        private void button_inviteListAdd_Click(object sender, RoutedEventArgs e)
        {

        }

        private void button_inviteListDelete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void button_inviteListUpdate_Click(object sender, RoutedEventArgs e)
        {

        }









        #region

        private ChildWindow_Make_AnumPaperElement makeAnumPaperElementWin = null;
        private void button_anumContentAdd_Click(object sender, RoutedEventArgs e)
        {
            if (makeAnumPaperElementWin == null)
            {
                makeAnumPaperElementWin = new ChildWindow_Make_AnumPaperElement();
                makeAnumPaperElementWin.myId = _myId;
                makeAnumPaperElementWin.Closed += new EventHandler(makeAnumPaperElement_Closed);
            }
            makeAnumPaperElementWin.Show();
        }
        void makeAnumPaperElement_Closed(object sender, EventArgs e)
        {
            //if (makeAnumPaperElementWin.DialogResult == true)
            //{
            //    _anumContent.Add_Content(makeAnumPaperElementWin.subjectData);
            //    ReFill_listBox_anumContent(_anumContent);
            //}
        }

        private void button_anumContentDelete_Click(object sender, RoutedEventArgs e)
        {
            //int curItemIndex = Get_listBoxItemIndex_anumContent(listBox_anumContent.SelectedItems[0]);
            //_anumContent.paperContent.RemoveAt(curItemIndex);
            //listBox_anumContent.Items.RemoveAt(curItemIndex);
            //ReSet_btns_anumContent();
        }
        private void button_anumContentMoveUp_Click(object sender, RoutedEventArgs e)
        {
            //int curItemIndex = Get_listBoxItemIndex_anumContent(listBox_anumContent.SelectedItems[0]);
            //DataProcessing.Depot.Subject elm = _anumContent.paperContent[curItemIndex];
            //_anumContent.paperContent.RemoveAt(curItemIndex);
            //_anumContent.paperContent.Insert(curItemIndex - 1, elm);

            //object lbItem = listBox_anumContent.Items[curItemIndex];
            //listBox_anumContent.Items.RemoveAt(curItemIndex);
            //listBox_anumContent.Items.Insert(curItemIndex - 1, lbItem);
            //listBox_anumContent.SelectedItem = lbItem;
            //ReSet_btns_anumContent();
        }
        private void button_anumContentMoveDown_Click(object sender, RoutedEventArgs e)
        {
            //int curItemIndex = Get_listBoxItemIndex_anumContent(listBox_anumContent.SelectedItems[0]);
            //DataProcessing.Depot.Subject elm = _anumContent.paperContent[curItemIndex];
            //_anumContent.paperContent.RemoveAt(curItemIndex);
            //bool appendMod = (curItemIndex == (_anumContent.paperContent.Count - 1));
            //if (appendMod)
            //{
            //    _anumContent.paperContent.Add(elm);
            //}
            //else
            //{
            //    _anumContent.paperContent.Insert(curItemIndex + 1, elm);
            //}

            //object lbItem = listBox_anumContent.Items[curItemIndex];
            //listBox_anumContent.Items.RemoveAt(curItemIndex);
            //if (appendMod)
            //{
            //    listBox_anumContent.Items.Add(lbItem);
            //}
            //else
            //{
            //    listBox_anumContent.Items.Insert(curItemIndex + 1, lbItem);
            //}
            //listBox_anumContent.SelectedItem = lbItem;
            //ReSet_btns_anumContent();
        }

        private void button_anumContentUpdate_Click(object sender, RoutedEventArgs e)
        {
            //infoPanel.ShowInfo("正在更新公告页面……", true);
            //anumClient.Save_ContentAsync(_myId.id, dataGrid_Announcements.Selection[0].name, _anumContent.IOContent);
        }
        void anumClient_Save_ContentCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                infoPanel.ShowInfo("公告页面更新完成", false);
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }


        #endregion

        private void button_publish_Click(object sender, RoutedEventArgs e)
        {
            //infoPanel.ShowInfo("正在发布公告……", true);
            //DataGrid_Announcements_DG_DataTemplete.DataGrid_Announcements_Binding slct = dataGrid_Announcements.Selection[0];
            //anumClient.PublishAsync(_myId.id, slct.name);
        }
        void anumClient_PublishCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                dataGrid_Announcements.Refresh();
                infoPanel.ShowInfo("公告发布完成！", false);
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }

        private void button_anumContentView_Click(object sender, RoutedEventArgs e)
        {

        }







    }
}
