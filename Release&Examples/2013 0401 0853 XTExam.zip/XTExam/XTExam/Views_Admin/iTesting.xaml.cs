﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;

using System.IO;
using System.IO.IsolatedStorage;

namespace XTExam.Views_Admin
{
    public partial class iTesting : Page
    {
        public iTesting()
        {
            InitializeComponent();
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {


            WebClient client = new WebClient();
            Uri uri = new Uri("/Response/Testing.aspx", UriKind.Relative);
            //object token = new object();
            //token.data1 = "data1";
            client.DownloadStringCompleted += new DownloadStringCompletedEventHandler(client_DownloadStringCompleted);
            client.DownloadStringAsync(uri);


        }

        void client_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error != null)
            {
                textBox1.Text = e.Error.ToString();
            }
            else textBox1.Text = e.Result;
        }

        public interface ISendNodifacations
        {

        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {



            //string storPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            //StreamWriter sw = File.AppendText(storPath + "\\a.txt");
            //sw.WriteLine(textBox1.Text);
            //sw.Flush();
            //sw.Close();
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            WebClient wClient = new WebClient();
            Uri rui = new Uri("/Response/Testing.aspx", UriKind.Relative);

            wClient.UploadStringCompleted += new UploadStringCompletedEventHandler(wClient_UploadStringCompleted);
            wClient.UploadStringAsync(rui, textBox1.Text);
        }

        void wClient_UploadStringCompleted(object sender, UploadStringCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                MessageBox.Show("OK!");
            }
            else
            {
                MessageBox.Show("Failed!\r\n" + e.Error.ToString());
            }
        }

        private void button4_Click(object sender, RoutedEventArgs e)
        {
            // test
            //IsolatedStorageFile isFile = IsolatedStorageFile.GetUserStoreForSite();
            //StreamWriter sw = new StreamWriter(isFile.CreateFile("a.txt"));
            //sw.WriteLine("this is a test");
            //sw.Flush();
            //sw.Close();



            //client.
            //ServiceReference1.IService1Channel channel = client.cr
        }



    }
}
