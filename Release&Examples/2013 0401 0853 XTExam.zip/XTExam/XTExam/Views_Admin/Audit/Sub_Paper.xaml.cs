﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using System.Windows.Browser;
using XTExam.ServiceReference_HallExam;
using XTExam.Views_Admin.Audit.controls;
using XTExam.ServiceReference_Auditing;
using System.Collections.ObjectModel;
using XTExam.CodeSharing.Entities;

namespace XTExam.Views_Admin.Audit
{
    public partial class Sub_Paper : UserControl
    {
        public DataProcessing.UserRegister.UserInfo myId { set; get; }
        string examerPath;
        public Sub_Paper(DataProcessing.UserRegister.UserInfo myID, string examerPath)
        {
            this.myId = myID;
            this.examerPath = examerPath;
            InitializeComponent();
            string[] parts = examerPath.Split(new string[] { "\\" }, StringSplitOptions.RemoveEmptyEntries);
            textBox_hallName.Text = parts[0];
            textBox_examerName.Text = HttpUtility.UrlDecode(parts[1]);
        }
        Service_HallExamClient serviceClient_Exam;
        Service_AuditingClient serviceClient_Audit;
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            if (myId == null || !myId.hasId)
            {
                this.IsEnabled = false;
                return;
            }
            infoPanel.ProcessingStart += new EventHandler(infoPanel_ProcessingStart);
            infoPanel.ProcessingComplete += new EventHandler(infoPanel_ProcessingComplete);

            serviceClient_Audit = new Service_AuditingClient();
            serviceClient_Audit.AuditingSetCompleted += new EventHandler<System.ComponentModel.AsyncCompletedEventArgs>(serviceClient_Audit_AuditingSetCompleted);
            //serviceClient_Audit.AuditingDropCompleted += new EventHandler<System.ComponentModel.AsyncCompletedEventArgs>(serviceClient_Audit_AuditingDropCompleted);
            serviceClient_Audit.AuditingSetCompleteCompleted += new EventHandler<System.ComponentModel.AsyncCompletedEventArgs>(serviceClient_Audit_AuditingSetCompleteCompleted);

            serviceClient_Exam = new Service_HallExamClient();
            serviceClient_Exam.GetUserPaper_IOContentCompleted += new EventHandler<GetUserPaper_IOContentCompletedEventArgs>(serviceClient_Exam_GetUserPaper_IOContentCompleted);
            serviceClient_Exam.SaveUserPaperDataCompleted += new EventHandler<System.ComponentModel.AsyncCompletedEventArgs>(serviceClient_Exam_SaveUserPaperDataCompleted);

            infoPanel.ShowInfo("正在读取试卷……", true);
            serviceClient_Exam.GetUserPaper_IOContentAsync(textBox_hallName.Text, textBox_examerName.Text, myId.id);
        }


        void infoPanel_ProcessingComplete(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            this.Cursor = Cursors.Arrow;
        }
        void infoPanel_ProcessingStart(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            this.Cursor = Cursors.Wait;
            UpdateLayout();
        }

        DataProcessing.ExamHall.UserExam.UserPaper paper;
        List<AuditElementLine> paperElmsUIList;
        void serviceClient_Exam_GetUserPaper_IOContentCompleted(object sender, GetUserPaper_IOContentCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result != null)
                {
                    infoPanel.ShowInfo("已获取试卷，正在准备批阅……", true);
                    paper = new DataProcessing.ExamHall.UserExam.UserPaper();
                    paper.IOContent = e.Result;
                    paperElmsUIList = new List<AuditElementLine>();
                    ReFillUI();
                }
                else
                {
                    infoPanel.ShowInfo("未能获取试卷，请稍候再试", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }

        private void ReFillUI()
        {
            stackPanel_paperElements.Children.Clear();
            //PaperHelper paper;
            //List<AuditElementLine> paperElmsUIList;
            AuditElementLine newAElm;
            DataProcessing.ExamHall.UserExam.UserPaper.Element elm;
            int subNo = 1;
            for (int i = 0; i < paper.elements.Count; i++)
            {
                elm = paper.elements[i];
                if (elm.subject.type == DataProcessing.Depot.Subject.Type.Caption) subNo = 0;
                newAElm = new AuditElementLine(myId, elm, subNo);
                stackPanel_paperElements.Children.Add(newAElm);
                paperElmsUIList.Add(newAElm);
                subNo++;
            }
            infoPanel.ShowInfo("正在标记您的批卷状态，请稍候……", true);
            serviceClient_Audit.AuditingSetAsync(myId.id, examerPath);
        }
        void serviceClient_Audit_AuditingSetCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                infoPanel.ShowInfo("标记完成", false);
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }


        private void button_save_Click(object sender, RoutedEventArgs e)
        {
            infoPanel.ShowInfo("正在保存批阅……", true);
            ObservableCollection<string> userDataLines = new ObservableCollection<string>();
            for (int i = 0; i < paperElmsUIList.Count; i++)
            {
                userDataLines.Add(paperElmsUIList[i].GetUserData_WithGradeAndRemark().IOContent);
            }
            serviceClient_Exam.SaveUserPaperDataAsync(userDataLines, textBox_hallName.Text, textBox_examerName.Text, myId.id);
        }
        void serviceClient_Exam_SaveUserPaperDataCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                infoPanel.ShowInfo("保存完成！", false);
                if (isToFinish)
                {
                    infoPanel.ShowInfo("正在完成批阅……", true);
                    serviceClient_Audit.AuditingSetCompleteAsync(myId.id, examerPath);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
            isToFinish = false;
        }
        void serviceClient_Audit_AuditingSetCompleteCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                button_finish.IsEnabled = false;
                button_save.IsEnabled = false;
                infoPanel.ShowInfo("批卷完成，请您返回待批列表",false);
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }


        bool isToFinish = false;
        private void button_finish_Click(object sender, RoutedEventArgs e)
        {
            isToFinish = true;
            button_save_Click(sender, e);
        }
        //void serviceClient_Audit_AuditingDropCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        //{
        //    //throw new NotImplementedException();
        //    if (e.Error == null)
        //    {
        //        infoPanel.ShowInfo("标记完成", false);
        //    }
        //    else
        //    {
        //        infoPanel.ShowInfo(e.Error);
        //    }
        //}
    }
}
