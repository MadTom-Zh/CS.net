﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;

using XTExam.ServiceReference_Auditing;
using System.Collections.ObjectModel;
using XTExam.Views_Admin.Audit.controls;
using XTExam.CodeSharing.Entities;

namespace XTExam.Views_Admin.Audit
{
    public partial class Sub_Entry : Page
    {
        public DataProcessing.UserRegister.UserInfo myId { set; get; }
        public Sub_Entry(DataProcessing.UserRegister.UserInfo myId)
        {
            this.myId = myId;
            InitializeComponent();
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        Service_AuditingClient serviceClient;
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (myId == null || !myId.hasId)
            {
                this.IsEnabled = false;
                return;
            }
            infoPanel.ProcessingStart += new EventHandler(infoPanel_ProcessingStart);
            infoPanel.ProcessingComplete += new EventHandler(infoPanel_ProcessingComplete);

            serviceClient = new Service_AuditingClient();
            serviceClient.GetMyExamerListCompleted += new EventHandler<GetMyExamerListCompletedEventArgs>(serviceClient_GetMyExamerListCompleted);
            serviceClient.GetMyAuditingExamerListCompleted += new EventHandler<GetMyAuditingExamerListCompletedEventArgs>(serviceClient_GetMyAuditingExamerListCompleted);

            infoPanel.ShowInfo("正在获取我的待批列表……", true);
            serviceClient.GetMyExamerListAsync(myId.id);
        }
        void infoPanel_ProcessingComplete(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            this.Cursor = Cursors.Arrow;
        }
        void infoPanel_ProcessingStart(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            this.Cursor = Cursors.Wait;
        }

        ObservableCollection<string> myExamerListLines;
        void serviceClient_GetMyExamerListCompleted(object sender, GetMyExamerListCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result != null)
                {
                    myExamerListLines = e.Result;
                    infoPanel.ShowInfo("正在获取我的批阅（批阅中）列表……", true);
                    serviceClient.GetMyAuditingExamerListAsync(myId.id);
                }
                else
                {
                    infoPanel.ShowInfo("未能获取试卷列表", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }
        ObservableCollection<string> myAuditingExamerListLines;
        void serviceClient_GetMyAuditingExamerListCompleted(object sender, GetMyAuditingExamerListCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result != null)
                {
                    myAuditingExamerListLines = e.Result;
                    infoPanel.ShowInfo("获取完成，正在填充界面……", true);
                    FillData2UI();
                }
                else
                {
                    infoPanel.ShowInfo("获取试卷（批阅中）列表时出错，请重新进入此页", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }

        private void FillData2UI()
        {
            stackPanel_Auditing.Children.Clear();
            stackPanel_Waiting.Children.Clear();
            EntryLine item;
            foreach (string auditingLine in myAuditingExamerListLines)
            {
                item = new EntryLine(auditingLine);
                item.BtnClicked += new EventHandler(item_BtnClicked);
                stackPanel_Auditing.Children.Add(item);
            }
            bool atingFound;
            foreach (string line in myExamerListLines)
            {
                atingFound = false;
                foreach (string ating in myAuditingExamerListLines)
                {
                    if (ating == line)
                    {
                        atingFound = true;
                        break;
                    }
                }
                if (!atingFound)
                {
                    item = new EntryLine(line);
                    item.BtnClicked += new EventHandler(item_BtnClicked);
                    stackPanel_Waiting.Children.Add(item);
                }
            }
            infoPanel.ShowInfo("就绪", false);
        }
        public event EventHandler CallAuditPaper;
        void item_BtnClicked(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            if (CallAuditPaper != null) CallAuditPaper(sender, e);
        }
    }
}
