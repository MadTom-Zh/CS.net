﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace XTExam.Views_Admin.Audit.controls
{
    public partial class EntryLine : UserControl
    {
        private string examerPath;
        public EntryLine(string examerPath)
        {
            this.examerPath = examerPath;
            InitializeComponent();
            string[] parts = examerPath.Split(new string[] { "\\" }, StringSplitOptions.RemoveEmptyEntries);
            textBlock_hallName.Text = parts[0];
            textBlock_examerName.Text = parts[1];
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
        }

        public event EventHandler BtnClicked;
        private void button_Click(object sender, RoutedEventArgs e)
        {
            if (BtnClicked != null) BtnClicked(examerPath, new EventArgs());
        }
    }
}
