﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.Controls;
using XTExam.CodeSharing.Entities;

namespace XTExam.Views_Admin.Audit.controls
{
    public partial class AuditElementLine : UserControl
    {
        public DataProcessing.UserRegister.UserInfo myId
        {
            set;
            get;
        }
        int NO;
        DataProcessing.ExamHall.UserExam.UserPaper.Element paperElement;
        public AuditElementLine(DataProcessing.UserRegister.UserInfo myID, DataProcessing.ExamHall.UserExam.UserPaper.Element paperElement, int NO)
        {
            this.myId = myID;
            this.NO = NO;
            this.paperElement = paperElement;
            InitializeComponent();
        }

        SubjectUI subjUI;
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            if (myId == null || !myId.hasId)
            {
                this.IsEnabled = false;
                return;
            }
            subjUI = new SubjectUI(myId, NO, paperElement.subject, Class_SubjUIHelper.ShowType.SubjectWithUserAnswerAndRemark, paperElement.userData);
            LayoutRoot.Children.Add(subjUI);
            if (paperElement.subject.type  == DataProcessing.Depot.Subject.Type.Caption)
            {
                LayoutRoot.ColumnDefinitions[1].Width = new GridLength(0);
            }
            slider_grade.Maximum = paperElement.subject.grades;
            slider_grade.Value = paperElement.userData.grade;
            SetSliderValue2Text();
            textBox_remark.Text = paperElement.userData.singleRemark;
        }

        private void slider_grade_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            SetSliderValue2Text();
        }
        private void SetSliderValue2Text()
        {
            textBox_grade.Text = slider_grade.Value.ToString("#0.00");
        }

        public DataProcessing.ExamHall.UserExam.UserPaper.Element.UserData GetUserData_WithGradeAndRemark()
        {
            paperElement.userData.grade = slider_grade.Value;
            paperElement.userData.singleRemark = textBox_remark.Text;
            return paperElement.userData;
        }
    }
}
