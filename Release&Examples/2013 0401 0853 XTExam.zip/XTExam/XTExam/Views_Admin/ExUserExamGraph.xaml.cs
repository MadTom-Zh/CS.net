﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.CodeSharing.Entities;
using System.Windows.Threading;

namespace XTExam.Views_Admin
{
    public partial class ExUserExamGraph : UserControl
    {
        public ExUserExamGraph()
        {
            InitializeComponent();
        }

        XTExam.ServiceReference_Result.Service_ResultClient resultServiceClient;
        DispatcherTimer uiTimer;
        private void LayoutRoot_Loaded(object sender, RoutedEventArgs e)
        {
            HideGraphTempls();
            //label_graphTime.Content = "图表计算时间：2013-??-?? ??:??:??";

            if (resultServiceClient == null)
            {
                resultServiceClient = new ServiceReference_Result.Service_ResultClient();
                resultServiceClient.CheckGraphDataStatus_Ex2013Completed += resultServiceClient_CheckGraphDataStatus_Ex2013Completed;

                resultServiceClient.ReGatherAllCompleted += resultServiceClient_ReGatherAllCompleted;

                resultServiceClient.GetGraphData_Ex2013Completed += resultServiceClient_GetGraphData_Ex2013Completed;
                resultServiceClient.GetGraphInfo_Ex2013Completed += resultServiceClient_GetGraphInfo_Ex2013Completed;

            }
            infoPanel.ShowInfo("正在获取图形数据状态...", true);
            resultServiceClient.CheckGraphDataStatus_Ex2013Async();

            GraphDataReady += ExUserExamGraph_GraphDataReady;

            if (uiTimer == null)
            {
                uiTimer = new DispatcherTimer()
                {
                    Interval = new TimeSpan(0, 0, 0, 0, 120),

                };
                uiTimer.Tick += uiTimer_Tick;
                uiTimer.Start();
            }

            // 检查是否需要重新统计

            // 不需要则直接加载数据

            // 如果需要，则等待加载数据，并提示如果失败，请重新刷新本页
        }



        string loadingErrorInfo = "数据加载失败，请稍后再试。";
        void resultServiceClient_CheckGraphDataStatus_Ex2013Completed(object sender, ServiceReference_Result.CheckGraphDataStatus_Ex2013CompletedEventArgs e)
        {
            if (e.Error == null)
            {
                MessageBoxResult userFeedBack;
                if (e.Result == 0)
                {
                    userFeedBack = MessageBox.Show("系统无图形数据，是否立即收集？", "收集图形数据", MessageBoxButton.OKCancel);
                    if (userFeedBack == MessageBoxResult.OK)
                    {
                        infoPanel.ShowInfo("正在执行图形数据收集...", true);
                        resultServiceClient.ReGatherAllAsync();
                    }
                }
                else if (e.Result == 1)
                {
                    infoPanel.ShowInfo("正在读取图形数据...", true);
                    resultServiceClient.GetGraphData_Ex2013Async();
                }
                else if (e.Result == 2)
                {
                    userFeedBack = MessageBox.Show("数据过期，目前不能执行重新收集，是否显示上次数据？", "非服务器空闲时间", MessageBoxButton.OKCancel);
                    if (userFeedBack == MessageBoxResult.OK)
                    {
                        infoPanel.ShowInfo("正在执行图形数据收集...", true);
                        resultServiceClient.GetGraphData_Ex2013Async();
                    }
                }
                else if (e.Result == 3)
                {
                    userFeedBack = MessageBox.Show("数据过期，是否立即收集？", "收集图形数据", MessageBoxButton.OKCancel);
                    if (userFeedBack == MessageBoxResult.OK)
                    {
                        infoPanel.ShowInfo("正在执行图形数据收集...", true);
                        resultServiceClient.ReGatherAllAsync();
                    }
                    else
                    {
                        infoPanel.ShowInfo("正在执行图形数据收集...", true);
                        resultServiceClient.GetGraphData_Ex2013Async();
                    }
                }
                else if (e.Result == 4)
                {
                    MessageBox.Show("抱歉，目前无法执行任何操作！", "非服务器空闲时间", MessageBoxButton.OKCancel);
                }
                return;
            }
            infoPanel.ShowInfo(loadingErrorInfo, false);
        }



        void resultServiceClient_ReGatherAllCompleted(object sender, ServiceReference_Result.ReGatherAllCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                if (e.Result == true)
                {
                    infoPanel.ShowInfo("正在读取图形数据...", true);
                    resultServiceClient.GetGraphData_Ex2013Async();
                    return;
                }
            }
            infoPanel.ShowInfo(loadingErrorInfo, false);
        }


        public DataProcessing.Results.GraphData_Ex2013 graphData;
        public event EventHandler GraphDataReady;

        void resultServiceClient_GetGraphData_Ex2013Completed(object sender, ServiceReference_Result.GetGraphData_Ex2013CompletedEventArgs e)
        {
            if (e.Error == null)
            {
                graphData = new DataProcessing.Results.GraphData_Ex2013(e.Result);
                if (GraphDataReady != null)
                {
                    GraphDataReady(this, new EventArgs());
                }
                return;
            }
            infoPanel.ShowInfo(loadingErrorInfo, false);
        }
        void resultServiceClient_GetGraphInfo_Ex2013Completed(object sender, ServiceReference_Result.GetGraphInfo_Ex2013CompletedEventArgs e)
        {
            if (e.Error == null)
            {
                label_graphTime.Content = "图表计算时间：" + e.Result;
                infoPanel.ShowInfo("绘图完成！", false);
                return;
            }
            infoPanel.ShowInfo("未能获取图形时间信息！", false);
        }


        private void HideGraphTempls()
        {
            rectangle_tmpl.Visibility = System.Windows.Visibility.Collapsed;
            rectangle_barGreen.Visibility = System.Windows.Visibility.Collapsed;
            rectangle_barRed.Visibility = System.Windows.Visibility.Collapsed;
            label_organiName.Visibility = System.Windows.Visibility.Collapsed;
        }
        private void Ting()
        {
            // resize the grid, so it can reDraw
            gridGraph.Margin = new Thickness(25, gridGraph.Margin.Top, 26, gridGraph.Margin.Bottom);
            gridGraph.Margin = new Thickness(gridGraph.Margin.Right, gridGraph.Margin.Top, gridGraph.Margin.Right, gridGraph.Margin.Bottom);
        }

        private void gridGraph_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            _gridSize = e.NewSize;
            if (isGraphDataReady == true)
            {
                curDrawAction = DrawActions.PaperSizeChanged;
            }
        }


        private bool isGraphDataReady = false;
        void ExUserExamGraph_GraphDataReady(object sender, EventArgs e)
        {
            isGraphDataReady = true;
            curDrawAction = DrawActions.DrawStart;
        }

        //private bool isDrawing = false;
        //private bool isReDrawNeeded = false;

        public enum DrawActions
        {
            Ready = 0,
            DrawStart = 1,
            Drawing = 2,
            PaperSizeChanged = 3,
            DrawStoped = 4,
            DrawComplete = 5,
        }
        private DrawActions curDrawAction = DrawActions.Ready;

        #region 绘图使用数据、方法
        private Size _gridSize = new Size(0, 0); // 图纸尺寸
        private Point oPoint = new Point(0, 0); // Y轴上面的定点，依次作为原点

        private double gapLeft = 20;
        private double gapVMid = 7;
        private double gapRight = 20;
        private double gapTop = 20;
        private double gapHMid = 3;
        private double gapButtom = 40;

        private double hightLabel = 17;
        private double hightYAxis = 0;
        private double hightOrganiBlock = 0;

        private double widthLabelOrganiMax = 0;
        private double widthLabelSingleChar = 11.7;
        private double widthXAxis = 0;

        private double widthSingleStepValue = 0;

        private int coordiCountXAxis = 0;
        private int coordiCountYAxis = 0;

        private int counterXAxisCoordis;
        private int counterXAxisCoordis_dotLines;
        private int counterYAxisCoordis_lables;
        private int counterYAxisCoordis_bars_Green;
        private int counterYAxisCoordis_bars_Red;

        private void ReComputMapSizes()
        {
            hightYAxis = _gridSize.Height - (gapTop + gapHMid + hightLabel + gapButtom);
            hightOrganiBlock = hightYAxis / graphData.Items.Count;

            int countOrgChar = 0;
            foreach (DataProcessing.Results.GraphData_Ex2013.DataItem di in graphData.Items)
            {
                if (di.organi.Length > countOrgChar)
                {
                    countOrgChar = di.organi.Length;
                }
            }

            widthLabelOrganiMax = countOrgChar * widthLabelSingleChar;
            widthXAxis = _gridSize.Width - (gapLeft + gapVMid + gapRight + widthLabelOrganiMax);

            oPoint.X = gapLeft + gapVMid + widthLabelOrganiMax;
            oPoint.Y = gapTop;

            coordiCountXAxis = (int)widthXAxis / 100;
            counterXAxisCoordis = 0;
            counterXAxisCoordis_dotLines = 0;

            double tmpDouble;
            if (coordiCountXAxis <= 1) coordiCountXAxis = 2;
            tmpDouble = graphData.CountAll_Max / (coordiCountXAxis - 1);
            widthSingleStepValue = (int)(tmpDouble / 10 + 1) * 10;

            if ((widthSingleStepValue * coordiCountXAxis) > graphData.CountAll_Max)
            {
            }
            else
            {
                // 人数多，不够显示
                widthSingleStepValue += 10;
                while ((widthSingleStepValue * coordiCountXAxis) < graphData.CountAll_Max)
                {
                    widthSingleStepValue += 10;
                }
            }

            if ((widthSingleStepValue * coordiCountXAxis) > graphData.CountAll_Max)
            {
                // 人数坐标点 多， 总人数少
                coordiCountXAxis -= 1;
                while ((widthSingleStepValue * coordiCountXAxis) > graphData.CountAll_Max)
                {
                    coordiCountXAxis -= 1;
                }
                coordiCountXAxis += 1;
            }
            else
            {
            }

            coordiCountYAxis = graphData.Items.Count;

            counterYAxisCoordis_bars_Green
                = counterYAxisCoordis_bars_Red
                = counterYAxisCoordis_lables
                = 0;

        }

        List<Rectangle> graphRectangleList = new List<Rectangle>();
        List<Label> graphLabelList = new List<Label>();
        private void ClearPaper()
        {
            for (int i = graphRectangleList.Count - 1; i >= 0; i--)
            {
                gridGraph.Children.Remove(graphRectangleList[i]);
            }
            graphRectangleList.Clear();
            for (int i = graphLabelList.Count - 1; i >= 0; i--)
            {
                gridGraph.Children.Remove(graphLabelList[i]);
            }
            graphLabelList.Clear();
        }

        private Rectangle MakeRectangle_BlackFrame()
        {
            Rectangle result = new Rectangle();
            result.Stroke = rectangle_tmpl.Stroke;
            return result;
        }
        private Rectangle MakeRectangle_RedBar()
        {
            Rectangle result = new Rectangle();
            result.Stroke = rectangle_barRed.Stroke;
            result.Fill = rectangle_barRed.Fill;
            return result;
        }
        private Rectangle MakeRectangle_GreenBar()
        {
            Rectangle result = new Rectangle();
            result.Stroke = rectangle_barGreen.Stroke;
            result.Fill = rectangle_barGreen.Fill;
            return result;
        }

        private bool Redraw_OneStep()
        {
            if (graphRectangleList.Count == 0)
            {
                // 绘制X轴
                Rectangle line = MakeRectangle_BlackFrame();
                line.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
                line.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                line.Height = 1;
                line.Width = widthXAxis;
                line.Margin = new Thickness((gapLeft + widthLabelOrganiMax + gapVMid), (gapTop + hightYAxis), 0, 0);
                gridGraph.Children.Add(line);
                graphRectangleList.Add(line);
            }
            else if (graphRectangleList.Count == 1)
            {
                // 绘制Y轴
                Rectangle line = MakeRectangle_BlackFrame();
                line.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
                line.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                line.Height = hightYAxis;
                line.Width = 1;
                line.Margin = new Thickness((gapLeft + widthLabelOrganiMax + gapVMid), (gapTop), 0, 0);
                gridGraph.Children.Add(line);
                graphRectangleList.Add(line);
            }
            else
            {
                if (counterXAxisCoordis <= coordiCountXAxis - 1)
                {
                    // 绘制人数坐标点 和 文本

                    Rectangle line = MakeRectangle_BlackFrame();
                    line.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
                    line.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                    line.Height = 6;
                    line.Width = 1;
                    double xCoordi = gapLeft + widthLabelOrganiMax + gapVMid + (counterXAxisCoordis + 1) * (widthXAxis / coordiCountXAxis);
                    double yCoordi = gapTop + hightYAxis;
                    line.Margin = new Thickness(xCoordi, (yCoordi - 3), 0, 0);
                    gridGraph.Children.Add(line);
                    graphRectangleList.Add(line);

                    Label newLabel = new Label();
                    newLabel.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
                    newLabel.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                    newLabel.FontFamily = label_graphTime.FontFamily;
                    newLabel.FontSize = label_graphTime.FontSize;
                    newLabel.Foreground = label_graphTime.Foreground;
                    newLabel.Content = (widthSingleStepValue * (counterXAxisCoordis + 1)).ToString("###,###,###");
                    newLabel.Margin = new Thickness(xCoordi, (yCoordi + 3), 0, 0);
                    gridGraph.Children.Add(newLabel);
                    graphLabelList.Add(newLabel);

                    counterXAxisCoordis++;
                }
                else if (counterYAxisCoordis_lables < graphData.Items.Count)
                {
                    // 绘制组织名称文本
                    Label newLabel = new Label();
                    newLabel.HorizontalAlignment = System.Windows.HorizontalAlignment.Right;
                    newLabel.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                    newLabel.FontFamily = label_graphTime.FontFamily;
                    newLabel.FontSize = label_graphTime.FontSize;
                    newLabel.Foreground = label_graphTime.Foreground;
                    newLabel.Content = graphData.Items[counterYAxisCoordis_lables].organi;
                    double rightCoordi = gapRight + widthXAxis + gapVMid;
                    double tmpDouble = hightYAxis / graphData.Items.Count;
                    double topCoordi = gapTop + tmpDouble * counterYAxisCoordis_lables + tmpDouble * 0.5 - (hightLabel / 2);

                    newLabel.Margin = new Thickness(0, topCoordi, rightCoordi, 0);
                    gridGraph.Children.Add(newLabel);
                    graphLabelList.Add(newLabel);


                    counterYAxisCoordis_lables++;
                }
                else if (counterXAxisCoordis_dotLines < coordiCountXAxis)
                {
                    // 绘制人数虚线
                    Rectangle line = MakeRectangle_BlackFrame();
                    line.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
                    line.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                    line.Height = hightYAxis;
                    line.Width = 1;
                    line.Opacity = 0.4;
                    double xCoordi = gapLeft + widthLabelOrganiMax + gapVMid + (counterXAxisCoordis_dotLines + 1) * (widthXAxis / coordiCountXAxis);
                    double yCoordi = gapTop;
                    line.Margin = new Thickness(xCoordi, yCoordi, 0, 0);
                    gridGraph.Children.Add(line);
                    graphRectangleList.Add(line);


                    counterXAxisCoordis_dotLines++;
                }
                else if (counterYAxisCoordis_bars_Green < graphData.Items.Count)
                {
                    // 绘制全部人数条棒 - 绿色
                    Rectangle newRectan = MakeRectangle_GreenBar();
                    newRectan.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
                    newRectan.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                    newRectan.Height = hightOrganiBlock * 0.4;
                    newRectan.Width = (graphData.Items[counterYAxisCoordis_bars_Green].countAll / widthSingleStepValue) * (widthXAxis / coordiCountXAxis);
                    if (newRectan.Width > 1)
                    {
                        newRectan.Width -= 1;
                    }
                    double xCoordi = gapLeft + widthLabelOrganiMax + gapVMid + 2;
                    double yCoordi = gapTop + (hightOrganiBlock * counterYAxisCoordis_bars_Green) + hightOrganiBlock * 0.1;
                    newRectan.Margin = new Thickness(xCoordi, yCoordi, 0, 0);
                    gridGraph.Children.Add(newRectan);
                    graphRectangleList.Add(newRectan);


                    counterYAxisCoordis_bars_Green++;
                }
                else if (counterYAxisCoordis_bars_Red < graphData.Items.Count)
                {
                    // 绘制 党员 人数条棒 - 红色
                    Rectangle newRectan = MakeRectangle_RedBar();
                    newRectan.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
                    newRectan.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                    newRectan.Height = hightOrganiBlock * 0.4;
                    newRectan.Width = (graphData.Items[counterYAxisCoordis_bars_Red].countPaMem / widthSingleStepValue) * (widthXAxis / coordiCountXAxis);
                    if (newRectan.Width > 1)
                    {
                        newRectan.Width -= 1;
                    }
                    double xCoordi = gapLeft + widthLabelOrganiMax + gapVMid + 2;
                    double yCoordi = gapTop + (hightOrganiBlock * counterYAxisCoordis_bars_Red) + hightOrganiBlock * 0.5;
                    newRectan.Margin = new Thickness(xCoordi, yCoordi, 0, 0);
                    gridGraph.Children.Add(newRectan);
                    graphRectangleList.Add(newRectan);


                    counterYAxisCoordis_bars_Red++;
                }
                else return false;
            }
            return true;
        }

        #endregion

        int countDown = 0;
        void uiTimer_Tick(object sender, EventArgs e)
        {
            switch (curDrawAction)
            {
                case DrawActions.Ready:
                    {
                        // 无动作
                        break;
                    }
                case DrawActions.DrawStart:
                    {
                        // 准备绘图数据
                        // 准备计数器
                        ReComputMapSizes();
                        ClearPaper();
                        curDrawAction = DrawActions.Drawing;
                        break;
                    }
                case DrawActions.Drawing:
                    {
                        // 执行绘制，计数器变动
                        if (Redraw_OneStep() == false)
                        {
                            curDrawAction = DrawActions.DrawComplete;
                        }
                        break;
                    }
                case DrawActions.PaperSizeChanged:
                    {
                        // 图纸变更，停止
                        countDown = 10;
                        curDrawAction = DrawActions.DrawStoped;
                        infoPanel.ShowInfo("准备重新绘图...", false);
                        break;
                    }
                case DrawActions.DrawStoped:
                    {
                        // 倒计时，准备重绘
                        countDown--;
                        if (countDown == 0)
                        {
                            curDrawAction = DrawActions.DrawStart;
                        }
                        break;
                    }
                case DrawActions.DrawComplete:
                    {
                        // 完成
                        infoPanel.ShowInfo("正在读取图形数据信息...", true);
                        curDrawAction = DrawActions.Ready;
                        resultServiceClient.GetGraphInfo_Ex2013Async();
                        break;
                    }
            }
        }
    }
}
