﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.CodeSharing.Entities;
using System.Windows.Threading;

namespace XTExam.Views_Admin
{
    public partial class ExUserExamGraph2 : UserControl
    {
        public ExUserExamGraph2()
        {
            InitializeComponent();
        }


        XTExam.ServiceReference_Result.Service_ResultClient resultServiceClient;
        DispatcherTimer uiTimer;
        private void LayoutRoot_Loaded(object sender, RoutedEventArgs e)
        {
            HideGraphTempls();
            //label_graphTime.Content = "图表计算时间：2013-??-?? ??:??:??";

            if (resultServiceClient == null)
            {
                resultServiceClient = new ServiceReference_Result.Service_ResultClient();
                //resultServiceClient.CheckGraphDataStatus_Ex2013Completed += resultServiceClient_CheckGraphDataStatus_Ex2013Completed;

                //resultServiceClient.ReGatherAllCompleted += resultServiceClient_ReGatherAllCompleted;

                resultServiceClient.GetGraphData_Ex2013Completed += resultServiceClient_GetGraphData_Ex2013Completed;
                resultServiceClient.GetGraphInfo_Ex2013Completed += resultServiceClient_GetGraphInfo_Ex2013Completed;

            }
            //infoPanel.ShowInfo("正在获取图形数据状态...", true);
            //resultServiceClient.CheckGraphDataStatus_Ex2013Async();

            infoPanel.ShowInfo("正在读取图形数据...", true);
            resultServiceClient.GetGraphData_Ex2013Async();

            GraphDataReady += ExUserExamGraph_GraphDataReady;

            if (uiTimer == null)
            {
                uiTimer = new DispatcherTimer()
                {
                    Interval = new TimeSpan(0, 0, 0, 0, 120),

                };
                uiTimer.Tick += uiTimer_Tick;
                uiTimer.Start();
            }

            // 检查是否需要重新统计

            // 不需要则直接加载数据

            // 如果需要，则等待加载数据，并提示如果失败，请重新刷新本页
        }



        string loadingErrorInfo = "数据加载失败，请稍后再试。";


        public DataProcessing.Results.GraphData_Ex2013 graphData;
        public event EventHandler GraphDataReady;

        void resultServiceClient_GetGraphData_Ex2013Completed(object sender, ServiceReference_Result.GetGraphData_Ex2013CompletedEventArgs e)
        {
            if (e.Error == null)
            {
                graphData = new DataProcessing.Results.GraphData_Ex2013(e.Result);
                if (GraphDataReady != null)
                {
                    GraphDataReady(this, new EventArgs());
                }
                return;
            }
            else
            {
            }
            infoPanel.ShowInfo(loadingErrorInfo, false);
        }
        void resultServiceClient_GetGraphInfo_Ex2013Completed(object sender, ServiceReference_Result.GetGraphInfo_Ex2013CompletedEventArgs e)
        {
            if (e.Error == null)
            {
                label_graphTime.Content = "图表计算时间：" + e.Result;
                infoPanel.ShowInfo("绘图完成！", false);
                return;
            }
            infoPanel.ShowInfo("未能获取图形时间信息！", false);
        }


        private void HideGraphTempls()
        {
            rectangle_tmpl.Visibility = System.Windows.Visibility.Collapsed;
            rectangle_barGreen.Visibility = System.Windows.Visibility.Collapsed;
            rectangle_barRed.Visibility = System.Windows.Visibility.Collapsed;
            label_organiName.Visibility = System.Windows.Visibility.Collapsed;
        }
        private void Ting()
        {
            // resize the grid, so it can reDraw
            gridGraph.Margin = new Thickness(25, gridGraph.Margin.Top, 26, gridGraph.Margin.Bottom);
            gridGraph.Margin = new Thickness(gridGraph.Margin.Right, gridGraph.Margin.Top, gridGraph.Margin.Right, gridGraph.Margin.Bottom);
        }

        private void gridGraph_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            _gridSize = e.NewSize;
            if (isGraphDataReady == true)
            {
                curDrawAction = DrawActions.PaperSizeChanged;
            }
        }


        private bool isGraphDataReady = false;
        void ExUserExamGraph_GraphDataReady(object sender, EventArgs e)
        {
            isGraphDataReady = true;
            curDrawAction = DrawActions.DrawStart;
        }

        //private bool isDrawing = false;
        //private bool isReDrawNeeded = false;

        public enum DrawActions
        {
            Ready = 0,
            DrawStart = 1,
            Drawing = 2,
            PaperSizeChanged = 3,
            DrawStoped = 4,
            DrawComplete = 5,
        }
        private DrawActions curDrawAction = DrawActions.Ready;

        #region 绘图使用数据、方法
        private Size _gridSize = new Size(0, 0); // 图纸尺寸
        private Point oPoint = new Point(0, 0); // Y轴上面的定点，依次作为原点

        private double gapLeft = 20;
        private double gapVMid = 7;
        private double gapRight = 20;
        private double gapTop = 20;
        private double gapHMid = 3;
        private double gapButtom = 40;

        private double hightLabel = 17;
        private double widthLabelSingleChar = 11.7;


        private double hightYAxis = 0;
        private double widthXAxis = 0;

        private double widthOrganiBlock = 0;
        private double widthLabelCountNumerMax = 0;


        private double heightSingleStepValue = 0;

        private int coordiCountYAxis = 0;
        private int coordiCountXAxis = 0;

        private int counterYAxisCoordis;
        private int counterYAxisCoordis_dotLines;
        private int counterXAxisCoordis_lables;
        private int counterXAxisCoordis_bars_Green;
        private int counterXAxisCoordis_bars_Red;

        private void ReSizeOrganiLabels()
        {
            DataProcessing.Results.GraphData_Ex2013.DataItem item;
            for (int i = graphData.Items.Count - 1; i >= 0; i--)
            {
                item = graphData.Items[i];
                if (item.organi.Contains("宁夏电力公司本部"))
                {
                    item.organi = item.organi.Replace("宁夏电力公司本部", "公司本部");
                }
                else if (item.organi.Contains("银川供电局"))
                {
                    item.organi = "银川局";
                }
                else if (item.organi.Contains("宁夏电力建设监理咨询有限公司"))
                {
                    item.organi = item.organi.Replace("宁夏电力建设监理咨询有限公司", "监理公司");
                }
                else if (item.organi.Contains("宁夏电力公司吴忠供电局"))
                {
                    item.organi = item.organi.Replace("宁夏电力公司吴忠供电局", "吴忠局");
                }
                else if (item.organi.Contains("宁夏电力公司吴忠供电局"))
                {
                    item.organi = item.organi.Replace("宁夏电力公司吴忠供电局", "吴忠局");
                }
                else if (item.organi.Contains("宁夏电力公司石嘴山供电局"))
                {
                    item.organi = item.organi.Replace("宁夏电力公司石嘴山供电局", "石嘴山局");
                }
                else if (item.organi.Contains("宁夏电力公司中卫供电局"))
                {
                    item.organi = item.organi.Replace("宁夏电力公司中卫供电局", "中卫局");
                }
                else if (item.organi.Contains("宁夏电力公司宁东供电局"))
                {
                    item.organi = item.organi.Replace("宁夏电力公司宁东供电局", "宁东局");
                }
                else if (item.organi.Contains("宁夏电力公司固原供电局"))
                {
                    item.organi = item.organi.Replace("宁夏电力公司固原供电局", "固原局");
                }
                else if (item.organi.Contains("宁夏电力公司检修公司"))
                {
                    item.organi = item.organi.Replace("宁夏电力公司检修公司", "检修公司");
                }
                else if (item.organi.Contains("宁夏电力公司电力科学研究院"))
                {
                    item.organi = item.organi.Replace("宁夏电力公司电力科学研究院", "电科院");
                }
                else if (item.organi.Contains("宁夏电力公司经济技术研究院"))
                {
                    item.organi = item.organi.Replace("宁夏电力公司经济技术研究院", "经研院");
                }
                else if (item.organi.Contains("宁夏电力公司信息通信分公司"))
                {
                    item.organi = item.organi.Replace("宁夏电力公司信息通信分公司", "信通公司");
                }
                else if (item.organi.Contains("宁夏电力公司教育培训中心"))
                {
                    item.organi = item.organi.Replace("宁夏电力公司教育培训中心", "教培中心");
                }
                else if (item.organi.Contains("宁夏送变电工程公司"))
                {
                    item.organi = item.organi.Replace("宁夏送变电工程公司", "送变电公司");
                }
                else if (item.organi.Contains("宁夏电力公司物资供应公司"))
                {
                    item.organi = item.organi.Replace("宁夏电力公司物资供应公司", "物资公司");
                }
                else if (item.organi.Contains("宁夏电力公司综合服务中心"))
                {
                    item.organi = item.organi.Replace("宁夏电力公司综合服务中心", "服务中心");
                }
                else if (item.organi.Contains("宁夏电力集体资产投资集团有限公司"))
                {
                    item.organi = item.organi.Replace("宁夏电力集体资产投资集团有限公司", "投资集团");
                }

                graphData.Items[i] = item;
            }
        }

        private void ReComputMapSizes()
        {
            ReSizeOrganiLabels();

            //int countOrgChar = 0;
            //foreach (DataProcessing.Results.GraphData_Ex2013.DataItem di in graphData.Items)
            //{
            //    if (di.organi.Length > countOrgChar)
            //    {
            //        countOrgChar = di.organi.Length;
            //    }
            //}

            //widthLabelCountNumerMax = countOrgChar * widthLabelSingleChar;
            widthLabelCountNumerMax = 5 * widthLabelSingleChar;

            hightYAxis = _gridSize.Height - (gapTop + gapHMid + hightLabel + gapButtom);
            widthXAxis = _gridSize.Width - (gapLeft + gapVMid + gapRight + widthLabelCountNumerMax);



            widthOrganiBlock = widthXAxis / graphData.Items.Count;



            //oPoint.X = gapLeft + gapVMid + widthLabelCountNumerMax;
            //oPoint.Y = gapTop;

            coordiCountYAxis = (int)hightYAxis / 30;
            counterYAxisCoordis = 0;
            counterYAxisCoordis_dotLines = 0;

            double tmpDouble;
            if (coordiCountYAxis <= 1) coordiCountYAxis = 2;
            tmpDouble = graphData.CountAll_Max / (coordiCountYAxis - 1);
            heightSingleStepValue = (int)(tmpDouble / 10 + 1) * 10;

            if ((heightSingleStepValue * coordiCountYAxis) > graphData.CountAll_Max)
            {
            }
            else
            {
                // 人数多，不够显示
                heightSingleStepValue += 10;
                while ((heightSingleStepValue * coordiCountYAxis) < graphData.CountAll_Max)
                {
                    heightSingleStepValue += 10;
                }
            }

            if ((heightSingleStepValue * coordiCountYAxis) > graphData.CountAll_Max)
            {
                // 人数坐标点 多， 总人数少
                coordiCountYAxis -= 1;
                while ((heightSingleStepValue * coordiCountYAxis) > graphData.CountAll_Max)
                {
                    coordiCountYAxis -= 1;
                }
                coordiCountYAxis += 1;
            }
            else
            {
            }

            coordiCountXAxis = graphData.Items.Count;

            counterXAxisCoordis_bars_Green
                = counterXAxisCoordis_bars_Red
                = counterXAxisCoordis_lables
                = 0;

        }

        List<Rectangle> graphRectangleList = new List<Rectangle>();
        List<Label> graphLabelList = new List<Label>();
        private void ClearPaper()
        {
            for (int i = graphRectangleList.Count - 1; i >= 0; i--)
            {
                gridGraph.Children.Remove(graphRectangleList[i]);
            }
            graphRectangleList.Clear();
            for (int i = graphLabelList.Count - 1; i >= 0; i--)
            {
                gridGraph.Children.Remove(graphLabelList[i]);
            }
            graphLabelList.Clear();
        }

        private Rectangle MakeRectangle_BlackFrame()
        {
            Rectangle result = new Rectangle();
            result.Stroke = rectangle_tmpl.Stroke;
            return result;
        }
        private Rectangle MakeRectangle_RedBar()
        {
            Rectangle result = new Rectangle();
            result.Stroke = rectangle_barRed.Stroke;
            result.Fill = rectangle_barRed.Fill;
            return result;
        }
        private Rectangle MakeRectangle_GreenBar()
        {
            Rectangle result = new Rectangle();
            result.Stroke = rectangle_barGreen.Stroke;
            result.Fill = rectangle_barGreen.Fill;
            return result;
        }

        private bool Redraw_OneStep()
        {
            //Rectangle newRectan;
            if (graphRectangleList.Count == 0)
            {
                // 绘制X轴
                Rectangle line = MakeRectangle_BlackFrame();
                line.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
                line.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                line.Height = 1;
                line.Width = widthXAxis;
                line.Margin = new Thickness((gapLeft + widthLabelCountNumerMax + gapVMid), (gapTop + hightYAxis), 0, 0);
                gridGraph.Children.Add(line);
                graphRectangleList.Add(line);
            }
            else if (graphRectangleList.Count == 1)
            {
                // 绘制Y轴
                Rectangle line = MakeRectangle_BlackFrame();
                line.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
                line.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                line.Height = hightYAxis;
                line.Width = 1;
                line.Margin = new Thickness((gapLeft + widthLabelCountNumerMax + gapVMid), (gapTop), 0, 0);
                gridGraph.Children.Add(line);
                graphRectangleList.Add(line);
            }
            else
            {
                if (counterYAxisCoordis <= coordiCountYAxis - 1)
                {
                    // 绘制人数坐标点 和 文本

                    Rectangle line = MakeRectangle_BlackFrame();
                    line.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
                    line.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                    line.Width = 6;
                    line.Height = 1;
                    double xCoordi = gapLeft + widthLabelCountNumerMax + gapVMid;
                    double yCoordi = gapTop + hightYAxis - (counterYAxisCoordis + 1) * (hightYAxis / coordiCountYAxis);
                    line.Margin = new Thickness(xCoordi - 3, yCoordi, 0, 0);
                    gridGraph.Children.Add(line);
                    graphRectangleList.Add(line);

                    Label newLabel = new Label();
                    newLabel.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
                    newLabel.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                    newLabel.FontFamily = label_graphTime.FontFamily;
                    newLabel.FontSize = label_graphTime.FontSize;
                    newLabel.Foreground = label_graphTime.Foreground;
                    newLabel.Content = (heightSingleStepValue * (counterYAxisCoordis + 1)).ToString("###,###,###");
                    newLabel.Margin = new Thickness(xCoordi - newLabel.Content.ToString().Length * widthLabelSingleChar, (yCoordi - 8), 0, 0);
                    gridGraph.Children.Add(newLabel);
                    graphLabelList.Add(newLabel);

                    counterYAxisCoordis++;
                }
                else if (counterXAxisCoordis_lables < graphData.Items.Count)
                {
                    // 绘制组织名称文本
                    Label newLabel = new Label();
                    newLabel.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
                    newLabel.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                    newLabel.FontFamily = label_graphTime.FontFamily;
                    newLabel.FontSize = label_graphTime.FontSize;
                    newLabel.Foreground = label_graphTime.Foreground;
                    newLabel.Content = graphData.Items[counterXAxisCoordis_lables].organi;
                    double topCoordi = gapTop + hightYAxis + 3;
                    double tmpDouble = widthXAxis / graphData.Items.Count;
                    double leftCoordi = gapLeft + widthLabelCountNumerMax + gapVMid
                        + tmpDouble * counterXAxisCoordis_lables + tmpDouble * 0.5
                        - (newLabel.Content.ToString().Length * widthLabelSingleChar / 2);

                    newLabel.Margin = new Thickness(leftCoordi, topCoordi, 0, 0);
                    gridGraph.Children.Add(newLabel);
                    graphLabelList.Add(newLabel);


                    counterXAxisCoordis_lables++;
                }
                else if (counterYAxisCoordis_dotLines < coordiCountYAxis)
                {
                    // 绘制人数虚线
                    Rectangle line = MakeRectangle_BlackFrame();
                    line.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
                    line.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                    line.Height = 1;
                    line.Width = widthXAxis;
                    line.Opacity = 0.4;
                    double xCoordi = gapLeft + widthLabelCountNumerMax + gapVMid;
                    double yCoordi = gapTop + hightYAxis
                        - (counterYAxisCoordis_dotLines + 1) * (hightYAxis / coordiCountYAxis);
                    line.Margin = new Thickness(xCoordi, yCoordi, 0, 0);
                    gridGraph.Children.Add(line);
                    graphRectangleList.Add(line);


                    counterYAxisCoordis_dotLines++;
                }
                else if (counterXAxisCoordis_bars_Green < graphData.Items.Count)
                {
                    // 绘制全部人数条棒 - 绿色
                    Rectangle line = MakeRectangle_GreenBar();
                    line.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
                    line.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                    line.Width = widthOrganiBlock * 0.4;
                    line.Height = (graphData.Items[counterXAxisCoordis_bars_Green].countAll / heightSingleStepValue) * (hightYAxis / coordiCountYAxis);
                    if (line.Height > 1)
                    {
                        line.Height -= 1;
                    }
                    double xCoordi = gapLeft + widthLabelCountNumerMax + gapVMid
                        + (widthOrganiBlock * counterXAxisCoordis_bars_Green) + widthOrganiBlock * 0.1;
                    double yCoordi = gapTop + hightYAxis - line.Height - 2;
                    line.Margin = new Thickness(xCoordi, yCoordi, 0, 0);
                    //line.Tag = graphData.Items[counterXAxisCoordis_bars_Green];

                    ToolTipService.SetToolTip(line, graphData.Items[counterXAxisCoordis_bars_Green].organi + "参考总人数：" + graphData.Items[counterXAxisCoordis_bars_Green].countAll);
                    //ToolTip tip = new ToolTip();
                    //tip.Content = ;
                    //tip.Parent = line;

                    gridGraph.Children.Add(line);
                    graphRectangleList.Add(line);


                    counterXAxisCoordis_bars_Green++;
                }
                else if (counterXAxisCoordis_bars_Red < graphData.Items.Count)
                {
                    // 绘制 党员 人数条棒 - 红色
                    Rectangle line = MakeRectangle_RedBar();
                    line.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
                    line.VerticalAlignment = System.Windows.VerticalAlignment.Top;
                    line.Width = widthOrganiBlock * 0.4;
                    line.Height = (graphData.Items[counterXAxisCoordis_bars_Red].countPaMem / heightSingleStepValue) * (hightYAxis / coordiCountYAxis);
                    if (line.Height > 1)
                    {
                        line.Height -= 1;
                    }
                    double xCoordi = gapLeft + widthLabelCountNumerMax + gapVMid
                        + (widthOrganiBlock * counterXAxisCoordis_bars_Red) + widthOrganiBlock * 0.5;
                    double yCoordi = gapTop + hightYAxis - line.Height - 2;
                    line.Margin = new Thickness(xCoordi, yCoordi, 0, 0);

                    ToolTipService.SetToolTip(line, graphData.Items[counterXAxisCoordis_bars_Red].organi + "参考党员人数：" + graphData.Items[counterXAxisCoordis_bars_Red].countPaMem);
                    
                    gridGraph.Children.Add(line);
                    graphRectangleList.Add(line);


                    counterXAxisCoordis_bars_Red++;
                }
                else return false;
            }
            return true;
        }

        private void SetUserCount()
        {
            string msg = "参考总人数：";
            int count = 0;
            for(int i = graphData.Items.Count-1;i>=0; i--)
            {
                count += graphData.Items[i].countAll;
            }
            msg += count + "（人），其中党员人数：";
            count = 0;
            for (int i = graphData.Items.Count - 1; i >= 0; i--)
            {
                count += graphData.Items[i].countPaMem;
            }
            msg += count + "（人）";
            label_userCount.Content = msg;
        }

        #endregion

        int countDown = 0;
        void uiTimer_Tick(object sender, EventArgs e)
        {
            switch (curDrawAction)
            {
                case DrawActions.Ready:
                    {
                        // 无动作
                        break;
                    }
                case DrawActions.DrawStart:
                    {
                        // 准备绘图数据
                        // 准备计数器
                        ReComputMapSizes();
                        ClearPaper();
                        curDrawAction = DrawActions.Drawing;
                        break;
                    }
                case DrawActions.Drawing:
                    {
                        // 执行绘制，计数器变动
                        if (Redraw_OneStep() == false)
                        {
                            curDrawAction = DrawActions.DrawComplete;
                        }
                        break;
                    }
                case DrawActions.PaperSizeChanged:
                    {
                        // 图纸变更，停止
                        countDown = 10;
                        curDrawAction = DrawActions.DrawStoped;
                        infoPanel.ShowInfo("准备重新绘图...", false);
                        break;
                    }
                case DrawActions.DrawStoped:
                    {
                        // 倒计时，准备重绘
                        countDown--;
                        if (countDown == 0)
                        {
                            curDrawAction = DrawActions.DrawStart;
                        }
                        break;
                    }
                case DrawActions.DrawComplete:
                    {
                        // 完成
                        SetUserCount();
                        infoPanel.ShowInfo("正在读取图形数据信息...", true);
                        curDrawAction = DrawActions.Ready;
                        resultServiceClient.GetGraphInfo_Ex2013Async();
                        break;
                    }
            }
        }
    }
}
