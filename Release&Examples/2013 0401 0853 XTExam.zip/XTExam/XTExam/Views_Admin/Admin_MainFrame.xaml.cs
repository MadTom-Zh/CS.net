﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;

using XTExam.Views_Admin.User;
using XTExam.CodeSharing.Entities;

namespace XTExam.Views_Admin
{
    public partial class Admin_MainFrame : Page
    {
        public DataProcessing.UserRegister.UserInfo myId
        {
            set;
            get;
        }
        public Admin_MainFrame(DataProcessing.UserRegister.UserInfo myID)
        {
            InitializeComponent();
            this.myId = myID;
            if (myId == null || !myId.hasId)
            {
                this.IsEnabled = false;
            }
        }

        // 当用户导航到此页面时执行。
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            hyperlinkButton_announcement.IsEnabled = myId.couldAdminAnnouncement;
            hyperlinkButton_audit.IsEnabled = myId.couldAuditPaper;
            hyperlinkButton_paper.IsEnabled = myId.couldMakePaper;
            hyperlinkButton_user.IsEnabled = myId.couldAdminUser;
        }

        private void hyperlinkButton_user_Click(object sender, RoutedEventArgs e)
        {
            Admin_User adminUserWin = new Admin_User(myId);
            ContentFrame.Content = adminUserWin;
        }

        private void hyperlinkButton_paper_Click(object sender, RoutedEventArgs e)
        {
            Views_Admin.Paper.Admin_Paper adminPaperWin = new Views_Admin.Paper.Admin_Paper(myId);
            ContentFrame.Content = adminPaperWin;
        }

        private void hyperlinkButton_audit_Click(object sender, RoutedEventArgs e)
        {
            Views_Admin.Audit.Audit_Guide auWin = new Views_Admin.Audit.Audit_Guide(myId);
            ContentFrame.Content = auWin;
        }

        private void hyperlinkButton_announcement_Click(object sender, RoutedEventArgs e)
        {
            Views_Admin.Announcement.Admin_Announcement anumWin = new Announcement.Admin_Announcement(myId);
            ContentFrame.Content = anumWin;
        }

        private void hyperlinkButton_resultStati_Click(object sender, RoutedEventArgs e)
        {
            // 加载 成绩统计图形界面
            Views_Admin.ExUserExamGraph graphWin = new ExUserExamGraph();

            ContentFrame.Content = graphWin;
        }

        private void hyperlinkButton_resultStati2_Click(object sender, RoutedEventArgs e)
        {
            Views_Admin.ExUserExamGraph2 graph2Win = new ExUserExamGraph2();

            ContentFrame.Content = graph2Win;
        }
    }
}
