﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;

using XTExam.CodeSharing.Entities;

namespace XTExam.Views_Admin.Paper
{
    public partial class Admin_Paper : Page
    {
        public DataProcessing.UserRegister.UserInfo myId
        {
            set;
            get;
        }
        public Admin_Paper(DataProcessing.UserRegister.UserInfo myID)
        {
            InitializeComponent();
            this.myId = myID;
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (myId == null || !myId.hasId)
            {
                this.IsEnabled = false;
                return;
            }
            tabItem_Depot_GotFocus(tabItem_Depot, e);
        }
        Sub_Depot subDepot = null;
        Sub_MakeExamHall subMakeHall = null;
        //Sub_MakeExamHall subMakeHall = null;
        private void tabItem_Depot_GotFocus(object sender, RoutedEventArgs e)
        {
            if (myId.couldMakePaper && subDepot == null)
            {
                subDepot = new Sub_Depot(myId);
                tabItem_Depot.Content = subDepot;
            }
        }

        private void tabItem_MakeHall_GotFocus(object sender, RoutedEventArgs e)
        {
            if (myId.couldMakePaper && subMakeHall == null)
            {
                subMakeHall = new Sub_MakeExamHall(myId);
                tabItem_MakeHall.Content = subMakeHall;
            }
        }


        private void tabItem_DropExam_GotFocus(object sender, RoutedEventArgs e)
        {
            //if (myID[12].ToLower() == "true" &&    == null)
            //{
            //       = new   (myID);
            //      Content =  ;
            //}
        }



    }
}
