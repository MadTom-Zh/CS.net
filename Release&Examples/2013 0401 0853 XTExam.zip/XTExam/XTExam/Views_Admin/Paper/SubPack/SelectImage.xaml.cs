﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.ServiceReference_Depot;
using System.IO;
using System.Collections.ObjectModel;
using System.Windows.Media.Imaging;
using System.Windows.Browser;
using XTExam.CodeSharing.Entities;

namespace XTExam.Views_Admin.Paper.SubPack
{
    public partial class SelectImage : ChildWindow
    {
        public DataProcessing.UserRegister.UserInfo myId { set; get; }
        public SelectImage( DataProcessing.UserRegister.UserInfo myId)
        {
            this.myId = myId;
            InitializeComponent();
        }

        private Service_DepotClient serviceClient;
        private void ChildWindow_Loaded(object sender, RoutedEventArgs e)
        {
            if (myId == null || !myId.hasId)
            {
                this.IsEnabled = false;
                return;
            }
            infoPanel.ProcessingStart += new EventHandler(infoPanel_ProcessingStart);
            infoPanel.ProcessingComplete += new EventHandler(infoPanel_ProcessingComplete);

            serviceClient = new Service_DepotClient();
            serviceClient.GetImageListCompleted += new EventHandler<GetImageListCompletedEventArgs>(serviceClient_GetImageListCompleted);
            serviceClient.UploadImageCompleted += new EventHandler<UploadImageCompletedEventArgs>(serviceClient_UploadImageCompleted);

            infoPanel.ShowInfo("正在获取图片列表……", true);
            serviceClient.GetImageListAsync();

            selLocalImageDlg = new OpenFileDialog();
            selLocalImageDlg.Filter = "Suppoted Files|*.jpg;*.png|Jpeg Files (*.jpg)|*.jpg|Png Files (*.png)|*.png|All Files(*.*)|*.*";
            selLocalImageDlg.Multiselect = false;
        }

        void infoPanel_ProcessingComplete(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            this.IsEnabled = true;
        }
        void infoPanel_ProcessingStart(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            this.IsEnabled = false;
        }

        void serviceClient_GetImageListCompleted(object sender, GetImageListCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result != null)
                {
                    listBox_imageList_FillImageNames(e.Result);
                    infoPanel.ShowInfo("成功获取图片列表", false);
                }
                else
                {
                    infoPanel.ShowInfo("未能成功获取图片列表，请关闭后重试", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }
        private void listBox_imageList_FillImageNames(ObservableCollection<string> imageNameList)
        {
            listBox_imageList.Items.Clear();
            TextBlock newItem;
            for (int i = 0; i < imageNameList.Count; i++)
            {
                newItem = new TextBlock();
                newItem.Text = imageNameList[i];
                listBox_imageList.Items.Add(newItem);
            }
        }
        private void listBox_imageList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems[0] != null)
            {
                TextBlock target = (TextBlock)e.AddedItems[0];
                string fileName = HttpUtility.UrlEncode(target.Text);
                string uriStr = "../Services/subjectImage.aspx?name=" + fileName;
                Uri imgUri = new Uri(uriStr, UriKind.RelativeOrAbsolute);
                //HtmlPage.Window.Navigate(imgUri);
                WebClient imageDownloader = new WebClient();
                infoPanel.ShowInfo("正在尝试下载图片……", true);
                imageDownloader.OpenReadCompleted += new OpenReadCompletedEventHandler(imageDownloader_OpenReadCompleted);
                imageDownloader.OpenReadAsync(imgUri);
            }
        }
        void imageDownloader_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            // throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result != null)
                {
                    BitmapImage imgSource = new BitmapImage();
                    imgSource.SetSource(e.Result);
                    imageUI.Source = imgSource;
                    TextBlock target = (TextBlock)listBox_imageList.SelectedItem;
                    textBox_imagePath.Text = target.Text;
                    infoPanel.ShowInfo("已获取图片", false);
                }
                else
                {
                    infoPanel.ShowInfo("未能获取图片，请重试", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private OpenFileDialog selLocalImageDlg;
        private byte[] selLocalImageDlg_data;
        private int selLocalImageDlg_dataMaxLength = 1024;
        private long selLocalImageDlg_dataOffSet;
        private void button_upLoad_Click(object sender, RoutedEventArgs e)
        {
            if (selLocalImageDlg.ShowDialog() == true && selLocalImageDlg.File != null)
            {
                if (selLocalImageDlg.File.Length < selLocalImageDlg_dataMaxLength) selLocalImageDlg_dataOffSet = selLocalImageDlg.File.Length;
                else selLocalImageDlg_dataOffSet = selLocalImageDlg_dataMaxLength;
                byte[] data = new byte[selLocalImageDlg_dataOffSet];
                FileStream reader = selLocalImageDlg.File.OpenRead();
                selLocalImageDlg_data = new byte[selLocalImageDlg.File.Length];
                reader.Read(selLocalImageDlg_data, 0, (int)selLocalImageDlg.File.Length);
                for (int i = 0; i < selLocalImageDlg_dataOffSet; i++)
                {
                    data[i] = selLocalImageDlg_data[i];
                }
                reader.Close();
                serviceClient.UploadImageAsync(selLocalImageDlg.File.Name, data, false, myId.id);
            }
        }
        void serviceClient_UploadImageCompleted(object sender, UploadImageCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result)
                {
                    long fileSize = selLocalImageDlg_data.Length;
                    if (selLocalImageDlg_dataOffSet >= fileSize)
                    {
                        //infoPanel.ShowInfo("图片上载完成", false);
                        infoPanel.ShowInfo("重新加载图片列表……", true);
                        serviceClient.GetImageListAsync();
                        return;
                    }
                    int newLength;
                    double persent = (double)selLocalImageDlg_dataOffSet / fileSize * 100;
                    infoPanel.ShowInfo("已经上载[" + selLocalImageDlg_dataOffSet + "]B，完成 " + persent.ToString("##.00") + " %", true);
                    if ((selLocalImageDlg_dataOffSet + selLocalImageDlg_dataMaxLength) > fileSize) newLength = (int)(fileSize - selLocalImageDlg_dataOffSet);
                    else newLength = selLocalImageDlg_dataMaxLength;
                    byte[] data = new byte[newLength];
                    for (int i = 0; i < data.Length; i++)
                    {
                        data[i] = selLocalImageDlg_data[selLocalImageDlg_dataOffSet + i];
                    }
                    selLocalImageDlg_dataOffSet += newLength;
                    serviceClient.UploadImageAsync(selLocalImageDlg.File.Name, data, true, myId.id);
                }
                else
                {
                    infoPanel.ShowInfo("上载失败，请重试……", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }
        public string selectedImageName
        {
            get
            {
                if (textBox_imagePath.Text.Length > 0)
                {
                    string result = textBox_imagePath.Text;
                    return result;
                }
                return null;
            }
        }
    }
}

