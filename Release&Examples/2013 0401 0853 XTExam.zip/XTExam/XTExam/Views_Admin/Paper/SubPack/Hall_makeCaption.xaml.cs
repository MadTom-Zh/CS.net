﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.CodeSharing.Entities;

namespace XTExam.Views_Admin.Paper.SubPack
{
    public partial class Hall_makeCaption : ChildWindow
    {
        public Hall_makeCaption()
        {
            InitializeComponent();
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private string judgedCaption = "";
        private void textBox_caption_TextChanged(object sender, TextChangedEventArgs e)
        {
            judgedCaption = textBox_caption.Text.Trim();
            OKButton.IsEnabled = (judgedCaption.Length != 0);
            ReBuildSample();
        }
        private void slider_fontSize_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (textBox_fontSize == null) return;
            textBox_fontSize.Text = (int)slider_fontSize.Value + "";
            ReBuildSample();
        }
        private void radioButton_L_Checked(object sender, RoutedEventArgs e)
        {
            ReBuildSample();
        }
        private void radioButton_M_Checked(object sender, RoutedEventArgs e)
        {
            ReBuildSample();
        }
        private void radioButton_R_Checked(object sender, RoutedEventArgs e)
        {
            ReBuildSample();
        }

        private void ReBuildSample()
        {
            if (textBox_caption == null) return;
            Paragraph block = new Paragraph();
            block.Inlines.Add(textBox_caption.Text);
            block.FontSize = (int)slider_fontSize.Value;
            if (radioButton_L.IsChecked == true) block.TextAlignment = TextAlignment.Left;
            else if (radioButton_M.IsChecked == true) block.TextAlignment = TextAlignment.Center;
            else if (radioButton_R.IsChecked == true) block.TextAlignment = TextAlignment.Right;
            richTextBox_sample.Blocks.Clear();
            richTextBox_sample.Blocks.Add(block);
        }

        //public void SetAddData2HallInfo(ref HallInfoHelper data)
        public void SetAddData2HallInfo(ref DataProcessing.ExamHall.HallInfo data)
        {
            //HallInfoHelper.PaperElement newCap = new HallInfoHelper.PaperElement();
            DataProcessing.ExamHall.HallInfo.PaperElement newCap = new DataProcessing.ExamHall.HallInfo.PaperElement();
            newCap.caption = judgedCaption;
            newCap.captionSize = (int)slider_fontSize.Value;
            if (radioButton_L.IsChecked == true) newCap.captionAlign = DataProcessing.Depot.Subject.SubjectAlign.Left;
            else if (radioButton_M.IsChecked == true) newCap.captionAlign = DataProcessing.Depot.Subject.SubjectAlign.Middle;
            else if (radioButton_R.IsChecked == true) newCap.captionAlign = DataProcessing.Depot.Subject.SubjectAlign.Right;

            data.elements.Add(newCap);
        }
    }
}

