﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.ServiceReference_Depot;
using System.Collections.ObjectModel;
using XTExam.CodeSharing.Entities;

namespace XTExam.Views_Admin.Paper.SubPack
{
    public partial class Hall_makeSubjBlock : ChildWindow
    {
        public DataProcessing.UserRegister.UserInfo myId { set; get; }
        //private HallInfoHelper.PaperElement.Type _subjType;
        private DataProcessing.Depot.Subject.Type _subjType;
        public Hall_makeSubjBlock(DataProcessing.UserRegister.UserInfo myID, DataProcessing.Depot.Subject.Type subjType)
        {
            this.myId = myID;
            _subjType = subjType;
            InitializeComponent();
        }
        private void ChildWindow_Loaded(object sender, RoutedEventArgs e)
        {
            if (myId == null || !myId.hasId)
            {
                this.IsEnabled = false;
                return;
            }
            serviceClient = new Service_DepotClient();
            serviceClient.GetDepotSubjectCountsCompleted += new EventHandler<GetDepotSubjectCountsCompletedEventArgs>(serviceClient_GetDepotSubjectCountsCompleted);

            infoPanel.ProcessingStart += new EventHandler(infoPanel_ProcessingStart);
            infoPanel.ProcessingComplete += new EventHandler(infoPanel_ProcessingComplete);

            treeView_Depot.myID = myId;
            treeView_Depot.InfomatingStart += new EventHandler(treeView_Depot_InfomatingStart);
            treeView_Depot.InfomatingStop += new EventHandler(treeView_Depot_InfomatingStop);
            treeView_Depot.LoadTreeStart += new EventHandler(treeView_Depot_LoadTreeStart);
            treeView_Depot.SelectedNodeChanged += new EventHandler(treeView_Depot_SelectedNodeChanged);

            slider_single.IsEnabled = slider_muti.IsEnabled
                = slider_judge.IsEnabled = slider_blanks.IsEnabled
                = slider_qanswer.IsEnabled = false;
            if (_subjType == DataProcessing.Depot.Subject.Type.Single) slider_single.IsEnabled = true;
            else if (_subjType == DataProcessing.Depot.Subject.Type.Muti) slider_muti.IsEnabled = true;
            else if (_subjType == DataProcessing.Depot.Subject.Type.Judge) slider_judge.IsEnabled = true;
            else if (_subjType == DataProcessing.Depot.Subject.Type.Blanks) slider_blanks.IsEnabled = true;
            else if (_subjType == DataProcessing.Depot.Subject.Type.QAnswer) slider_qanswer.IsEnabled = true;
        }



        void infoPanel_ProcessingComplete(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            this.Cursor = Cursors.Arrow;
        }
        void infoPanel_ProcessingStart(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            this.Cursor = Cursors.Wait;
        }

        void treeView_Depot_InfomatingStart(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            infoPanel.ShowInfo(treeView_Depot.Infomating, true);
        }
        void treeView_Depot_InfomatingStop(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            infoPanel.ShowInfo(treeView_Depot.Infomating, false);
        }
        void treeView_Depot_LoadTreeStart(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            OKButton.IsEnabled = false;
        }

        Service_DepotClient serviceClient;
        private string selectedDepotPath = null;
        void treeView_Depot_SelectedNodeChanged(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            slider_single.Value = slider_muti.Value
                = slider_judge.Value = slider_blanks.Value
                = slider_qanswer.Value = 0;
            if (treeView_Depot.selectedNodeFullPath_isDepot)
            {
                selectedDepotPath = treeView_Depot.selectedNodeFullPath;
            }
            else selectedDepotPath = null;
            if (selectedDepotPath != null)
            {
                infoPanel.ShowInfo("正在获取题库题目数量……", true);
                serviceClient.GetDepotSubjectCountsAsync(selectedDepotPath, myId.id);
            }
        }
        void serviceClient_GetDepotSubjectCountsCompleted(object sender, GetDepotSubjectCountsCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                slider_single.Maximum = e.Result[0];
                slider_muti.Maximum = e.Result[1];
                slider_judge.Maximum = e.Result[2];
                slider_blanks.Maximum = e.Result[3];
                slider_qanswer.Maximum = e.Result[4];
                SetValueTextBoxes();
                infoPanel.ShowInfo("完成获取题目数，请拖动滑块", false);
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }


        private void OKButton_Click(object sender, RoutedEventArgs e)
        {

            this.DialogResult = true;
        }
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private int subjCount;
        private void slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Slider target = (Slider)sender;
            subjCount = (int)target.Value;
            if (subjCount > 0) OKButton.IsEnabled = true;
            SetValueTextBoxes();
        }
        private void SetValueTextBoxes()
        {
            textBox_single.Text = (int)slider_single.Value + " / " + (int)slider_single.Maximum;
            textBox_muti.Text = (int)slider_muti.Value + " / " + (int)slider_muti.Maximum;
            textBox_judge.Text = (int)slider_judge.Value + " / " + (int)slider_judge.Maximum;
            textBox_blanks.Text = (int)slider_blanks.Value + " / " + (int)slider_blanks.Maximum;
            textBox_qanswer.Text = (int)slider_qanswer.Value + " / " + (int)slider_qanswer.Maximum;
        }


        //public void GetAddData2HallInfo(ref HallInfoHelper target)
        public void GetAddData2HallInfo(ref DataProcessing.ExamHall.HallInfo target)
        {
            DataProcessing.ExamHall.HallInfo.PaperElement elm = new DataProcessing.ExamHall.HallInfo.PaperElement();
            elm.type = _subjType;
            elm.sourceDepot = selectedDepotPath;
            elm.subjectCount = subjCount;
            if (radioButton_fromB.IsChecked == true) elm.gainType = DataProcessing.ExamHall.HallInfo.PaperElement.GainType.FromBeginning;
            else if (radioButton_fromE.IsChecked == true) elm.gainType = DataProcessing.ExamHall.HallInfo.PaperElement.GainType.FromEnding;
            else if (radioButton_random.IsChecked == true) elm.gainType = DataProcessing.ExamHall.HallInfo.PaperElement.GainType.Random;

            target.elements.Add(elm);
        }
    }
}

