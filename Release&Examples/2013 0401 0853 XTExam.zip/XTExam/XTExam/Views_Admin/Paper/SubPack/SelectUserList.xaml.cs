﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.CodeSharing.Entities;

namespace XTExam.Views_Admin.Paper.SubPack
{
    public partial class SelectUserList : ChildWindow
    {
        public SelectUserList()
        {
            InitializeComponent();
        }
        private DataProcessing.UserRegister.UserInfo _myId;
        public DataProcessing.UserRegister.UserInfo myID
        {
            set
            {
                _myId = value;
                ChildWindow_Loaded(this, new RoutedEventArgs());
            }
        }
        private void ChildWindow_Loaded(object sender, RoutedEventArgs e)
        {
            if (_myId == null || !_myId.hasId) return;
            treeView_User.myID = _myId;
            treeView_User.SelectedNodeChanged += new EventHandler(treeView_User_SelectedNodeChanged);
            treeView_User.InformatingStart += new EventHandler(treeView_User_InformatingStart);
            treeView_User.InformatingEnd += new EventHandler(treeView_User_InformatingEnd);
        }

        void treeView_User_InformatingStart(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            infoPanel.ShowInfo(treeView_User.Informating, true);
        }
        void treeView_User_InformatingEnd(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            infoPanel.ShowInfo(treeView_User.Informating, false);
        }


        void treeView_User_SelectedNodeChanged(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            OKButton.IsEnabled = (treeView_User.selectedFilePath != null);
        }

        public string selectedUserListPath = null;
        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            selectedUserListPath = treeView_User.selectedFilePath;
            this.DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}

