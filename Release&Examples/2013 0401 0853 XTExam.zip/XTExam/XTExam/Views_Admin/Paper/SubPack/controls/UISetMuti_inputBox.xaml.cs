﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace XTExam.Views_Admin.Paper.SubPack.controls
{
    public partial class UISetMuti_inputBox : ChildWindow
    {
        public UISetMuti_inputBox()
        {
            InitializeComponent();
        }
        private void ChildWindow_Loaded(object sender, RoutedEventArgs e)
        {
            //textBox.Focus();
        }

        public string InputValue = null;
        private void textBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter) OKButton_Click(OKButton, new RoutedEventArgs());
            else if (e.Key == Key.Escape) CancelButton_Click(CancelButton, new RoutedEventArgs());
        }
        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            InputValue = textBox.Text;
            this.DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}

