﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using System.Collections.ObjectModel;
using XTExam.CodeSharing.Entities;

namespace XTExam.Views_Admin.Paper.SubPack.controls
{
    public partial class UISetBlanks : UserControl
    {
        public DataProcessing.UserRegister.UserInfo myId { set; get; }
        public UISetBlanks(DataProcessing.UserRegister.UserInfo myID)
        {
            this.myId = myID;
            InitializeComponent();
        }

        private void LayoutRoot_Loaded(object sender, RoutedEventArgs e)
        {
            if (myId == null || !myId.hasId)
            {
                this.IsEnabled = false;
                return;
            }
        }

        public void SetBlanks(string[] blanks)
        {
            textBox_BlankValueList.Text = "";
            for (int i = 0; i < blanks.Length; i++)
            {
                AddBlankValue(blanks[i]);
            }
        }
        public void SetBlanks(List<string> blankCollection)
        {
            textBox_BlankValueList.Text = "";
            for (int i = 0; i < blankCollection.Count; i++)
            {
                AddBlankValue(blankCollection[i]);
            }
        }
        private void AddBlankValue(string value)
        {
            while (value.Contains("\r\n")) value = value.Replace("\r\n", "");
            while (value.Contains("\r")) value = value.Replace("\r", "");
            while (value.Contains("\t")) value = value.Replace("\t", "");
            value = value.Trim();
            if (value.Length > 0) textBox_BlankValueList.Text += value + "\r\n";
        }
        public List<string> GetBlanks()
        {
            string[] blanks = textBox_BlankValueList.Text.Split(new string[] { "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);
            List<string> result = new List<string>();
            for (int i = 0; i < blanks.Length; i++)
            {
                if (blanks.Length == 0) continue;
                result.Add(blanks[i]);
            }
            return result;
        }

        public event EventHandler UI_Set_BlankComplete;
        public event EventHandler UI_EnSet_BlankComplete;
        public string UI_EnSet_BlankComplete_Value;
        public void UI_SetBlanks(string uiSubjectText, int startIndex, int endIndex)
        {
            if (startIndex == endIndex) return;
            string selection = uiSubjectText.Substring(startIndex, (endIndex - startIndex));
            List<int> blankIndexes = new List<int>();
            int testIndex = -1;
            while (true)
            {
                testIndex = uiSubjectText.IndexOf("【空缺】", testIndex + 1);
                if (testIndex == -1) break;
                else blankIndexes.Add(testIndex);
            }
            blankIndexes.Sort();
            if (selection == "【空缺】")
            {
                for (int i = blankIndexes.Count - 1; i >= 0; i--)
                {
                    if (blankIndexes[i] == startIndex)
                    {
                        List<string> orgBlanks = GetBlanks();
                        UI_EnSet_BlankComplete_Value = orgBlanks[i];
                        while (UI_EnSet_BlankComplete_Value.Contains("\r\n")) UI_EnSet_BlankComplete_Value = UI_EnSet_BlankComplete_Value.Replace("\r\n", "");
                        while (UI_EnSet_BlankComplete_Value.Contains("\r")) UI_EnSet_BlankComplete_Value = UI_EnSet_BlankComplete_Value.Replace("\r", "");
                        while (UI_EnSet_BlankComplete_Value.Contains("\t")) UI_EnSet_BlankComplete_Value = UI_EnSet_BlankComplete_Value.Replace("\t", "");
                        UI_EnSet_BlankComplete_Value = UI_EnSet_BlankComplete_Value.Trim();
                        orgBlanks.RemoveAt(i);
                        SetBlanks(orgBlanks);
                        if (UI_EnSet_BlankComplete != null) UI_EnSet_BlankComplete(this, new EventArgs());
                        break;
                    }
                }
            }
            else if (!selection.Contains("【") && !selection.Contains("】") && !(selection == "空" || selection == "缺" || selection == "空缺"))
            {
                List<string> orgBlanks = GetBlanks();
                bool inserted = false;
                for (int i = blankIndexes.Count - 1; i >= 0; i--)
                {
                    if (blankIndexes[i] < startIndex)
                    {
                        orgBlanks.Insert(i + 1, selection);
                        inserted = true;
                        break;
                    }
                }
                if (!inserted)
                {
                    orgBlanks.Insert(0, selection);
                }
                SetBlanks(orgBlanks);
                if (UI_Set_BlankComplete != null) UI_Set_BlankComplete(this, new EventArgs());
            }
        }

        public void SetBlanksAuditType(DataProcessing.Depot.Subject.BlanksAuditType audType)
        {
            if (audType == DataProcessing.Depot.Subject.BlanksAuditType.Percentage) radioButton_P.IsChecked = true;
            else radioButton_M.IsChecked = true;
        }
        public DataProcessing.Depot.Subject.BlanksAuditType GetBlanksAuditType()
        {
            if (radioButton_P.IsChecked == true) return DataProcessing.Depot.Subject.BlanksAuditType.Percentage;
            else return DataProcessing.Depot.Subject.BlanksAuditType.Match;
        }

        public void SetData2Subject(ref DataProcessing.Depot.Subject target)
        {
            target.blanksAnswers = GetBlanks();
            target.blanksAuditType = GetBlanksAuditType();
        }
    }
}
