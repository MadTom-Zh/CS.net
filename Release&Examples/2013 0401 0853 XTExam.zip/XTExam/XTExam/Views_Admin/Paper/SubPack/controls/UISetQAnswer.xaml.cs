﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.CodeSharing.Entities;

namespace XTExam.Views_Admin.Paper.SubPack.controls
{
    public partial class UISetQAnswer : UserControl
    {
        public DataProcessing.UserRegister.UserInfo myId { set; get; }
        public UISetQAnswer(DataProcessing.UserRegister.UserInfo myID)
        {
            this.myId = myID;
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            if (myId == null || !myId.hasId)
            {
                this.IsEnabled = false;
                return;
            }
        }

        public void SetAnswer(string value)
        {
            textBox_answer.Text = value;
        }
        public string GetAnswer()
        {
            string result = textBox_answer.Text.Replace("\r", "\r\n");
            result = result.Replace("\n\n", "\n");
            return result;
        }

        public void SetData2Subject(ref DataProcessing.Depot.Subject target)
        {
            target.qAnswer = GetAnswer();
        }
    }
}
