﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using System.Net.Browser;
using System.Collections.ObjectModel;
using XTExam.CodeSharing.Entities;

namespace XTExam.Views_Admin.Paper.SubPack.controls
{
    public partial class UISetMuti : UserControl
    {
        public DataProcessing.UserRegister.UserInfo myId { set; get; }
        public UISetMuti(DataProcessing.UserRegister.UserInfo myID)
        {
            this.myId = myID;
            InitializeComponent();
        }

        private void LayoutRoot_Loaded(object sender, RoutedEventArgs e)
        {
            if (myId == null || !myId.hasId)
            {
                this.IsEnabled = false;
                return;
            }
        }

        private void button_create_Click(object sender, RoutedEventArgs e)
        {
            UISetMuti_inputBox inputWin = new UISetMuti_inputBox();
            inputWin.Closed += new EventHandler(inputWin_Closed);
            inputWin.Show();
        }
        void inputWin_Closed(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            UISetMuti_inputBox target = (UISetMuti_inputBox)sender;
            if (target.DialogResult == true)
            {
                AddOption(target.InputValue.Replace("\r\n", "").Replace("\t", ""));
            }
        }
        private void AddOption(string opt)
        {
            CheckBox newItem = new CheckBox();
            newItem.Content = opt;
            listBox_options.Items.Add(newItem);
        }

        private void button_del_Click(object sender, RoutedEventArgs e)
        {
            if (listBox_options.SelectedIndex >= 0)
            {
                listBox_options.Items.RemoveAt(listBox_options.SelectedIndex);
            }
        }

        public void SetOptions(string[] options)
        {
            string opt;
            listBox_options.Items.Clear();
            for (int i = 0; i < options.Length; i++)
            {
                opt = options[i];
                opt = opt.Trim();
                opt = opt.Replace("\t", "");
                if (opt.Length > 0)
                {
                    AddOption(opt);
                }
            }
        }
        public void TrySetAnswer(string ansSequence)
        {
            try
            {
                CheckBox opt;
                for (int i = 0; i < listBox_options.Items.Count; i++)
                {
                    opt = (CheckBox)listBox_options.Items[i];
                    opt.IsChecked = (ansSequence[i] != '-');
                }
            }
            catch (Exception) { }
        }
        public void SetAudType(DataProcessing.Depot.Subject.MutiAuditType type)
        {
            if (type == DataProcessing.Depot.Subject.MutiAuditType.Percentage) radioButton_R.IsChecked = true;
            else radioButton_M.IsChecked = true;
        }

        public List<string> GetOptions()
        {
            List<string> result = new List<string>();
            CheckBox option;
            for (int i = 0; i < listBox_options.Items.Count; i++)
            {
                option = (CheckBox)listBox_options.Items[i];
                result.Add(option.Content.ToString());
            }
            return result;
        }
        public string GetAnswerSequence()
        {
            string result = "";
            CheckBox option;
            for (int i = 0; i < listBox_options.Items.Count; i++)
            {
                option = (CheckBox)listBox_options.Items[i];
                result += (option.IsChecked == true) ? "R" : "-";
            }
            return result;
        }
        public DataProcessing.Depot.Subject.MutiAuditType GetMutiAudType()
        {
            if (radioButton_R.IsChecked == true) return DataProcessing.Depot.Subject.MutiAuditType.Percentage;
            else return DataProcessing.Depot.Subject.MutiAuditType.Match;
        }

        public void SetData2Subject(ref DataProcessing.Depot.Subject target)
        {
            target.mutiOptions = GetOptions();
            target.IOMutiAnswers = GetAnswerSequence();
            target.mutiAuditType = GetMutiAudType();
        }
    }
}
