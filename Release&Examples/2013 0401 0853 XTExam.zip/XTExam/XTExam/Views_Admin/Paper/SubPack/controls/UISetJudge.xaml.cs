﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using System.Collections.ObjectModel;
using XTExam.CodeSharing.Entities;

namespace XTExam.Views_Admin.Paper.SubPack.controls
{
    public partial class UISetJudge : UserControl
    {
        public DataProcessing.UserRegister.UserInfo myId { set; get; }
        public UISetJudge(DataProcessing.UserRegister.UserInfo myID)
        {
            this.myId = myID;
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            if (myId == null || !myId.hasId)
            {
                this.IsEnabled = false;
                return;
            }
        }

        public void SetOptions(string[] opts)
        {
            textBox_opt1.Text = opts[0];
            textBox_opt2.Text = opts[1];
        }
        public void SetAns_LeftIsRight(bool isIt)
        {
            if (isIt) radioButton_A.IsChecked = true;
            else radioButton_B.IsChecked = true;
        }

        public List<string> GetOptions()
        {
            List<string> result = new List<string>();
            result.Add(textBox_opt1.Text.Replace("\r", "").Replace("\t", ""));
            result.Add(textBox_opt2.Text.Replace("\r", "").Replace("\t", ""));
            return result;
        }
        public bool GetAns_LeftIsRight()
        {
            return (radioButton_A.IsChecked == true);
        }

        public void SetData2Subject(ref DataProcessing.Depot.Subject target)
        {
            target.judgeOptions = GetOptions();
            target.judgeAnswer_leftIsRight = GetAns_LeftIsRight();
        }
    }
}
