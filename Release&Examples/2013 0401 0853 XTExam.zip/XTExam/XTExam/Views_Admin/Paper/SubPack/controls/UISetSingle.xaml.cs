﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using System.Collections.ObjectModel;
using XTExam.CodeSharing.Entities;

namespace XTExam.Views_Admin.Paper.SubPack.controls
{
    public partial class UISetSingle : UserControl
    {
        public DataProcessing.UserRegister.UserInfo myId
        {
            set;
            get;
        }
        public UISetSingle(DataProcessing.UserRegister.UserInfo myID)
        {
            this.myId = myID;
            InitializeComponent();
        }
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            if (myId == null || !myId.hasId)
            {
                this.IsEnabled = false;
            }
        }

        private void textBox_single_options_TextChanged(object sender, TextChangedEventArgs e)
        {
            int optsCount = GetOptions().Count;
            if (listBox_single_answer.Items.Count != optsCount)
            {
                ReBuildRadios(optsCount);
            }
            TrySetAnswer(trySetAnswerIndex + "");
        }
        private void ReBuildRadios(int count)
        {
            listBox_single_answer.Items.Clear();
            RadioButton newOpt;
            for (int i = 0; i < count; i++)
            {
                newOpt = new RadioButton();
                newOpt.GroupName = "singleAnswer";
                newOpt.Content = "第[" + (i + 1) + "]项";
                listBox_single_answer.Items.Add(newOpt);
            }
        }
        private void listBox_single_answer_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            trySetAnswerIndex = listBox_single_answer.SelectedIndex;
        }

        public ObservableCollection<string> GetOptions()
        {
            string optsStr = textBox_single_options.Text;
            string[] lines = optsStr.Split(new string[] { "\r\n", "\r" }, StringSplitOptions.None);
            string line;
            ObservableCollection<string> result = new ObservableCollection<string>();
            for (int i = 0; i < lines.Length; i++)
            {
                line = lines[i].Trim();
                if (line.Length > 0)
                {
                    result.Add(line);
                }
            }
            return result;
        }
        public void SetOptions(string[] opts, bool refresh)
        {
            string opt, optionsText = "";
            int optCount = 0;
            for (int i = 0; i < opts.Length; i++)
            {
                opt = opts[i].Trim();
                if (opt.Length > 0) optCount++;
                optionsText += opt + "\r\n";
            }
            textBox_single_options.Text = optionsText;
            ReBuildRadios(optCount);
        }
        private int trySetAnswerIndex = 0;
        public void TrySetAnswer(string index)
        {
            try
            {
                int ind = int.Parse(index);
                RadioButton target = (RadioButton)listBox_single_answer.Items[ind];
                trySetAnswerIndex = ind;
                target.IsChecked = true;
            }
            catch (Exception) { }
        }
        public int TryGetAnswer()
        {
            int result = 0;
            try
            {
                RadioButton target;
                for (int i = 0; i < listBox_single_answer.Items.Count; i++)
                {
                    target = (RadioButton)listBox_single_answer.Items[i];
                    if (target.IsChecked == true)
                    {
                        result = i;
                        break;
                    }
                }
            }
            catch (Exception) { }
            return result;
        }

        public void SetData2Subject(ref DataProcessing.Depot.Subject target)
        {
            string IO = "";
            foreach (string opt in GetOptions())
            {
                if (IO.Length > 0) IO += DataProcessing.Depot.Subject.JOIN_SEPARATOR;
                IO += opt;
            }
            target.IOSingleOptions = IO;
            target.singleAnswer_curIndex = TryGetAnswer();
        }

    }
}
