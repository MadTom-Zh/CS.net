﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.ServiceReference_Depot;
using System.Collections.ObjectModel;
using XTExam.CodeSharing.Entities;

namespace XTExam.Views_Admin.Paper.SubPack
{
    public partial class ViewDepotDetal : ChildWindow
    {
        private string _depotPath;
        public DataProcessing.UserRegister.UserInfo myId { set; get; }
        public ViewDepotDetal(string path, DataProcessing.UserRegister.UserInfo myId)
        {
            _depotPath = path;
            this.myId = myId;
            InitializeComponent();
        }

        private Service_DepotClient serviceClient;
        private void ChildWindow_Loaded(object sender, RoutedEventArgs e)
        {
            if (_depotPath == null || _depotPath.Length == 0)
            {
                this.IsEnabled = false;
                return;
            }
            else if (myId == null || !myId.hasId)
            {
                this.IsEnabled = false;
                return;
            }
            serviceClient = new Service_DepotClient();
            serviceClient.LoadDepotDetailCompleted += new EventHandler<LoadDepotDetailCompletedEventArgs>(serviceClient_LoadDepotDetailCompleted);
            serviceClient.LoadDepotCompleted += new EventHandler<LoadDepotCompletedEventArgs>(serviceClient_LoadDepotCompleted);
            serviceClient.SaveDepotDetailCompleted += new EventHandler<SaveDepotDetailCompletedEventArgs>(serviceClient_SaveDepotDetailCompleted);

            infoPanel.ShowInfo("正在读取题库信息头……", true);
            serviceClient.LoadDepotDetailAsync(_depotPath);
        }
        void serviceClient_LoadDepotDetailCompleted(object sender, LoadDepotDetailCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result != null)
                {
                    textBox_title.Text = e.Result[0];
                    textBox_remark.Text = e.Result[1];
                    textBox_createTime.Text = e.Result[2];
                    textBox_creater.Text = e.Result[3];
                    textBox_modifyTime.Text = e.Result[4];
                    textBox_modifier.Text = e.Result[5];
                    infoPanel.ShowInfo("正在尝试加载题库……", true);
                    serviceClient.LoadDepotAsync(_depotPath, myId.id);
                }
                else
                {
                    infoPanel.ShowInfo("未能成功获取题库信息头，请关闭后重试", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }
        private void button_saveRemark_Click(object sender, RoutedEventArgs e)
        {
            ObservableCollection<string> newHeader = new ObservableCollection<string>();
            newHeader.Add(null);
            newHeader.Add(textBox_remark.Text);
            newHeader.Add(null);
            newHeader.Add(null);
            newHeader.Add(null);
            newHeader.Add(null);
            infoPanel.ShowInfo("正在保存描述……", true);
            serviceClient.SaveDepotDetailAsync(_depotPath, newHeader, myId.id);
        }
        void serviceClient_SaveDepotDetailCompleted(object sender, SaveDepotDetailCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result)
                {
                    infoPanel.ShowInfo("保存成功", true);
                }
                else
                {
                    infoPanel.ShowInfo("未能获取题库，请关闭后重试", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }
        private DataProcessing.Depot _depot;
        void serviceClient_LoadDepotCompleted(object sender, LoadDepotCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result != null)
                {
                    _depot = new DataProcessing.Depot( e.Result);
                    FillAllSubjects2UI();
                    infoPanel.ShowInfo("成功获取题库", false);
                }
                else
                {
                    infoPanel.ShowInfo("未能获取题库，请关闭后重试", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }
        private void FillAllSubjects2UI()
        {
            // 填充第二页签
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

    }
}

