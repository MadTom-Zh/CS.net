﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.Views_Admin.Paper.SubPack;
using XTExam.ServiceReference_HallAdmin;
using XTExam.CodeSharing.Entities;

namespace XTExam.Views_Admin.Paper
{
    public partial class Sub_MakeExamHall : UserControl
    {
        public DataProcessing.UserRegister.UserInfo myId
        {
            set;
            get;
        }
        public Sub_MakeExamHall(DataProcessing.UserRegister.UserInfo myID)
        {
            this.myId = myID;
            InitializeComponent();

            if (myID == null || !myId.hasId)
            {
                this.IsEnabled = false;
                return;
            }
            selectDocDlg = new OpenFileDialog();
            selectDocDlg.Filter = "Office Word Document|*.doc;*.docx";
            selectDocDlg.Multiselect = false;

            //hallInfo = new HallInfoHelper();
            hallInfo = new DataProcessing.ExamHall.HallInfo();
            serviceClient = new Service_HallAdminClient();
            serviceClient.AddHallCompleted += new EventHandler<System.ComponentModel.AsyncCompletedEventArgs>(serviceClient_AddHallCompleted);
            serviceClient.UploadExtraFileCompleted += new EventHandler<System.ComponentModel.AsyncCompletedEventArgs>(serviceClient_UploadExtraFileCompleted);
        }
        //HallInfoHelper hallInfo;
        DataProcessing.ExamHall.HallInfo hallInfo;
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
        }


        private void button_cancel_Click(object sender, RoutedEventArgs e)
        {
            tabItem_note.Focus();
            tabItem_note.IsSelected = true;
        }

        #region 设置考试名称
        private void textBox_hallName_TextChanged(object sender, TextChangedEventArgs e)
        {
            hallInfo.hallName = textBox_hallName.Text;
        }
        #endregion

        #region 选择考试用户列表
        private void button_chooseExamerListPath_Click(object sender, RoutedEventArgs e)
        {
            SelectUserList sULWin = new SelectUserList();
            sULWin.myID = myId;
            sULWin.Closed += new EventHandler(sULWin_Closed);
            sULWin.Show();
        }
        void sULWin_Closed(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            SelectUserList target = (SelectUserList)sender;
            if (target.DialogResult == true)
            {
                if (target.selectedUserListPath != null)
                {
                    textBox_examerListPath.Text = target.selectedUserListPath;
                    hallInfo.examerListPath = textBox_examerListPath.Text;
                }
            }
        }
        #endregion

        #region 设置试卷-离线考试
        private void checkBox_useOffLineExam_Checked(object sender, RoutedEventArgs e)
        {
            hallInfo.isSubmitPaper = checkBox_useOffLineExam.IsChecked.Value;
            if (checkBox_useOffLineExam.IsChecked == true) grid_makePaperElement.Visibility = Visibility.Collapsed;
            else grid_makePaperElement.Visibility = Visibility.Visible;
        }

        OpenFileDialog selectDocDlg;
        private void button_chooseDoc_Click(object sender, RoutedEventArgs e)
        {
            if (selectDocDlg.ShowDialog() == true)
            {
                textBox_docName.Text = selectDocDlg.File.Name;
                hallInfo.isSubmitPaper_docName = textBox_docName.Text;
            }
        }
        #endregion

        #region 设置试卷-组合试卷
        private void button_addCaption_Click(object sender, RoutedEventArgs e)
        {
            Hall_makeCaption capWin = new Hall_makeCaption();
            capWin.Closed += new EventHandler(capWin_Closed);
            capWin.Show();
        }
        void capWin_Closed(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            Hall_makeCaption target = (Hall_makeCaption)sender;
            if (target.DialogResult == true)
            {
                target.SetAddData2HallInfo(ref hallInfo);
                ReBuildList_PaperElements();
            }
        }

        private void ReBuildList_PaperElements()
        {
            listBox_paperElements.Items.Clear();
            //HallInfoHelper.PaperElement elm;
            DataProcessing.ExamHall.HallInfo.PaperElement elm;
            StackPanel lItem;
            TextBlock subText = null, text = null;
            for (int i = 0; i < hallInfo.elements.Count; i++)
            {
                elm = hallInfo.elements[i];
                lItem = new StackPanel();
                lItem.Orientation = Orientation.Vertical;
                switch (elm.type)
                {
                    case DataProcessing.Depot.Subject.Type.Caption:
                        subText = new TextBlock();
                        subText.Text = "标语";
                        subText.Text += "   字号【" + elm.captionSize + "】";
                        subText.Text += "，对齐方式 " + elm.captionAlign.ToString();
                        text = new TextBlock(); text.Text = elm.caption;
                        break;
                    case DataProcessing.Depot.Subject.Type.Single:
                        subText = new TextBlock(); subText.Text = "单选题块";
                        break;
                    case DataProcessing.Depot.Subject.Type.Muti:
                        subText = new TextBlock(); subText.Text = "多选题块";
                        break;
                    case DataProcessing.Depot.Subject.Type.Judge:
                        subText = new TextBlock(); subText.Text = "判断题块";
                        break;
                    case DataProcessing.Depot.Subject.Type.Blanks:
                        subText = new TextBlock(); subText.Text = "填空题块";
                        break;
                    case DataProcessing.Depot.Subject.Type.QAnswer:
                        subText = new TextBlock(); subText.Text = "问答题块";
                        break;
                }
                if (elm.type != DataProcessing.Depot.Subject.Type.Caption)
                {
                    text = new TextBlock();
                    text.FontSize = 14;
                    text.Text = "来自题库【" + elm.sourceDepot + "】，抽取【" + elm.subjectCount + "】题，抽取方式【" + elm.gainType + "】";
                }
                lItem.Children.Add(subText);
                lItem.Children.Add(text);
                listBox_paperElements.Items.Add(lItem);
            }
        }

        private void button_addSubjBlock_Click(object sender, RoutedEventArgs e)
        {
            Button target = (Button)sender;
            string btnName = target.Name.ToLower();
            DataProcessing.Depot.Subject.Type elmType = DataProcessing.Depot.Subject.Type.Caption;
            if (btnName.Contains("single")) elmType = DataProcessing.Depot.Subject.Type.Single;
            if (btnName.Contains("muti")) elmType = DataProcessing.Depot.Subject.Type.Muti;
            if (btnName.Contains("judge")) elmType = DataProcessing.Depot.Subject.Type.Judge;
            if (btnName.Contains("blank")) elmType = DataProcessing.Depot.Subject.Type.Blanks;
            if (btnName.Contains("qanswer")) elmType = DataProcessing.Depot.Subject.Type.QAnswer;
            Hall_makeSubjBlock makeSubjWin = new Hall_makeSubjBlock(myId, elmType);
            makeSubjWin.Closed += new EventHandler(makeSubjWin_Closed);
            makeSubjWin.Show();
        }
        void makeSubjWin_Closed(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            Hall_makeSubjBlock target = (Hall_makeSubjBlock)sender;
            if (target.DialogResult == true)
            {
                target.GetAddData2HallInfo(ref hallInfo);
                ReBuildList_PaperElements();
            }
        }

        private void button_dropElement_Click(object sender, RoutedEventArgs e)
        {
            if (listBox_paperElements.SelectedIndex > 0)
            {
                hallInfo.elements.RemoveAt(listBox_paperElements.SelectedIndex);
                ReBuildList_PaperElements();
            }
        }
        #endregion


        #region 设置时间
        private void datePicker_examStart_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            hallInfo.startTime = datePicker_examStart.SelectedDate.Value;
        }
        private void datePicker_examEnd_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            hallInfo.endTime = datePicker_examEnd.SelectedDate.Value;
        }

        private void checkBox_onetimeExam_Checked(object sender, RoutedEventArgs e)
        {
            hallInfo.isOneTimeExam = checkBox_onetimeExam.IsChecked;
        }
        private void slider_examTimeLength_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (textBox_examTimeLength == null) return;
            textBox_examTimeLength.Text = "" + slider_examTimeLength.Value.ToString("##.00");
            hallInfo.examinatingTimeLength = slider_examTimeLength.Value;
        }
        #endregion

        #region 查看设置概要
        private void tabItem_Finish_GotFocus(object sender, RoutedEventArgs e)
        {
            bool isPass = true;
            textBox_resume.Text = "";
            string reLine = "\r\n";
            string tabSpace = "    ";
            string text = reLine + "考试名称：" + reLine;
            hallInfo.hallName = textBox_hallName.Text;
            text += tabSpace + hallInfo.hallName + reLine;
            if (hallInfo.hallName.Length == 0) isPass = false;
            text += reLine + "参与人员名单：" + reLine;
            text += tabSpace + hallInfo.examerListPath + reLine;
            hallInfo.examerListPath = textBox_examerListPath.Text;
            if (hallInfo.examerListPath.Length == 0) isPass = false;
            text += reLine + "考试类型：" + reLine;
            text += tabSpace + (hallInfo.isSubmitPaper ? "离线考试" : "在线考试") + reLine;
            if (hallInfo.isSubmitPaper)
            {
                text += reLine + "试卷文件名：" + reLine;
                text += tabSpace + hallInfo.isSubmitPaper_docName + reLine;
                if (hallInfo.isSubmitPaper_docName.Length == 0) isPass = false;
            }
            else
            {
                bool hasSubjects = false;
                text += reLine + "试卷内容配置：" + reLine;
                DataProcessing.ExamHall.HallInfo.PaperElement elm;
                bool isCaption;
                for (int i = 0; i < hallInfo.elements.Count; i++)
                {
                    elm = hallInfo.elements[i];
                    isCaption = false;
                    switch (elm.type)
                    {
                        case DataProcessing.Depot.Subject.Type.Caption:
                            text += tabSpace + "【标语】" + elm.caption + "，字号【" + elm.captionSize + "】，对齐方式【" + elm.captionAlign + "】" + reLine;
                            isCaption = true;
                            break;
                        case DataProcessing.Depot.Subject.Type.Single:
                            text += tabSpace + "【单选题块】来自题库【";
                            break;
                        case DataProcessing.Depot.Subject.Type.Muti:
                            text += tabSpace + "【多选题块】来自题库【";
                            break;
                        case DataProcessing.Depot.Subject.Type.Judge:
                            text += tabSpace + "【判断题块】来自题库【";
                            break;
                        case DataProcessing.Depot.Subject.Type.Blanks:
                            text += tabSpace + "【填空题块】来自题库【";
                            break;
                        case DataProcessing.Depot.Subject.Type.QAnswer:
                            text += tabSpace + "【简答题块】来自题库【";
                            break;
                    }
                    if (!isCaption)
                    {
                        hasSubjects = true;
                        text += elm.sourceDepot + "】，抽取【" + elm.subjectCount + "】题，抽取方式【";
                        text += ((elm.gainType == DataProcessing.ExamHall.HallInfo.PaperElement.GainType.FromBeginning) ? "从开头" : (elm.gainType == DataProcessing.ExamHall.HallInfo.PaperElement.GainType.FromEnding) ? "从结尾" : "随机") + "】" + reLine;
                    }
                }
                if (!hasSubjects) isPass = false;
            }
            text += reLine + "考试起止时间：" + reLine;
            text += tabSpace + "启动时间 " + hallInfo.startTime.ToString("yyyy-MM-dd") + reLine;
            text += tabSpace + "停止时间 " + hallInfo.endTime.ToString("yyyy-MM-dd") + reLine;
            if (hallInfo.endTime <= DateTime.Now) isPass = false;
            text += reLine + "答卷限定时间：" + reLine;
            if (hallInfo.examinatingTimeLength == 0) hallInfo.examinatingTimeLength = slider_examTimeLength.Value;
            text += tabSpace + "" + hallInfo.examinatingTimeLength.ToString("##.00") + "小时" + reLine;
            if (hallInfo.examinatingTimeLength <= 0.1) isPass = false;
            textBox_resume.Text = text;
            button_finish.IsEnabled = isPass;
        }
        #endregion

        Service_HallAdminClient serviceClient;
        private void button_finish_Click(object sender, RoutedEventArgs e)
        {
            if (button_finish_needRe_UploadDoc)
            {
                button_finish_StartUpLoadExFile();
            }
            else
            {
                infoPanel.ShowInfo("正在尝试创建本次考试……", true);
                serviceClient.AddHallAsync(hallInfo.IOContent);
            }
            button_finish_needRe_UploadDoc = false;
        }
        private bool button_finish_needRe_UploadDoc = false;
        private byte[] extraFileData;
        private int extraFileDataOffSet = 0;
        private int extraFile_BlockMaxSize = 1024;
        void serviceClient_AddHallCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            button_finish_needRe_UploadDoc = false;
            if (e.Error == null)
            {
                if (hallInfo.isSubmitPaper)
                {
                    button_finish_StartUpLoadExFile();
                }
                else
                {
                    infoPanel.ShowInfo("创建完成！", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }
        private void button_finish_StartUpLoadExFile()
        {
            infoPanel.ShowInfo("正在启动文件上载进程……", true);
            extraFileData = new byte[selectDocDlg.File.Length];
            selectDocDlg.File.OpenRead().Read(extraFileData, 0, (int)selectDocDlg.File.Length);
            byte[] data2Up;
            if (extraFileData.Length < extraFile_BlockMaxSize) data2Up = new byte[extraFileData.Length];
            else data2Up = new byte[extraFile_BlockMaxSize];
            for (int i = 0; i < data2Up.Length; i++)
            {
                data2Up[i] = extraFileData[i];
            }
            extraFileDataOffSet = data2Up.Length;
            serviceClient.UploadExtraFileAsync(myId.id, hallInfo.hallName, textBox_docName.Text, data2Up, false);
        }
        void serviceClient_UploadExtraFileCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (extraFileDataOffSet == extraFileData.Length)
                {
                    infoPanel.ShowInfo("全部完成！已成功完成附加文件上载", false);
                    return;
                }
                infoPanel.ShowInfo("已上载数据[" + extraFileDataOffSet + "]字节，完成进度 " + (100.0 * extraFileDataOffSet / extraFileData.Length).ToString("##.00") + " %", true);
                byte[] data2Up;
                if (extraFileData.Length - extraFileDataOffSet < extraFile_BlockMaxSize) data2Up = new byte[extraFileData.Length - extraFileDataOffSet];
                else data2Up = new byte[extraFile_BlockMaxSize];
                for (int i = 0; i < data2Up.Length; i++)
                {
                    data2Up[i] = extraFileData[i + extraFileDataOffSet];
                }
                extraFileDataOffSet += data2Up.Length;
                serviceClient.UploadExtraFileAsync(myId.id, hallInfo.hallName, textBox_docName.Text, data2Up, true);
            }
            else
            {
                button_finish_needRe_UploadDoc = true;
                infoPanel.ShowInfo("此时，在此点击 完成 按钮进行重试；" + e.Error.Message, false);
            }
        }
    }
}
