﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using System.Windows.Media.Imaging;
using XTExam.ServiceReference_Depot;
using System.Collections.ObjectModel;
using XTExam.Views_Admin.Paper.SubPack;
using XTExam.Views_Admin.Paper.SubPack.controls;
using XTExam.Controls;
using XTExam.CodeSharing.Entities;

namespace XTExam.Views_Admin.Paper
{
    public partial class Sub_Depot : UserControl
    {
        public DataProcessing.UserRegister.UserInfo myId
        {
            set;
            get;
        }
        public Sub_Depot(DataProcessing.UserRegister.UserInfo myID)
        {
            this.myId = myID;
            InitializeComponent();
        }


        private Service_DepotClient serviceClient;

        private UISetSingle uiSetSingle;
        private UISetMuti uiSetMuti;
        private UISetJudge uiSetJudge;
        private UISetBlanks uiSetBlanks;
        private UISetQAnswer uiSetQAnswer;
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (myId == null || !myId.hasId)
            {
                this.IsEnabled = false;
                return;
            }
            tabControl_depotCtrls.IsEnabled = listBox_subject.IsEnabled = false;

            infoPanel.ProcessingStart += new EventHandler(infoPanel_ProcessingStart);
            infoPanel.ProcessingComplete += new EventHandler(infoPanel_ProcessingComplete);

            treeView_Depot.myID = myId;
            treeView_Depot.SelectedNodeChanged += new EventHandler(treeView_Depot_SelectedNodeChanged);
            treeView_Depot.InfomatingStart += new EventHandler(treeView_Depot_InfomatingStart);
            treeView_Depot.InfomatingStop += new EventHandler(treeView_Depot_InfomatingStop);

            uiSetSingle = new UISetSingle(myId);
            uiSetMuti = new UISetMuti(myId);
            uiSetJudge = new UISetJudge(myId);
            uiSetBlanks = new UISetBlanks(myId);
            uiSetQAnswer = new UISetQAnswer(myId);

            uiSetBlanks.UI_Set_BlankComplete += new EventHandler(uiSetBlanks_UI_Set_BlankComplete);
            uiSetBlanks.UI_EnSet_BlankComplete += new EventHandler(uiSetBlanks_UI_EnSet_BlankComplete);

            serviceClient = new Service_DepotClient();
            serviceClient.AddDirCompleted += new EventHandler<AddDirCompletedEventArgs>(serviceClient_AddDirCompleted);
            serviceClient.AddPotCompleted += new EventHandler<AddPotCompletedEventArgs>(serviceClient_AddPotCompleted);
            serviceClient.DropStorItemCompleted += new EventHandler<DropStorItemCompletedEventArgs>(serviceClient_DropStorItemCompleted);

            serviceClient.LoadDepotCompleted += new EventHandler<LoadDepotCompletedEventArgs>(serviceClient_LoadDepotCompleted);

            serviceClient.SaveDepotCompleted += new EventHandler<SaveDepotCompletedEventArgs>(serviceClient_SaveDepotCompleted);

            //button_reloadTree_Click(button_reloadTree, e);
            radioButton_single_Checked(radioButton_pSingle, new RoutedEventArgs());
        }

        void treeView_Depot_InfomatingStart(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            infoPanel.ShowInfo(treeView_Depot.Infomating, true);
        }
        void treeView_Depot_InfomatingStop(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            infoPanel.ShowInfo(treeView_Depot.Infomating, false);
        }

        void infoPanel_ProcessingStart(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            this.Cursor = Cursors.Wait;
        }
        void infoPanel_ProcessingComplete(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            this.Cursor = Cursors.Arrow;
        }


        #region 存储节点操作，增加、删除
        private void button_addDirSub_Click(object sender, RoutedEventArgs e)
        {
            if (treeView_Depot.selectedNodeFullPath == null)
            {
                infoPanel.ShowInfo("请选择一个父节点", false);
                return;
            }
            string path = treeView_Depot.selectedNodeFullPath;
            path += "\\" + textBox_dir.Text;
            serviceClient.AddDirAsync(path, myId.id);
        }
        private void button_addDir_Click(object sender, RoutedEventArgs e)
        {
            string path = "";
            if (treeView_Depot.selectedNodeFullPath != null) path = treeView_Depot.selectedNodeFullPath;
            if (path.Contains('\\')) path = path.Substring(0, path.LastIndexOf('\\'));
            else path = "";
            path += "\\" + textBox_dir.Text;
            serviceClient.AddDirAsync(path, myId.id);
        }
        void serviceClient_AddDirCompleted(object sender, AddDirCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result)
                {
                    treeView_Depot.ReloadTree();
                    infoPanel.ShowInfo("添加成功", false);
                }
                else
                {
                    infoPanel.ShowInfo("未能成功添加，请重试……", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }

        private void button_addPotSub_Click(object sender, RoutedEventArgs e)
        {
            if (treeView_Depot.selectedNodeFullPath == null)
            {
                infoPanel.ShowInfo("请选择一个父节点", false);
                return;
            }
            string path = treeView_Depot.selectedNodeFullPath;
            path += "\\" + textBox_pot.Text;
            serviceClient.AddPotAsync(path, myId.id);
        }
        private void button_addPot_Click(object sender, RoutedEventArgs e)
        {
            string path = "";
            if (treeView_Depot.selectedNodeFullPath != null) path = treeView_Depot.selectedNodeFullPath;
            if (path.Contains('\\')) path = path.Substring(0, path.LastIndexOf('\\'));
            else path = "";
            path += "\\" + textBox_pot.Text;
            serviceClient.AddPotAsync(path, myId.id);
        }
        void serviceClient_AddPotCompleted(object sender, AddPotCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result)
                {
                    treeView_Depot.ReloadTree();
                    infoPanel.ShowInfo("添加成功", false);
                }
                else
                {
                    infoPanel.ShowInfo("未能成功添加，请重试……", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }

        private void button_drpNode_Click(object sender, RoutedEventArgs e)
        {
            if (treeView_Depot.selectedNodeFullPath == null)
            {
                infoPanel.ShowInfo("请选择一个节点", false);
                return;
            }
            string path = treeView_Depot.selectedNodeFullPath;
            serviceClient.DropStorItemAsync(path, myId.id);
        }
        void serviceClient_DropStorItemCompleted(object sender, DropStorItemCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result)
                {
                    treeView_Depot.ReloadTree();
                    infoPanel.ShowInfo("删除成功", false);
                }
                else
                {
                    infoPanel.ShowInfo("未能成功删除，请重试……", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }
        #endregion

        #region 读取题库、保存题库、追加题库
        private DataProcessing.Depot myDepot = new DataProcessing.Depot();
        void treeView_Depot_SelectedNodeChanged(object sender, EventArgs e)
        {
            //throw new NotImplementedException();

            if (treeView_Depot.selectedNodeFullPath == null)
            {
                button_upLoad.IsEnabled = false;
                tabControl_depotCtrls.IsEnabled = listBox_subject.IsEnabled = false;
            }
            else
            {
                if (treeView_Depot.selectedNodeFullPath_isDepot)
                {
                    listBox_subject.Items.Clear();
                    infoPanel.ShowInfo("正在尝试读取题库……", true);
                    serviceClient.LoadDepotAsync(treeView_Depot.selectedNodeFullPath, myId.id);
                }
            }
            tabControl_depotCtrls.IsEnabled = listBox_subject.IsEnabled = treeView_Depot.selectedNodeFullPath_isDepot;
        }
        void serviceClient_LoadDepotCompleted(object sender, LoadDepotCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result != null)
                {
                    myDepot.IOContent_Subjects = e.Result;
                    listBox_subject_ReloadSource(myDepot);
                    button_upLoad.IsEnabled = false;
                    infoPanel.ShowInfo("成功读取题库[" + treeView_Depot.selectedNodeFullPath + "]", false);
                }
                else
                {
                    infoPanel.ShowInfo("未能成功读取题库，请稍候再试", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }
        private void listBox_subject_ReloadSource(DataProcessing.Depot source)
        {
            StackPanel newItem;
            listBox_subject.Items.Clear();
            DataProcessing.Depot.Subject subject;
            //string subjectText;
            for (int i = 0; i < source.subjects.Count; i++)
            {
                subject = source.subjects[i];
                newItem = Templetes.UI.ListViewItem_Subject(subject.type, (i + 1) + "、" + subject.subject);
                listBox_subject.Items.Add(newItem);
            }
        }

        #endregion

        #region 批量添加试题
        private void button_PInput_ClearText_Click(object sender, RoutedEventArgs e)
        {
            textBox_PInput.Text = "";
        }
        private void button_PInput_Add_Click(object sender, RoutedEventArgs e)
        {
            infoPanel.ShowInfo("正在运算，请稍候……", true);
            DataProcessing.Depot.Subject helper;

            string inputText = textBox_PInput.Text;
            inputText = inputText.Replace("\r", "\r\n");
            inputText = inputText.Replace("\n\n", "\n");
            while (inputText.Contains("\r\n ")) inputText = inputText.Replace("\r\n ", "\r\n");
            while (inputText.Contains(" \r\n")) inputText = inputText.Replace(" \r\n", "\r\n");
            while (inputText.StartsWith("\r\n")) inputText = inputText.Substring(2);
            while (inputText.EndsWith("\r\n")) inputText = inputText.Substring(0, inputText.Length - 2);
            string subjHeader = "Subj:";
            string[] mBlocks = inputText.Split(new string[] { subjHeader }, StringSplitOptions.RemoveEmptyEntries);
            string oneBlock;

            string info = "";
            string subInfo = null;
            string blockTextLeft = "";
            int inputCount = 0;
            for (int i = 0; i < mBlocks.Length; i++)
            {
                oneBlock = subjHeader + mBlocks[i];
                helper = new DataProcessing.Depot.Subject();
                if (radioButton_pSingle.IsChecked == true)
                {
                    subInfo = helper.ScriptSingle_Set(oneBlock);
                }
                else if (radioButton_pMuti.IsChecked == true)
                {
                    subInfo = helper.ScriptMuti_Set(oneBlock);
                }
                else if (radioButton_pJudge.IsChecked == true)
                {
                    subInfo = helper.ScriptJudge_Set(oneBlock);
                }
                else if (radioButton_pBlanks.IsChecked == true)
                {
                    subInfo = helper.ScriptBlanks_Set(oneBlock);
                }
                else if (radioButton_pQAnswer.IsChecked == true)
                {
                    subInfo = helper.ScriptQAnswer_Set(oneBlock);
                }
                if (subInfo != null)
                {
                    blockTextLeft += oneBlock + "\r\n";
                    info += subInfo.Replace("[NO]", "" + (i + 1));
                }
                else
                {
                    bool orgSFound = false;
                    for (int j = myDepot.subjects.Count - 1; j >= 0; j--)
                    {
                        if (myDepot.subjects[j].subject == helper.subject)
                        {
                            if (myDepot.subjects[j].type == helper.type)
                            {
                                orgSFound = true;
                                if (checkBox_pOverWrite.IsChecked == true)
                                {
                                    myDepot.subjects[j].LineContent = helper.LineContent;
                                    inputCount++;
                                }
                                else info += (i + 1) + "题不可复写；";
                            }
                        }
                    }
                    if (!orgSFound)
                    {
                        myDepot.subjects.Add(helper);
                        inputCount++;
                    }
                }
            }
            listBox_subject_ReloadSource(myDepot);
            textBox_PInput.Text = blockTextLeft;
            info += "操作完成，添加(/复写)试题[" + inputCount + "]条";
            infoPanel.ShowInfo(info, false);
            if (inputCount > 0)
            {
                textBox_image.Text = "";
                button_upLoad.IsEnabled = true;
            }
        }
        private bool myDepot_Add(DataProcessing.Depot.Subject subject, bool isOverWrite)
        {
            DataProcessing.Depot.Subject subj;
            for (int i = myDepot.subjects.Count - 1; i >= 0; i--)
            {
                subj = myDepot.subjects[i];
                if (subj.subjectAligh == subject.subjectAligh)
                {
                    if (subj.subject == subject.subject)
                    {
                        if (!isOverWrite) return false;
                        else myDepot.subjects.RemoveAt(i);
                    }
                }
            }
            button_upLoad.IsEnabled = true;
            myDepot.subjects.Add(subject);
            return true;
        }
        private bool myDepot_RemoveAt(int index)
        {
            if (index < 0 || index >= myDepot.subjects.Count) return false;
            myDepot.subjects.RemoveAt(index);
            button_upLoad.IsEnabled = true;
            return true;
        }
        #endregion

        #region 上载题库
        private void button_upLoad_Click(object sender, RoutedEventArgs e)
        {
            if (treeView_Depot.selectedNodeFullPath == null)
            {
                infoPanel.ShowInfo("还没有选择一个题库", false);
            }
            else
            {
                infoPanel.ShowInfo("正在尝试保存题库……", true);
                serviceClient.SaveDepotAsync(treeView_Depot.selectedNodeFullPath, myDepot.IOContent_Subjects, myId.id);
            }
        }
        void serviceClient_SaveDepotCompleted(object sender, SaveDepotCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result)
                {
                    infoPanel.ShowInfo("保存成功！", false);
                }
                else
                {
                    infoPanel.ShowInfo("失败，请稍候再试", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error);
            }
        }
        #endregion

        #region 切换（单个、批量修改试题）页签，点击“题型”单选按钮
        private void tabItem_subjectPInput_GotFocus(object sender, RoutedEventArgs e)
        {
            if (treeView_Depot.selectedNodeFullPath == null || !treeView_Depot.selectedNodeFullPath_isDepot)
            {
                tabItem_subjectModify.IsSelected = true;
                tabItem_subjectModify.Focus();
                infoPanel.ShowInfo("请首选选择题库！", false);
            }
        }
        private void radioButton_single_Checked(object sender, RoutedEventArgs e)
        {
            if (grid_UISites == null) return;
            grid_UISites.Children.Clear();
            RadioButton tar = (RadioButton)sender;
            string btnName = tar.Name.ToLower();
            if (btnName.Contains("single"))
            {
                grid_UISites.Children.Add(uiSetSingle);
                radioButton_pSingle.IsChecked = true;
            }
            else if (btnName.Contains("muti"))
            {
                grid_UISites.Children.Add(uiSetMuti);
                radioButton_pMuti.IsChecked = true;
            }
            else if (btnName.Contains("judge"))
            {
                grid_UISites.Children.Add(uiSetJudge);
                radioButton_pJudge.IsChecked = true;
            }
            else if (btnName.Contains("blank"))
            {
                grid_UISites.Children.Add(uiSetBlanks);
                radioButton_pBlanks.IsChecked = true;
            }
            else if (btnName.Contains("qanswer"))
            {
                grid_UISites.Children.Add(uiSetQAnswer);
                radioButton_pQAnswer.IsChecked = true;
            }
        }
        #endregion

        #region 题目选择，填充数据到修改控件，删除条目
        private void listBox_subject_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (listBox_subject.SelectedIndex >= 0)
            {
                listBox_subject_FillSubject2UI(myDepot.subjects[listBox_subject.SelectedIndex]);
            }
        }
        private void listBox_subject_FillSubject2UI(DataProcessing.Depot.Subject subject)
        {
            textBox_subject.Text = subject.subject;
            textBox_image.Text = subject.imageFileName;
            textBox_grades.Text = "" + subject.grades;
            switch (subject.type)
            {
                case DataProcessing.Depot.Subject.Type.Single:
                    radioButton_sSingle.IsChecked = true;
                    uiSetSingle.SetOptions(subject.IOSingleOptions.Split(new string[] { DataProcessing.Depot.Subject.JOIN_SEPARATOR }, StringSplitOptions.None), true);
                    uiSetSingle.TrySetAnswer("" + subject.singleAnswer_curIndex);
                    textBox_PInput.Text = subject.ScriptSingle;
                    break;
                case DataProcessing.Depot.Subject.Type.Muti:
                    radioButton_sMuti.IsChecked = true;
                    uiSetMuti.SetAudType(subject.mutiAuditType);
                    uiSetMuti.SetOptions(subject.IOMutiOptions.Split(new string[] { DataProcessing.Depot.Subject.JOIN_SEPARATOR }, StringSplitOptions.None));
                    uiSetMuti.TrySetAnswer(subject.IOMutiAnswers);
                    textBox_PInput.Text = subject.ScriptMuti;
                    break;
                case DataProcessing.Depot.Subject.Type.Judge:
                    radioButton_sJudge.IsChecked = true;
                    uiSetJudge.SetAns_LeftIsRight(subject.judgeAnswer_leftIsRight);
                    uiSetJudge.SetOptions(subject.IOJudgeOptions.Split(new string[] { DataProcessing.Depot.Subject.JOIN_SEPARATOR }, StringSplitOptions.None));
                    textBox_PInput.Text = subject.ScriptJudge;
                    break;
                case DataProcessing.Depot.Subject.Type.Blanks:
                    radioButton_sBlanks.IsChecked = true;
                    textBox_subject.Text = subject.subject.Replace(DataProcessing.Depot.Subject.JOIN_SEPARATOR, "【空缺】");
                    uiSetBlanks.SetBlanks(subject.blanksAnswers);
                    uiSetBlanks.SetBlanksAuditType(subject.blanksAuditType);
                    textBox_PInput.Text = subject.ScriptBlanks;
                    break;
                case DataProcessing.Depot.Subject.Type.QAnswer:
                    radioButton_sQAnswer.IsChecked = true;
                    uiSetQAnswer.SetAnswer(subject.qAnswer);
                    textBox_PInput.Text = subject.ScriptQAnswer;
                    break;
            }
        }
        private void listBox_subject_KeyUp(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.Delete:
                    myDepot_RemoveAt(listBox_subject.SelectedIndex);
                    listBox_subject_ReloadSource(myDepot);
                    break;
                case Key.Enter:
                    if (listBox_subject.SelectedIndex >= 0)
                    {
                        DataProcessing.Depot.Subject helper = new DataProcessing.Depot.Subject();
                        List<List<string>> orgData = myDepot.subjects[listBox_subject.SelectedIndex].LineContent;
                        List<string> inOrgData;
                        List<List<string>> data = new List<List<string>>();
                        List<string> inData;
                        for (int i = 0; i < orgData.Count; i++)
                        {
                            inOrgData = orgData[i];
                            inData = new List<string>();
                            for (int j = 0; j < inOrgData.Count; j++)
                            {
                                inData.Add(inOrgData[i]);
                            }
                            data.Add(inData);
                        }
                        helper.LineContent = data;
                        ViewSubject vsWin = new ViewSubject(myId, 1, helper, treeView_Depot.selectedNodeFullPath, Class_SubjUIHelper.ShowType.SubjectWithAnswer, null);
                        vsWin.Show();
                    }
                    break;
            }
        }
        #endregion

        #region 单个试题，界面操作，按钮“添加、修改”，添加“图片”，设置填空

        private void button_add_modify_Click(object sender, RoutedEventArgs e)
        {
            double grands;
            try
            {
                grands = double.Parse(textBox_grades.Text);
                if (grands <= 0 || grands > 100) throw new Exception("分数在预想范围之外");
            }
            catch (Exception err)
            {
                infoPanel.ShowInfo(err);
                return;
            }
            checkBox_pOverWrite.IsChecked = true;
            DataProcessing.Depot.Subject subjHelper = new DataProcessing.Depot.Subject();
            subjHelper.subject = textBox_subject.Text;
            subjHelper.imageFileName = textBox_image.Text;
            subjHelper.grades = grands;
            if (radioButton_sSingle.IsChecked == true)
            {
                uiSetSingle.SetData2Subject(ref subjHelper);
                textBox_PInput.Text = subjHelper.ScriptSingle;
            }
            else if (radioButton_sMuti.IsChecked == true)
            {
                uiSetMuti.SetData2Subject(ref subjHelper);
                textBox_PInput.Text = subjHelper.ScriptMuti;
            }
            else if (radioButton_sJudge.IsChecked == true)
            {
                uiSetJudge.SetData2Subject(ref subjHelper);
                textBox_PInput.Text = subjHelper.ScriptJudge;
            }
            else if (radioButton_sBlanks.IsChecked == true)
            {
                uiSetBlanks.SetData2Subject(ref subjHelper);
                textBox_PInput.Text = subjHelper.ScriptBlanks;
            }
            else if (radioButton_sQAnswer.IsChecked == true)
            {
                uiSetQAnswer.SetData2Subject(ref subjHelper);
                textBox_PInput.Text = subjHelper.ScriptQAnswer;
            }
            button_PInput_Add_Click(button_PInput_Add, e);
        }

        private void button_blanks_SetBlanks_Click(object sender, RoutedEventArgs e)
        {
            uiSetBlanks.UI_SetBlanks(textBox_subject.Text, textBox_subject.SelectionStart, textBox_subject.SelectionStart + textBox_subject.SelectionLength);
        }
        void uiSetBlanks_UI_Set_BlankComplete(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            textBox_subject.SelectedText = "【空缺】";
        }
        void uiSetBlanks_UI_EnSet_BlankComplete(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            textBox_subject.SelectedText = uiSetBlanks.UI_EnSet_BlankComplete_Value;
        }

        private void button_image_Click(object sender, RoutedEventArgs e)
        {
            if (treeView_Depot.selectedNodeFullPath != null && treeView_Depot.selectedNodeFullPath_isDepot)
            {
                SelectImage selectImgWin = new SelectImage(myId);
                selectImgWin.Closed += new EventHandler(selectImgWin_Closed);
                selectImgWin.Show();
            }
        }
        void selectImgWin_Closed(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            SelectImage target = (SelectImage)sender;
            if (target.DialogResult == true && target.selectedImageName != null)
            {
                textBox_image.Text = target.selectedImageName;
            }
        }
        private void button_imageRemove_Click(object sender, RoutedEventArgs e)
        {
            textBox_image.Text = "";
        }
        #endregion
    }
}
