﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;

using System.Windows.Media.Imaging;
using XTExam.Views_Admin.User.SubPack;
using System.Collections.ObjectModel;
using XTExam.CodeSharing.Entities;

namespace XTExam.Views_Admin.User
{
    public partial class Admin_User : Page
    {
        public DataProcessing.UserRegister.UserInfo myId { set; get; }
        public Admin_User(DataProcessing.UserRegister.UserInfo myID)
        {
            InitializeComponent();
            this.myId = myID;
            if (myID == null || !myId.hasId)
            {
                this.IsEnabled = false;
            }
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        //private MediaElement sound_error;
        //private MediaElement sound_eg1;
        //private MediaElement sound_eg2;
        //private MediaElement sound_eg3;
        ServiceReference_User.Service_UserClient serviceClient;
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            infoPanel.ProcessingStart += new EventHandler(infoPanel_ProcessingStart);
            infoPanel.ProcessingComplete += new EventHandler(infoPanel_ProcessingComplete);

            treeView_User.myID = myId;
            treeView_User.SelectedNodeChanged += new EventHandler(treeView_User_SelectedNodeChanged);

            //sound_error = new MediaElement();
            //sound_error.Source = new Uri("/sound/error.mp3", UriKind.Relative);
            //sound_error.Volume = 100;
            //sound_eg1 = new MediaElement();
            //sound_eg1.Source = new Uri("/sound/note.mp3", UriKind.Relative);
            //sound_eg1.Volume = 100;
            //sound_eg2 = new MediaElement();
            //sound_eg2.Source = new Uri("/sound/info.mp3", UriKind.Relative);
            //sound_eg2.Volume = 100;
            //sound_eg3 = new MediaElement();
            //sound_eg3.Source = new Uri("/sound/bing2.mp3", UriKind.Relative);
            //sound_eg3.Volume = 100;

            serviceClient = new ServiceReference_User.Service_UserClient();
            serviceClient.AddStorPathCompleted += new EventHandler<ServiceReference_User.AddStorPathCompletedEventArgs>(serviceClient_AddStorPathCompleted);
            serviceClient.AddStorFileCompleted += new EventHandler<ServiceReference_User.AddStorFileCompletedEventArgs>(serviceClient_AddStorFileCompleted);
            serviceClient.DelStorNodeCompleted += new EventHandler<ServiceReference_User.DelStorNodeCompletedEventArgs>(serviceClient_DelStorNodeCompleted);
            serviceClient.CopyStorNodeCompleted += new EventHandler<ServiceReference_User.CopyStorNodeCompletedEventArgs>(serviceClient_CopyStorNodeCompleted);
            serviceClient.SetFileBodyCompleted += new EventHandler<ServiceReference_User.SetFileBodyCompletedEventArgs>(serviceClient_SetFileBodyCompleted);
            serviceClient.GetFileBodyCompleted += new EventHandler<ServiceReference_User.GetFileBodyCompletedEventArgs>(serviceClient_GetFileBodyCompleted);

            serviceClient.SetPro2AdminUserCompleted += new EventHandler<ServiceReference_User.SetPro2AdminUserCompletedEventArgs>(serviceClient_SetPro2AdminUserCompleted);
            serviceClient.SetPro2AuditPaperCompleted += new EventHandler<ServiceReference_User.SetPro2AuditPaperCompletedEventArgs>(serviceClient_SetPro2AuditPaperCompleted);
            serviceClient.SetPro2CheckResultCompleted += new EventHandler<ServiceReference_User.SetPro2CheckResultCompletedEventArgs>(serviceClient_SetPro2CheckResultCompleted);
            serviceClient.SetPro2MakePaperCompleted += new EventHandler<ServiceReference_User.SetPro2MakePaperCompletedEventArgs>(serviceClient_SetPro2MakePaperCompleted);

            serviceClient.ReSyncAllCompleted += new EventHandler<System.ComponentModel.AsyncCompletedEventArgs>(serviceClient_ReSyncAllCompleted);
        }

        void infoPanel_ProcessingComplete(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            this.Cursor = Cursors.Arrow;
        }
        void infoPanel_ProcessingStart(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            this.Cursor = Cursors.Wait;
        }


        #region 用户操作，创建、删除 节点操作
        private void button_createFolder_sub_Click(object sender, RoutedEventArgs e)
        {
            string fullPath = treeView_User.selectedDirPath;
            if (fullPath == null)
            {
                infoPanel.ShowInfo("请选择一个文件夹", false);
                return;
            }
            fullPath += "\\" + textBox_folder.Text;
            infoPanel.ShowInfo("正在创建文件夹……", true);
            serviceClient.AddStorPathAsync(fullPath);
        }
        private void button_createFolder_Click(object sender, RoutedEventArgs e)
        {
            string fullPath = (treeView_User.selectedDirPath == null) ? treeView_User.selectedFilePath : treeView_User.selectedDirPath;
            if (fullPath == null) fullPath = "";
            if (fullPath.Contains('\\'))
            {
                fullPath = fullPath.Substring(0, fullPath.LastIndexOf('\\'));
            }
            else fullPath = "";
            fullPath += "\\" + textBox_folder.Text;
            infoPanel.ShowInfo("正在创建文件夹……", true);
            serviceClient.AddStorPathAsync(fullPath);
        }
        void serviceClient_AddStorPathCompleted(object sender, ServiceReference_User.AddStorPathCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result)
                {
                    infoPanel.ShowInfo("创建成功", false);
                    treeView_User.ReloadTree();
                }
                else
                {
                    infoPanel.ShowInfo("未能创建，可能文件夹已经存在", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error.Message, false);
            }
        }


        private void button_createFile_sub_Click(object sender, RoutedEventArgs e)
        {
            string fullPath = treeView_User.selectedDirPath;
            if (fullPath == null)
            {
                infoPanel.ShowInfo("请选择一个文件夹", false);
                return;
            }
            fullPath += "\\" + textBox_file.Text;
            infoPanel.ShowInfo("正在创建文件……", true);
            serviceClient.AddStorFileAsync(fullPath, myId.id);
        }
        private void button_createFile_Click(object sender, RoutedEventArgs e)
        {
            string fullPath = treeView_User.selectedDirPath;
            if (treeView_User.selectedFilePath != null)
            {
                infoPanel.ShowInfo("不能在文件上创建文件", false);
                return;
            }
            if (fullPath == null) fullPath = "";
            if (fullPath.Contains('\\'))
            {
                fullPath = fullPath.Substring(0, fullPath.LastIndexOf('\\'));
            }
            else fullPath = "";
            fullPath += "\\" + textBox_file.Text;
            infoPanel.ShowInfo("正在创建文件……", true);
            serviceClient.AddStorFileAsync(fullPath, myId.id);
        }
        void serviceClient_AddStorFileCompleted(object sender, ServiceReference_User.AddStorFileCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result)
                {
                    infoPanel.ShowInfo("创建成功", false);
                    treeView_User.ReloadTree();
                }
                else
                {
                    infoPanel.ShowInfo("未能创建，可能名单已经存在", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error.Message, false);
            }
        }


        private void button_delNode_Click(object sender, RoutedEventArgs e)
        {
            string path = (treeView_User.selectedFilePath == null) ? treeView_User.selectedDirPath : treeView_User.selectedFilePath;
            if (path == null)
            {
                infoPanel.ShowInfo("请选择一个节点", false);
                return;
            }
            infoPanel.ShowInfo("正在删除节点……", true);
            serviceClient.DelStorNodeAsync(path, myId.id);
        }
        void serviceClient_DelStorNodeCompleted(object sender, ServiceReference_User.DelStorNodeCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result)
                {
                    infoPanel.ShowInfo("删除成功", false);
                    treeView_User.ReloadTree();
                }
                else
                {
                    infoPanel.ShowInfo("未能删除，可能节点已经由另一管理员删除", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error.Message, false);
            }
        }
        #endregion

        #region 复制 / 粘贴 存储节点
        private string button_copyNode_nodePath;
        private void button_copyNode_Click(object sender, RoutedEventArgs e)
        {
            string path = (treeView_User.selectedFilePath == null) ? treeView_User.selectedDirPath : treeView_User.selectedFilePath;
            if (path == null) return;
            button_copyNode_nodePath = path;
        }

        private void button_pauseNode_Click(object sender, RoutedEventArgs e)
        {
            if (button_copyNode_nodePath == null || button_copyNode_nodePath.Length == 0) return;
            string targetPath = (treeView_User.selectedDirPath == null) ? treeView_User.selectedFilePath : treeView_User.selectedDirPath;
            if (targetPath == null) targetPath = "";
            if (targetPath.StartsWith(button_copyNode_nodePath) || targetPath == button_copyNode_nodePath)
            {
                infoPanel.ShowInfo("不允许将父节点复制到子节点中！", false);
                return;
            }
            targetPath += "\\" + (button_copyNode_nodePath.Contains('\\') ? button_copyNode_nodePath.Substring(button_copyNode_nodePath.LastIndexOf('\\')) : button_copyNode_nodePath);
            infoPanel.ShowInfo("正在发送请求……", true);
            serviceClient.CopyStorNodeAsync(button_copyNode_nodePath, targetPath, myId.id);
        }
        void serviceClient_CopyStorNodeCompleted(object sender, ServiceReference_User.CopyStorNodeCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result)
                {
                    infoPanel.ShowInfo("复制成功", false);
                    treeView_User.ReloadTree();
                }
                else
                {
                    infoPanel.ShowInfo("未能成功复制！", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error.Message, false);
            }
        }
        #endregion


        #region 编辑、添加 名单 内容
        private void button_clearUserText_Click(object sender, RoutedEventArgs e)
        {
            textBox_inputUIdList.Text = "";
        }
        private string[] button_add_ids;
        private void button_add_Click(object sender, RoutedEventArgs e)
        {
            if (treeView_User.selectedFilePath == null)
            {
                infoPanel.ShowInfo("请选择文件节点", false);
                return;
            }
            button_add_ids = textBox_inputUIdList_ids(textBox_inputUIdList.Text);
            ObservableCollection<string> uIdList = new ObservableCollection<string>();
            bool found;
            for (int i = 0; i < button_add_ids.Length; i++)
            {
                found = false;
                foreach (string uidList_Item in uIdList)
                {
                    if (uidList_Item == button_add_ids[i]) found = true;
                }
                if (found) continue;
                uIdList.Add(button_add_ids[i]);
            }
            infoPanel.ShowInfo("正在添加账号到名单……", true);
            serviceClient.SetFileBodyAsync(treeView_User.selectedFilePath, uIdList, myId.id);
        }
        private string[] textBox_inputUIdList_ids(string wholeText)
        {
            return wholeText.Split(new string[] { "\r", "\n", ",", "，", ";", "；", "\t", "/", "、", "\\", "＼" }, StringSplitOptions.RemoveEmptyEntries);
        }
        void serviceClient_SetFileBodyCompleted(object sender, ServiceReference_User.SetFileBodyCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result)
                {
                    infoPanel.ShowInfo("变更成功", false);
                }
                else
                {
                    infoPanel.ShowInfo("未能成功变更名单内容", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error.Message, false);
            }
        }
        #endregion


        void treeView_User_SelectedNodeChanged(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            if (treeView_User.selectedFilePath != null)
            {
                infoPanel.ShowInfo("正在重新获取名单内容……", true);
                serviceClient.GetFileBodyAsync(treeView_User.selectedFilePath);
            }
            else
            {
                textBox_inputUIdList.Text = "";
            }
        }
        void serviceClient_GetFileBodyCompleted(object sender, ServiceReference_User.GetFileBodyCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result != null)
                {
                    string listContent = "";
                    foreach (string id in e.Result)
                    {
                        listContent += id + "\r\n";
                    }
                    textBox_inputUIdList.Text = listContent;
                    textBox_inputUIdList_forPro.Text = listContent;
                    infoPanel.ShowInfo("名单[" + treeView_User.selectedFilePath + "]内容已经显示", false);
                }
                else
                {
                    infoPanel.ShowInfo("未能获取名单[" + treeView_User.selectedFilePath + "]内容", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error.Message, false);
            }

        }


        #region 权限操作
        private void button_proAddAdminUser_Click(object sender, RoutedEventArgs e)
        {
            string[] ids = textBox_inputUIdList_ids(textBox_inputUIdList_forPro.Text);
            if (ids.Length == 0) return;
            infoPanel.ShowInfo("正在处理请求……", true);
            serviceClient.SetPro2AdminUserAsync(Conv_strArr2ObCollec(ids), true);
        }
        private void button_proDrpAdminUsers_Click(object sender, RoutedEventArgs e)
        {
            string[] ids = textBox_inputUIdList_ids(textBox_inputUIdList_forPro.Text);
            if (ids.Length == 0) return;
            infoPanel.ShowInfo("正在处理请求……", true);
            serviceClient.SetPro2AdminUserAsync(Conv_strArr2ObCollec(ids), false);
        }
        void serviceClient_SetPro2AdminUserCompleted(object sender, ServiceReference_User.SetPro2AdminUserCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result != null)
                {
                    if (e.Result.Count > 0)
                    {
                        string udId = "";
                        foreach (string id in e.Result)
                        {
                            if (udId.Length > 0) udId += "、";
                            udId += id;
                        }
                        infoPanel.ShowInfo("完成部分权限变更，下列账号[" + udId + "]未能实现变更", false);
                    }
                    else
                    {
                        infoPanel.ShowInfo("成功完成[用户管理权限]变更", false);
                    }
                }
                else
                {
                    infoPanel.ShowInfo("请求未能成功执行，请稍后重试", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error.Message, false);
            }
        }
        private ObservableCollection<string> Conv_strArr2ObCollec(string[] strArr)
        {
            ObservableCollection<string> result = new ObservableCollection<string>();
            for (int i = 0; i < strArr.Length; i++)
            {
                result.Add(strArr[i]);
            }
            return result;
        }

        private void button_proAddResult_Click(object sender, RoutedEventArgs e)
        {
            string[] ids = textBox_inputUIdList_ids(textBox_inputUIdList_forPro.Text);
            if (ids.Length == 0) return;
            infoPanel.ShowInfo("正在处理请求……", true);
            serviceClient.SetPro2CheckResultAsync(Conv_strArr2ObCollec(ids), true);
        }
        private void button_proDrpResult_Click(object sender, RoutedEventArgs e)
        {
            string[] ids = textBox_inputUIdList_ids(textBox_inputUIdList_forPro.Text);
            if (ids.Length == 0) return;
            infoPanel.ShowInfo("正在处理请求……", true);
            serviceClient.SetPro2CheckResultAsync(Conv_strArr2ObCollec(ids), false);
        }
        void serviceClient_SetPro2CheckResultCompleted(object sender, ServiceReference_User.SetPro2CheckResultCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result != null)
                {
                    if (e.Result.Count > 0)
                    {
                        string udId = "";
                        foreach (string id in e.Result)
                        {
                            if (udId.Length > 0) udId += "、";
                            udId += id;
                        }
                        infoPanel.ShowInfo("完成部分权限变更，下列账号[" + udId + "]未能实现变更", false);
                    }
                    else
                    {
                        infoPanel.ShowInfo("成功完成[成绩查询权限]变更", false);
                    }
                }
                else
                {
                    infoPanel.ShowInfo("请求未能成功执行，请稍后重试", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error.Message, false);
            }
        }

        private void button_proAddAudit_Click(object sender, RoutedEventArgs e)
        {
            string[] ids = textBox_inputUIdList_ids(textBox_inputUIdList_forPro.Text);
            if (ids.Length == 0) return;
            infoPanel.ShowInfo("正在处理请求……", true);
            serviceClient.SetPro2AuditPaperAsync(Conv_strArr2ObCollec(ids), true);
        }
        private void button_proDrpAudit_Click(object sender, RoutedEventArgs e)
        {
            string[] ids = textBox_inputUIdList_ids(textBox_inputUIdList_forPro.Text);
            if (ids.Length == 0) return;
            infoPanel.ShowInfo("正在处理请求……", true);
            serviceClient.SetPro2AuditPaperAsync(Conv_strArr2ObCollec(ids), false);
        }
        void serviceClient_SetPro2AuditPaperCompleted(object sender, ServiceReference_User.SetPro2AuditPaperCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result != null)
                {
                    if (e.Result.Count > 0)
                    {
                        string udId = "";
                        foreach (string id in e.Result)
                        {
                            if (udId.Length > 0) udId += "、";
                            udId += id;
                        }
                        infoPanel.ShowInfo("完成部分权限变更，下列账号[" + udId + "]未能实现变更", false);
                    }
                    else
                    {
                        infoPanel.ShowInfo("成功完成[批阅试卷权限]变更", false);
                    }
                }
                else
                {
                    infoPanel.ShowInfo("请求未能成功执行，请稍后重试", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error.Message, false);
            }
        }

        private void button_proAddPaper_Click(object sender, RoutedEventArgs e)
        {
            string[] ids = textBox_inputUIdList_ids(textBox_inputUIdList_forPro.Text);
            if (ids.Length == 0) return;
            infoPanel.ShowInfo("正在处理请求……", true);
            serviceClient.SetPro2MakePaperAsync(Conv_strArr2ObCollec(ids), true);
        }
        private void button_proDrpPaper_Click(object sender, RoutedEventArgs e)
        {
            string[] ids = textBox_inputUIdList_ids(textBox_inputUIdList_forPro.Text);
            if (ids.Length == 0) return;
            infoPanel.ShowInfo("正在处理请求……", true);
            serviceClient.SetPro2MakePaperAsync(Conv_strArr2ObCollec(ids), false);
        }
        void serviceClient_SetPro2MakePaperCompleted(object sender, ServiceReference_User.SetPro2MakePaperCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result != null)
                {
                    if (e.Result.Count > 0)
                    {
                        string udId = "";
                        foreach (string id in e.Result)
                        {
                            if (udId.Length > 0) udId += "、";
                            udId += id;
                        }
                        infoPanel.ShowInfo("完成部分权限变更，下列账号[" + udId + "]未能实现变更", false);
                    }
                    else
                    {
                        infoPanel.ShowInfo("成功完成[编制试卷权限]变更", false);
                    }
                }
                else
                {
                    infoPanel.ShowInfo("请求未能成功执行，请稍后重试", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error.Message, false);
            }
        }
        #endregion

        private void button_ReSyncAll_Click(object sender, RoutedEventArgs e)
        {
            infoPanel.ShowInfo("同步进行中……", true);
            serviceClient.ReSyncAllAsync(myId.id);
        }

        void serviceClient_ReSyncAllCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                infoPanel.ShowInfo("全部同步完成！！", false);
            }
            else
            {
                infoPanel.ShowInfo(e.Error.Message, false);
            }
        }
    }
}
