﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using XTExam.ServiceReference_User;
using System.Collections.ObjectModel;
using XTExam.CodeSharing.Entities;

namespace XTExam.Views_Admin.User.SubPack
{
    public partial class ChildWindow_UserListDetail : ChildWindow
    {
        public DataProcessing.UserRegister.UserInfo myId { set; get; }
        public ChildWindow_UserListDetail(DataProcessing.UserRegister.UserInfo myID)
        {
            InitializeComponent();
            this.myId = myID;
            if (myID == null || !myId.hasId)
            {
                this.DialogResult = false;
            }
        }
        private string _uListPath;

        private string tmp_remark;
        public void Show(string uListPath)
        {
            this.Show();
            _uListPath = uListPath;
            infoPanel.ShowInfo("正在获取用户名册信息", true);
            Service_UserClient client_listHeader = new Service_UserClient();
            client_listHeader.GetFileHeaderCompleted += new EventHandler<GetFileHeaderCompletedEventArgs>(client_GetFileHeaderCompleted);
            client_listHeader.GetFileHeaderAsync(_uListPath);
        }

        #region 获取名单信息，删除条目操作
        void client_GetFileHeaderCompleted(object sender, GetFileHeaderCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result != null)
                {
                    SetUserListHeader(e.Result);
                    infoPanel.ShowInfo("正在获取用户名册", true);
                    Service_UserClient cliend_idList = new Service_UserClient();
                    cliend_idList.GetFileBodyCompleted += new EventHandler<GetFileBodyCompletedEventArgs>(cliend_GetFileBodyCompleted);
                    cliend_idList.GetFileBodyAsync(_uListPath);
                }
                else
                {
                    infoPanel.ShowInfo("未能获取名册信息，可能是网络问题，请关闭此窗口后重试。", false);
                    this.IsEnabled = false;
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error.Message, false);
                this.IsEnabled = false;
            }
        }
        void cliend_GetFileBodyCompleted(object sender, GetFileBodyCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result != null)
                {
                    Service_UserClient client_fullUserList = new Service_UserClient();
                    client_fullUserList.GetUsersCompleted += new EventHandler<GetUsersCompletedEventArgs>(client_fullUserList_GetUsersCompleted);
                    client_fullUserList.GetUsersAsync(e.Result);
                }
                else
                {
                    infoPanel.ShowInfo("未能获取名册，可能是网络问题，请关闭此窗口后重试。", false);
                    this.IsEnabled = false;
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error.Message, false);
                this.IsEnabled = false;
            }
        }

        ObservableCollection<ObservableCollection<string>> fullUserList;
        List<UserDetail> dataGrid_main_source;
        void client_fullUserList_GetUsersCompleted(object sender, GetUsersCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result != null)
                {
                    fullUserList = e.Result;
                    dataGrid_main_source = new List<UserDetail>();
                    for (int i = 0; i < fullUserList.Count; i++)
                    {
                        dataGrid_main_source.Add(new UserDetail(fullUserList[i]));
                    }
                    dataGrid_main.ItemsSource = dataGrid_main_source;
                    //string tmp = dataGrid_main_source[0].账号;
                    infoPanel.ShowInfo("就绪", false);
                }
                else
                {
                    infoPanel.ShowInfo("未能获取用户详情，请关闭此窗口后重试。", false);
                    this.IsEnabled = false;
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error.Message, false);
                this.IsEnabled = false;
            }
        }
        private void button_delete_Click(object sender, RoutedEventArgs e)
        {
            if (dataGrid_main.SelectedItems != null)
            {
                string id1, id2;
                List<int> indexList = new List<int>();
                for (int i = dataGrid_main_source.Count - 1; i >= 0; i--)
                {
                    if (dataGrid_main.SelectedItems.Count == 0) break;
                    for (int j = dataGrid_main.SelectedItems.Count - 1; j >= 0; j--)
                    {
                        id1 = dataGrid_main_source[i].账号;
                        id2 = ((UserDetail)(dataGrid_main.SelectedItems[j])).账号;
                        if (id1 == id2)
                        {
                            indexList.Add(i);
                            break;
                        }
                    }
                }
                indexList.Sort();
                for (int i = indexList.Count - 1; i >= 0; i--)
                {
                    dataGrid_main_source.RemoveAt(indexList[i]);
                }
                dataGrid_main.ItemsSource = null;
                dataGrid_main.ItemsSource = dataGrid_main_source;
            }
        }
        #endregion

        Service_UserClient serviceClient;
        private ObservableCollection<string> userDetailWin_Header2Save;
        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            if (tmp_remark != textBox_remark.Text)
            {
                serviceClient = new Service_UserClient();
                userDetailWin_Header2Save = GetUserListHeader();
                serviceClient.SetFileHeaderAsync(_uListPath, userDetailWin_Header2Save, myId.id);
            }
            this.DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
        private static string FORMAT_LONG_DATE = "yyyy-MM-dd HH:mm:ss";
        public ObservableCollection<string> GetUserListHeader()
        {
            ObservableCollection<string> result = new ObservableCollection<string>();
            result.Add("");
            result.Add("");
            result.Add(DateTime.Now.ToString(FORMAT_LONG_DATE));
            result.Add(myId.id);
            result.Add("");
            result.Add(textBox_remark.Text);
            return result;
        }
        public ObservableCollection<string> GetUserListBody()
        {
            ObservableCollection<string> result = new ObservableCollection<string>();
            if (dataGrid_main_source != null)
            {
                for (int i = 0; i < dataGrid_main_source.Count; i++)
                {
                    result.Add(dataGrid_main_source[i].账号);
                }
            }
            return result;
        }
        private void SetUserListHeader(ObservableCollection<string> header)
        {
            textBox_createTime.Text = header[0];
            textBox_creator.Text = header[1];
            textBox_modifyTime.Text = header[2];
            textBox_modifier.Text = header[3];
            textBox_title.Text = header[4];
            textBox_remark.Text = header[5];
            tmp_remark = textBox_remark.Text;
        }


        void serviceClient_SetFileHeaderCompleted(object sender, ServiceReference_User.SetFileHeaderCompletedEventArgs e)
        {
            //throw new NotImplementedException();
            if (e.Error == null)
            {
                if (e.Result)
                {
                    infoPanel.ShowInfo("成功设置名单页头信息", false);
                }
                else
                {
                    infoPanel.ShowInfo("未能成功设置名单页头信息", false);
                }
            }
            else
            {
                infoPanel.ShowInfo(e.Error.Message, false);
            }
        }


        public class UserDetail
        {
            public string 账号 { get; set; }
            public string 姓名 { get; set; }
            public string 上次登录IP { get; set; }
            public string 所属单位 { get; set; }

            public bool 账号管理 { get; set; }
            public bool 成绩查询 { get; set; }
            public bool 试题制备 { get; set; }
            public bool 批阅试卷 { get; set; }
            public string 批卷权限范围 { get; set; }

            public string 创建时间 { get; set; }
            public string 创建者 { get; set; }
            public string 最后修改时间 { get; set; }
            public string 最后修改者 { get; set; }

            public UserDetail(ObservableCollection<string> userInfo)
            {
                this.账号 = userInfo[0];
                this.姓名 = userInfo[1];
                this.上次登录IP = userInfo[2];
                this.所属单位 = userInfo[3];

                this.创建时间 = userInfo[6];
                //this.创建时间 = DateTime.Parse(userInfo[6]);
                this.创建者 = userInfo[7];
                this.最后修改时间 = userInfo[8];
                //this.最后修改时间 = DateTime.Parse(userInfo[8]);
                this.最后修改者 = userInfo[9];

                this.账号管理 = bool.Parse(userInfo[10]);
                this.成绩查询 = bool.Parse(userInfo[11]);
                this.试题制备 = bool.Parse(userInfo[12]);
                this.批阅试卷 = bool.Parse(userInfo[13]);
                this.批卷权限范围 = userInfo[14];
            }
        }
    }
}

