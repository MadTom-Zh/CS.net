﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Navigation;
using System.Windows.Shapes;

using XTExam.Views_General;
using XTExam.Views_General.Examination;
using XTExam.Views_General.Announcement;
using XTExam.Views_Admin;
using System.Windows.Browser;
using XTExam.CodeSharing.Entities;
//using XTExam.ServiceReference_Announcements;

namespace XTExam
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }

        // After the Frame navigates, ensure the HyperlinkButton representing the current page is selected
        private void ContentFrame_Navigated(object sender, NavigationEventArgs e)
        {
            //foreach (UIElement child in LinksStackPanel.Children)
            //{
            //    HyperlinkButton hb = child as HyperlinkButton;
            //    if (hb != null && hb.NavigateUri != null)
            //    {
            //        if (hb.NavigateUri.ToString().Equals(e.Uri.ToString()))
            //        {
            //            VisualStateManager.GoToState(hb, "ActiveLink", true);
            //        }
            //        else
            //        {
            //            VisualStateManager.GoToState(hb, "InactiveLink", true);
            //        }
            //    }
            //}
        }

        // If an error occurs during navigation, show an error window
        private void ContentFrame_NavigationFailed(object sender, NavigationFailedEventArgs e)
        {
            e.Handled = true;
            ChildWindow errorWin = new ErrorWindow(e.Uri);
            errorWin.Show();
        }

        #region 登录 和 登出
        ChildWindow_Login loginWin;
        public DataProcessing.UserRegister.UserInfo myId
        {
            set;
            get;
        }
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            myId = new DataProcessing.UserRegister.UserInfo(null, null);

            ChildWindow_RegAndLogin_usingIDNO exLoginWin = new ChildWindow_RegAndLogin_usingIDNO();
            exLoginWin.Closed += exLoginWin_Closed;
            exLoginWin.CallBackToNormalLoginUI += exLoginWin_CallBackToNormalLoginUI;
            exLoginWin.Show();
        }

        void exLoginWin_CallBackToNormalLoginUI(object sender, EventArgs e)
        {
            ChildWindow_RegAndLogin_usingIDNO target
                = (ChildWindow_RegAndLogin_usingIDNO)sender;
            target.DialogResult = false;
            target.Close();

            loginWin = new ChildWindow_Login();
            loginWin.Closed += new EventHandler(loginWin_Closed);
            loginWin.Show();
        }

        void exLoginWin_Closed(object sender, EventArgs e)
        {
            ChildWindow_RegAndLogin_usingIDNO target
                = (ChildWindow_RegAndLogin_usingIDNO)sender;
            if (target.DialogResult == true && target.myId.id.Length > 0)
            {
                myId = target.myId;
                _SetUserLogon();
            }
        }
        void loginWin_Closed(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            if (loginWin.DialogResult == true && loginWin.myId.hasId)
            {
                myId = loginWin.myId;
                _SetUserLogon();
            }
            else
            {
                loginWin.Show();
            }
        }

        private void _SetUserLogon()
        {
            button_logOff.Content = "" + myId.name + " [登出?]";
            if (myId.couldAdminUser || myId.couldAuditPaper || myId.couldMakePaper || myId.couldAdminAnnouncement)
            {
                hyperlinkButton_admin.IsEnabled = true;
            }
            else
            {
                hyperlinkButton_admin.IsEnabled = false;
            }
            hyperlinkButton_result.IsEnabled = myId.couldCheckResult;
            Action_AfterLogon();
        }

        private void button_logOff_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult feedBack = MessageBox.Show("您即将登出系统，确定 登出 吗？！", "警告", MessageBoxButton.OKCancel);
            if (feedBack == MessageBoxResult.OK)
            {
                myId = null;
                button_logOff.Content = "Off Line";
                loginWin.Show();
            }
        }
        #endregion

        //private Service_AnnouncementsClient anumClient;
        private void Action_AfterLogon()
        {
            //if (anumClient == null)
            //{
            //    anumClient = new Service_AnnouncementsClient();
            //    anumClient.Check_HaveAnums2VoteCompleted += new EventHandler<Check_HaveAnums2VoteCompletedEventArgs>(anumClient_Check_HaveAnums2VoteCompleted);
            //}
            //anumClient.Check_HaveAnums2VoteAsync(myId.id);
        }
        //void anumClient_Check_HaveAnums2VoteCompleted(object sender, Check_HaveAnums2VoteCompletedEventArgs e)
        //{
        //    if (e.Error == null)
        //    {
        //        if (e.Result)
        //        {
        //            AnumBtnAnimation.Begin();
        //        }
        //        else
        //        {
        //            AnumBtnAnimation.Seek(new TimeSpan(0));
        //            AnumBtnAnimation.Stop();
        //        }
        //    }
        //    else throw e.Error;
        //}

        private void hyperlinkButton_Announcements_Click(object sender, RoutedEventArgs e)
        {
            AnumBtnAnimation.Seek(new TimeSpan(0));
            AnumBtnAnimation.Stop();

            Announcements anumWin = new Announcements();
            anumWin.myId = myId;
            ContentFrame.Content = anumWin;
        }

        private void hyperlinkButton_Examinate_Click(object sender, RoutedEventArgs e)
        {
            Exam_Guide exWin = new Exam_Guide(myId);
            ContentFrame.Content = exWin;
        }


        private void hyperlinkButton_result_Click(object sender, RoutedEventArgs e)
        {
            string op = myId.id;
            string flag = DateTime.Now.ToFileTime().ToString("X");
            HtmlPage.Window.Navigate(new Uri("Pages/Results.aspx?op=" + op + "&flag=" + flag, UriKind.Relative), "_blank");
        }

        private void hyperlinkButton_admin_Click(object sender, RoutedEventArgs e)
        {
            Admin_MainFrame adminFrameWin = new Admin_MainFrame(myId);
            ContentFrame.Content = adminFrameWin;
        }

        private void Link_about_Click(object sender, RoutedEventArgs e)
        {
            HtmlPage.Window.Navigate(new Uri("Pages/Help.html", UriKind.Relative), "_blank");
        }

        private void Link_graph_Click(object sender, RoutedEventArgs e)
        {
            Views_Admin.ExUserExamGraph2 graph2Win = new ExUserExamGraph2();
            ContentFrame.Content = graph2Win;
        }

    }
}