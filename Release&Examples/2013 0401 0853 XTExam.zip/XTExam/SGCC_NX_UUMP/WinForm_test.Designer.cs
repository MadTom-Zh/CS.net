﻿namespace SGCC_NX_UUMP
{
    partial class WinForm_test
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox_cfgDetail = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button_reLoadCfg = new System.Windows.Forms.Button();
            this.comboBox_cfgList = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox_test = new System.Windows.Forms.GroupBox();
            this.textBox_DN = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button_checkUID = new System.Windows.Forms.Button();
            this.button_checkCon_Oracle = new System.Windows.Forms.Button();
            this.textBox_uID = new System.Windows.Forms.TextBox();
            this.button_loadUORG = new System.Windows.Forms.Button();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox_cfgDetail1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.button_reLoadCfg1 = new System.Windows.Forms.Button();
            this.comboBox_conPar1 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox_test1 = new System.Windows.Forms.GroupBox();
            this.textBox_orgs = new System.Windows.Forms.TextBox();
            this.textBox_DN1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.button_checkPWD = new System.Windows.Forms.Button();
            this.button_conPlant = new System.Windows.Forms.Button();
            this.textBox_pwd = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox_test.SuspendLayout();
            this.statusStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox_test1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.textBox_cfgDetail);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.button_reLoadCfg);
            this.groupBox1.Controls.Add(this.comboBox_cfgList);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(358, 358);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "连接参数";
            // 
            // textBox_cfgDetail
            // 
            this.textBox_cfgDetail.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_cfgDetail.Location = new System.Drawing.Point(8, 61);
            this.textBox_cfgDetail.Multiline = true;
            this.textBox_cfgDetail.Name = "textBox_cfgDetail";
            this.textBox_cfgDetail.ReadOnly = true;
            this.textBox_cfgDetail.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_cfgDetail.Size = new System.Drawing.Size(344, 291);
            this.textBox_cfgDetail.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "细节：";
            // 
            // button_reLoadCfg
            // 
            this.button_reLoadCfg.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_reLoadCfg.Location = new System.Drawing.Point(277, 18);
            this.button_reLoadCfg.Name = "button_reLoadCfg";
            this.button_reLoadCfg.Size = new System.Drawing.Size(75, 23);
            this.button_reLoadCfg.TabIndex = 2;
            this.button_reLoadCfg.Text = "重读参数";
            this.button_reLoadCfg.UseVisualStyleBackColor = true;
            this.button_reLoadCfg.Click += new System.EventHandler(this.button_reLoadCfg_Click);
            // 
            // comboBox_cfgList
            // 
            this.comboBox_cfgList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox_cfgList.FormattingEnabled = true;
            this.comboBox_cfgList.Location = new System.Drawing.Point(53, 20);
            this.comboBox_cfgList.Name = "comboBox_cfgList";
            this.comboBox_cfgList.Size = new System.Drawing.Size(218, 20);
            this.comboBox_cfgList.TabIndex = 1;
            this.comboBox_cfgList.SelectedIndexChanged += new System.EventHandler(this.comboBox_cfgList_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "名称：";
            // 
            // groupBox_test
            // 
            this.groupBox_test.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_test.Controls.Add(this.textBox_DN);
            this.groupBox_test.Controls.Add(this.label5);
            this.groupBox_test.Controls.Add(this.label3);
            this.groupBox_test.Controls.Add(this.button_checkUID);
            this.groupBox_test.Controls.Add(this.button_checkCon_Oracle);
            this.groupBox_test.Controls.Add(this.textBox_uID);
            this.groupBox_test.Location = new System.Drawing.Point(12, 376);
            this.groupBox_test.Name = "groupBox_test";
            this.groupBox_test.Size = new System.Drawing.Size(358, 113);
            this.groupBox_test.TabIndex = 1;
            this.groupBox_test.TabStop = false;
            this.groupBox_test.Text = "测试";
            // 
            // textBox_DN
            // 
            this.textBox_DN.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_DN.Location = new System.Drawing.Point(53, 54);
            this.textBox_DN.Name = "textBox_DN";
            this.textBox_DN.Size = new System.Drawing.Size(299, 21);
            this.textBox_DN.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 57);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 12);
            this.label5.TabIndex = 2;
            this.label5.Text = "DN：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "账号：";
            // 
            // button_checkUID
            // 
            this.button_checkUID.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_checkUID.Location = new System.Drawing.Point(196, 25);
            this.button_checkUID.Name = "button_checkUID";
            this.button_checkUID.Size = new System.Drawing.Size(75, 23);
            this.button_checkUID.TabIndex = 1;
            this.button_checkUID.Text = "验证";
            this.button_checkUID.UseVisualStyleBackColor = true;
            this.button_checkUID.Click += new System.EventHandler(this.button_checkUID_Click);
            // 
            // button_checkCon_Oracle
            // 
            this.button_checkCon_Oracle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_checkCon_Oracle.Location = new System.Drawing.Point(277, 25);
            this.button_checkCon_Oracle.Name = "button_checkCon_Oracle";
            this.button_checkCon_Oracle.Size = new System.Drawing.Size(75, 23);
            this.button_checkCon_Oracle.TabIndex = 1;
            this.button_checkCon_Oracle.Text = "连接O";
            this.button_checkCon_Oracle.UseVisualStyleBackColor = true;
            this.button_checkCon_Oracle.Click += new System.EventHandler(this.button_checkCon_Click);
            // 
            // textBox_uID
            // 
            this.textBox_uID.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_uID.Location = new System.Drawing.Point(53, 25);
            this.textBox_uID.Name = "textBox_uID";
            this.textBox_uID.Size = new System.Drawing.Size(137, 21);
            this.textBox_uID.TabIndex = 0;
            // 
            // button_loadUORG
            // 
            this.button_loadUORG.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_loadUORG.Location = new System.Drawing.Point(283, 47);
            this.button_loadUORG.Name = "button_loadUORG";
            this.button_loadUORG.Size = new System.Drawing.Size(60, 23);
            this.button_loadUORG.TabIndex = 3;
            this.button_loadUORG.Text = "读组织";
            this.button_loadUORG.UseVisualStyleBackColor = true;
            this.button_loadUORG.Click += new System.EventHandler(this.button_loadUORG_Click);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 492);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(747, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "statusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(83, 17);
            this.toolStripStatusLabel.Text = "Processing...";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.groupBox1);
            this.splitContainer1.Panel1.Controls.Add(this.groupBox_test);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.groupBox2);
            this.splitContainer1.Panel2.Controls.Add(this.groupBox_test1);
            this.splitContainer1.Size = new System.Drawing.Size(747, 492);
            this.splitContainer1.SplitterDistance = 373;
            this.splitContainer1.TabIndex = 3;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.textBox_cfgDetail1);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.button_reLoadCfg1);
            this.groupBox2.Controls.Add(this.comboBox_conPar1);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Location = new System.Drawing.Point(9, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(349, 359);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "连接参数";
            // 
            // textBox_cfgDetail1
            // 
            this.textBox_cfgDetail1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_cfgDetail1.Location = new System.Drawing.Point(8, 61);
            this.textBox_cfgDetail1.Multiline = true;
            this.textBox_cfgDetail1.Name = "textBox_cfgDetail1";
            this.textBox_cfgDetail1.ReadOnly = true;
            this.textBox_cfgDetail1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_cfgDetail1.Size = new System.Drawing.Size(335, 292);
            this.textBox_cfgDetail1.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 46);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 3;
            this.label6.Text = "细节：";
            // 
            // button_reLoadCfg1
            // 
            this.button_reLoadCfg1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_reLoadCfg1.Location = new System.Drawing.Point(268, 18);
            this.button_reLoadCfg1.Name = "button_reLoadCfg1";
            this.button_reLoadCfg1.Size = new System.Drawing.Size(75, 23);
            this.button_reLoadCfg1.TabIndex = 2;
            this.button_reLoadCfg1.Text = "重读参数";
            this.button_reLoadCfg1.UseVisualStyleBackColor = true;
            this.button_reLoadCfg1.Click += new System.EventHandler(this.button_reLoadCfg_Click);
            // 
            // comboBox_conPar1
            // 
            this.comboBox_conPar1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox_conPar1.FormattingEnabled = true;
            this.comboBox_conPar1.Location = new System.Drawing.Point(53, 20);
            this.comboBox_conPar1.Name = "comboBox_conPar1";
            this.comboBox_conPar1.Size = new System.Drawing.Size(209, 20);
            this.comboBox_conPar1.TabIndex = 1;
            this.comboBox_conPar1.SelectedIndexChanged += new System.EventHandler(this.comboBox_conPar1_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 12);
            this.label7.TabIndex = 0;
            this.label7.Text = "名称：";
            // 
            // groupBox_test1
            // 
            this.groupBox_test1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_test1.Controls.Add(this.textBox_orgs);
            this.groupBox_test1.Controls.Add(this.textBox_DN1);
            this.groupBox_test1.Controls.Add(this.button_loadUORG);
            this.groupBox_test1.Controls.Add(this.label4);
            this.groupBox_test1.Controls.Add(this.label8);
            this.groupBox_test1.Controls.Add(this.label9);
            this.groupBox_test1.Controls.Add(this.button_checkPWD);
            this.groupBox_test1.Controls.Add(this.button_conPlant);
            this.groupBox_test1.Controls.Add(this.textBox_pwd);
            this.groupBox_test1.Location = new System.Drawing.Point(9, 376);
            this.groupBox_test1.Name = "groupBox_test1";
            this.groupBox_test1.Size = new System.Drawing.Size(349, 113);
            this.groupBox_test1.TabIndex = 1;
            this.groupBox_test1.TabStop = false;
            this.groupBox_test1.Text = "测试";
            // 
            // textBox_orgs
            // 
            this.textBox_orgs.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_orgs.Location = new System.Drawing.Point(53, 76);
            this.textBox_orgs.Name = "textBox_orgs";
            this.textBox_orgs.Size = new System.Drawing.Size(290, 21);
            this.textBox_orgs.TabIndex = 4;
            // 
            // textBox_DN1
            // 
            this.textBox_DN1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_DN1.Location = new System.Drawing.Point(53, 22);
            this.textBox_DN1.Name = "textBox_DN1";
            this.textBox_DN1.Size = new System.Drawing.Size(209, 21);
            this.textBox_DN1.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 79);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 2;
            this.label4.Text = "组织：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 25);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 2;
            this.label8.Text = "DN：";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 52);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 2;
            this.label9.Text = "密码：";
            // 
            // button_checkPWD
            // 
            this.button_checkPWD.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_checkPWD.Location = new System.Drawing.Point(202, 47);
            this.button_checkPWD.Name = "button_checkPWD";
            this.button_checkPWD.Size = new System.Drawing.Size(75, 23);
            this.button_checkPWD.TabIndex = 1;
            this.button_checkPWD.Text = "验证";
            this.button_checkPWD.UseVisualStyleBackColor = true;
            this.button_checkPWD.Click += new System.EventHandler(this.button_checkUPWD_Click);
            // 
            // button_conPlant
            // 
            this.button_conPlant.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_conPlant.Location = new System.Drawing.Point(268, 20);
            this.button_conPlant.Name = "button_conPlant";
            this.button_conPlant.Size = new System.Drawing.Size(75, 23);
            this.button_conPlant.TabIndex = 1;
            this.button_conPlant.Text = "连接P";
            this.button_conPlant.UseVisualStyleBackColor = true;
            this.button_conPlant.Click += new System.EventHandler(this.button_checkCon_Plant_Click);
            // 
            // textBox_pwd
            // 
            this.textBox_pwd.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_pwd.Location = new System.Drawing.Point(53, 49);
            this.textBox_pwd.Name = "textBox_pwd";
            this.textBox_pwd.Size = new System.Drawing.Size(143, 21);
            this.textBox_pwd.TabIndex = 0;
            // 
            // WinForm_test
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(747, 514);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.statusStrip);
            this.Name = "WinForm_test";
            this.Text = "WinForm_test";
            this.Shown += new System.EventHandler(this.WinForm_test_Shown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox_test.ResumeLayout(false);
            this.groupBox_test.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox_test1.ResumeLayout(false);
            this.groupBox_test1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button_reLoadCfg;
        private System.Windows.Forms.ComboBox comboBox_cfgList;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_cfgDetail;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox_test;
        private System.Windows.Forms.TextBox textBox_DN;
        private System.Windows.Forms.Button button_loadUORG;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button_checkUID;
        private System.Windows.Forms.Button button_checkCon_Oracle;
        private System.Windows.Forms.TextBox textBox_uID;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBox_cfgDetail1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button_reLoadCfg1;
        private System.Windows.Forms.ComboBox comboBox_conPar1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox_test1;
        private System.Windows.Forms.TextBox textBox_orgs;
        private System.Windows.Forms.TextBox textBox_DN1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button_checkPWD;
        private System.Windows.Forms.Button button_conPlant;
        private System.Windows.Forms.TextBox textBox_pwd;
    }
}