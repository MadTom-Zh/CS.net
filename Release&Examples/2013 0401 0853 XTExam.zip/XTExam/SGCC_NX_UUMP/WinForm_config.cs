﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Media;

namespace SGCC_NX_UUMP
{
    public partial class WinForm_config : Form
    {
        public WinForm_config()
        {
            InitializeComponent();
            Application.ThreadException += new System.Threading.ThreadExceptionEventHandler(Application_ThreadException);
        }

        void Application_ThreadException(object sender, System.Threading.ThreadExceptionEventArgs e)
        {
            //throw new NotImplementedException();
            toolStripStatusLabel.Text = e.Exception.Message;
            SystemSounds.Hand.Play();
        }

        //public string
        private void WinForm_config_Shown(object sender, EventArgs e)
        {
            folderBD.SelectedPath = AppDomain.CurrentDomain.BaseDirectory;
            button_browse_Click(button_browse, e);
            ShowInfo("Ready");
            this.Show();
        }

        private void ShowInfo(string msg)
        {
            toolStripStatusLabel.Text = msg;
            Update();
        }

        FolderBrowserDialog folderBD = new FolderBrowserDialog();
        private void button_browse_Click(object sender, EventArgs e)
        {
            if (folderBD.ShowDialog() == DialogResult.OK)
            {
                textBox_ioPath.Text = folderBD.SelectedPath;
                button_refresh_Click(button_refresh, e);
            }
        }

        ConnectionParameters CP;
        private void button_refresh_Click(object sender, EventArgs e)
        {
            ShowInfo("Reloading...");
            if (textBox_ioPath.Text.Length == 0) return;
            CP = new ConnectionParameters(textBox_ioPath.Text);
            comboBox_profiles.Items.Clear();
            foreach (ConnectionParameters.Parameter par in CP.AllParameters)
            {
                comboBox_profiles.Items.Add(par.ParName);
            }
            ShowInfo("Ready");
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            CP.DelPar(comboBox_profiles.SelectedText);
            comboBox_profiles.Items.Remove(comboBox_profiles.SelectedItem);
        }

        private void button_save_Click(object sender, EventArgs e)
        {
            ShowInfo("Saving...");
            CP.SetPar(Data_fromUI());
            button_refresh_Click(button_refresh, e);
        }
        private ConnectionParameters.Parameter Data_fromUI()
        {
            ConnectionParameters.Parameter result = new ConnectionParameters.Parameter();
            result.ParName = textBox_parName.Text;
            result.ParDescription = textBox_parDescp.Text;
            result.IP = textBox_ip.Text;
            result.Port = int.Parse(textBox_port.Text);
            result.SI = textBox_si.Text;
            result.table = textBox_table.Text;
            result.Service = textBox_service.Text;
            result.User = textBox_user.Text;
            result.DN = textBox_DN.Text;
            result.Password = textBox_PWD.Text;
            return result;
        }
        private void Data_toUI(ConnectionParameters.Parameter conPar)
        {
            textBox_parName.Text = conPar.ParName;
            textBox_parDescp.Text = conPar.ParDescription;
            textBox_ip.Text = conPar.IP;
            textBox_port.Text = conPar.Port.ToString();
            textBox_si.Text = conPar.SI;
            textBox_table.Text = conPar.table;
            textBox_service.Text = conPar.Service;
            textBox_user.Text = conPar.User;
            textBox_DN.Text = conPar.DN;
            textBox_PWD.Text = conPar.Password;
        }

        private void comboBox_profiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            Data_toUI(CP.GetPar(comboBox_profiles.Text));
        }

    }
}
