﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SGCC_NX_UUMP
{
    public partial class WinForm_test : Form
    {
        public WinForm_test()
        {
            InitializeComponent();
            Application.ThreadException += new System.Threading.ThreadExceptionEventHandler(Application_ThreadException);
        }

        void Application_ThreadException(object sender, System.Threading.ThreadExceptionEventArgs e)
        {
            //throw new NotImplementedException();
            ShowInfo(e.Exception.Message);
            System.Media.SystemSounds.Hand.Play();
        }

        private void WinForm_test_Shown(object sender, EventArgs e)
        {
            groupBox_test.Enabled = false;
            folderBrowserDialog.SelectedPath = AppDomain.CurrentDomain.BaseDirectory;
            button_reLoadCfg_Click(button_reLoadCfg, e);
            ShowInfo("ready");
            this.Show();
        }

        private void ShowInfo(string msg)
        {
            toolStripStatusLabel.Text = msg;
            Update();
        }

        ConnectionParameters CP;
        List<ConnectionParameters.Parameter> AllConPars;
        private void button_reLoadCfg_Click(object sender, EventArgs e)
        {
            comboBox_cfgList.Items.Clear();
            comboBox_conPar1.Items.Clear();
            selectedConPar = null;
            textBox_cfgDetail.Text = "";
            if (folderBrowserDialog.ShowDialog(this) == DialogResult.OK)
            {
                CP = new ConnectionParameters(folderBrowserDialog.SelectedPath);
                AllConPars = CP.AllParameters;
                foreach (ConnectionParameters.Parameter conPar in AllConPars)
                {
                    comboBox_cfgList.Items.Add(conPar.ParName);
                    comboBox_conPar1.Items.Add(conPar.ParName);
                }
                groupBox_test1.Enabled = groupBox_test.Enabled = true;
            }
            else
            {
                groupBox_test1.Enabled = groupBox_test.Enabled = false;
            }
        }

        private ConnectionParameters.Parameter selectedConPar;
        private void comboBox_cfgList_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach (ConnectionParameters.Parameter conPar in AllConPars)
            {
                if (conPar.ParName == comboBox_cfgList.Text)
                {
                    selectedConPar = conPar;
                    string reLine = "\r\n", tab = "\t";
                    textBox_cfgDetail.Text = "";
                    textBox_cfgDetail.Text += "名称：" + reLine;
                    textBox_cfgDetail.Text += tab + selectedConPar.ParName + reLine;
                    textBox_cfgDetail.Text += "描述：" + reLine;
                    textBox_cfgDetail.Text += tab + selectedConPar.ParDescription + reLine;
                    textBox_cfgDetail.Text += "IP地址：" + reLine;
                    textBox_cfgDetail.Text += tab + selectedConPar.IP + reLine;
                    textBox_cfgDetail.Text += "端口：" + reLine;
                    textBox_cfgDetail.Text += tab + selectedConPar.Port + reLine;
                    textBox_cfgDetail.Text += "实例名：" + reLine;
                    textBox_cfgDetail.Text += tab + selectedConPar.SI + reLine;
                    textBox_cfgDetail.Text += "服务名：" + reLine;
                    textBox_cfgDetail.Text += tab + selectedConPar.Service + reLine;
                    textBox_cfgDetail.Text += "用户：" + reLine;
                    textBox_cfgDetail.Text += tab + selectedConPar.User + reLine;
                    textBox_cfgDetail.Text += "DN：" + reLine;
                    textBox_cfgDetail.Text += tab + selectedConPar.DN + reLine;
                    textBox_cfgDetail.Text += "密码：" + reLine;
                    textBox_cfgDetail.Text += tab + selectedConPar.Password + reLine;
                    textBox_cfgDetail.Text += "表名：" + reLine;
                    textBox_cfgDetail.Text += tab + selectedConPar.table + reLine;
                    break;
                }
            }
        }

        private ConnectionParameters.Parameter selectedConPar1;
        private void comboBox_conPar1_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach (ConnectionParameters.Parameter conPar in AllConPars)
            {
                if (conPar.ParName == comboBox_conPar1.Text)
                {
                    selectedConPar1 = conPar;
                    string reLine = "\r\n", tab = "\t";
                    textBox_cfgDetail1.Text = "";
                    textBox_cfgDetail1.Text += "名称：" + reLine;
                    textBox_cfgDetail1.Text += tab + selectedConPar1.ParName + reLine;
                    textBox_cfgDetail1.Text += "描述：" + reLine;
                    textBox_cfgDetail1.Text += tab + selectedConPar1.ParDescription + reLine;
                    textBox_cfgDetail1.Text += "IP地址：" + reLine;
                    textBox_cfgDetail1.Text += tab + selectedConPar1.IP + reLine;
                    textBox_cfgDetail1.Text += "端口：" + reLine;
                    textBox_cfgDetail1.Text += tab + selectedConPar1.Port + reLine;
                    textBox_cfgDetail1.Text += "实例名：" + reLine;
                    textBox_cfgDetail1.Text += tab + selectedConPar1.SI + reLine;
                    textBox_cfgDetail1.Text += "服务名：" + reLine;
                    textBox_cfgDetail1.Text += tab + selectedConPar1.Service + reLine;
                    textBox_cfgDetail1.Text += "用户：" + reLine;
                    textBox_cfgDetail1.Text += tab + selectedConPar1.User + reLine;
                    textBox_cfgDetail1.Text += "DN：" + reLine;
                    textBox_cfgDetail1.Text += tab + selectedConPar1.DN + reLine;
                    textBox_cfgDetail1.Text += "密码：" + reLine;
                    textBox_cfgDetail1.Text += tab + selectedConPar1.Password + reLine;
                    textBox_cfgDetail1.Text += "表名：" + reLine;
                    textBox_cfgDetail1.Text += tab + selectedConPar1.table + reLine;
                    break;
                }
            }
        }
        private void button_checkCon_Click(object sender, EventArgs e)
        {
            ShowInfo("正在启动连接");
            if (PlantWatcher.Indexer.CheckConnection_Oracle(folderBrowserDialog.SelectedPath, comboBox_cfgList.Text))
            {
                ShowInfo("成功！");
            }
            else
            {
                ShowInfo("失败！");
            }
        }

        private void button_checkUID_Click(object sender, EventArgs e)
        {
            ShowInfo("正在查找用户");
            string userDN = PlantWatcher.Indexer.GetUserDN_Oracle(folderBrowserDialog.SelectedPath, comboBox_cfgList.Text, textBox_uID.Text);
            if (userDN != null)
            {
                ShowInfo("成功！");
                textBox_DN1.Text = textBox_DN.Text = userDN;
            }
            else
            {
                ShowInfo("失败！");
                textBox_DN.Text = "";
            }
        }


        private void button_checkCon_Plant_Click(object sender, EventArgs e)
        {
            ShowInfo("正在启动连接");
            if (PlantWatcher.CheckConnection(folderBrowserDialog.SelectedPath, comboBox_conPar1.Text))
            {
                ShowInfo("成功！");
            }
            else
            {
                ShowInfo("失败！");
            }
        }

        private void button_checkUPWD_Click(object sender, EventArgs e)
        {
            ShowInfo("正在查找用户");
            if (PlantWatcher.IsUserPass(folderBrowserDialog.SelectedPath, comboBox_conPar1.Text, textBox_DN1.Text, textBox_pwd.Text))
            {
                ShowInfo("成功！");
            }
            else
            {
                ShowInfo("失败！");
            }
        }

        private void button_loadUORG_Click(object sender, EventArgs e)
        {
            ShowInfo("正在查找用户DN");
            List<string> orgs = PlantWatcher.GetFullNames(folderBrowserDialog.SelectedPath, comboBox_conPar1.Text, textBox_DN1.Text);
            if (orgs == null || orgs.Count == 0)
            {
                ShowInfo("失败！");
            }
            else
            {
                ShowInfo("成功！");
                string orgStr = "";
                for (int i = 0; i < orgs.Count; i++)
                {
                    if (orgStr.Length > 0) orgStr += "\\";
                    orgStr += orgs[i];
                }
                textBox_orgs.Text = orgStr;
            }
        }

    }
}
