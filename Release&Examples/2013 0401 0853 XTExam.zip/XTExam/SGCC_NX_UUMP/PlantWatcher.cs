﻿using System;
using System.Collections.Generic;
using System.Text;

using Novell.Directory.Ldap;
using Novell.Directory.Ldap.Utilclass;

using System.Data;
using System.IO;

using Oracle.DataAccess.Client;

namespace SGCC_NX_UUMP
{
    public class PlantWatcher
    {
        private static void Log(string msg)
        {
            string logPath = AppDomain.CurrentDomain.BaseDirectory + "\\SGCC_NX_UUMP.Log";
            if (false == Directory.Exists(logPath))
            {
                Directory.CreateDirectory(logPath);
            }
            DateTime now = DateTime.Now;
            string fileFullName = logPath + "\\" + now .ToString("yyyy-MM-dd")+ ".txt";
            File.AppendAllText(fileFullName,now.ToString("HH:mm:ss.fff")+ msg);
        }
        public class Indexer
        {
            public static bool CheckConnection_Oracle(string ioConfigDir, string configName)
            {
                return (GetUserDN_Oracle(ioConfigDir, configName, "00110024") == null) ? false : true;
            }
            public static string GetUserDN_Oracle(string ioConfigDir, string configName, string uId)
            {
                string result = null;
                ConnectionParameters CP = new ConnectionParameters(ioConfigDir);
                ConnectionParameters.Parameter conPar = CP.GetPar(configName);
                try
                {
                    OracleConnection con = new OracleConnection();
                    //con.ConnectionString = "Data Source=" + conPar.IP + ":" + conPar.Port + ":orcl;Persist Security Info=True;User Id=" + conPar.User + "; Password=" + conPar.Password + "";
                    //con.ConnectionString = "Data Source=" + conPar.IP + ":" + conPar.Port + ";Integrated Security=no;User Id=" + conPar.User + "; Password=" + conPar.Password + "";

                    con.ConnectionString = "Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=" + conPar.IP + ") (PORT=" + conPar.Port + ")))(CONNECT_DATA=(SERVICE_NAME=" + conPar.Service + ")));Persist Security Info=True;User Id=" + conPar.User + "; Password=" + conPar.Password + "";
                    con.Open();
                    if (con.State != ConnectionState.Open)
                    {
                        throw new Exception("Denial of DB Server connection, bad connection parameters!");
                    }
                    //string sql = "select user_dn from acm_user where user_name='" + uId + "'";
                    string sql = "select user_dn from uums_acm_user where user_name='" + uId + "'";
                    OracleDataAdapter oracleDA = new OracleDataAdapter(sql, con);
                    DataSet resultDS = new System.Data.DataSet();
                    oracleDA.Fill(resultDS);
                    if (resultDS.Tables.Count >= 1)
                    {
                        if (resultDS.Tables[0].Rows.Count >= 1)
                        {
                            result = resultDS.Tables[0].Rows[0]["USER_DN"].ToString();
                        }
                    }
                    con.Close();
                }
                catch (Exception err)
                {
                    // for testing
                    throw err;
                }
                return result;
            }
        }
        public static bool CheckConnection(string ioConfigDir, string configName)
        {
            ConnectionParameters CP = new ConnectionParameters(ioConfigDir);
            ConnectionParameters.Parameter conPar = CP.GetPar(configName);
            LdapConnection con = new LdapConnection();
            con.Connect(conPar.IP, conPar.Port);
            try
            {
                con.Bind(LdapConnection.Ldap_V3, conPar.DN, conPar.Password);
                return true;
            }
            catch (LdapException err)
            {
                Log(err.ToString());
                return false;
            }
            finally
            {
                con.Disconnect();
            }
        }

        public static bool IsUserPass(string ioConfigDir, string configName, string DN, string password)
        {
            ConnectionParameters CP = new ConnectionParameters(ioConfigDir);
            ConnectionParameters.Parameter conPar = CP.GetPar(configName);
            LdapConnection con = new LdapConnection();
            con.Connect(conPar.IP, conPar.Port);
            try
            {
                con.Bind(LdapConnection.Ldap_V3, DN, password);
                return true;
            }
            catch (LdapException err)
            {
                Log(err.ToString());
                return false;
            }
            finally
            {
                con.Disconnect();
            }
        }
        public static List<string> GetFullNames(string ioConfigDir, string configName, string DN)
        {
            LdapConnection con = new LdapConnection();
            try
            {
                ConnectionParameters CP = new ConnectionParameters(ioConfigDir);
                ConnectionParameters.Parameter conPar = CP.GetPar(configName);

                con.Connect(conPar.IP, conPar.Port);
                return _GetFullNames(ref con, ref conPar, DN);
            }
            catch (LdapException err)
            {
                Log(err.ToString());
                return null;
            }
            finally
            {
                con.Disconnect();
            }
        }
        private static List<string> _GetFullNames(ref LdapConnection con, ref  ConnectionParameters.Parameter conPar, string DN)
        {
            DN = DN.Trim();
            if (DN.StartsWith("o=")) return null;
            con.Bind(LdapConnection.Ldap_V3, conPar.DN, conPar.Password);

            LdapSearchResults lsc = con.Search(DN,
                                                LdapConnection.SCOPE_SUB,
                                                "",
                                                null,
                                                false);

            System.Collections.IEnumerator ienum = lsc.next().getAttributeSet().GetEnumerator();

            //string pairs = "";
            string curOrg = null;
            while (ienum.MoveNext())
            {
                LdapAttribute attribute = (LdapAttribute)ienum.Current;
                //pairs += attribute.Name + "\t" + attribute.StringValue + "\r\n";
                if (DN.StartsWith("cn") && attribute.Name == "fullName")
                {
                    curOrg = attribute.StringValue;
                    break;
                }
                //else if (attribute.Name == "SgccChnName")
                else if (attribute.Name.ToLower() == "sgccchnname")
                {
                    curOrg = attribute.StringValue;
                    break;
                }

            }
            if (DN.Contains(",")) DN = DN.Substring(DN.IndexOf(',') + 1);
            List<string> subOrgNames = _GetFullNames(ref con, ref conPar, DN);
            List<string> result = new List<string>();
            if (subOrgNames != null)
            {
                for (int i = 0; i < subOrgNames.Count; i++)
                {
                    result.Add(subOrgNames[i]);
                }
            }
            result.Add(curOrg);
            return result;
        }
    }
}
