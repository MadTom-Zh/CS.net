﻿using System;
using System.Collections.Generic;
using System.Text;

using System.IO;

namespace SGCC_NX_UUMP
{
    public class ConnectionParameters
    {
        public class Parameter
        {
            public string ParName;
            public string ParDescription;

            public string IP;
            public int Port;
            public string SI;
            public string Service;
            public string User;
            public string DN;
            public string Password;
            public string table;

            public Parameter()
            {
            }

            public static string PERFIX_PAR_NAME = "NAME:";
            public static string PERFIX_PAR_DESCRIP_START = "DESCRIPTION START:";
            public static string PERFIX_PAR_DESCRIP_END = "DESCRIPTION END;";

            public static string PERFIX_IP = "IP:";
            public static string PERFIX_PORT = "PORT:";
            public static string PERFIX_SERVICE = "SERVICE:";
            public static string PERFIX_USER = "USER:";
            public static string PERFIX_DN = "DN:";
            public static string PERFIX_PWD = "PWD:";
            public static string PERFIX_SI = "SI:";
            public static string PERFIX_TABLE = "TABLE:";

            public string IOContent
            {
                set
                {
                    string[] lines = value.Split(new string[] { "\r\n" }, StringSplitOptions.None);
                    ParDescription = "";
                    bool isDescrip = false;
                    foreach (string line in lines)
                    {
                        if (line.StartsWith("==")) continue;
                        if (line.StartsWith(PERFIX_PAR_NAME)) ParName = line.Substring(PERFIX_PAR_NAME.Length);
                        else if (line.StartsWith(PERFIX_PAR_DESCRIP_END)) isDescrip = false;
                        else if (isDescrip)
                        {
                            if (ParDescription.Length > 0) ParDescription += "\r\n";
                            ParDescription += line;
                        }
                        else if (line.StartsWith(PERFIX_PAR_DESCRIP_START)) isDescrip = true;
                        else if (line.StartsWith(PERFIX_IP)) IP = line.Substring(PERFIX_IP.Length);
                        else if (line.StartsWith(PERFIX_PORT)) Port = int.Parse(line.Substring(PERFIX_PORT.Length));
                        else if (line.StartsWith(PERFIX_SI)) SI = line.Substring(PERFIX_SI.Length);
                        else if (line.StartsWith(PERFIX_SERVICE)) Service = line.Substring(PERFIX_SERVICE.Length);
                        else if (line.StartsWith(PERFIX_USER)) User = line.Substring(PERFIX_USER.Length);
                        else if (line.StartsWith(PERFIX_DN)) DN = line.Substring(PERFIX_DN.Length);
                        else if (line.StartsWith(PERFIX_PWD)) Password = line.Substring(PERFIX_PWD.Length);
                        else if (line.StartsWith(PERFIX_TABLE)) table = line.Substring(PERFIX_TABLE.Length);
                    }
                }
                get
                {
                    string result = "";
                    string reLine = "\r\n";
                    result += PERFIX_PAR_NAME + ParName + reLine;
                    result += PERFIX_PAR_DESCRIP_START + reLine;
                    result += ParDescription + reLine;
                    result += PERFIX_PAR_DESCRIP_END + reLine;
                    result += PERFIX_IP + IP + reLine;
                    result += PERFIX_PORT + Port + reLine;
                    result += PERFIX_SI + SI + reLine;
                    result += PERFIX_SERVICE + Service + reLine;
                    result += PERFIX_USER + User + reLine;
                    result += PERFIX_DN + DN + reLine;
                    result += PERFIX_PWD + Password + reLine;
                    result += PERFIX_TABLE + table;
                    return result;
                }
            }
        }
        private static string _PAR_SEPARATOR = "==========================";

        public List<Parameter> AllParameters;
        private string _ioStorDir;
        private static string _IO_FILENAME = "SGCC_NX_UUMP.ConnectionParameters";
        private string _ioFullFileName;
        public ConnectionParameters(string ioStorDir)
        {
            _ioStorDir = ioStorDir;
            if (!Directory.Exists(_ioStorDir)) Directory.CreateDirectory(_ioStorDir);
            _ioFullFileName = _ioStorDir + "\\" + _IO_FILENAME;
            if (!File.Exists(_ioFullFileName)) File.WriteAllText(_ioFullFileName, "");
            LoadAllPars();
        }
        private List<Parameter> LoadAllPars()
        {
            AllParameters = new List<Parameter>();
            string[] ioLines = File.ReadAllLines(_ioFullFileName);
            string block = "";
            Parameter newPar;
            foreach (string line in ioLines)
            {
                if (line.StartsWith("=="))
                {
                    if (block.Length > 0)
                    {
                        newPar = new Parameter();
                        newPar.IOContent = block;
                        AllParameters.Add(newPar);
                        block = "";
                    }
                    continue;
                }
                if (block.Length > 0) block += "\r\n";
                block += line;
            }
            if (block.Length > 0)
            {
                newPar = new Parameter();
                newPar.IOContent = block;
                AllParameters.Add(newPar);
            }
            return AllParameters;
        }

        public Parameter GetPar(string parName)
        {
            foreach (Parameter par in AllParameters)
            {
                if (par.ParName == parName)
                {
                    return par;
                }
            }
            return null;
        }
        public Parameter GetPar_byIP(string IP)
        {
            foreach (Parameter par in AllParameters)
            {
                if (par.IP == IP)
                {
                    return par;
                }
            }
            return null;
        }
        public Parameter GetPar(string IP, string table)
        {
            foreach (Parameter par in AllParameters)
            {
                if (par.IP == IP && par.table == table)
                {
                    return par;
                }
            }
            return null;
        }

        public void SetPar(Parameter newPar)
        {
            Parameter foundPar = null;
            bool found = false;
            for (int i = AllParameters.Count - 1; i >= 0; i--)
            {
                foundPar = AllParameters[i];
                if (foundPar.ParName == newPar.ParName)
                {
                    AllParameters[i] = newPar;
                    found = true;
                    break;
                }
            }
            if (!found) AllParameters.Add(newPar);
            SaveAllPars();
        }
        public void DelPar(string parName)
        {
            Parameter foundPar = null;
            bool found = false;
            for (int i = AllParameters.Count - 1; i >= 0; i--)
            {
                foundPar = AllParameters[i];
                if (foundPar.ParName == parName)
                {
                    AllParameters.RemoveAt(i);
                    found = true;
                    break;
                }
            }
            if (found) SaveAllPars();
        }
        private void SaveAllPars()
        {
            string content = "";
            foreach (Parameter par in AllParameters)
            {
                content += _PAR_SEPARATOR + "\r\n";
                content += par.IOContent + "\r\n";
            }
            File.WriteAllText(_ioFullFileName, content);
        }
    }
}
