﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;
using SharpCompress;

namespace XTExam.CodeSharing.Entities
{
    public class DataProcessing
    {
        public class UserList
        {
            public class Header
            {
                public DateTime createTime;
                public string creater;
                public DateTime modifyTime;
                public string modifier;
                public string title;
                public string remark;

                public Header(string title, string creater, DateTime createTime)
                {
                    this.title = title;
                    creater = modifier = creater;
                    createTime = modifyTime = createTime;
                }
                public Header(string IOContent)
                {
                    if (IOContent == null) IOContent = "";
                    this.IOContent = IOContent;
                }

                private static string SEPARATOR_CREATE_TIME = "####CREATETIME:";
                private static string SEPARATOR_CREATER = "####CREATER:";
                private static string SEPARATOR_MODIFY_TIME = "####MODIFYTIME:";
                private static string SEPARATOR_MODIFIER = "####MODIFIER:";
                private static string SEPARATOR_TITLE = "####TITEL:";
                private static string SEPARATOR_REMARK_START = "####START_REMARK:";
                private static string SEPARATOR_REMARK_END = "####END_REMARK;";
                private static string FORMAT_DATE_TO_STRING = "yyyy-MM-dd HH:mm:ss";
                /// <summary>
                /// get or set Content for IO
                /// if set it, original value will be changed
                /// </summary>
                public string IOContent
                {
                    get
                    {
                        string result = "";
                        string reLine = "\r\n";
                        result += SEPARATOR_CREATE_TIME + createTime.ToString(FORMAT_DATE_TO_STRING) + reLine;
                        result += SEPARATOR_CREATER + creater + reLine;
                        result += SEPARATOR_MODIFY_TIME + modifyTime.ToString(FORMAT_DATE_TO_STRING) + reLine;
                        result += SEPARATOR_MODIFIER + modifier + reLine;
                        result += SEPARATOR_TITLE + title + reLine;
                        result += SEPARATOR_REMARK_START + reLine;
                        result += remark + reLine;
                        result += SEPARATOR_REMARK_END;
                        return result;
                    }
                    set
                    {
                        string[] conLines = value.Split(new string[] { "\r\n" }, StringSplitOptions.None);
                        string line;
                        bool isRemark = false;
                        remark = "";
                        for (int i = 0; i < conLines.Length; i++)
                        {
                            line = conLines[i];
                            if (line.StartsWith(SEPARATOR_CREATE_TIME))
                            {
                                createTime = DateTime.Parse(line.Substring(SEPARATOR_CREATE_TIME.Length));
                            }
                            else if (line.StartsWith(SEPARATOR_CREATER))
                            {
                                creater = line.Substring(SEPARATOR_CREATER.Length);
                            }
                            else if (line.StartsWith(SEPARATOR_MODIFY_TIME))
                            {
                                modifyTime = DateTime.Parse(line.Substring(SEPARATOR_MODIFY_TIME.Length));
                            }
                            else if (line.StartsWith(SEPARATOR_MODIFIER))
                            {
                                modifier = line.Substring(SEPARATOR_MODIFIER.Length);
                            }
                            else if (line.StartsWith(SEPARATOR_TITLE))
                            {
                                title = line.Substring(SEPARATOR_TITLE.Length);
                            }
                            else if (line.StartsWith(SEPARATOR_REMARK_END))
                            {
                                isRemark = false;
                            }
                            else if (isRemark)
                            {
                                if (remark.Length > 0) remark += "\r\n";
                                remark += line;
                            }
                            else if (line.StartsWith(SEPARATOR_REMARK_START))
                            {
                                isRemark = true;
                            }
                        }
                    }
                }

                /// <summary>
                /// get or set Line Struction of ListHeader
                /// content as [create time] [creater] [modify time] [modifier]
                /// [title] and [remark]
                /// </summary>
                public List<string> LineContent
                {
                    get
                    {
                        List<string> result = new List<string>();
                        string[] lines = this.IOContent.Split(new string[] { "\r\n" }, StringSplitOptions.None);
                        bool itemFound = false;
                        for (int i = 0; i < lines.Length; i++)
                        {
                            if (lines[i].StartsWith(SEPARATOR_CREATE_TIME))
                            {
                                result.Add(lines[i].Substring(SEPARATOR_CREATE_TIME.Length));
                                itemFound = true;
                                break;
                            }
                        }
                        if (!itemFound) result.Add("");
                        itemFound = false;
                        for (int i = 0; i < lines.Length; i++)
                        {
                            if (lines[i].StartsWith(SEPARATOR_CREATER))
                            {
                                result.Add(lines[i].Substring(SEPARATOR_CREATER.Length));
                                itemFound = true;
                                break;
                            }
                        }
                        if (!itemFound) result.Add("");
                        itemFound = false;
                        for (int i = 0; i < lines.Length; i++)
                        {
                            if (lines[i].StartsWith(SEPARATOR_MODIFY_TIME))
                            {
                                result.Add(lines[i].Substring(SEPARATOR_MODIFY_TIME.Length));
                                itemFound = true;
                                break;
                            }
                        }
                        if (!itemFound) result.Add("");
                        itemFound = false;
                        for (int i = 0; i < lines.Length; i++)
                        {
                            if (lines[i].StartsWith(SEPARATOR_MODIFIER))
                            {
                                result.Add(lines[i].Substring(SEPARATOR_MODIFIER.Length));
                                itemFound = true;
                                break;
                            }
                        }
                        if (!itemFound) result.Add("");


                        itemFound = false;
                        for (int i = 0; i < lines.Length; i++)
                        {
                            if (lines[i].StartsWith(SEPARATOR_TITLE))
                            {
                                result.Add(lines[i].Substring(SEPARATOR_TITLE.Length));
                                itemFound = true;
                                break;
                            }
                        }
                        if (!itemFound) result.Add("");
                        bool remarkStart = false;
                        string remark = "";
                        for (int i = 0; i < lines.Length; i++)
                        {
                            if (lines[i].StartsWith(SEPARATOR_REMARK_END))
                            {
                                break;
                            }
                            else if (remarkStart)
                            {
                                if (remark.Length > 0) remark += "\r\n";
                                remark += lines[i];
                            }
                            else if (lines[i].StartsWith(SEPARATOR_REMARK_START))
                            {
                                remarkStart = true;
                            }
                        }
                        result.Add(remark);
                        return result;
                    }
                    set
                    {
                        if (value[0].Length > 0) createTime = DateTime.Parse(value[0]);
                        if (value[1].Length > 0) creater = value[1];
                        if (value[2].Length > 0) modifyTime = DateTime.Parse(value[2]);
                        if (value[3].Length > 0) modifier = value[3];

                        if (value[4].Length > 0) title = value[4];
                        if (value[5].Length > 0) remark = value[5];
                    }
                }
            }
            public class Body
            {
            }
        }

        public class UserRegister
        {
            public class UserInfo
            {
                public string id;
                public string name;
                public string logenIP;
                public string orgPath;

                public string exPwd;
                public string inPwd;

                public DateTime createTime;
                public string creater;
                public DateTime modifyTime;
                public string modifier;

                public bool couldAdminUser = false;
                public bool couldCheckResult = false;
                public bool couldMakePaper = false;
                public bool couldAuditPaper = false;
                public bool couldAdminAnnouncement = false;

                public string auditOrgPathes;

                public static string FORMAT_DATE_LONGSTRING = "yyyy-MM-dd HH:mm:ss";

                public UserInfo(string id, string op)
                {
                    this.id = id;
                    name = id;
                    logenIP = "";
                    orgPath = "";

                    exPwd = "";
                    inPwd = "xtgs_examination_system";

                    DateTime now = DateTime.Now;
                    createTime = now;
                    creater = op;
                    modifyTime = now;
                    modifier = op;

                    auditOrgPathes = "{none}";
                }
                public UserInfo(string ioContent)
                {
                    this.IOContent = ioContent;
                }
                public bool hasId
                {
                    get
                    {
                        return (id != null && id.Length > 0);
                    }
                }
                public string IOContent
                {
                    get
                    {
                        string result = "";
                        result += id + "\t";
                        result += name + "\t";
                        result += logenIP + "\t";
                        result += orgPath + "\t";

                        result += exPwd + "\t";
                        result += inPwd + "\t";

                        result += createTime.ToString(FORMAT_DATE_LONGSTRING) + "\t";
                        result += creater + "\t";
                        result += modifyTime.ToString(FORMAT_DATE_LONGSTRING) + "\t";
                        result += modifier + "\t";

                        result += couldAdminUser + "\t";
                        result += couldCheckResult + "\t";
                        result += couldMakePaper + "\t";
                        result += couldAuditPaper + "\t";
                        result += couldAdminAnnouncement + "\t";

                        result += auditOrgPathes;
                        return result;
                    }
                    set
                    {
                        string[] parts = value.Split(new char[] { '\t' });
                        id = parts[0];
                        name = parts[1];
                        logenIP = parts[2];
                        orgPath = parts[3];

                        exPwd = parts[4];
                        inPwd = parts[5];

                        createTime = DateTime.Parse(parts[6]);
                        creater = parts[7];
                        modifyTime = DateTime.Parse(parts[8]);
                        modifier = parts[9];

                        couldAdminUser = bool.Parse(parts[10]);
                        couldCheckResult = bool.Parse(parts[11]);
                        couldMakePaper = bool.Parse(parts[12]);
                        couldAuditPaper = bool.Parse(parts[13]);
                        couldAdminAnnouncement = bool.Parse(parts[14]);
                        auditOrgPathes = parts[15];
                    }
                }
                private static string SEPARATOR_AUDIT_ORGPATH_JOIN = "##>><<##";
                public string[] auditOrgPathList()
                {
                    return auditOrgPathes.Split(new string[] { SEPARATOR_AUDIT_ORGPATH_JOIN }, StringSplitOptions.RemoveEmptyEntries);
                }

                public List<string> LineContent
                {
                    get
                    {
                        List<string> result = new List<string>();
                        string[] parts = this.IOContent.Split(new char[] { '\t' });
                        for (int i = 0; i < parts.Length; i++)
                        {
                            result.Add(parts[i]);
                        }
                        return result;
                    }
                }
            }
            public class UserInfoEx
            {
                public string id;
                public string name;
                public bool isPaMem;
                public string idNo;
                public string orgPath;

                public UserInfoEx()
                {
                }
                public UserInfoEx(string ioContent)
                {
                    this.IOContent = ioContent;
                }
                public string IOContent
                {
                    get
                    {
                        string result = "";
                        result += id + "\t";
                        result += name + "\t";
                        result += ((isPaMem == true) ? "1" : "0") + "\t";
                        result += idNo + "\t";
                        result += orgPath + "\t";

                        return result;
                    }
                    set
                    {
                        string[] parts = value.Split(new char[] { '\t' });
                        id = parts[0];
                        name = parts[1];
                        isPaMem = (parts[2] == "1");
                        idNo = parts[3];
                        orgPath = parts[4];
                    }
                }

            }

            public class OrganFrame
            {
                private string _name;
                public string name { get { return _name; } }
                public string FullName
                {
                    get
                    {
                        if (_parent == null)
                        {
                            if (_givenPath != null && _givenPath.Length > 0)
                            {
                                return _givenPath + "\\" + name;
                            }
                            else return name;
                        }
                        else return (_parent.FullName + "\\" + name);
                    }
                }

                private string _givenPath;
                public string givenPath
                {
                    get
                    {
                        if (_givenPath == null || _givenPath.Length <= 0)
                        {
                            return null;
                        }
                        else
                        {
                            return _givenPath;
                        }
                    }
                }
                private OrganFrame _parent = null;
                public OrganFrame parent { get { return _parent; } }
                public void ReSet_Parent(OrganFrame parent)
                {
                    _parent = parent;
                }
                public void ReSet_Parent(string parentFullName)
                {
                    _givenPath = parentFullName;
                }

                public OrganFrame(string parentFullName, string name)
                {
                    _givenPath = parentFullName;
                    _name = name;
                }
                public OrganFrame(ref OrganFrame parent, string name)
                {
                    _parent = parent;
                    _name = name;
                }
                public OrganFrame(string ioContent)
                {
                    IOContent_onMyLevel = ioContent;
                }

                public List<OrganFrame> subOrgs = new List<OrganFrame>();
                public List<UserInfo> members = new List<UserInfo>();
                public bool manual_hasChild = false;
                public bool hasChild
                {
                    get { return (subOrgs.Count > 0) || (members.Count > 0); }
                }

                public void Add_subOrg(OrganFrame subOrg)
                {
                    // parent name, or, myyyyyy path ?????
                    //if (subOrg.givenParentPath != null)
                    //{
                    //    if ((this.givenParentPath != null && this.givenParentPath != subOrg.givenParentPath)
                    //        ||(this.parent != null && this.parent.FullName != subOrg.givenParentPath))
                    //    {
                    //        throw new Exception("Can Not Add SubOrg ["+subOrg.name+"] at ["+this.givenParentPath+"]");
                    //    }
                    //}
                    //else if (subOrg.parent != null)
                    //{
                    //    if ((this.givenParentPath != null && this.givenParentPath != subOrg.parent.FullName)
                    //        || (this.parent != null && this.parent.FullName != subOrg.parent.FullName))
                    //    {
                    //        throw new Exception("Can Not Add SubOrg [" + subOrg.name + "] at [" + this.parent.FullName + "]");
                    //    }
                    //}
                    subOrg.ReSet_Parent(this);
                    subOrgs.Add(subOrg);
                }
                public void Add_member(UserInfo member)
                {
                    members.Add(member);
                }

                private static string FLAG_RELINE = "\r\n";
                private static string FLAG_TAB = "\t";
                private static string FLAG_PATH = "OrgPath: ";
                private static string FLAG_NAME = "OrgName: ";
                private static string FLAG_ONE_SUBORGNAME_ANDIF_HASCHILD = "SubOrgName_and_ifHasChild: ";
                private static string FLAG_ONE_MEMBER_IOCONTENT = "MemberIOContent: ";
                public string IOContent_onMyLevel
                {
                    set
                    {
                        string[] lines = value.Split(new string[] { "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);
                        string[] subOrgParts;
                        OrganFrame subOrg;
                        subOrgs.Clear();
                        members.Clear();
                        foreach (string line in lines)
                        {
                            if (line.StartsWith(FLAG_PATH))
                            {
                                this._parent = null;
                                this._givenPath = line.Substring(FLAG_PATH.Length);
                            }
                            else if (line.StartsWith(FLAG_NAME))
                            {
                                this._name = line.Substring(FLAG_NAME.Length);
                            }
                            else if (line.StartsWith(FLAG_ONE_SUBORGNAME_ANDIF_HASCHILD))
                            {
                                subOrgParts = line.Substring(FLAG_ONE_SUBORGNAME_ANDIF_HASCHILD.Length).Split(new string[] { FLAG_TAB }, StringSplitOptions.None);
                                subOrg = new OrganFrame(this._givenPath, subOrgParts[0]);
                                subOrg.manual_hasChild = bool.Parse(subOrgParts[1]);
                                subOrgs.Add(subOrg);
                            }
                            else if (line.StartsWith(FLAG_ONE_MEMBER_IOCONTENT))
                            {
                                members.Add(new UserInfo(line.Substring(FLAG_ONE_MEMBER_IOCONTENT.Length)));
                            }
                        }
                    }
                    get
                    {
                        string result = "";
                        if (this.parent != null)
                        {
                            result += FLAG_PATH + this.parent.FullName + FLAG_RELINE;
                        }
                        else if (this.givenPath != null)
                        {
                            result += FLAG_PATH + this.givenPath + FLAG_RELINE;
                        }
                        else result += FLAG_PATH + "" + FLAG_RELINE;

                        result += FLAG_NAME + this.name + FLAG_RELINE;
                        foreach (OrganFrame oneOrg in subOrgs)
                        {
                            result += FLAG_ONE_SUBORGNAME_ANDIF_HASCHILD + oneOrg.name + FLAG_TAB
                                + (oneOrg.hasChild || oneOrg.manual_hasChild).ToString() + FLAG_RELINE;
                        }
                        foreach (UserInfo oneMem in members)
                        {
                            result += FLAG_ONE_MEMBER_IOCONTENT + oneMem.IOContent + FLAG_RELINE;
                        }
                        return result;
                    }
                }
            }
        }


        public class Results
        {
            public class ResultData
            {
                public string hallName { set; get; }
                public string userId { set; get; }
                public string userName { set; get; }
                public string userOrgPath { set; get; }
                public bool isPaperAudited { set; get; }
                public double grades { set; get; }

                public ResultData()
                {
                }
                public ResultData(string ioContent)
                {
                    IOContent = ioContent;
                }

                public string IOContent
                {
                    set
                    {
                        string[] parts = value.Split(new char[] { '\t' });
                        hallName = parts[0];
                        userId = parts[1];
                        userName = parts[2];
                        userOrgPath = parts[3];
                        isPaperAudited = (parts[4] == "1") ? true : false;
                        grades = double.Parse(parts[5]);
                    }
                    get
                    {
                        string tabChar = "\t";
                        string result = "";
                        result += hallName + tabChar;
                        result += userId + tabChar;
                        result += userName + tabChar;
                        result += userOrgPath + tabChar;
                        result += (isPaperAudited ? "1" : "0") + tabChar;
                        result += grades + tabChar;

                        return result;
                    }
                }
            }
            public class GraphData_Ex2013
            {
                public class DataItem
                {
                    public string organi;
                    public int countAll;
                    public int countPaMem;

                    public DataItem Clone()
                    {
                        return new DataItem(this.IOContent);
                    }

                    public DataItem()
                    {
                    }
                    public DataItem(string organi, int countAll, int countPaMem)
                    {
                        this.organi = organi;
                        this.countAll = countAll;
                        this.countPaMem = countPaMem;
                    }
                    public DataItem(string ioContent)
                    {
                        IOContent = ioContent;
                    }

                    public string IOContent
                    {
                        set
                        {
                            string[] parts = value.Split(new char[] { '\t' });
                            organi = parts[0];
                            countAll = int.Parse(parts[1]);
                            countPaMem = int.Parse(parts[2]);
                        }
                        get
                        {
                            string result = "";
                            string tabChar = "\t";
                            result += organi + tabChar;
                            result += countAll + tabChar;
                            result += countPaMem + "";
                            return result;
                        }
                    }
                }

                private List<DataItem> _items = new List<DataItem>();
                public List<DataItem> Items
                {
                    get
                    {
                        return _items;
                    }
                    set
                    {
                        _items = value;
                    }
                }

                public GraphData_Ex2013()
                {
                }
                public GraphData_Ex2013(string ioContent)
                {
                    IOContent = ioContent;
                }

                public void AddItem(string organi, int countAll, int countPaMem)
                {
                    AddItem(new DataItem(organi, countAll, countPaMem));
                }
                public void AddItem(DataItem item)
                {
                    _items.Add(item);
                    _needSort = true;
                }

                public void AddCount(string organi, int countAll, int countPaMem)
                {
                    DataItem curItem;
                    bool notFound = true;
                    for (int i = _items.Count - 1; i >= 0; i--)
                    {
                        curItem = _items[i];
                        if (organi == curItem.organi)
                        {
                            curItem.countAll += countAll;
                            curItem.countPaMem += countPaMem;
                            _items[i] = curItem;
                            notFound = false;
                        }
                    }
                    if (notFound == true)
                    {
                        _items.Add(new DataItem(organi, countAll, countPaMem));
                    }
                    _needSort = true;
                }

                private bool _needSort = true;
                public bool NeedSort
                {
                    get
                    {
                        return _needSort;
                    }
                }
                public void SortItems_CountAll_DESC()
                {
                    DataItem latterItem, formerItem;
                    for (int i = _items.Count - 1; i > 0; i--)
                    {
                        for (int j = i - 1; j >= 0; j--)
                        {
                            latterItem = _items[i];
                            formerItem = _items[j];
                            if (formerItem.countAll < latterItem.countAll)
                            {
                                _SwapItems(i, j);
                            }
                        }
                    }
                    _needSort = false;
                }
                private void _SwapItems(int idx1, int idx2)
                {
                    DataItem tempItem = _items[idx1].Clone();
                    _items[idx1] = _items[idx2].Clone();
                    _items[idx2] = tempItem;
                }

                public int CountAll_Max
                {
                    get
                    {
                        if (Items.Count == 0) return 0;
                        if (_needSort == true)
                        {
                            SortItems_CountAll_DESC();
                        }
                        return Items[0].countAll;
                    }
                }
                public int CountAll_Min
                {
                    get
                    {
                        if (Items.Count == 0) return 0;
                        if (_needSort == true)
                        {
                            SortItems_CountAll_DESC();
                        }
                        return Items[Items.Count - 1].countAll;
                    }
                }

                public string IOContent
                {
                    get
                    {
                        string result = "";
                        foreach (DataItem item in _items)
                        {
                            if (result.Length > 0) result += "\r\n";
                            result += item.IOContent;
                        }
                        return result;
                    }
                    set
                    {
                        string[] lines = value.Split(new string[] { "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);
                        _items.Clear();
                        DataItem newIt;
                        foreach (string line in lines)
                        {
                            newIt = new DataItem(line);
                            _items.Add(newIt);
                        }
                        _needSort = true;
                    }
                }
            }
        }

        public class ExamHall
        {
            public class HallInfo
            {
                public string op { set; get; }
                public string hallName { set; get; }

                public bool isSubmitPaper { set; get; }
                public string isSubmitPaper_docName { set; get; }

                public string examerListPath { set; get; }
                public class PaperElement
                {
                    public DataProcessing.Depot.Subject.Type type { set; get; }

                    public string caption { set; get; }
                    public DataProcessing.Depot.Subject.SubjectAlign captionAlign { set; get; }
                    public int captionSize { set; get; }

                    public string sourceDepot { set; get; }
                    public int subjectCount { set; get; }

                    public enum GainType
                    {
                        FromBeginning = 0,
                        FromEnding = 1,
                        Random = 2
                    }
                    public GainType gainType { set; get; }

                    public string IOContent
                    {
                        set
                        {
                            string[] parts = value.Split(new char[] { '\t' });
                            bool isCaption = false;
                            switch (parts[0])
                            {
                                default:
                                case "Caption":
                                    isCaption = true;
                                    type = DataProcessing.Depot.Subject.Type.Caption;
                                    break;
                                case "Single":
                                    type = DataProcessing.Depot.Subject.Type.Single;
                                    break;
                                case "Muti":
                                    type = DataProcessing.Depot.Subject.Type.Muti;
                                    break;
                                case "Judge":
                                    type = DataProcessing.Depot.Subject.Type.Judge;
                                    break;
                                case "Blanks":
                                    type = DataProcessing.Depot.Subject.Type.Blanks;
                                    break;
                                case "QAnswer":
                                    type = DataProcessing.Depot.Subject.Type.QAnswer;
                                    break;
                            }
                            if (isCaption)
                            {
                                caption = parts[1];
                                switch (parts[2])
                                {
                                    default:
                                    case "Left":
                                        captionAlign = DataProcessing.Depot.Subject.SubjectAlign.Left;
                                        break;
                                    case "Middle":
                                        captionAlign = DataProcessing.Depot.Subject.SubjectAlign.Middle;
                                        break;
                                    case "Right":
                                        captionAlign = DataProcessing.Depot.Subject.SubjectAlign.Right;
                                        break;
                                }
                                captionSize = int.Parse(parts[3]);
                            }
                            else
                            {
                                sourceDepot = parts[1];
                                subjectCount = int.Parse(parts[2]);
                                switch (parts[3])
                                {
                                    default:
                                    case "FromBeginning":
                                        gainType = GainType.FromBeginning;
                                        break;
                                    case "FromEnding":
                                        gainType = GainType.FromEnding;
                                        break;
                                    case "Random":
                                        gainType = GainType.Random;
                                        break;
                                }
                            }
                        }
                        get
                        {
                            string result = "";
                            string tabChar = "\t";
                            result += type.ToString() + tabChar;
                            switch (type)
                            {
                                case DataProcessing.Depot.Subject.Type.Caption:
                                    result += caption + tabChar;
                                    result += captionAlign.ToString() + tabChar;
                                    result += captionSize + tabChar;
                                    break;
                                default:
                                    result += sourceDepot + tabChar;
                                    result += subjectCount + tabChar;
                                    result += gainType.ToString() + tabChar;
                                    break;
                            }
                            return result;
                        }
                    }
                }
                private List<PaperElement> _elements;
                public List<PaperElement> elements
                {
                    set
                    {
                        _elements = value;
                        _IOElements = "";
                        if (_elements == null) return;
                        for (int i = 0; i < _elements.Count; i++)
                        {
                            if (_IOElements.Length > 0) _IOElements += "\r\n";
                            _IOElements += _elements[i].IOContent;
                        }
                    }
                    get
                    {
                        if (_IOElements != null && _IOElements.Length > 0) IOElements = _IOElements;
                        return _elements;
                    }
                }
                public bool IsManualAuditNeed
                {
                    get
                    {
                        foreach (PaperElement elm in _elements)
                        {
                            if (elm.type == Depot.Subject.Type.Blanks
                                || elm.type == Depot.Subject.Type.QAnswer)
                            {
                                return true;
                            }
                        }
                        return false;
                    }
                }
                private string _IOElements;
                public string IOElements
                {
                    set
                    {
                        _IOElements = value;
                        if (_elements == null) _elements = new List<PaperElement>();
                        _elements.Clear();
                        if (value == null) return;
                        string[] lines = value.Split(new string[] { "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);
                        PaperElement newE;
                        for (int i = 0; i < lines.Length; i++)
                        {
                            if (lines[i].Length == 0) continue;
                            newE = new PaperElement();
                            newE.IOContent = lines[i];
                            _elements.Add(newE);
                        }
                    }
                    get
                    {
                        if (_elements != null && _elements.Count > 0) elements = _elements;
                        return _IOElements;
                    }
                }

                public DateTime startTime { set; get; }
                public DateTime endTime { set; get; }
                public bool? isOneTimeExam { set; get; }
                public double examinatingTimeLength { set; get; }

                private static string HEADER_OP = "OP:";
                private static string HEADER_HALLNAME = "HallName:";
                private static string HEADER_IS_SUBMIT_PAPER = "Is submitPaper:";
                private static string HEADER_IS_SUBMIT_PAPER_DOCNAME = "Doc Name:";
                private static string HEADER_EXAMER_LISTPATH = "Examer List:";
                private static string HEADER_START_TIME = "Start Time:";
                private static string HEADER_END_TIME = "End Time:";
                private static string HEADER_IS_ONETIME_EXAM = "Is One-Time Exam:";
                private static string FORMAT_LONG_DATETIME = "yyyy-MM-dd HH:mm:ss";
                private static string HEADER_EXAM_TIMELENGTH_TIME = "Examinating TimeLength:";
                private static string HEADER_ELEMENTS_START = "Elements Start:";
                private static string HEADER_ELEMENTS_END = "Elements End:";
                public string IOContent
                {
                    set
                    {
                        string[] ioLines = value.Split(new string[] { "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);
                        string line;
                        bool isElementStart = false;
                        string elementsTextBlock = "";
                        for (int i = 0; i < ioLines.Length; i++)
                        {
                            line = ioLines[i];
                            if (line.StartsWith(HEADER_OP)) op = line.Substring(HEADER_OP.Length);
                            else if (line.StartsWith(HEADER_HALLNAME)) hallName = line.Substring(HEADER_HALLNAME.Length);
                            else if (line.StartsWith(HEADER_IS_SUBMIT_PAPER)) isSubmitPaper = bool.Parse(line.Substring(HEADER_IS_SUBMIT_PAPER.Length));
                            else if (line.StartsWith(HEADER_IS_SUBMIT_PAPER_DOCNAME)) isSubmitPaper_docName = line.Substring(HEADER_IS_SUBMIT_PAPER_DOCNAME.Length);
                            else if (line.StartsWith(HEADER_EXAMER_LISTPATH)) examerListPath = line.Substring(HEADER_EXAMER_LISTPATH.Length);
                            else if (line.StartsWith(HEADER_START_TIME)) startTime = DateTime.Parse(line.Substring(HEADER_START_TIME.Length));
                            else if (line.StartsWith(HEADER_END_TIME)) endTime = DateTime.Parse(line.Substring(HEADER_END_TIME.Length));
                            else if (line.StartsWith(HEADER_IS_ONETIME_EXAM))
                            {
                                try
                                {
                                    isOneTimeExam = bool.Parse(line.Substring(HEADER_IS_ONETIME_EXAM.Length));
                                }
                                catch (Exception)
                                {
                                    isOneTimeExam = false;
                                }
                            }
                            else if (line.StartsWith(HEADER_EXAM_TIMELENGTH_TIME)) examinatingTimeLength = double.Parse(line.Substring(HEADER_EXAM_TIMELENGTH_TIME.Length));
                            else if (line.StartsWith(HEADER_ELEMENTS_START)) isElementStart = true;
                            else if (line.StartsWith(HEADER_ELEMENTS_END)) isElementStart = false;
                            else if (isElementStart)
                            {
                                if (elementsTextBlock.Length > 0) elementsTextBlock += "\r\n";
                                elementsTextBlock += line;
                            }
                        }
                        IOElements = elementsTextBlock;
                    }
                    get
                    {
                        string result = "";
                        string reLine = "\r\n";
                        result += HEADER_OP + op + reLine;
                        result += HEADER_HALLNAME + hallName + reLine;
                        result += HEADER_IS_SUBMIT_PAPER + isSubmitPaper.ToString() + reLine;
                        result += HEADER_IS_SUBMIT_PAPER_DOCNAME + isSubmitPaper_docName + reLine;
                        result += HEADER_EXAMER_LISTPATH + examerListPath + reLine;
                        result += HEADER_START_TIME + startTime.ToString(FORMAT_LONG_DATETIME) + reLine;
                        result += HEADER_END_TIME + endTime.ToString(FORMAT_LONG_DATETIME) + reLine;
                        result += HEADER_IS_ONETIME_EXAM + isOneTimeExam.ToString() + reLine;
                        result += HEADER_EXAM_TIMELENGTH_TIME + examinatingTimeLength + reLine;
                        result += HEADER_ELEMENTS_START + reLine;
                        result += IOElements + reLine;
                        result += HEADER_ELEMENTS_END + reLine;
                        return result;
                    }
                }

                public HallInfo()
                {
                    _elements = new List<PaperElement>();
                }
            }

            public class UserExam
            {
                public class Info
                {
                    public string hallName { set; get; }
                    public string userName { set; get; } // 这里应该改成 User ID，实际中也用的是ID
                    public double examTimeLength { set; get; }
                    public double examTimeUsed { set; get; }

                    // these three timePoint could just have one In Condition
                    public DateTime lastStartTime { set; get; }
                    public DateTime lastPauseTime { set; get; }
                    public DateTime lastEndTime { set; get; }

                    public bool isAudited { set; get; }

                    private static string HEADER_HALLNAME = "Hall Name:";
                    private static string HEADER_USERNAME = "User Name:";
                    private static string HEADER_TIMELEN_DEF = "Exam TimeLength:";
                    private static string HEADER_TIMELEN_USD = "Exam TimeUsed:";
                    private static string HEADER_TIMEPOINT_START = "Last StartTimeOA:";
                    private static string HEADER_TIMEPOINT_PAUSE = "Last PauseTimeOA:";
                    private static string HEADER_TIMEPOINT_END = "Last EndTimeOA:";
                    private static string HEADER_IS_AUDITED = "Is Audited:";
                    // use "\t//" to make timePoint Comment
                    private static string FORMAT_LONG_DATETIME = "yyyy-MM-dd HH:mm:ss";
                    public string IOContent
                    {
                        set
                        {
                            string[] lines = value.Split(new string[] { "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);
                            char tabChr = '\t';
                            foreach (string line in lines)
                            {
                                if (line.StartsWith(HEADER_HALLNAME)) hallName = line.Substring(HEADER_HALLNAME.Length);
                                else if (line.StartsWith(HEADER_USERNAME)) userName = line.Substring(HEADER_USERNAME.Length);
                                else if (line.StartsWith(HEADER_TIMELEN_DEF)) examTimeLength = double.Parse(line.Substring(HEADER_TIMELEN_DEF.Length));
                                else if (line.StartsWith(HEADER_TIMELEN_USD)) examTimeUsed = double.Parse(line.Substring(HEADER_TIMELEN_USD.Length));
                                else if (line.StartsWith(HEADER_IS_AUDITED)) isAudited = bool.Parse(line.Substring(HEADER_IS_AUDITED.Length));

                                else if (line.StartsWith(HEADER_TIMEPOINT_START))
                                {
                                    string str = line.Substring(HEADER_TIMEPOINT_START.Length);
                                    if (str.Contains('\t')) str = str.Split(new char[] { tabChr })[0];
                                    lastStartTime = DateTime.FromOADate(double.Parse(str));
                                }
                                else if (line.StartsWith(HEADER_TIMEPOINT_PAUSE))
                                {
                                    string str = line.Substring(HEADER_TIMEPOINT_PAUSE.Length);
                                    if (str.Contains('\t')) str = str.Split(new char[] { tabChr })[0];
                                    lastPauseTime = DateTime.FromOADate(double.Parse(str));
                                }
                                else if (line.StartsWith(HEADER_TIMEPOINT_END))
                                {
                                    string str = line.Substring(HEADER_TIMEPOINT_END.Length);
                                    if (str.Contains('\t')) str = str.Split(new char[] { tabChr })[0];
                                    lastEndTime = DateTime.FromOADate(double.Parse(str));
                                }
                            }
                        }
                        get
                        {
                            string result = "";
                            string reLine = "\r\n";
                            result += HEADER_HALLNAME + hallName + reLine;
                            result += HEADER_USERNAME + userName + reLine;
                            result += HEADER_TIMELEN_DEF + examTimeLength.ToString() + reLine;
                            result += HEADER_TIMELEN_USD + examTimeUsed.ToString() + reLine;
                            result += HEADER_TIMEPOINT_START + lastStartTime.ToOADate() + "\t//" + lastStartTime.ToString(FORMAT_LONG_DATETIME) + reLine;
                            result += HEADER_TIMEPOINT_PAUSE + lastPauseTime.ToOADate() + "\t//" + lastPauseTime.ToString(FORMAT_LONG_DATETIME) + reLine;
                            result += HEADER_TIMEPOINT_END + lastEndTime.ToOADate() + "\t//" + lastEndTime.ToString(FORMAT_LONG_DATETIME) + reLine;
                            result += HEADER_IS_AUDITED + isAudited.ToString() + reLine;

                            return result;
                        }
                    }
                }

                public class UserPaper
                {
                    public UserPaper()
                    {
                    }
                    public UserPaper(string ioContent)
                    {
                        this.IOContent = ioContent;
                    }

                    public class Element
                    {
                        public DataProcessing.Depot.Subject subject { set; get; }
                        public class UserData
                        {
                            public string answer { set; get; }
                            public double grade { set; get; }
                            public string singleRemark { set; get; }

                            public string IOContent
                            {
                                set
                                {
                                    string[] parts = value.Split(new char[] { '\t' });
                                    answer = parts[0];
                                    grade = double.Parse(parts[1]);
                                    singleRemark = parts[2];
                                }
                                get
                                {
                                    string result = "";
                                    string tabStr = "\t";
                                    result += answer + tabStr;
                                    result += grade + tabStr;
                                    result += singleRemark + tabStr;
                                    return result;
                                }
                            }
                            public UserData()
                            {
                                answer = singleRemark = "";
                                grade = 0;
                            }
                        }
                        public UserData userData { set; get; }

                        public Element(DataProcessing.Depot.Subject subj, UserData userData)
                        {
                            this.subject = subj;
                            if (userData == null) userData = new UserData();
                            this.userData = userData;
                        }
                        public Element(string ioContent)
                        {
                            this.IOContent = ioContent;
                        }

                        public static string JOIN_SEPARATOR = "\tJOIN\t";
                        public string IOContent
                        {
                            set
                            {
                                string[] parts = value.Split(new string[] { JOIN_SEPARATOR }, StringSplitOptions.None);
                                if (subject == null) subject = new DataProcessing.Depot.Subject("");
                                subject.IOContent = parts[0];
                                if (userData == null) userData = new UserData();
                                userData.IOContent = parts[1];
                            }
                            get
                            {
                                return subject.IOContent + JOIN_SEPARATOR + userData.IOContent;
                            }
                        }

                        public double GetAuditedGrade(UserData dataWithAnswer)
                        {
                            double result = 0;
                            switch (subject.type)
                            {
                                default:
                                case DataProcessing.Depot.Subject.Type.Caption:
                                    break;
                                case DataProcessing.Depot.Subject.Type.Single:
                                    try
                                    {
                                        if (subject.singleAnswer_curIndex == int.Parse(dataWithAnswer.answer)) return subject.grades;
                                    }
                                    catch (Exception) { }
                                    break;
                                case DataProcessing.Depot.Subject.Type.Muti:
                                    if (subject.mutiAuditType == DataProcessing.Depot.Subject.MutiAuditType.Match)
                                    {
                                        if (dataWithAnswer.answer == subject.IOMutiAnswers) return subject.grades;
                                    }
                                    else
                                    {
                                        for (int i = subject.mutiAnswers.Count - 1; i >= 0; i--)
                                        {
                                            if (dataWithAnswer.answer.Length >= (i + 1) && subject.mutiAnswers[i] == (dataWithAnswer.answer[i] != '-'))
                                            {
                                                result += subject.grades / subject.mutiAnswers.Count;
                                            }
                                        }
                                    }
                                    break;
                                case DataProcessing.Depot.Subject.Type.Judge:
                                    try
                                    {
                                        if (bool.Parse(dataWithAnswer.answer) == subject.judgeAnswer_leftIsRight) return subject.grades;
                                    }
                                    catch (Exception) { }
                                    break;
                                case DataProcessing.Depot.Subject.Type.Blanks:
                                    List<string> userAnswers = new List<string>();
                                    string[] userAnsParts = dataWithAnswer.answer.Split(new string[] { DataProcessing.Depot.Subject.JOIN_SEPARATOR }, StringSplitOptions.None);
                                    for (int i = 0; i < userAnsParts.Length; i++)
                                    {
                                        userAnswers.Add(userAnsParts[i]);
                                    }
                                    if (subject.blanksAuditType == DataProcessing.Depot.Subject.BlanksAuditType.Match)
                                    {
                                        if (userAnsParts.Length == subject.blanksAnswers.Count)
                                        {
                                            for (int i = userAnswers.Count - 1; i >= 0; i--)
                                            {
                                                if (userAnswers[i] == subject.blanksAnswers[i]) continue;
                                                else return 0;
                                            }
                                            return subject.grades;
                                        }
                                    }
                                    else
                                    {
                                        List<string> curAnswers = new List<string>();
                                        for (int i = subject.blanksAnswers.Count - 1; i >= 0; i--)
                                        {
                                            curAnswers.Add(subject.blanksAnswers[i]);
                                        }
                                        for (int i = curAnswers.Count - 1; i >= 0; i--)
                                        {
                                            for (int j = userAnswers.Count - 1; j >= 0; j--)
                                            {
                                                if (curAnswers[i] == userAnswers[j])
                                                {
                                                    curAnswers.RemoveAt(i);
                                                    userAnswers.RemoveAt(j);
                                                    result += subject.grades / subject.blanksAnswers.Count;
                                                }
                                            }
                                        }
                                    }
                                    break;
                                case DataProcessing.Depot.Subject.Type.QAnswer:
                                    if (dataWithAnswer.answer.Trim() == subject.qAnswer) return subject.grades;
                                    break;
                            }

                            return result;
                        }
                    }


                    private List<Element> _elements = new List<Element>();
                    public List<Element> elements
                    {
                        set
                        {
                            _elements = value;
                            _IOContent = "";
                            if (_elements == null) return;
                            for (int i = 0; i < _elements.Count; i++)
                            {
                                if (_IOContent.Length > 0) _IOContent += "\r\n";
                                _IOContent += _elements[i].IOContent;
                            }
                        }
                        get
                        {
                            if (_IOContent != null) IOContent = _IOContent;
                            return _elements;
                        }
                    }
                    private string _IOContent;
                    public string IOContent
                    {
                        set
                        {
                            //_IOContent = (value == null) ? null : (StringCompress.DeCompress(value));
                            _IOContent = value;
                            if (_elements == null) _elements = new List<Element>();
                            _elements.Clear();
                            if (_IOContent == null) return;
                            string[] lines = _IOContent.Split(new string[] { "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);
                            for (int i = 0; i < lines.Length; i++)
                            {
                                _elements.Add(new Element(lines[i]));
                            }
                        }
                        get
                        {
                            if (_elements != null) elements = _elements;
                            //return StringCompress.Compress(_IOContent);
                            return _IOContent;
                        }
                    }

                    public double GetGrades()
                    {
                        double result = 0;
                        foreach (Element subj in elements)
                        {
                            if (subj.subject.type == DataProcessing.Depot.Subject.Type.Caption) continue;
                            else result += subj.userData.grade;
                        }
                        return result;
                    }
                }
            }

            public class StatusAnalysis
            {
                private HallInfo hallInfo;
                private UserExam.Info userExamInfo;
                public StatusAnalysis(HallInfo hallInfo, UserExam.Info userExamInfo)
                {
                    if (hallInfo == null)
                    {
                        throw new Exception("Hall Info is NULL, process abort!");
                    }
                    this.hallInfo = hallInfo;
                    this.userExamInfo = userExamInfo;

                    if (userExamInfo == null)
                    {
                        _AnalysisOnlyHallInfo();
                    }
                    else
                    {
                        _AnalysisHallInfo_with_UserExamInfo();
                    }
                }

                private void _AnalysisOnlyHallInfo()
                {
                    if (hallInfo.startTime.ToOADate() > 0 && hallInfo.startTime > DateTime.Now)
                    {
                        // 还未到开考时间
                        _couldShowPaper = false;
                        _couldWritePaper = false;
                        _couldShowAnswer = false;
                        _couldShowGrade = false;
                    }
                    else if (hallInfo.endTime.ToOADate() > 0 && hallInfo.endTime < DateTime.Now)
                    {
                        // 超过考试日期
                        _couldShowPaper = true;
                        _couldWritePaper = false;
                        _couldShowAnswer = true;
                        _couldShowGrade = true;
                    }
                    else
                    {
                        // 仍在考试日期以内
                        _couldShowPaper = true;
                        _couldWritePaper = false;
                        _couldShowAnswer = false;
                        _couldShowGrade = false;
                    }
                }
                private void _AnalysisHallInfo_with_UserExamInfo()
                {
                    if (hallInfo.startTime.ToOADate() > 0 && hallInfo.startTime > DateTime.Now)
                    {
                        // 还未到开考时间
                        _couldShowPaper = false;
                        _couldWritePaper = false;
                        _couldShowAnswer = false;
                        _couldShowGrade = false;
                    }
                    else if (hallInfo.endTime.ToOADate() > 0 && hallInfo.endTime < DateTime.Now)
                    {
                        // 超过考试日期
                        _couldShowPaper = true;
                        _couldWritePaper = false;
                        _couldShowAnswer = true;
                        _couldShowGrade = true;
                    }
                    else
                    {
                        // 仍在考试日期以内
                        if (userExamInfo.lastEndTime.ToOADate() > 0 && userExamInfo.lastEndTime < DateTime.Now)
                        {
                            // 考生已经交卷
                            _couldShowPaper = true;
                            _couldWritePaper = false;
                            _couldShowAnswer = false;
                            _couldShowGrade = true;
                        }
                        else if (userExamInfo.examTimeUsed >= hallInfo.examinatingTimeLength)
                        {
                            // 考试用时超时
                            _couldShowPaper = true;
                            _couldWritePaper = false;
                            _couldShowAnswer = false;
                            _couldShowGrade = true;
                        }
                        else
                        {
                            // 仍可以答卷
                            _couldShowPaper = true;
                            _couldWritePaper = true;
                            _couldShowAnswer = false;
                            _couldShowGrade = false;
                        }
                    }
                }

                // 能否显示试卷？
                private bool _couldShowPaper = false;
                public bool CouldShowPaper
                {
                    get
                    {
                        return _couldShowPaper;
                    }
                }

                // 能否执行答题？
                private bool _couldWritePaper = false;
                public bool CouldWritePaper
                {
                    get
                    {
                        return _couldWritePaper;
                    }
                }

                // 能否显示答案？
                private bool _couldShowAnswer = false;
                public bool CouldShowAnswer
                {
                    get
                    {
                        return _couldShowAnswer;
                    }
                }

                // 能否显示分数？
                private bool _couldShowGrade = false;
                public bool CouldShowGrade
                {
                    get
                    {
                        return _couldShowGrade;
                    }
                }

            }
        }

        public class Depot
        {
            public class Subject
            {
                public enum Type
                {
                    Caption = 0, // "caption",
                    Single = 1, // "single",
                    Muti = 2, // "muti",
                    Judge = 3, // "judge",
                    Blanks = 4, // "blanks",
                    QAnswer = 5 // "qAnswer"
                }
                public Type GetType(string text)
                {
                    switch (text)
                    {
                        default:
                        case "Caption":
                            return Type.Caption;
                        case "Single":
                            return Type.Single;
                        case "Muti":
                            return Type.Muti;
                        case "Judge":
                            return Type.Judge;
                        case "Blanks":
                            return Type.Blanks;
                        case "QAnswer":
                            return Type.QAnswer;
                    }
                }
                public Type type { set; get; }
                public string subject { set; get; }
                public enum SubjectAlign
                {
                    Left = 0, // "left",
                    Middle = 1, // "middle",
                    Right = 2 // "right"
                }
                public SubjectAlign GetSubjectAligh(string text)
                {
                    switch (text)
                    {
                        default:
                        case "Left":
                            return SubjectAlign.Left;
                        case "Middle":
                            return SubjectAlign.Middle;
                        case "Right":
                            return SubjectAlign.Right;
                    }
                }
                public SubjectAlign subjectAligh { set; get; }
                public int subjectWeight { set; get; }
                public string imageFileName { set; get; }

                public double grades { set; get; }

                public static string JOIN_SEPARATOR = ">>><<<";
                private string _IOSingleOptions;
                public string IOSingleOptions
                {
                    set
                    {
                        if (_singleOptions == null) _singleOptions = new List<string>();
                        _singleOptions.Clear();
                        string[] options = value.Split(new string[] { JOIN_SEPARATOR }, StringSplitOptions.RemoveEmptyEntries);
                        for (int i = 0; i < options.Length; i++)
                        {
                            _singleOptions.Add(options[i]);
                        }
                        _IOSingleOptions = value;
                    }
                    get
                    {
                        return _IOSingleOptions;
                    }
                }
                public List<string> _singleOptions;
                public List<string> singleOptions
                {
                    set
                    {
                        _singleOptions = value;
                        _IOSingleOptions = "";
                        if (_singleOptions == null) return;
                        for (int i = 0; i < _singleOptions.Count; i++)
                        {
                            if (_IOSingleOptions.Length > 0) _IOSingleOptions += JOIN_SEPARATOR;
                            _IOSingleOptions += _singleOptions[i];
                        }
                    }
                    get
                    {
                        return _singleOptions;
                    }
                }

                public int singleAnswer_curIndex { set; get; }

                private string _IOMutiOptions;
                public string IOMutiOptions
                {
                    set
                    {
                        _IOMutiOptions = (value == null) ? "" : value; ;
                        if (_mutiOptions == null) _mutiOptions = new List<string>();
                        _mutiOptions.Clear();
                        string[] opts = _IOMutiOptions.Split(new string[] { JOIN_SEPARATOR }, StringSplitOptions.RemoveEmptyEntries);
                        for (int i = 0; i < opts.Length; i++)
                        {
                            _mutiOptions.Add(opts[i]);
                        }
                    }
                    get
                    {
                        return _IOMutiOptions;
                    }
                }
                private List<string> _mutiOptions;
                public List<string> mutiOptions
                {
                    set
                    {
                        _mutiOptions = value;
                        _IOMutiOptions = "";
                        if (_mutiOptions == null) return;
                        for (int i = 0; i < value.Count; i++)
                        {
                            if (_IOMutiOptions.Length > 0) _IOMutiOptions += JOIN_SEPARATOR;
                            _IOMutiOptions += value[i];
                        }
                    }
                    get
                    {
                        return _mutiOptions;
                    }
                }

                private string _IOMutiAnswers;
                public string IOMutiAnswers
                {
                    set
                    {
                        _IOMutiAnswers = (value == null) ? "" : value; ;
                        if (_mutiAnswers == null) _mutiAnswers = new List<bool>();
                        _mutiAnswers.Clear();
                        for (int i = 0; i < value.Length; i++)
                        {
                            _mutiAnswers.Add(value[i] != '-');
                        }
                    }
                    get
                    {
                        return _IOMutiAnswers;
                    }
                }
                private List<bool> _mutiAnswers;
                public List<bool> mutiAnswers
                {
                    set
                    {
                        _mutiAnswers = value;
                        _IOMutiAnswers = "";
                        for (int i = 0; i < _mutiAnswers.Count; i++)
                        {
                            _IOMutiAnswers += (_mutiAnswers[i]) ? "R" : "-";
                        }
                    }
                    get
                    {
                        return _mutiAnswers;
                    }
                }

                public enum MutiAuditType
                {
                    Percentage = 0,
                    Match = 1
                }
                public MutiAuditType GetMutiAuditType(string text)
                {
                    switch (text)
                    {
                        default:
                        case "Percentage":
                            return MutiAuditType.Percentage;
                        case "Match":
                            return MutiAuditType.Match;
                    }
                }
                public MutiAuditType mutiAuditType { set; get; }



                private string _IOJudgeOptions;
                public string IOJudgeOptions
                {
                    set
                    {
                        _IOJudgeOptions = (value == null) ? "" : value; ;
                        if (_judgeOptions == null) _judgeOptions = new List<string>();
                        _judgeOptions.Clear();
                        string[] opts = _IOJudgeOptions.Split(new string[] { JOIN_SEPARATOR }, StringSplitOptions.RemoveEmptyEntries);
                        for (int i = 0; i < opts.Length; i++)
                        {
                            _judgeOptions.Add(opts[i]);
                        }
                    }
                    get
                    {
                        return _IOJudgeOptions;
                    }
                }
                private List<string> _judgeOptions;
                public List<string> judgeOptions
                {
                    set
                    {
                        _judgeOptions = value;
                        _IOJudgeOptions = "";
                        if (_judgeOptions == null) return;
                        for (int i = 0; i < value.Count; i++)
                        {
                            if (_IOJudgeOptions.Length > 0) _IOJudgeOptions += JOIN_SEPARATOR;
                            _IOJudgeOptions += value[i];
                        }
                    }
                    get
                    {
                        return _judgeOptions;
                    }
                }

                public bool judgeAnswer_leftIsRight { set; get; }



                private string _IOBlanksAnswers;
                public string IOBlanksAnswers
                {
                    set
                    {
                        _IOBlanksAnswers = (value == null) ? "" : value; ;
                        if (_blanksAnswers == null) _blanksAnswers = new List<string>();
                        _blanksAnswers.Clear();
                        string[] opts = _IOBlanksAnswers.Split(new string[] { JOIN_SEPARATOR }, StringSplitOptions.RemoveEmptyEntries);
                        for (int i = 0; i < opts.Length; i++)
                        {
                            _blanksAnswers.Add(opts[i]);
                        }
                    }
                    get
                    {
                        return _IOBlanksAnswers;
                    }
                }
                private List<string> _blanksAnswers;
                public List<string> blanksAnswers
                {
                    set
                    {
                        _blanksAnswers = value;
                        _IOBlanksAnswers = "";
                        if (_blanksAnswers == null) return;
                        for (int i = 0; i < value.Count; i++)
                        {
                            if (_IOBlanksAnswers.Length > 0) _IOBlanksAnswers += JOIN_SEPARATOR;
                            _IOBlanksAnswers += value[i];
                        }
                        while (_IOBlanksAnswers.Contains("\n")) _IOBlanksAnswers = _IOBlanksAnswers.Replace("\n", "");
                        while (_IOBlanksAnswers.Contains("\r")) _IOBlanksAnswers = _IOBlanksAnswers.Replace("\r", "");
                    }
                    get
                    {
                        return _blanksAnswers;
                    }
                }



                public enum BlanksAuditType
                {
                    Percentage = 0,
                    Match = 1
                }
                public BlanksAuditType GetBlanksAuditType(string text)
                {
                    switch (text)
                    {
                        default:
                        case "Percentage":
                            return BlanksAuditType.Percentage;
                        case "Match":
                            return BlanksAuditType.Match;
                    }
                }
                public BlanksAuditType blanksAuditType { set; get; }

                public string qAnswer { set; get; }

                public string IOContent
                {
                    set
                    {
                        if (value == null || value.Length == 0) return;
                        string[] parts = value.Split(new char[] { '\t' });
                        int indexer = 0;
                        this.type = GetType(parts[indexer]); indexer++;
                        this.subject = parts[indexer].Replace("\\r", "\r\n"); indexer++;
                        this.subjectAligh = GetSubjectAligh(parts[indexer]); indexer++;
                        this.subjectWeight = int.Parse(parts[indexer]); indexer++;
                        this.imageFileName = parts[indexer]; indexer++;

                        this.grades = double.Parse(parts[indexer]); indexer++;

                        this.IOSingleOptions = parts[indexer]; indexer++;
                        this.singleAnswer_curIndex = int.Parse(parts[indexer]); indexer++;

                        this.IOMutiOptions = parts[indexer]; indexer++;
                        this.IOMutiAnswers = parts[indexer]; indexer++;
                        this.mutiAuditType = GetMutiAuditType(parts[indexer]); indexer++;

                        this.IOJudgeOptions = parts[indexer]; indexer++;
                        this.judgeAnswer_leftIsRight = bool.Parse(parts[indexer]); indexer++;

                        this.IOBlanksAnswers = parts[indexer]; indexer++;
                        this.blanksAuditType = GetBlanksAuditType(parts[indexer]); indexer++;

                        this.qAnswer = parts[indexer].Replace("\\r", "\r\n");
                    }
                    get
                    {
                        string result = "";
                        string tabChar = "\t";

                        result += type.ToString() + tabChar;
                        result += ((subject == null) ? "" : subject.Replace("\r\n", "\\r")) + tabChar;
                        result += subjectAligh.ToString() + tabChar;
                        result += subjectWeight + tabChar;
                        result += ((imageFileName == null) ? "" : imageFileName) + tabChar;

                        result += grades + tabChar;

                        result += IOSingleOptions + tabChar;
                        result += singleAnswer_curIndex + tabChar;

                        result += IOMutiOptions + tabChar;
                        result += IOMutiAnswers + tabChar;
                        result += mutiAuditType.ToString() + tabChar;

                        result += IOJudgeOptions + tabChar;
                        result += judgeAnswer_leftIsRight.ToString() + tabChar;

                        result += IOBlanksAnswers + tabChar;
                        result += blanksAuditType.ToString() + tabChar;

                        result += ((this.qAnswer == null) ? "" : this.qAnswer.Replace("\r\n", "\\r")) + tabChar;

                        return result;
                    }
                }

                public List<List<string>> LineContent
                {
                    set
                    {
                        int indexer = 0;
                        type = GetType(value[indexer][0]); indexer++;
                        subject = value[indexer][0].Replace("\\r", "\r\n"); indexer++;
                        subjectAligh = GetSubjectAligh(value[indexer][0]); indexer++;
                        subjectWeight = int.Parse(value[indexer][0]); indexer++;
                        imageFileName = value[indexer][0]; indexer++;

                        grades = double.Parse(value[indexer][0]); indexer++;

                        singleOptions = value[indexer]; indexer++;
                        singleAnswer_curIndex = int.Parse(value[indexer][0]); indexer++;

                        mutiOptions = value[indexer]; indexer++;
                        mutiAnswers = Conv_strList2BoolList(value[indexer]); indexer++;
                        mutiAuditType = GetMutiAuditType(value[indexer][0]); indexer++;

                        judgeOptions = value[indexer]; indexer++;
                        judgeAnswer_leftIsRight = bool.Parse(value[indexer][0]); indexer++;

                        blanksAnswers = value[indexer]; indexer++;
                        blanksAuditType = GetBlanksAuditType(value[indexer][0]); indexer++;

                        qAnswer = value[indexer][0].Replace("\\r", "\r\n");
                    }
                    get
                    {
                        List<List<string>> result = new List<List<string>>();

                        List<string> subItem = new List<string>();
                        subItem.Add(type.ToString()); result.Add(subItem);

                        // 0
                        subItem = new List<string>();
                        subItem.Add(subject.Replace("\r\n", "\\r")); result.Add(subItem);

                        // 1
                        subItem = new List<string>();
                        subItem.Add(subjectAligh.ToString()); result.Add(subItem);

                        // 2
                        subItem = new List<string>();
                        subItem.Add("" + subjectWeight); result.Add(subItem);

                        // 3
                        subItem = new List<string>();
                        subItem.Add(imageFileName); result.Add(subItem);

                        // 4
                        subItem = new List<string>();
                        subItem.Add("" + grades); result.Add(subItem);

                        // 5
                        result.Add(singleOptions);

                        // 6
                        subItem = new List<string>();
                        subItem.Add("" + singleAnswer_curIndex); result.Add(subItem);

                        // 7
                        result.Add(mutiOptions);
                        // 8
                        result.Add(Conv_boolList2StrList(mutiAnswers));

                        // 9
                        subItem = new List<string>();
                        subItem.Add(mutiAuditType.ToString()); result.Add(subItem);

                        // 10
                        result.Add(judgeOptions);

                        // 11
                        subItem = new List<string>();
                        subItem.Add(judgeAnswer_leftIsRight.ToString()); result.Add(subItem);

                        // 12
                        result.Add(blanksAnswers);

                        // 13
                        subItem = new List<string>();
                        subItem.Add(blanksAuditType.ToString()); result.Add(subItem);

                        // 14
                        subItem = new List<string>();
                        subItem.Add((qAnswer == null) ? "" : qAnswer.Replace("\r\n", "\\r")); result.Add(subItem);

                        return result;
                    }
                }
                private List<bool> Conv_strList2BoolList(List<string> source)
                {
                    List<bool> result = new List<bool>();
                    if (source == null) return result;
                    for (int i = 0; i < source.Count; i++)
                    {
                        result.Add(bool.Parse(source[i]));
                    }
                    return result;
                }
                private List<string> Conv_boolList2StrList(List<bool> source)
                {
                    List<string> result = new List<string>();
                    if (source == null) return result;
                    for (int i = 0; i < source.Count; i++)
                    {
                        result.Add(source[i].ToString());
                    }
                    return result;
                }

                public Subject()
                {
                }
                public Subject(string ioContent)
                {
                    IOContent = ioContent;
                }
                public Subject(List<List<string>> lineContent)
                {
                    LineContent = lineContent;
                }

                #region Client Data Processing
                public static string JOIN_SEPARATOR_4UITEXT = "-->";
                public static string JOIN_SEPARATOR_BLANK_4UITEXT = "【空缺】";

                public string ScriptSingle
                {
                    get
                    {
                        string result = "";
                        string reLine = "\r\n";
                        result += "Subj:" + subject + reLine;
                        result += "Img:" + imageFileName + reLine;
                        result += "Opts:" + IOSingleOptions.Replace(JOIN_SEPARATOR, JOIN_SEPARATOR_4UITEXT) + reLine;
                        result += "CInd:" + singleAnswer_curIndex + reLine;
                        result += "Gds:" + grades + reLine;
                        return result;
                    }
                }
                /// <summary>
                /// set data from Script
                /// if there's error, the result will not be null
                /// </summary>
                /// <param name="textBlock">input script</param>
                /// <returns>error info, use cur number to replace "[NO]"</returns>
                public string ScriptSingle_Set(string textBlock)
                {
                    textBlock = textBlock.Replace("\r", "\r\n");
                    textBlock = textBlock.Replace("\n\n", "\n");
                    string header_subj = "Subj:";
                    string header_img = "\r\nImg:";
                    string header_opts = "\r\nOpts:";
                    string header_cind = "\r\nCInd:";
                    string header_gds = "\r\nGds:";

                    string newSubj = "";
                    string newImg = "";
                    string newOpts = "";
                    string newCInd = "";
                    string newGds = "";

                    string info = "";
                    bool isBlockOK = true;
                    if (!textBlock.Contains(header_subj) || !textBlock.Contains(header_opts) || !textBlock.Contains(header_cind) || !textBlock.Contains(header_gds))
                    {
                        info += "[NO]题格式错误；";
                        isBlockOK = false;
                    }
                    string[] textBlockParts;
                    textBlockParts = textBlock.Split(new string[] { header_subj, header_img, header_opts, header_cind, header_gds }, StringSplitOptions.RemoveEmptyEntries);
                    if (isBlockOK && textBlockParts.Length < 4)
                    {
                        info += "[NO]题少数据；";
                        isBlockOK = false;
                    }
                    else if (isBlockOK)
                    {
                        if (textBlockParts.Length == 4)
                        {
                            newSubj = textBlockParts[0];
                            newImg = "";
                            newOpts = textBlockParts[1];
                            newCInd = textBlockParts[2];
                            newGds = textBlockParts[3];
                        }
                        else
                        {
                            newSubj = textBlockParts[0];
                            newImg = textBlockParts[1];
                            newOpts = textBlockParts[2];
                            newCInd = textBlockParts[3];
                            newGds = textBlockParts[4];
                        }
                        newImg = String_RemoveAll(newImg, "\r\n");
                        newImg = String_RemoveAll(newImg, "\t");
                        newOpts = String_RemoveAll(newOpts, "\r\n");
                        newOpts = String_RemoveAll(newOpts, "\t\t");
                        newCInd = String_RemoveAll(newCInd, "\r\n");
                        newCInd = String_RemoveAll(newCInd, "\t");
                        newGds = String_RemoveAll(newGds, "\r\n");
                        newGds = String_RemoveAll(newGds, "\t");
                    }
                    string[] newOpts_parts = newOpts.Split(new string[] { JOIN_SEPARATOR_4UITEXT }, StringSplitOptions.RemoveEmptyEntries);
                    if (isBlockOK && newOpts_parts.Length < 2)
                    {
                        info += "[NO]题选项太少；";
                        isBlockOK = false;
                    }
                    if (isBlockOK)
                    {
                        try
                        {
                            int ind = int.Parse(newCInd);
                            if (ind < 0 || ind >= newOpts_parts.Length)
                            {
                                throw new Exception("索引超出选项范围！");
                            }
                        }
                        catch (Exception)
                        {
                            info += "[NO]题未知答案；";
                            isBlockOK = false;
                        }
                    }
                    if (isBlockOK)
                    {
                        try
                        {
                            double gds = double.Parse(newGds);
                            if (gds < 0 || gds > 100) throw new Exception("分数太小或太大");
                        }
                        catch (Exception)
                        {
                            info += "[NO]题未知分数；";
                            isBlockOK = false;
                        }
                    }

                    if (!isBlockOK)
                    {
                        return info;
                    }
                    this.type = Type.Single;
                    this.subject = newSubj.Replace("\r\n", "\\r");
                    this.imageFileName = newImg;
                    this.grades = double.Parse(newGds);
                    this.IOSingleOptions = newOpts.Replace(JOIN_SEPARATOR_4UITEXT, JOIN_SEPARATOR);
                    this.singleAnswer_curIndex = int.Parse(newCInd);

                    return null;
                }
                private string String_RemoveAll(string source, string target)
                {
                    while (source.Contains(target)) source = source.Replace(target, "");
                    return source;
                }

                public string ScriptMuti
                {
                    get
                    {
                        string result = "";
                        string reLine = "\r\n";
                        result += "Subj:" + subject + reLine;
                        result += "Img:" + imageFileName + reLine;
                        result += "Opts:" + IOMutiOptions.Replace(JOIN_SEPARATOR, JOIN_SEPARATOR_4UITEXT) + reLine;
                        result += "Ans:" + IOMutiAnswers + reLine;
                        result += "AudType:" + mutiAuditType + reLine;
                        result += "Gds:" + grades + reLine;
                        return result;
                    }
                }
                public string ScriptMuti_Set(string textBlock)
                {
                    textBlock = textBlock.Replace("\r", "\r\n");
                    textBlock = textBlock.Replace("\n\n", "\n");
                    string header_subj = "Subj:";
                    string header_img = "\r\nImg:";
                    string header_opts = "\r\nOpts:";
                    string header_ans = "\r\nAns:";
                    string header_auditType = "\r\nAudType:";
                    string header_gds = "\r\nGds:";

                    string newSubj = "";
                    string newImg = "";
                    string newOpts = "";
                    string newAns = "";
                    string newAudType = "";
                    string newGds = "";

                    string info = "";
                    bool isBlockOK = true;
                    if (!textBlock.Contains(header_subj)
                        || !textBlock.Contains(header_opts)
                        || !textBlock.Contains(header_ans)
                        || !textBlock.Contains(header_auditType)
                        || !textBlock.Contains(header_gds))
                    {
                        info += "[NO]题格式错误；";
                        isBlockOK = false;
                    }
                    string[] textBlockParts;
                    textBlockParts = textBlock.Split(new string[] { header_subj, header_img, header_opts, header_ans, header_auditType, header_gds }, StringSplitOptions.RemoveEmptyEntries);
                    if (isBlockOK && textBlockParts.Length < 5)
                    {
                        info += "[NO]题少数据；";
                        isBlockOK = false;
                    }
                    else if (isBlockOK)
                    {
                        if (textBlockParts.Length == 5)
                        {
                            newSubj = textBlockParts[0];
                            newImg = "";
                            newOpts = textBlockParts[1];
                            newAns = textBlockParts[2];
                            newAudType = textBlockParts[3];
                            newGds = textBlockParts[4];
                        }
                        else
                        {
                            newSubj = textBlockParts[0];
                            newImg = textBlockParts[1];
                            newOpts = textBlockParts[2];
                            newAns = textBlockParts[3];
                            newAudType = textBlockParts[4];
                            newGds = textBlockParts[5];
                        }
                        newImg = String_RemoveAll(newImg, "\r\n");
                        newImg = String_RemoveAll(newImg, "\t");
                        newOpts = String_RemoveAll(newOpts, "\r\n");
                        newOpts = String_RemoveAll(newOpts, "\t\t");
                        newAns = String_RemoveAll(newAns, "\r\n");
                        newAns = String_RemoveAll(newAns, "\t");
                        newAudType = String_RemoveAll(newAudType, "\r\n");
                        newAudType = String_RemoveAll(newAudType, "\t");
                        newGds = String_RemoveAll(newGds, "\r\n");
                        newGds = String_RemoveAll(newGds, "\t");
                    }
                    string[] newOpts_parts = newOpts.Split(new string[] { JOIN_SEPARATOR_4UITEXT }, StringSplitOptions.RemoveEmptyEntries);
                    if (isBlockOK && newOpts_parts.Length < 2)
                    {
                        info += "[NO]题选项太少；";
                        isBlockOK = false;
                    }
                    if (isBlockOK)
                    {
                        if (newAns.Length != newOpts_parts.Length)
                        {
                            info += "[NO]题未知答案；";
                            isBlockOK = false;
                        }
                    }
                    if (isBlockOK)
                    {
                        try
                        {
                            double gds = double.Parse(newGds);
                            if (gds < 0 || gds > 100) throw new Exception("分数太小或太大");
                        }
                        catch (Exception)
                        {
                            info += "[NO]题未知分数；";
                            isBlockOK = false;
                        }
                    }

                    if (!isBlockOK)
                    {
                        return info;
                    }
                    this.type = Type.Muti;
                    this.subject = newSubj.Replace("\r\n", "\\r");
                    this.imageFileName = newImg;
                    this.grades = double.Parse(newGds);
                    this.IOMutiOptions = newOpts.Replace(JOIN_SEPARATOR_4UITEXT, JOIN_SEPARATOR);
                    this.IOMutiAnswers = newAns;
                    switch (newAudType)
                    {
                        default:
                        case "Percentage":
                            this.mutiAuditType = MutiAuditType.Percentage;
                            break;
                        case "Match":
                            this.mutiAuditType = MutiAuditType.Match;
                            break;
                    }
                    return null;
                }

                public string ScriptJudge
                {
                    get
                    {
                        string result = "";
                        string reLine = "\r\n";
                        result += "Subj:" + subject + reLine;
                        result += "Img:" + imageFileName + reLine;
                        result += "Opts:" + IOJudgeOptions.Replace(JOIN_SEPARATOR, JOIN_SEPARATOR_4UITEXT) + reLine;
                        result += "FirstIsTrue:" + judgeAnswer_leftIsRight + reLine;
                        result += "Gds:" + grades + reLine;
                        return result;
                    }
                }
                public string ScriptJudge_Set(string textBlock)
                {
                    textBlock = textBlock.Replace("\r", "\r\n");
                    textBlock = textBlock.Replace("\n\n", "\n");
                    string header_subj = "Subj:";
                    string header_img = "\r\nImg:";
                    string header_opts = "\r\nOpts:";
                    string header_firstIsTrue = "\r\nFirstIsTrue:";
                    string header_gds = "\r\nGds:";

                    string newSubj = "";
                    string newImg = "";
                    string newOpts = "";
                    string newFirstIsTrue = "";
                    string newGds = "";

                    string info = "";
                    bool isBlockOK = true;
                    if (!textBlock.Contains(header_subj)
                        || !textBlock.Contains(header_opts)
                        || !textBlock.Contains(header_firstIsTrue)
                        || !textBlock.Contains(header_gds))
                    {
                        info += "[NO]题格式错误；";
                        isBlockOK = false;
                    }
                    string[] textBlockParts;
                    textBlockParts = textBlock.Split(new string[] { header_subj, header_img, header_opts, header_firstIsTrue, header_gds }, StringSplitOptions.RemoveEmptyEntries);
                    if (isBlockOK && textBlockParts.Length < 4)
                    {
                        info += "[NO]题少数据；";
                        isBlockOK = false;
                    }
                    else if (isBlockOK)
                    {
                        if (textBlockParts.Length == 4)
                        {
                            newSubj = textBlockParts[0];
                            newImg = "";
                            newOpts = textBlockParts[1];
                            newFirstIsTrue = textBlockParts[2];
                            newGds = textBlockParts[3];
                        }
                        else
                        {
                            newSubj = textBlockParts[0];
                            newImg = textBlockParts[1];
                            newOpts = textBlockParts[2];
                            newFirstIsTrue = textBlockParts[3];
                            newGds = textBlockParts[4];
                        }
                        newImg = String_RemoveAll(newImg, "\r\n");
                        newImg = String_RemoveAll(newImg, "\t");
                        newOpts = String_RemoveAll(newOpts, "\r\n");
                        newOpts = String_RemoveAll(newOpts, "\t\t");
                        newFirstIsTrue = String_RemoveAll(newFirstIsTrue, "\r\n");
                        newFirstIsTrue = String_RemoveAll(newFirstIsTrue, "\t");
                        newGds = String_RemoveAll(newGds, "\r\n");
                        newGds = String_RemoveAll(newGds, "\t");
                    }
                    string[] newOpts_parts = newOpts.Split(new string[] { JOIN_SEPARATOR_4UITEXT }, StringSplitOptions.RemoveEmptyEntries);
                    if (isBlockOK && (newOpts_parts.Length < 2 || newOpts_parts.Length > 2))
                    {
                        info += "[NO]题选项太少(?多)；";
                        isBlockOK = false;
                    }
                    if (isBlockOK)
                    {
                        try
                        {
                            bool.Parse(newFirstIsTrue);
                        }
                        catch (Exception)
                        {
                            info += "[NO]题未知答案；";
                            isBlockOK = false;
                        }
                    }
                    if (isBlockOK)
                    {
                        try
                        {
                            double gds = double.Parse(newGds);
                            if (gds < 0 || gds > 100) throw new Exception("分数太小或太大");
                        }
                        catch (Exception)
                        {
                            info += "[NO]题未知分数；";
                            isBlockOK = false;
                        }
                    }

                    if (!isBlockOK)
                    {
                        return info;
                    }
                    this.type = Type.Judge;
                    this.subject = newSubj.Replace("\r\n", "\\r");
                    this.imageFileName = newImg;
                    this.grades = double.Parse(newGds);
                    this.IOJudgeOptions = newOpts.Replace(JOIN_SEPARATOR_4UITEXT, JOIN_SEPARATOR);
                    this.judgeAnswer_leftIsRight = bool.Parse(newFirstIsTrue);
                    return null;
                }

                public string ScriptBlanks
                {
                    get
                    {
                        string result = "";
                        string reLine = "\r\n";
                        result += "Subj:" + subject.Replace(JOIN_SEPARATOR, JOIN_SEPARATOR_BLANK_4UITEXT) + reLine;
                        result += "Img:" + imageFileName + reLine;
                        result += "Opts:" + IOBlanksAnswers.Replace(JOIN_SEPARATOR, JOIN_SEPARATOR_4UITEXT) + reLine;
                        result += "AudType:" + blanksAuditType + reLine;
                        result += "Gds:" + grades + reLine;
                        return result;
                    }
                }
                public string ScriptBlanks_Set(string textBlock)
                {
                    textBlock = textBlock.Replace("\r", "\r\n");
                    textBlock = textBlock.Replace("\n\n", "\n");
                    string header_subj = "Subj:";
                    string header_img = "\r\nImg:";
                    string header_opts = "\r\nOpts:";
                    string header_auditType = "\r\nAudType:";
                    string header_gds = "\r\nGds:";

                    string newSubj = "";
                    string newImg = "";
                    string newOpts = "";
                    string newAudType = "";
                    string newGds = "";

                    string info = "";
                    bool isBlockOK = true;
                    if (!textBlock.Contains(header_subj)
                        || !textBlock.Contains(header_opts)
                        || !textBlock.Contains(header_auditType)
                        || !textBlock.Contains(header_gds))
                    {
                        info += "[NO]题格式错误；";
                        isBlockOK = false;
                    }
                    string[] textBlockParts;
                    textBlockParts = textBlock.Split(new string[] { header_subj, header_img, header_opts, header_auditType, header_gds }, StringSplitOptions.RemoveEmptyEntries);
                    if (isBlockOK && textBlockParts.Length < 4)
                    {
                        info += "[NO]题少数据；";
                        isBlockOK = false;
                    }
                    else if (isBlockOK)
                    {
                        if (textBlockParts.Length == 4)
                        {
                            newSubj = textBlockParts[0];
                            newImg = "";
                            newOpts = textBlockParts[1];
                            newAudType = textBlockParts[2];
                            newGds = textBlockParts[3];
                        }
                        else
                        {
                            newSubj = textBlockParts[0];
                            newImg = textBlockParts[1];
                            newOpts = textBlockParts[2];
                            newAudType = textBlockParts[3];
                            newGds = textBlockParts[4];
                        }
                        newImg = String_RemoveAll(newImg, "\r\n");
                        newImg = String_RemoveAll(newImg, "\t");
                        newOpts = String_RemoveAll(newOpts, "\r\n");
                        newOpts = String_RemoveAll(newOpts, "\t\t");
                        newAudType = String_RemoveAll(newAudType, "\r\n");
                        newAudType = String_RemoveAll(newAudType, "\t");
                        newGds = String_RemoveAll(newGds, "\r\n");
                        newGds = String_RemoveAll(newGds, "\t");
                    }
                    string[] newOpts_parts = newOpts.Split(new string[] { JOIN_SEPARATOR_4UITEXT }, StringSplitOptions.RemoveEmptyEntries);
                    //if (isBlockOK && newOpts_parts.Length < 2)
                    //{
                    //    info += "[NO]题选项太少；";
                    //    isBlockOK = false;
                    //}
                    string[] subjParts = newSubj.Split(new string[] { JOIN_SEPARATOR_BLANK_4UITEXT }, StringSplitOptions.None);
                    if (isBlockOK)
                    {
                        if (newOpts_parts.Length != (subjParts.Length - 1))
                        {
                            info += "[NO]题未知答案；";
                            isBlockOK = false;
                        }
                    }
                    if (isBlockOK)
                    {
                        try
                        {
                            double gds = double.Parse(newGds);
                            if (gds < 0 || gds > 100) throw new Exception("分数太小或太大");
                        }
                        catch (Exception)
                        {
                            info += "[NO]题未知分数；";
                            isBlockOK = false;
                        }
                    }

                    if (!isBlockOK)
                    {
                        return info;
                    }
                    this.type = Type.Blanks;
                    this.subject = newSubj.Replace(JOIN_SEPARATOR_BLANK_4UITEXT, JOIN_SEPARATOR).Replace("\r\n", "\\r");
                    this.imageFileName = newImg;
                    this.grades = double.Parse(newGds);
                    string ioAns = newOpts.Replace(JOIN_SEPARATOR_4UITEXT, JOIN_SEPARATOR);
                    while (ioAns.Contains("\r\n")) ioAns = ioAns.Replace("\r\n", "");
                    while (ioAns.Contains("\r")) ioAns = ioAns.Replace("\r", "");
                    this.IOBlanksAnswers = ioAns;
                    switch (newAudType)
                    {
                        default:
                        case "Percentage":
                            this.blanksAuditType = BlanksAuditType.Percentage;
                            break;
                        case "Match":
                            this.blanksAuditType = BlanksAuditType.Match;
                            break;
                    }
                    return null;
                }

                public string ScriptQAnswer
                {
                    get
                    {
                        string result = "";
                        string reLine = "\r\n";
                        result += "Subj:" + subject + reLine;
                        result += "Img:" + imageFileName + reLine;
                        result += "Answer:" + qAnswer + reLine;
                        result += "Gds:" + grades + reLine;
                        return result;
                    }
                }
                public string ScriptQAnswer_Set(string textBlock)
                {
                    textBlock = textBlock.Replace("\r", "\r\n");
                    textBlock = textBlock.Replace("\n\n", "\n");
                    string header_subj = "Subj:";
                    string header_img = "\r\nImg:";
                    string header_answer = "\r\nAnswer:";
                    string header_gds = "\r\nGds:";

                    string newSubj = "";
                    string newImg = "";
                    string newAnswer = "";
                    string newGds = "";

                    string info = "";
                    bool isBlockOK = true;
                    if (!textBlock.Contains(header_subj)
                        || !textBlock.Contains(newAnswer)
                        || !textBlock.Contains(header_gds))
                    {
                        info += "[NO]题格式错误；";
                        isBlockOK = false;
                    }
                    string[] textBlockParts;
                    textBlockParts = textBlock.Split(new string[] { header_subj, header_img, header_answer, header_gds }, StringSplitOptions.RemoveEmptyEntries);
                    if (isBlockOK && textBlockParts.Length < 3)
                    {
                        info += "[NO]题少数据；";
                        isBlockOK = false;
                    }
                    else if (isBlockOK)
                    {
                        if (textBlockParts.Length == 3)
                        {
                            newSubj = textBlockParts[0];
                            newImg = "";
                            newAnswer = textBlockParts[1];
                            newGds = textBlockParts[2];
                        }
                        else
                        {
                            newSubj = textBlockParts[0];
                            newImg = textBlockParts[1];
                            newAnswer = textBlockParts[2];
                            newGds = textBlockParts[3];
                        }
                        newImg = String_RemoveAll(newImg, "\r\n");
                        newImg = String_RemoveAll(newImg, "\t");
                        newGds = String_RemoveAll(newGds, "\r\n");
                        newGds = String_RemoveAll(newGds, "\t");
                    }
                    //string[] newOpts_parts = newOpts.Split(new string[] { "\t" }, StringSplitOptions.RemoveEmptyEntries);
                    //if (isBlockOK && (newOpts_parts.Length < 2 || newOpts_parts.Length > 2))
                    //{
                    //    info += "[NO]题选项太少(?多)；";
                    //    isBlockOK = false;
                    //}
                    //if (isBlockOK)
                    //{
                    //    try
                    //    {
                    //        bool.Parse(newFirstIsTrue);
                    //    }
                    //    catch (Exception)
                    //    {
                    //        info += "[NO]题未知答案；";
                    //        isBlockOK = false;
                    //    }
                    //}
                    if (isBlockOK)
                    {
                        try
                        {
                            double gds = double.Parse(newGds);
                            if (gds < 0 || gds > 100) throw new Exception("分数太小或太大");
                        }
                        catch (Exception)
                        {
                            info += "[NO]题未知分数；";
                            isBlockOK = false;
                        }
                    }

                    if (!isBlockOK)
                    {
                        return info;
                    }
                    this.type = Type.QAnswer;
                    this.subject = newSubj.Replace("\r\n", "\\r");
                    this.imageFileName = newImg;
                    this.grades = double.Parse(newGds);
                    this.qAnswer = newAnswer.Replace("\r\n", "\\r");
                    return null;
                }
                #endregion

            }
            public class Detail
            {
                public string title { set; get; }
                public string remark { set; get; }
                public DateTime createTime;
                public string creater;
                public DateTime modifyTime;
                public string modifier;

                private static string HEADER_TITLE = "Title:";
                private static string HEADER_REMARK_START = "Remark Start:";
                private static string HEADER_REMARK_END = "Remark End;";
                private static string HEADER_CREATETIME = "Create Time:";
                private static string HEADER_CREATER = "Creater:";
                private static string HEADER_MODIFYTIME = "Modify Time:";
                private static string HEADER_MODIFIER = "Modifier:";
                private static string FORMAT_LONG_DATETIME_STRING = "yyyy-MM-dd HH:mm:ss";

                public string IOContent
                {
                    set
                    {
                        string[] lines = value.Split(new string[] { "\r\n" }, StringSplitOptions.None);
                        string line;
                        bool remarkStart = false;
                        remark = "";
                        for (int i = 0; i < lines.Length; i++)
                        {
                            line = lines[i];
                            if (line.StartsWith(HEADER_TITLE)) title = line.Substring(HEADER_TITLE.Length);
                            else if (line.StartsWith(HEADER_CREATER)) creater = line.Substring(HEADER_CREATER.Length);
                            else if (line.StartsWith(HEADER_MODIFIER)) modifier = line.Substring(HEADER_MODIFIER.Length);
                            else if (line.StartsWith(HEADER_CREATETIME)) createTime = DateTime.Parse(line.Substring(HEADER_CREATETIME.Length));
                            else if (line.StartsWith(HEADER_MODIFYTIME)) modifyTime = DateTime.Parse(line.Substring(HEADER_MODIFYTIME.Length));
                            else if (line.StartsWith(HEADER_REMARK_START)) remarkStart = true;
                            else if (line.StartsWith(HEADER_REMARK_END)) remarkStart = false;
                            else if (remarkStart)
                            {
                                if (remark.Length > 0) remark += "\r\n";
                                remark += line;
                            }
                        }
                    }
                    get
                    {
                        string result = "";
                        string reLine = "\r\n";
                        result += HEADER_TITLE + title + reLine;
                        result += HEADER_REMARK_START + reLine;
                        result += remark + reLine;
                        result += HEADER_REMARK_END + reLine;
                        result += HEADER_CREATETIME + createTime.ToString(FORMAT_LONG_DATETIME_STRING) + reLine;
                        result += HEADER_CREATER + creater + reLine;
                        result += HEADER_MODIFYTIME + modifyTime.ToString(FORMAT_LONG_DATETIME_STRING) + reLine;
                        result += HEADER_MODIFIER + modifier + reLine;

                        return result;
                    }
                }

                public List<string> LineContent
                {
                    set
                    {
                        int indexer = 0;
                        if (value[indexer] != null && value[indexer].Length > 0) title = value[indexer]; indexer++;
                        remark = value[indexer]; indexer++;
                        if (value[indexer] != null && value[indexer].Length > 0) createTime = DateTime.Parse(value[indexer]); indexer++;
                        if (value[indexer] != null && value[indexer].Length > 0) creater = value[indexer]; indexer++;
                        if (value[indexer] != null && value[indexer].Length > 0) modifyTime = DateTime.Parse(value[indexer]); indexer++;
                        if (value[indexer] != null && value[indexer].Length > 0) modifier = value[indexer]; indexer++;
                    }
                    get
                    {
                        List<string> result = new List<string>();
                        result.Add(title);
                        result.Add(remark);
                        result.Add(createTime.ToString(FORMAT_LONG_DATETIME_STRING));
                        result.Add(creater);
                        result.Add(modifyTime.ToString(FORMAT_LONG_DATETIME_STRING));
                        result.Add(modifier);
                        return result;
                    }
                }
            }

            private List<Subject> _subjects = new List<Subject>();
            public List<Subject> subjects
            {
                set
                {
                    _subjects = value;
                }
                get
                {
                    return _subjects;
                }
            }
            public int CountSingle
            {
                get
                {
                    int result = 0;
                    foreach (Subject sub in _subjects)
                    {
                        if (sub.type == Subject.Type.Single) result++;
                    }
                    return result;
                }
            }
            public int CountMuti
            {
                get
                {
                    int result = 0;
                    foreach (Subject sub in _subjects)
                    {
                        if (sub.type == Subject.Type.Muti) result++;
                    }
                    return result;
                }
            }
            public int CountJudge
            {
                get
                {
                    int result = 0;
                    foreach (Subject sub in _subjects)
                    {
                        if (sub.type == Subject.Type.Judge) result++;
                    }
                    return result;
                }
            }
            public int CountBlanks
            {
                get
                {
                    int result = 0;
                    foreach (Subject sub in _subjects)
                    {
                        if (sub.type == Subject.Type.Blanks) result++;
                    }
                    return result;
                }
            }
            public int CountQAnswer
            {
                get
                {
                    int result = 0;
                    foreach (Subject sub in _subjects)
                    {
                        if (sub.type == Subject.Type.QAnswer) result++;
                    }
                    return result;
                }
            }

            public static string JOIN_SEPARATOR_SUBJECTS = "\r\n\r\n*Next Subject Below*\r\n\r\n";
            public string IOContent_Subjects
            {
                get
                {
                    string result = "";
                    foreach (Subject sub in _subjects)
                    {
                        if (result.Length > 0)
                        {
                        }
                        result += JOIN_SEPARATOR_SUBJECTS;
                        result += sub.IOContent;
                    }
                    return StringCompress.Compress(result);
                }
                set
                {
                    _subjects.Clear();
                    if (value == null || value.Length <= 0)
                    {
                        return;
                    }
                    string[] subIos = (StringCompress.DeCompress(value)).Split(new string[] { JOIN_SEPARATOR_SUBJECTS }, StringSplitOptions.None);
                    Subject sub;
                    foreach (string io in subIos)
                    {
                        if (io == null || io.Length <= 0) continue;
                        sub = new Subject(io);
                        _subjects.Add(sub);
                    }

                }
            }

            public Depot()
            {
            }
            public Depot(string ioContent_Subjects)
            {
                this.IOContent_Subjects = ioContent_Subjects;
            }

            public Depot Clone()
            {
                return new Depot(this.IOContent_Subjects);
            }
        }

        public class AuditPaper
        {
            public class AuditingItem
            {
                public string op { set; get; }
                public string examerPath { set; get; }

                public string IOContent
                {
                    set
                    {
                        string[] parts = value.Split(new char[] { '\t' });
                        if (parts == null || parts.Length < 2) return;
                        op = parts[0];
                        examerPath = parts[1];
                    }
                    get
                    {
                        string result = (op == null) ? "" : op;
                        result += "\t" + ((examerPath == null) ? "" : examerPath);
                        return result;
                    }
                }
            }
        }

        public class Announcement
        {
            public class Info
            {
                public string op { set; get; }
                public string modifier { set; get; }
                public string name { set; get; }

                public DateTime startTime { set; get; }
                public DateTime endTime { set; get; }

                public DateTime createTime { set; get; }
                public DateTime modifyTime { set; get; }
                public DateTime publicTime { set; get; }

                public Info()
                {
                }
                public Info(string ioContent)
                {
                    this.IOContent = ioContent;
                }

                public bool isPublished
                {
                    get
                    {
                        return (publicTime > createTime && publicTime > modifyTime);
                    }
                }
                public bool isDated
                {
                    get
                    {
                        return (endTime < DateTime.Now);
                    }
                }
                public bool isStart
                {
                    get
                    {
                        return (startTime <= DateTime.Now);
                    }
                }

                private static string FLAG_RELINE = "\r\n";
                private static string FLAG_OP = "Create by: ";
                private static string FLAG_MODIFIER = "Last Modify by: ";
                private static string FLAG_NAME = "Announcement name: ";
                private static string FLAG_STARTTIME = "Anum Start At: ";
                private static string FLAG_ENDTIME = "Anum End At: ";
                private static string FLAG_CREATETIME = "Create At: ";
                private static string FLAG_MODIFYTIME = "Modify At: ";
                private static string FLAG_PUBLICTIME = "Public At: ";
                private static string DATETIME_LONGSTR_FORMAT = "yyyy-MM-dd HH:mm:ss";
                public string IOContent
                {
                    set
                    {
                        string[] lines = value.Split(new string[] { "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);
                        foreach (string line in lines)
                        {
                            if (line.StartsWith(FLAG_OP))
                            {
                                op = line.Substring(FLAG_OP.Length);
                            }
                            else if (line.StartsWith(FLAG_MODIFIER))
                            {
                                modifier = line.Substring(FLAG_MODIFIER.Length);
                            }
                            else if (line.StartsWith(FLAG_NAME))
                            {
                                name = line.Substring(FLAG_NAME.Length);
                            }
                            else if (line.StartsWith(FLAG_STARTTIME))
                            {
                                startTime = DateTime.Parse(line.Substring(FLAG_STARTTIME.Length));
                            }
                            else if (line.StartsWith(FLAG_ENDTIME))
                            {
                                endTime = DateTime.Parse(line.Substring(FLAG_ENDTIME.Length));
                            }
                            else if (line.StartsWith(FLAG_CREATETIME))
                            {
                                createTime = DateTime.Parse(line.Substring(FLAG_CREATETIME.Length));
                            }
                            else if (line.StartsWith(FLAG_MODIFYTIME))
                            {
                                modifyTime = DateTime.Parse(line.Substring(FLAG_MODIFYTIME.Length));
                            }
                            else if (line.StartsWith(FLAG_PUBLICTIME))
                            {
                                publicTime = DateTime.Parse(line.Substring(FLAG_PUBLICTIME.Length));
                            }
                        }
                    }
                    get
                    {
                        string result = "";
                        result += FLAG_OP + op + FLAG_RELINE;
                        result += FLAG_MODIFIER + modifyTime + FLAG_RELINE;
                        result += FLAG_NAME + name + FLAG_RELINE;
                        result += FLAG_STARTTIME + startTime.ToString(DATETIME_LONGSTR_FORMAT) + FLAG_RELINE;
                        result += FLAG_ENDTIME + endTime.ToString(DATETIME_LONGSTR_FORMAT) + FLAG_RELINE;
                        result += FLAG_CREATETIME + createTime.ToString(DATETIME_LONGSTR_FORMAT) + FLAG_RELINE;
                        result += FLAG_MODIFYTIME + modifyTime.ToString(DATETIME_LONGSTR_FORMAT) + FLAG_RELINE;
                        result += FLAG_PUBLICTIME + publicTime.ToString(DATETIME_LONGSTR_FORMAT) + FLAG_RELINE;
                        return result;
                    }
                }
            }
            public class InvitedUserList
            {
                public class Invitation
                {
                    public string userId;
                    public string userName;
                    public string orgPath;
                    public bool isVoted;

                    public Invitation()
                    {
                        isVoted = false;
                    }
                    public Invitation(string IOContent)
                    {
                        this.IOContent = IOContent;
                    }

                    public static bool operator ==(Invitation a, Invitation b)
                    {
                        return Equals(ref a, ref b);
                    }
                    public static bool operator !=(Invitation a, Invitation b)
                    {
                        return !Equals(ref a, ref b);
                    }
                    public static bool Equals(ref Invitation a, ref Invitation b)
                    {
                        if (a.userId == b.userId
                            && a.userName == b.userName
                            && a.orgPath == b.orgPath)
                        {
                            return true;
                        }
                        else return false;
                    }

                    public override bool Equals(object obj)
                    {
                        return base.Equals(obj);
                    }
                    public override int GetHashCode()
                    {
                        return base.GetHashCode();
                    }

                    public string IOContent
                    {
                        set
                        {
                            string[] parts = value.Split(new char[] { '\t' });
                            userId = parts[0];
                            userName = parts[1];
                            orgPath = parts[2];
                            isVoted = bool.Parse(parts[3]);
                            ;
                        }
                        get
                        {
                            string result = userId;
                            result += "\t" + userName;
                            result += "\t" + orgPath;
                            result += "\t" + isVoted.ToString();
                            return result;
                        }
                    }
                }
                private List<Invitation> _data = new List<Invitation>();
                public List<Invitation> data
                {
                    set
                    {
                        _data = value;
                        _Sort_RemoveRepeat_IvtList(ref _data);
                    }
                    get { return _data; }
                }

                public void Set_List(List<Invitation> subList)
                {
                    _data.AddRange(subList);
                    _Sort_RemoveRepeat_IvtList(ref _data);
                }
                private void _Sort_RemoveRepeat_IvtList(ref List<Invitation> source)
                {
                    List<string> sorter = new List<string>();
                    for (int i = source.Count - 1; i >= 0; i--)
                    {
                        sorter.Add(source[i].userId);
                    }
                    sorter.Sort();
                    string curId;
                    Invitation tmpIvt;
                    for (int i = sorter.Count - 1; i > 1; i--)
                    {
                        curId = sorter[i];
                        for (int j = i; j >= 0; j--)
                        {
                            if (source[j].userId == curId)
                            {
                                if (i == j) break;
                                tmpIvt = source[j];
                                source.RemoveAt(j);
                                source.Insert(i, tmpIvt);
                            }
                        }
                    }

                    for (int i = source.Count - 1; i > 0; i--)
                    {
                        if (source[i] == source[i - 1])
                        {
                            source.RemoveAt(i);
                        }
                    }
                }

                public string IOContent
                {
                    set
                    {
                        _data.Clear();
                        string[] lines = value.Split(new string[] { "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);
                        foreach (string line in lines)
                        {
                            _data.Add(new Invitation(line));
                        }
                        _Sort_RemoveRepeat_IvtList(ref _data);
                    }
                    get
                    {
                        string result = "";
                        for (int i = 0; i < data.Count; i++)
                        {
                            if (i != 0) result += "\r\n";
                            result += data[i].IOContent;
                        }
                        return result;
                    }
                }
            }

            public class Content
            {
                public List<Depot.Subject> paperContent { set; get; }
                public Content()
                {
                    paperContent = new List<Depot.Subject>();
                }
                public Content(string ioContent)
                {
                    this.IOContent = ioContent;
                }
                public void Add_Content(Depot.Subject elm)
                {
                    paperContent.Add(elm);
                }
                public void Remove_Content_At(int idx)
                {
                    List<Depot.Subject> list = paperContent;
                    list.RemoveAt(idx);
                    paperContent = list;
                }

                public string IOContent
                {
                    set
                    {
                        string[] lines = value.Split(new string[] { "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);
                        List<Depot.Subject> list = new List<Depot.Subject>();
                        for (int i = 0; i < lines.Length; i++)
                        {
                            list.Add(new Depot.Subject(lines[i]));
                        }
                        paperContent = list;
                    }
                    get
                    {
                        string result = "";
                        for (int i = 0; i < paperContent.Count; i++)
                        {
                            if (i != 0) result += "\r\n";
                            result += paperContent[i].IOContent;
                        }
                        return result;
                    }
                }
            }
        }
    }

    public class StringCompress
    {
        //public StringCompress()
        //{

        //}

        public static string Compress(string unCompressedString)
        {
            byte[] inputBuf = Encoding.Unicode.GetBytes(unCompressedString);
            if (inputBuf.Length == 0)
            {
                return null;
            }
            MemoryStream ms = new MemoryStream();

            SharpCompress.Compressor.BZip2.BZip2Stream zipSteam = new SharpCompress.Compressor.BZip2.BZip2Stream(ms, SharpCompress.Compressor.CompressionMode.Compress);
            zipSteam.Write(inputBuf, 0, inputBuf.Length);
            zipSteam.Close();

            byte[] outputBuf = ms.ToArray();
            ms.Close();
            ms.Dispose();
            zipSteam.Dispose();

            return System.Convert.ToBase64String(outputBuf);
        }

        public static string DeCompress(string compressedString)
        {
            byte[] inputBuf = System.Convert.FromBase64String(compressedString);
            if (inputBuf.Length == 0)
            {
                return null;
            }
            MemoryStream ms = new MemoryStream(inputBuf);
            ms.Position = 0;
            SharpCompress.Compressor.BZip2.BZip2Stream zipSteam = new SharpCompress.Compressor.BZip2.BZip2Stream(ms, SharpCompress.Compressor.CompressionMode.Decompress);

            MemoryStream outputMem = new MemoryStream();
            int readLength = 512;
            int readLengthCur = readLength;
            byte[] tmpBuf;
            while (readLengthCur == readLength)
            {
                tmpBuf = new byte[readLength];
                readLengthCur = zipSteam.Read(tmpBuf, 0, readLength);
                outputMem.Write(tmpBuf, 0, readLengthCur);
            }

            byte[] outputBuf = outputMem.ToArray();
            outputMem.Close();
            outputMem.Dispose();
            ms.Close();
            ms.Dispose();
            zipSteam.Close();
            zipSteam.Dispose();

            string result = Encoding.Unicode.GetString(outputBuf, 0, outputBuf.Length);
            return result;
        }

    }
}
