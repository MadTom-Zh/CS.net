﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using SGCC_NX_UUMP;

namespace XTExam.CodeSharing.Entities
{
    public class SGCC_NX_UUMP
    {
        private static string CONFIG_DIR
        {
            get
            {
                return AppDomain.CurrentDomain.BaseDirectory + "\\App_Data";
            }
        }
        private static string CONFIG_NAME_INDEXER = "用户列表，用户获取DN";
        private static string CONFIG_NAME_PLANT = "生产系统树形验证平台";
        public static bool IsUserExists(string uId)
        {
            string DN = PlantWatcher.Indexer.GetUserDN_Oracle(CONFIG_DIR, CONFIG_NAME_INDEXER, uId);
            return (DN == null) ? false : true;
        }
        public static bool IsUserPass(string uId, string pwd)
        {
            string DN = PlantWatcher.Indexer.GetUserDN_Oracle(CONFIG_DIR, CONFIG_NAME_INDEXER, uId);
            if (DN == null) return false;
            return PlantWatcher.IsUserPass(CONFIG_DIR, CONFIG_NAME_PLANT, DN, pwd);
        }
        public static List<string> GetUserFullPath(string uId)
        {
            string DN = PlantWatcher.Indexer.GetUserDN_Oracle(CONFIG_DIR, CONFIG_NAME_INDEXER, uId);
            return PlantWatcher.GetFullNames(CONFIG_DIR, CONFIG_NAME_PLANT, DN);
        }
    }
}
