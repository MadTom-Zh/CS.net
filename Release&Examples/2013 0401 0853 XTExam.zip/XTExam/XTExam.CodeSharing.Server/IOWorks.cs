﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;
using System.Web;

namespace XTExam.CodeSharing.Entities
{
    public class IOWorks
    {
        public class UserList
        {
            public static string FILENAME_SUFFIX_HEAD = "_hea.txt";
            public static string FILENAME_SUFFIX_BODY = ".txt";
            public static string IO_ROOT_PATH
            {
                get
                {
                    string rootPath = AppDomain.CurrentDomain.BaseDirectory + "\\App_Data\\User";
                    rootPath = rootPath.Replace("\\\\", "\\");
                    if (!Directory.Exists(rootPath)) Directory.CreateDirectory(rootPath);
                    return rootPath;
                }
            }

            public static string GetIOPath(string relatePath)
            {
                string path = IO_ROOT_PATH + "\\" + relatePath;
                if (Directory.Exists(path)) return path;
                return null;
            }
            public static string GetIOPath_BodyFile(string relatePath)
            {
                string path = IO_ROOT_PATH + "\\" + relatePath + FILENAME_SUFFIX_BODY;
                if (File.Exists(path)) return path;
                return null;
            }

            public static List<string> GetUserList(string relatePath)
            {
                string ioPath = GetIOPath_BodyFile(relatePath);
                if (ioPath == null) return null;
                string[] lines = File.ReadAllLines(ioPath);
                List<string> result = new List<string>();
                foreach (string id in lines)
                {
                    if (id.Length > 0) result.Add(id);
                }
                return result;
            }
        }

        public class UserRegister
        {
            public class UserInfo
            {
                public static string FORMAT_DATE_LONGSTRING = "yyyy-MM-dd HH:mm:ss";
                private static string _FILE_NAME_USER_DB = "User.db";
                private static string _FILE_FULLNAME_USER_DB
                {
                    get
                    {
                        return WebSite.Path_App_Data + "\\" + _FILE_NAME_USER_DB;
                    }
                }
                public static void SetUsers(List<string> idList, string op)
                {
                    string targetFile = WebSite.Path_App_Data + "\\" + _FILE_NAME_USER_DB;
                    if (!File.Exists(targetFile))
                    {
                        StreamWriter sw = File.CreateText(targetFile);
                        sw.Close();
                    }
                    string[] lines = File.ReadAllLines(targetFile);
                    string[] lineParts;
                    string oneId;
                    char[] spliter = new char[] { '\t' };
                    for (int i = 0; i < lines.Length; i++)
                    {
                        lineParts = lines[i].Split(spliter);
                        for (int j = idList.Count - 1; j >= 0; j--)
                        {
                            oneId = idList[j];
                            if (lineParts[0] == oneId)
                            {
                                idList.RemoveAt(j);
                            }
                        }
                    }
                    string ioContent = "";
                    for (int i = idList.Count - 1; i >= 0; i--)
                    {
                        if (ioContent.Length > 0)
                        {
                            ioContent += "\r\n";
                        }
                        ioContent += new DataProcessing.UserRegister.UserInfo(idList[i], op).IOContent;
                    }
                    File.AppendAllText(targetFile, "\r\n" + ioContent);
                }

                public static void SetUser(DataProcessing.UserRegister.UserInfo user, string op)
                {
                    string targetFile = _FILE_FULLNAME_USER_DB;
                    if (!File.Exists(targetFile))
                    {
                        StreamWriter sw = File.CreateText(targetFile);
                        sw.Close();
                    }
                    File.AppendAllText(targetFile, "\r\n" + user.IOContent);
                }

                public static void SetUser_exPWD(string id, string pwd)
                {
                    string targetFile = _FILE_FULLNAME_USER_DB;
                    string[] records = File.ReadAllLines(targetFile);
                    string line;
                    DataProcessing.UserRegister.UserInfo helper;
                    for (int j = 0; j < records.Length; j++)
                    {
                        line = records[j];
                        if (line.StartsWith(id))
                        {
                            if (line.StartsWith(id + "\t"))
                            {
                                helper = new DataProcessing.UserRegister.UserInfo(null, null);
                                helper.IOContent = line;
                                helper.exPwd = pwd;
                                records[j] = helper.IOContent;
                            }
                        }
                    }
                    File.WriteAllLines(targetFile, records);
                }

                public static DataProcessing.UserRegister.UserInfo GetUser(string id, string exPwd, string inPwd)
                {
                    WebSite.WriteLog("User[" + id + "], try use exPwd[" + exPwd + "] or inPwd[" + inPwd + "] to Login.");

                    bool exLogen = false;
                    bool userFound = false;
                    if (exPwd != null && exPwd.Length > 0)
                    {
                        //throw new Exception("Function Limitition!");
                        if (SGCC_NX_UUMP.IsUserPass(id, exPwd))
                        {
                            exLogen = true;

                            //helper.exPwd = exPwd;
                            //Class_Site.WriteLog("User[" + id + "] extra logen.");
                            //return helper;
                        }
                    }

                    string[] records = File.ReadAllLines(_FILE_FULLNAME_USER_DB);
                    DataProcessing.UserRegister.UserInfo helper;
                    foreach (string line in records)
                    {
                        if (line.StartsWith(id))
                        {
                            if (line.StartsWith(id + "\t"))
                            {
                                userFound = true;
                                helper = new DataProcessing.UserRegister.UserInfo(null, null);
                                helper.IOContent = line;
                                if (exLogen)
                                {
                                    if (helper.exPwd != exPwd)
                                    {
                                        IOWorks.UserRegister.UserInfo.SetUser_exPWD(id, exPwd);
                                    }
                                    WebSite.WriteLog("User[" + id + "] extra logen.");
                                    return helper;
                                }
                                if (helper.inPwd == inPwd)
                                {
                                    helper.IOContent = line;
                                    WebSite.WriteLog("User[" + id + "] inner logen.");
                                    return helper;
                                }
                            }
                        }
                    }
                    if (exLogen && !userFound)
                    {
                        //throw new Exception("Function Limitition!");
                        helper = new DataProcessing.UserRegister.UserInfo(id, id);
                        helper.exPwd = exPwd;
                        List<string> orgs = SGCC_NX_UUMP.GetUserFullPath(id);
                        helper.name = orgs[orgs.Count - 1];
                        helper.orgPath = "";
                        for (int i = 0; i < orgs.Count - 1; i++)
                        {
                            if (helper.orgPath.Length > 0) helper.orgPath += "\\";
                            helper.orgPath += orgs[i];
                        }
                        UserRegister.UserInfo.SetUser(helper, id);

                        WebSite.WriteLog("User[" + id + "] is bland new, create profile.");
                        WebSite.WriteLog("User[" + id + "] extra logen.");
                        return helper;
                    }
                    return null;
                }
                public static DataProcessing.UserRegister.UserInfo GetUser(string id)
                {
                    WebSite.WriteLog("Try GetUser [" + id + "]");
                    DataProcessing.UserRegister.UserInfo result = new DataProcessing.UserRegister.UserInfo(id, null);
                    string targetFile = WebSite.Path_App_Data + "\\" + _FILE_NAME_USER_DB;
                    string[] records = File.ReadAllLines(targetFile);
                    foreach (string line in records)
                    {
                        if (line.StartsWith(id))
                        {
                            if (line.StartsWith(id + "\t"))
                            {
                                WebSite.WriteLog("GotUser [" + id + "]");
                                result.IOContent = line;
                                return result;
                            }
                        }
                    }
                    return null;
                }

                public static List<DataProcessing.UserRegister.UserInfo> GetUsers(List<string> idList)
                {
                    List<DataProcessing.UserRegister.UserInfo> result = new List<DataProcessing.UserRegister.UserInfo>();
                    string targetFile = WebSite.Path_App_Data + "\\" + _FILE_NAME_USER_DB;
                    string[] records = File.ReadAllLines(targetFile);
                    DataProcessing.UserRegister.UserInfo newUser;
                    foreach (string line in records)
                    {
                        for (int i = idList.Count - 1; i >= 0; i--)
                        {
                            if (line.StartsWith(idList[i]))
                            {
                                if (line.StartsWith(idList[i] + "\t"))
                                {
                                    newUser = new DataProcessing.UserRegister.UserInfo(idList[i], null);
                                    newUser.IOContent = line;
                                    result.Add(newUser);
                                    idList.RemoveAt(i);
                                }
                            }
                        }
                    }
                    return result;
                }
                public static List<DataProcessing.UserRegister.UserInfo> GetAllUsers()
                {
                    List<DataProcessing.UserRegister.UserInfo> result = new List<DataProcessing.UserRegister.UserInfo>();
                    string targetFile = WebSite.Path_App_Data + "\\" + _FILE_NAME_USER_DB;
                    string[] records = File.ReadAllLines(targetFile);
                    DataProcessing.UserRegister.UserInfo newUser;
                    foreach (string line in records)
                    {
                        newUser = new DataProcessing.UserRegister.UserInfo(null, null);
                        newUser.IOContent = line;
                        result.Add(newUser);
                    }
                    return result;
                }

                public static List<string> SetPro(List<string> idList,
                    bool infuAdminUser, bool infuAdminUserValue,
                    bool infuCheckResult, bool infuCheckResultValue,
                    bool infuMakePaper, bool infuMakePaperValue,
                    bool infuAuditPaper, bool infuAuditPaperValue)
                {
                    string targetFile = WebSite.Path_App_Data + "\\" + _FILE_NAME_USER_DB;
                    string[] records = File.ReadAllLines(targetFile);
                    string line;
                    string curId;
                    DataProcessing.UserRegister.UserInfo helper;
                    for (int j = 0; j < records.Length; j++)
                    {
                        line = records[j];
                        for (int i = idList.Count - 1; i >= 0; i--)
                        {
                            curId = idList[i];
                            if (line.StartsWith(curId))
                            {
                                if (line.StartsWith(curId + "\t"))
                                {
                                    helper = new DataProcessing.UserRegister.UserInfo(null, null);
                                    helper.IOContent = line;
                                    if (infuAdminUser) helper.couldAdminUser = infuAdminUserValue;
                                    if (infuCheckResult) helper.couldCheckResult = infuCheckResultValue;
                                    if (infuMakePaper) helper.couldMakePaper = infuMakePaperValue;
                                    if (infuAuditPaper)
                                    {
                                        helper.couldAuditPaper = infuAuditPaperValue;
                                        if (helper.auditOrgPathes == "{none}")
                                        {
                                            helper.auditOrgPathes = helper.orgPath;
                                        }
                                        if (!infuAuditPaperValue)
                                        {
                                            helper.auditOrgPathes = "{none}";
                                        }
                                    }
                                    records[j] = helper.IOContent;
                                    idList.RemoveAt(i);
                                }
                            }
                        }
                    }
                    File.WriteAllLines(targetFile, records);
                    return idList;
                }

                public static bool ChangeUserBaseInfo(string op, string targetUserId, string userName, string userOrgPath)
                {
                    string targetFile = WebSite.Path_App_Data + "\\" + _FILE_NAME_USER_DB;
                    string[] records = File.ReadAllLines(targetFile);
                    string line;
                    DataProcessing.UserRegister.UserInfo helper;
                    bool userFound = false;
                    for (int j = 0; j < records.Length; j++)
                    {
                        line = records[j];
                        if (line.StartsWith(targetUserId))
                        {
                            if (line.StartsWith(targetUserId + "\t"))
                            {
                                helper = new DataProcessing.UserRegister.UserInfo(null, null);
                                helper.IOContent = line;
                                helper.name = userName;
                                helper.orgPath = userOrgPath;
                                records[j] = helper.IOContent;
                                userFound = true;
                                break;
                            }
                        }
                    }
                    File.WriteAllLines(targetFile, records);
                    return userFound;
                }

                public static bool ChangeUserInnerPassword(string op, string targetUserId, string oldPWD, string newPWD)
                {
                    string targetFile = WebSite.Path_App_Data + "\\" + _FILE_NAME_USER_DB;
                    string[] records = File.ReadAllLines(targetFile);
                    string line;
                    DataProcessing.UserRegister.UserInfo helper;
                    bool userFound = false;
                    for (int j = 0; j < records.Length; j++)
                    {
                        line = records[j];
                        if (line.StartsWith(targetUserId))
                        {
                            if (line.StartsWith(targetUserId + "\t"))
                            {
                                helper = new DataProcessing.UserRegister.UserInfo(null, null);
                                helper.IOContent = line;
                                if (helper.inPwd == oldPWD)
                                {
                                    helper.inPwd = newPWD;
                                    records[j] = helper.IOContent;
                                    userFound = true;
                                }
                            }
                        }
                    }
                    File.WriteAllLines(targetFile, records);
                    WebSite.WriteLog("User[" + op + "] changed user[" + targetUserId + "]' password[" + oldPWD + "] to newPassword[" + newPWD + "]");
                    return userFound;
                }

                public static List<string> GetAllUserId(string op)
                {
                    string targetFile = WebSite.Path_App_Data + "\\" + _FILE_NAME_USER_DB;
                    string[] records = File.ReadAllLines(targetFile);
                    string line;
                    DataProcessing.UserRegister.UserInfo helper;
                    List<string> result = new List<string>();
                    for (int j = 0; j < records.Length; j++)
                    {
                        line = records[j];
                        try
                        {
                            helper = new DataProcessing.UserRegister.UserInfo(null, null);
                            helper.IOContent = line;
                            if (helper.id != null && helper.id.Length > 0) result.Add(helper.id);
                        }
                        catch (Exception) { }
                    }
                    WebSite.WriteLog("User[" + op + "] get All userId.");
                    return result;
                }

                private static string _FILE_FULLNAME_USER_EXIDNO_DB
                {
                    get
                    {
                        string fileFName = WebSite.Path_App_Data + "\\" + "ExUser.db";
                        if (File.Exists(fileFName) == false)
                        {
                            File.WriteAllText(fileFName, "");
                        }
                        return fileFName;
                    }
                }
                // id,  name,  isPaMem,  idNo,  organi
                public static bool CheckIfUserIdOrUserIDNOExist(string id, string idNo)
                {
                    WebSite.WriteLog("CheckIfUserIdOrUserIDNOExist");
                    try
                    {
                        string[] lines = File.ReadAllLines(_FILE_FULLNAME_USER_EXIDNO_DB);
                        DataProcessing.UserRegister.UserInfoEx helper;
                        foreach (string line in lines)
                        {
                            if (line.Length == 0) continue;
                            helper = new DataProcessing.UserRegister.UserInfoEx(line);
                            if (helper.id == id || helper.idNo == idNo)
                            {
                                WebSite.WriteLog("Found user ID[" + id + "], IDNO[" + idNo + "]");
                                return true;
                            }
                        }
                    }
                    catch (Exception err)
                    {
                        WebSite.WriteLog(err);
                    }
                    return false;
                }

                public static bool RegExUserInfo(string exUserInfoIOContent)
                {
                    WebSite.WriteLog("RegExUserInfo");
                    try
                    {
                        DataProcessing.UserRegister.UserInfoEx helper
                            = new DataProcessing.UserRegister.UserInfoEx(exUserInfoIOContent);
                        if (helper.id.Length > 0 && helper.idNo.Length > 0 && helper.orgPath.Length > 0)
                        {
                            File.AppendAllText(_FILE_FULLNAME_USER_EXIDNO_DB, "\r\n" + exUserInfoIOContent);
                            return true;
                        }
                    }
                    catch (Exception err)
                    {
                        WebSite.WriteLog(err);
                    }
                    return false;
                }

                public static string LoadExUserFileContent()
                {
                    if (File.Exists(_FILE_FULLNAME_USER_EXIDNO_DB) == false)
                    {
                        return "";
                    }
                    return File.ReadAllText(_FILE_FULLNAME_USER_EXIDNO_DB);
                }
            }

            public class OrganFrame
            {
                public static DataProcessing.UserRegister.OrganFrame Get_OrganiNode(string fullName)
                {
                    DataProcessing.UserRegister.OrganFrame result = null;
                    if (fullName == null) fullName = "";
                    while (fullName.Contains("\\\\")) fullName = fullName.Replace("\\\\", "\\");
                    if (fullName.StartsWith("\\")) fullName = fullName.Substring(1);
                    if (fullName.EndsWith("\\")) fullName = fullName.Substring(0, fullName.Length - 1);
                    if (fullName.Contains("\\"))
                    {
                        string path = fullName.Substring(fullName.LastIndexOf("\\"));
                        result = new DataProcessing.UserRegister.OrganFrame(path, fullName.Substring(fullName.LastIndexOf("\\") + 1));
                    }
                    else if (fullName.Length <= 0)
                    {
                        result = new DataProcessing.UserRegister.OrganFrame("", "");
                    }
                    else result = new DataProcessing.UserRegister.OrganFrame("", fullName);
                    List<DataProcessing.UserRegister.UserInfo> allUsers = UserInfo.GetAllUsers();
                    string relateSubName;
                    string[] relateSubNameParts;

                    List<OrganName_and_ifHasChild> tmpFlagList = new List<OrganName_and_ifHasChild>();
                    foreach (DataProcessing.UserRegister.UserInfo oneUser in allUsers)
                    {
                        if (oneUser.orgPath.StartsWith(fullName))
                        {
                            relateSubName = oneUser.orgPath.Substring(fullName.Length);
                            if (relateSubName.Trim().Length <= 0)
                            {
                                // user here
                                result.Add_member(oneUser);
                            }
                            else
                            {
                                if (!relateSubName.StartsWith("\\")) continue;
                                relateSubNameParts = relateSubName.Split(new string[] { "\\" }, StringSplitOptions.RemoveEmptyEntries);
                                tmpFlagList.Add(new OrganName_and_ifHasChild(relateSubNameParts[0], relateSubNameParts.Length > 1));
                            }
                        }
                    }
                    tmpFlagList.Sort();
                    OrganName_and_ifHasChild flag;
                    for (int i = tmpFlagList.Count - 1; i > 0; i--)
                    {
                        if (tmpFlagList[i].name == tmpFlagList[i - 1].name)
                        {
                            flag = tmpFlagList[i];
                            tmpFlagList.RemoveAt(i);
                            flag.hasChild = (flag.hasChild || tmpFlagList[i - 1].hasChild);
                            tmpFlagList[i - 1] = flag;
                        }
                    }
                    DataProcessing.UserRegister.OrganFrame subOrg;
                    for (int i = tmpFlagList.Count - 1; i > 0; i--)
                    {
                        flag = tmpFlagList[i];
                        subOrg = new DataProcessing.UserRegister.OrganFrame(fullName, flag.name);
                        subOrg.manual_hasChild = flag.hasChild;
                        result.Add_subOrg(subOrg);
                    }
                    return result;
                }
                private struct OrganName_and_ifHasChild
                {
                    public string name;
                    public bool hasChild;
                    public OrganName_and_ifHasChild(string name, bool hasChild)
                    {
                        this.name = name;
                        this.hasChild = hasChild;
                    }
                }
            }
        }

        public class Results
        {
            public static List<DataProcessing.Results.ResultData> ReGatherAllResults()
            {
                List<DataProcessing.Results.ResultData> result = new List<DataProcessing.Results.ResultData>();
                //Class_User.UserRegister.User im = Class_User.UserRegister.GetUser(op);
                List<DataProcessing.ExamHall.UserExam.Info> examInfos = ExamHall.UserExam.GetAllExamInfo();
                DataProcessing.ExamHall.UserExam.Info oneExam;
                for (int i = examInfos.Count - 1; i >= 0; i--)
                {
                    oneExam = examInfos[i];
                    DataProcessing.Results.ResultData item = new DataProcessing.Results.ResultData();
                    item.hallName = oneExam.hallName;
                    item.userId = oneExam.userName;
                    item.userName = IOWorks.UserRegister.UserInfo.GetUser(item.userId).name;
                    item.userOrgPath = IOWorks.UserRegister.UserInfo.GetUser(oneExam.userName).orgPath;
                    item.isPaperAudited = oneExam.isAudited;
                    item.grades = new IOWorks.ExamHall.UserExam.UserPaper(oneExam.hallName, oneExam.userName, "system").data.GetGrades();
                    result.Add(item);
                }
                return result;
            }

            /// <summary>
            /// 检查是否在可执行数据收集的时间段之内，并检查数据状态
            /// 客户端执行此检查
            /// </summary>
            /// <returns>0-no Data, 1-Data OK, 2-Data outDated noGather, 3-Date outDated canGather, 4-no Data noGather</returns>
            public static int CheckGraphDataStatus()
            {
                string filePath = WebSite.Path_App_Data;
                string infoFileName = filePath + "\\graphData2013.dat";

                DateTime now = DateTime.Now;
                bool isInCompuTime = false;
                if ((now.Hour >= 13 && now.Hour < 14)
                    || (now.Hour >= 18 && now.Hour < 23))
                {
                    isInCompuTime = true;
                }
                if (File.Exists(infoFileName))
                {
                    DateTime timePoint = new FileInfo(infoFileName).LastWriteTime;


                    if (timePoint.Year == now.Year && timePoint.Month == now.Month && timePoint.Day == now.Day)
                    {
                        // it's today
                        if (isInCompuTime && Math.Abs(timePoint.Hour - now.Hour) > 4)
                        {
                            return 3;
                        }
                        else if (Math.Abs(timePoint.Hour - now.Hour) <= 4)
                        {
                            return 1;
                        }
                        else return 2;
                    }
                    else
                    {
                        if (isInCompuTime) return 3;
                        else return 2;
                    }
                }
                else
                {
                    if (isInCompuTime) return 0;
                    else return 4;
                }
            }

            /// <summary>
            /// 重新收集2013年考试的总成绩单
            /// 非常费时，请不要随意执行
            /// </summary>
            /// <returns></returns>
            public static bool ReGatherAllResults_Ex2013()
            {
                string filePath = WebSite.Path_App_Data;
                string dataFileName = filePath + "\\result2013.dat";
                string infoFileName = filePath + "\\result2013.inf";

                if (File.Exists(dataFileName))
                {
                    File.Delete(dataFileName);
                }
                if (File.Exists(infoFileName))
                {
                    File.Delete(infoFileName);
                }

                List<DataProcessing.ExamHall.UserExam.Info> examInfos = ExamHall.UserExam.GetAllExamInfo();
                DataProcessing.ExamHall.UserExam.Info oneExam;
                DateTime thisTime = new DateTime(2013, 2, 19);
                DataProcessing.Results.ResultData resultItem;
                string ioContent = "";
                for (int i = examInfos.Count - 1; i >= 0; i--)
                {
                    oneExam = examInfos[i];
                    if (oneExam.lastStartTime < thisTime)
                    {
                        continue;
                    }
                    resultItem = new DataProcessing.Results.ResultData();
                    resultItem.hallName = oneExam.hallName;
                    resultItem.userId = oneExam.userName;
                    resultItem.userName = IOWorks.UserRegister.UserInfo.GetUser(resultItem.userId).name;
                    resultItem.userOrgPath = IOWorks.UserRegister.UserInfo.GetUser(oneExam.userName).orgPath;
                    resultItem.isPaperAudited = oneExam.isAudited;
                    resultItem.grades = new IOWorks.ExamHall.UserExam.UserPaper(oneExam.hallName, oneExam.userName, "system").data.GetGrades();

                    if (ioContent.Length > 0) ioContent += "\r\n";
                    ioContent += resultItem.IOContent;
                }
                File.WriteAllText(dataFileName, ioContent);
                File.WriteAllText(infoFileName, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                return true;
            }

            public static bool ReGatherAll()
            {
                ReGatherAllResults_Ex2013();
                ReGatherGraphData_Ex2013();
                return true;
            }

            private static List<DataProcessing.Results.ResultData> LoadAllResult_Ex2013()
            {
                string filePath = WebSite.Path_App_Data;
                string dataFileName = filePath + "\\result2013.dat";
                //string infoFileName = filePath + "\\result2013.inf";
                List<DataProcessing.Results.ResultData> result = new List<DataProcessing.Results.ResultData>();
                if (File.Exists(dataFileName) == false)
                {
                    return result;
                }
                string[] lines = File.ReadAllLines(dataFileName);
                foreach (string line in lines)
                {
                    if (line.Length == 0) continue;
                    result.Add(new DataProcessing.Results.ResultData(line));
                }
                return result;
            }

            public static bool ReGatherGraphData_Ex2013()
            {
                WebSite.WriteLog("ReGatherGraphData_Ex2013()");
                string filePath = WebSite.Path_App_Data;
                string dataFileName = filePath + "\\graphData2013.dat";

                if (File.Exists(dataFileName) == true)
                {
                    File.Delete(dataFileName);
                }

                string[] exUserLines = UserRegister.UserInfo.LoadExUserFileContent().Split(new string[] { "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);
                DataProcessing.UserRegister.UserInfoEx exUserInfo;

                //// 获取本次考试所有帐号成绩信息
                //List<DataProcessing.Results.ResultData> resultList = LoadAllResult_Ex2013();

                // 装图形数据
                DataProcessing.Results.GraphData_Ex2013 graphDatHelper = new DataProcessing.Results.GraphData_Ex2013();
                foreach (string line in exUserLines)
                {
                    if (line.Trim().Length == 0) continue;
                    exUserInfo = new DataProcessing.UserRegister.UserInfoEx(line);
                    graphDatHelper.AddCount(exUserInfo.orgPath, 1, (exUserInfo.isPaMem == true ? 1 : 0));
                }

                File.WriteAllText(dataFileName, graphDatHelper.IOContent);
                return true;
            }

            public static string GetGraphData_Ex2013()
            {
                string filePath = WebSite.Path_App_Data;
                string dataFileName = filePath + "\\graphData2013.dat";
                //// 在这里执行一项额外工作，计算2013年总成绩单
                //ReGatherAllResults_Ex2013();


                //// 获取本次2013年考试，所有注册人员信息
                //string[] exUserLines = UserRegister.UserInfo.LoadExUserFileContent().Split(new string[] { "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);
                //DataProcessing.UserRegister.UserInfoEx exUserInfo;

                //// 获取本次考试所有帐号成绩信息
                //List<DataProcessing.Results.ResultData> resultList = LoadAllResult_Ex2013();

                //// 装图形数据
                //DataProcessing.Results.GraphData_Ex2013 graphDatHelper = new DataProcessing.Results.GraphData_Ex2013();
                //foreach (string line in exUserLines)
                //{
                //    exUserInfo = new DataProcessing.UserRegister.UserInfoEx(line);
                //    graphDatHelper.AddCount(exUserInfo.orgPath, 1, (exUserInfo.isPaMem == true ? 1 : 0));
                //}
                //return graphDatHelper.IOContent;
                if (File.Exists(dataFileName) == false)
                {
                    WebSite.WriteLog("graph file not exists");
                    ReGatherGraphData_Ex2013();
                    //return "";
                }
                else
                {
                    FileInfo dataFileInfo = new FileInfo(dataFileName);
                    WebSite.WriteLog("graph file exists");
                    if ((DateTime.Now - dataFileInfo.LastWriteTime) > new TimeSpan(3, 0, 0))
                    {
                        WebSite.WriteLog("graph file over 3 hours");
                        ReGatherGraphData_Ex2013();
                    }
                }
                return File.ReadAllText(dataFileName);
            }

            public static string GetGraphInfo_Ex2013()
            {
                WebSite.WriteLog("GetGraphInfo_Ex2013()");
                string filePath = WebSite.Path_App_Data;
                //string dataFileName = filePath + "\\result2013.dat";
                //string infoFileName = filePath + "\\result2013.inf";
                string dataFileName = filePath + "\\graphData2013.dat";

                if (File.Exists(dataFileName) == false)
                {
                    return "无日期";
                }
                FileInfo dataFileInfo = new FileInfo(dataFileName);
                return dataFileInfo.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss");
            }
        }


        public class WebSite
        {
            public static string Path_App_Data
            {
                get
                {
                    return (AppDomain.CurrentDomain.BaseDirectory + "\\App_Data").Replace("\\\\", "\\");
                }
            }

            public static void Web_IOInit()
            {
                string newDir = Path_App_Data + "\\User";
                if (!Directory.Exists(newDir))
                {
                    Directory.CreateDirectory(newDir);
                }
                newDir = Path_App_Data + "\\Logs";

                string userDB = Path_App_Data + "\\User.db";
                if (!File.Exists(userDB))
                {
                    File.WriteAllText(userDB, "Admin	LongTom				xtgs_examination_system	2010-05-18 13:31	Admin	2010-05-18 13:31	Admin	true	true	true	true	");
                }
            }

            public static void WriteLog(string msg)
            {
                WriteLog_rec("event", msg);
            }
            public static void WriteLog(Exception err)
            {
                WriteLog_rec("Error", err.ToString());
            }
            private static void WriteLog_rec(string type, string content)
            {
                DateTime now = DateTime.Now;
                string logPath = Path_App_Data + "\\Logs";
                if (!Directory.Exists(logPath))
                {
                    Directory.CreateDirectory(logPath);
                }
                File.AppendAllText(logPath + "\\" + now.ToString("yyyy-MM-dd") + ".txt", "\r\n" + now.ToString("HH:mm:ss") + " " + type + " " + content);
            }
        }

        public class ExamHall
        {
            public static string IO_ROOT_PATH
            {
                get
                {
                    string rootPath = AppDomain.CurrentDomain.BaseDirectory + "\\App_Data\\ExamHalls";
                    rootPath = rootPath.Replace("\\\\", "\\");
                    if (!Directory.Exists(rootPath)) Directory.CreateDirectory(rootPath);
                    return rootPath;
                }
            }

            public class HallInfo
            {
                private DataProcessing.ExamHall.HallInfo _data;
                public DataProcessing.ExamHall.HallInfo data
                {
                    set { _data = value; }
                    get { return _data; }
                }
                public HallInfo()
                {
                    _data = new DataProcessing.ExamHall.HallInfo();
                }
                public HallInfo(string hallName)
                {
                    _data = new DataProcessing.ExamHall.HallInfo();
                    _data.IOContent = File.ReadAllText(IO_ROOT_PATH + "\\" + hallName + "\\" + IO_FILENAME_HALL);
                }

                public static string IO_FILENAME_HALL = "HallInfo.txt";
                public void Save()
                {
                    string dirPath = IO_ROOT_PATH + "\\" + _data.hallName;
                    Directory.CreateDirectory(dirPath);
                    string filePath = dirPath + "\\" + IO_FILENAME_HALL;
                    File.WriteAllText(filePath, _data.IOContent);
                }

                /// <summary>
                /// check relations
                /// </summary>
                /// <returns>null 4Path</returns>
                public string CheckAll()
                {
                    if (_data.IOElements == null || _data.elements.Count == 0)
                    {
                        return "No paperElement Found";
                    }
                    string hallFullName = IO_ROOT_PATH + "\\" + _data.hallName;
                    if (Directory.Exists(hallFullName))
                    {
                        return "Hall already exists";
                    }
                    try
                    {
                        Directory.CreateDirectory(hallFullName);
                        Directory.Delete(hallFullName);
                    }
                    catch (Exception)
                    {
                        return "Could not Create this Hall, Check the name";
                    }

                    //examerListPath
                    List<string> userIDList = IOWorks.UserList.GetUserList(_data.examerListPath);
                    if (userIDList == null) return "Examer List not Exists";
                    if (userIDList.Count == 0) return "No member in List";

                    DataProcessing.ExamHall.HallInfo.PaperElement elm;
                    DataProcessing.Depot depotHelper;
                    for (int i = _data.elements.Count - 1; i >= 0; i--)
                    {
                        elm = _data.elements[i];
                        if (elm.type != DataProcessing.Depot.Subject.Type.Caption)
                        {
                            try
                            {
                                depotHelper = new IOWorks.Depot(elm.sourceDepot, _data.op).data;
                                switch (elm.type)
                                {
                                    case DataProcessing.Depot.Subject.Type.Single:
                                        if (depotHelper.CountSingle < _data.elements.Count) return "Not enough Singles";
                                        break;
                                    case DataProcessing.Depot.Subject.Type.Muti:
                                        if (depotHelper.CountMuti < _data.elements.Count) return "Not enough Muties";
                                        break;
                                    case DataProcessing.Depot.Subject.Type.Judge:
                                        if (depotHelper.CountJudge < _data.elements.Count) return "Not enough Judges";
                                        break;
                                    case DataProcessing.Depot.Subject.Type.Blanks:
                                        if (depotHelper.CountBlanks < _data.elements.Count) return "Not enough Blanks";
                                        break;
                                    case DataProcessing.Depot.Subject.Type.QAnswer:
                                        if (depotHelper.CountQAnswer < _data.elements.Count) return "Not enough QAnswers";
                                        break;
                                }
                            }
                            catch (Exception)
                            {
                                return "Depot Not Found";
                            }
                        }
                    }
                    return null;
                }

                public static string GetExtraFileStorPath(string hallName)
                {
                    string dirPath = IO_ROOT_PATH + "\\" + hallName + "\\ExtraFiles";
                    if (!Directory.Exists(dirPath)) Directory.CreateDirectory(dirPath);
                    return dirPath;
                }
                public static List<DataProcessing.ExamHall.HallInfo> GetAllHallInfo()
                {
                    List<DataProcessing.ExamHall.HallInfo> result = new List<DataProcessing.ExamHall.HallInfo>();
                    foreach (DirectoryInfo halDir in new DirectoryInfo(IO_ROOT_PATH).GetDirectories())
                    {
                        result.Add(new HallInfo(halDir.Name).data);
                    }
                    return result;
                }

                public static List<string> GetAllMyExam_HallInfos_IOContent(string examerName)
                {
                    List<string> result = new List<string>();
                    List<DataProcessing.ExamHall.HallInfo> hallInfoList = GetAllHallInfo();
                    List<string> userList;
                    foreach (DataProcessing.ExamHall.HallInfo hInfo in hallInfoList)
                    {
                        userList = IOWorks.UserList.GetUserList(hInfo.examerListPath);
                        foreach (string uId in userList)
                        {
                            if (uId == examerName)
                            {
                                result.Add(hInfo.IOContent);
                            }
                        }
                    }
                    return result;
                }
                public static List<string> GetAllExamers(string hallName)
                {
                    List<string> result = new List<string>();
                    foreach (DirectoryInfo uDir in new DirectoryInfo(IO_ROOT_PATH + "\\" + hallName).GetDirectories())
                    {
                        result.Add(HttpUtility.UrlDecode(uDir.Name));
                    }
                    return result;
                }
            }

            public class Admin
            {
                /// <summary>
                /// 
                /// </summary>
                /// <param name="hallInfoIOContent"></param>
                /// <returns>null 4Path</returns>
                public static string AddHall(string hallInfoIOContent)
                {
                    DataProcessing.ExamHall.HallInfo newHInfo = new DataProcessing.ExamHall.HallInfo();
                    newHInfo.IOContent = hallInfoIOContent;
                    HallInfo checker = new HallInfo();
                    checker.data = newHInfo;
                    string errorText = checker.CheckAll();
                    if (errorText != null) return errorText;
                    checker.Save();
                    return null;
                }
                public static bool AddWrite_ExtraFile(string op, string hallName, string fileName, byte[] data, bool isAppend)
                {
                    string filePath = HallInfo.GetExtraFileStorPath(hallName) + "\\" + fileName;
                    FileStream writer;
                    int offSet = 0;
                    if (!isAppend && File.Exists(filePath)) File.Delete(filePath);
                    if (isAppend)
                    {
                        offSet = (int)new FileInfo(filePath).Length - 1;
                        writer = new FileStream(filePath, FileMode.Append, FileAccess.Write, FileShare.None);
                    }
                    else writer = new FileStream(filePath, FileMode.CreateNew, FileAccess.Write, FileShare.None);
                    //if (isAppend) writer.Write(data, offSet, data.Length);
                    //else writer.Write(data, 0, data.Length);
                    writer.Write(data, 0, data.Length);
                    writer.Close();
                    IOWorks.WebSite.WriteLog("User[" + op + "] upload ExtraFile[" + fileName + "] toHall[" + hallName + "]");
                    return true;
                }
            }

            public class UserExam
            {
                public class Info
                {
                    public static string IO_FILE_NAME = "Info.txt";
                    private string ioFileFullPath;
                    private DataProcessing.ExamHall.UserExam.Info _data;
                    public DataProcessing.ExamHall.UserExam.Info data
                    {
                        set { _data = value; }
                        get { return _data; }
                    }
                    public Info(string hallName, string examerName)
                    {
                        _data = new DataProcessing.ExamHall.UserExam.Info();
                        _data.hallName = hallName;
                        _data.userName = examerName;
                        //_data.isAudited = needAudi ? false : true;
                        string storPath = IO_ROOT_PATH + "\\" + hallName + "\\" + HttpUtility.UrlEncode(examerName);
                        if (!Directory.Exists(storPath)) Directory.CreateDirectory(storPath);
                        ioFileFullPath = storPath + "\\" + IO_FILE_NAME;
                        if (!File.Exists(ioFileFullPath))
                        {
                            CreateInfo();
                        }
                        ReLoad();
                    }
                    private void CreateInfo()
                    {
                        DataProcessing.ExamHall.HallInfo hallInfo = new HallInfo(_data.hallName).data;
                        _data.examTimeLength = hallInfo.examinatingTimeLength;
                        _data.examTimeUsed = 0;
                        Save();
                    }
                    public void ReLoad()
                    {
                        _data.IOContent = File.ReadAllText(ioFileFullPath);
                    }
                    public void Save()
                    {
                        File.WriteAllText(ioFileFullPath, _data.IOContent);
                    }


                    public void SetStart()
                    {
                        if (CheckSetTimePoint2End())
                        {
                            if (_data.lastStartTime.ToOADate() != 0) AddTimeAndCheck(_data.lastStartTime);
                            _data.lastStartTime = DateTime.Now;
                            _data.lastPauseTime = new DateTime();
                            Save();
                        }
                    }
                    public void SetPause()
                    {
                        if (CheckSetTimePoint2End())
                        {
                            if (_data.lastStartTime.ToOADate() != 0)
                            {
                                _data.lastPauseTime = DateTime.Now;
                                _data.examTimeUsed += (_data.lastPauseTime - _data.lastStartTime).TotalHours;
                                _data.lastStartTime = new DateTime();
                                //bool isContainManAS = false;
                                AuditPaper();
                                Save();
                            }
                            //else throw new Exception("Your LastStartTime is inited, Use SetStart(an Exam) instead.");
                        }
                    }
                    public void SetEnd()
                    {
                        if (CheckSetTimePoint2End())
                        {
                            if (_data.lastStartTime.ToOADate() != 0)
                            {
                                _data.lastPauseTime = DateTime.Now;
                                _data.examTimeUsed += (_data.lastPauseTime - _data.lastStartTime).TotalHours;
                            }
                            _data.lastEndTime = DateTime.Now;
                            _data.lastStartTime = _data.lastPauseTime = new DateTime();
                            AuditPaper();
                            Save();
                            //else throw new Exception("Your LastStartTime is inited, Use SetStart(an Exam) instead.");
                        }
                    }

                    private bool CheckSetTimePoint2End()
                    {
                        //string errInfo = "TimePoint Check notPassed, you're Finished.";
                        if (_data.lastEndTime.ToOADate() != 0) return false;// throw new Exception(errInfo);
                        if (_data.examTimeUsed >= _data.examTimeLength)
                        {
                            _data.examTimeLength = _data.examTimeUsed;
                            AuditPaper();
                            Save();
                            return false;
                            //throw new Exception(errInfo);
                        }
                        if (_data.lastStartTime.ToOADate() != 0)
                        {
                            double timeUsed = (DateTime.Now - _data.lastStartTime).TotalHours;
                            if ((timeUsed + _data.examTimeUsed) >= _data.examTimeLength)
                            {
                                _data.examTimeUsed = _data.examTimeLength;
                                AuditPaper();
                                Save();
                                return false;
                                //throw new Exception(errInfo);
                            }
                        }
                        return true;
                    }
                    private void AddTimeAndCheck(DateTime lastTime)
                    {
                        _data.examTimeUsed += (DateTime.Now - lastTime).TotalHours;
                        CheckSetTimePoint2End();
                    }

                    private void AuditPaper()
                    {
                        UserPaper paper = new UserPaper(_data.hallName, _data.userName, "System");
                        paper.AuditAndSavePaper();
                    }
                }


                public class UserPaper
                {

                    private static string IO_FILENAME = "Paper.txt";
                    private string io_fileFullName;
                    private DataProcessing.ExamHall.UserExam.UserPaper _data;
                    public DataProcessing.ExamHall.UserExam.UserPaper data
                    {
                        get { return _data; }
                    }
                    public UserPaper(string hallName, string examerName, string op)
                    {
                        string filePath = IO_ROOT_PATH + "\\" + hallName + "\\" + HttpUtility.UrlEncode(examerName) + "\\" + IO_FILENAME;
                        io_fileFullName = filePath;
                        if (!File.Exists(io_fileFullName))
                        {
                            IOWorks.WebSite.WriteLog("Operator[" + op + "] create paper[" + hallName + "] for examer[" + examerName + "].");
                            CreatePaper(io_fileFullName, hallName, op);
                        }
                        _data = new DataProcessing.ExamHall.UserExam.UserPaper();
                        _data.IOContent = File.ReadAllText(io_fileFullName);
                        IOWorks.WebSite.WriteLog("Operator[" + op + "] load user[" + examerName + "]'s paper[" + hallName + "].");
                    }
                    private void CreatePaper(string fillFullPath, string hallName, string op)
                    {
                        string ioContent = "";
                        DataProcessing.ExamHall.HallInfo hallInfo = new IOWorks.ExamHall.HallInfo(hallName).data;
                        DataProcessing.ExamHall.HallInfo.PaperElement tmplate;
                        DataProcessing.Depot.Subject subj;
                        DataProcessing.ExamHall.UserExam.UserPaper.Element elm;
                        for (int i = 0; i < hallInfo.elements.Count; i++)
                        {
                            tmplate = hallInfo.elements[i];
                            switch (tmplate.type)
                            {
                                case DataProcessing.Depot.Subject.Type.Caption:
                                    subj = new DataProcessing.Depot.Subject("");
                                    subj.type = DataProcessing.Depot.Subject.Type.Caption;
                                    subj.subject = tmplate.caption;
                                    subj.subjectWeight = tmplate.captionSize;
                                    subj.subjectAligh = tmplate.captionAlign;
                                    elm = new DataProcessing.ExamHall.UserExam.UserPaper.Element(subj, new DataProcessing.ExamHall.UserExam.UserPaper.Element.UserData());
                                    ioContent += elm.IOContent + "\r\n";
                                    break;
                                default:
                                    DataProcessing.Depot depot = new IOWorks.Depot(tmplate.sourceDepot, op).data;
                                    if (depot.subjects.Count < tmplate.subjectCount)
                                    {
                                        throw new Exception("No Enough Depot subjects for Block[" + tmplate.IOContent + "]");
                                    }
                                    int loadedSubjCount = 0;
                                    int loadSubjIndex = 0;
                                    switch (tmplate.gainType)
                                    {
                                        case DataProcessing.ExamHall.HallInfo.PaperElement.GainType.FromBeginning:
                                            while (loadedSubjCount < tmplate.subjectCount)
                                            {
                                                elm = new DataProcessing.ExamHall.UserExam.UserPaper.Element(depot.subjects[loadSubjIndex], new DataProcessing.ExamHall.UserExam.UserPaper.Element.UserData());
                                                if (elm.subject.type == tmplate.type)
                                                {
                                                    ioContent += elm.IOContent + "\r\n";
                                                    loadedSubjCount++;
                                                }
                                                loadSubjIndex++;
                                            }
                                            break;
                                        case DataProcessing.ExamHall.HallInfo.PaperElement.GainType.FromEnding:
                                            while (loadedSubjCount < tmplate.subjectCount)
                                            {
                                                elm = new DataProcessing.ExamHall.UserExam.UserPaper.Element(depot.subjects[depot.subjects.Count - 1 - loadedSubjCount], new DataProcessing.ExamHall.UserExam.UserPaper.Element.UserData());
                                                if (elm.subject.type == tmplate.type)
                                                {
                                                    ioContent += elm.IOContent + "\r\n";
                                                    loadedSubjCount++;
                                                }
                                                loadSubjIndex++;
                                            }
                                            break;
                                        case DataProcessing.ExamHall.HallInfo.PaperElement.GainType.Random:
                                            DataProcessing.Depot copiedDepot = depot.Clone();
                                            int curInd;
                                            int timeOut = 10000;

                                            // 以下4行代码，可保证rad的随机序列有99%的机率是不同的
                                            int iSeed = 10;
                                            Random ro = new Random(iSeed);
                                            long tick = DateTime.Now.Ticks;
                                            Random rad = new Random((int)(tick & 0xffffffffL) | (int)(tick >> 32));


                                            while (loadedSubjCount < tmplate.subjectCount)
                                            {
                                                curInd = rad.Next(0, copiedDepot.subjects.Count);
                                                elm = new DataProcessing.ExamHall.UserExam.UserPaper.Element(copiedDepot.subjects[curInd], new DataProcessing.ExamHall.UserExam.UserPaper.Element.UserData());
                                                if (elm.subject.type == tmplate.type)
                                                {
                                                    ioContent += elm.IOContent + "\r\n";
                                                    copiedDepot.subjects.RemoveAt(curInd);
                                                    loadedSubjCount++;
                                                }
                                                timeOut--;
                                                if (timeOut <= 0)
                                                {
                                                    WebSite.WriteLog("Random Load Subject Block From Depot [" + tmplate.sourceDepot + "] has Timed Out!!");
                                                    break;
                                                }
                                            }
                                            break;
                                    }
                                    break;
                            }
                        }

                        File.WriteAllText(fillFullPath, ioContent);
                    }

                    public void SaveUserAnswer(List<string> answerLines)
                    {
                        if (answerLines.Count != _data.elements.Count) throw new Exception("UserData Length notMatch Element Length!");
                        List<DataProcessing.ExamHall.UserExam.UserPaper.Element> paperElms = _data.elements;
                        DataProcessing.ExamHall.UserExam.UserPaper.Element elm;
                        for (int i = answerLines.Count - 1; i >= 0; i--)
                        {
                            elm = paperElms[i];
                            elm.userData.answer = answerLines[i];
                            paperElms[i] = elm;
                        }
                        _data.elements = paperElms;
                        File.WriteAllText(io_fileFullName, _data.IOContent);
                    }
                    public void SaveUserData(List<string> userData)
                    {
                        if (userData.Count != _data.elements.Count) throw new Exception("UserData Length notMatch Element Length!");
                        List<DataProcessing.ExamHall.UserExam.UserPaper.Element> paperElms = _data.elements;
                        DataProcessing.ExamHall.UserExam.UserPaper.Element elm;
                        for (int i = userData.Count - 1; i >= 0; i--)
                        {
                            elm = paperElms[i];
                            paperElms[i].userData.IOContent = userData[i];
                            paperElms[i] = elm;
                        }
                        _data.elements = paperElms;
                        File.WriteAllText(io_fileFullName, _data.IOContent);
                    }

                    public void AuditAndSavePaper()
                    {
                        List<DataProcessing.ExamHall.UserExam.UserPaper.Element> paperElms = _data.elements;
                        DataProcessing.ExamHall.UserExam.UserPaper.Element elm;
                        for (int i = _data.elements.Count - 1; i >= 0; i--)
                        {
                            elm = paperElms[i];
                            elm.userData.grade = elm.GetAuditedGrade(elm.userData);
                            paperElms[i] = elm;
                        }
                        _data.elements = paperElms;
                        File.WriteAllText(io_fileFullName, _data.IOContent);
                    }

                }

                public static List<DataProcessing.ExamHall.UserExam.Info> GetAllExamInfo()
                {
                    List<DataProcessing.ExamHall.HallInfo> allHall = IOWorks.ExamHall.HallInfo.GetAllHallInfo();
                    List<DataProcessing.ExamHall.UserExam.Info> result = new List<DataProcessing.ExamHall.UserExam.Info>();
                    //List<string> examerList = new List<string>();
                    foreach (DataProcessing.ExamHall.HallInfo hInfo in allHall)
                    {

                        foreach (string examerName in IOWorks.ExamHall.HallInfo.GetAllExamers(hInfo.hallName))
                        {
                            //examerList.Add(examerName);
                            result.Add(new IOWorks.ExamHall.UserExam.Info(hInfo.hallName, examerName).data);
                        }
                    }
                    //List<Class_User.UserRegister.User> examers = Class_User.UserRegister.GetUsers(examerList);
                    //for (int i = examers.Count - 1; i >= 0; i--)
                    //{
                    //    Class_User.UserRegister.User oneExamer = examers[i];
                    //    if(oneExamer.orgPath.StartsWith())
                    //}
                    return result;
                }
            }
        }

        public class Depot
        {
            public class Storage
            {
                public static string PATH_DEPOT_ROOT
                {
                    get
                    {
                        string rootPath = AppDomain.CurrentDomain.BaseDirectory + "\\App_Data\\Depot";
                        rootPath = rootPath.Replace("\\\\", "\\");
                        if (!Directory.Exists(rootPath)) Directory.CreateDirectory(rootPath);
                        return rootPath;
                    }
                }
                public static bool SetDir(string path, string op)
                {
                    if (path.Contains(PREFIX_DEPOT_IO)) return false;
                    string testDepot = path.Substring(0, path.LastIndexOf('\\')) + "\\" + path.Substring(path.LastIndexOf('\\') + 1);
                    if (Directory.Exists(testDepot)) return false;
                    if (path.EndsWith("\\")) path = path.Substring(0, path.Length - 1);
                    string target = PATH_DEPOT_ROOT + "\\" + path;
                    if (!Directory.Exists(target))
                    {
                        Directory.CreateDirectory(target);
                        IOWorks.WebSite.WriteLog("User[" + op + "] create depot Directory[" + path + "] complete");
                        return true;
                    }
                    return false;
                }

                public static string PREFIX_DEPOT_IO = "depot-of-";
                public static bool SetDepot(string path, string op)
                {
                    if (path.Contains(PREFIX_DEPOT_IO) || path == null || path.Length == 0) return false;
                    string testDepot = path.Substring(0, path.LastIndexOf('\\'));
                    if (testDepot.Contains('\\'))
                    {
                        testDepot = testDepot.Substring(0, testDepot.LastIndexOf('\\')) + "\\" + PREFIX_DEPOT_IO + testDepot.Substring(testDepot.LastIndexOf('\\') + 1);
                    }
                    else
                    {
                        testDepot = PREFIX_DEPOT_IO + testDepot;
                    }
                    string storRootPath = PATH_DEPOT_ROOT;
                    if (Directory.Exists(storRootPath + "\\" + testDepot)) return false;
                    if (path.EndsWith("\\")) path = path.Substring(0, path.Length - 1);
                    string target;
                    if (path.Contains('\\'))
                    {
                        target = path.Substring(0, path.LastIndexOf('\\')) + "\\" + PREFIX_DEPOT_IO + path.Substring(path.LastIndexOf('\\') + 1);
                    }
                    else target = PREFIX_DEPOT_IO + path;
                    target = storRootPath + "\\" + target;
                    if (!Directory.Exists(target))
                    {
                        Directory.CreateDirectory(target);
                        DataProcessing.Depot.Detail header = new DataProcessing.Depot.Detail();
                        header.title = path.Contains('\\') ? (path.Substring(path.LastIndexOf('\\') + 1)) : path;
                        header.remark = "";
                        header.createTime = header.modifyTime = DateTime.Now;
                        header.creater = header.modifier = op;
                        IOWorks.Depot.SaveDepotDetail(path, header);
                        IOWorks.WebSite.WriteLog("User[" + op + "] create Depot[" + path + "] complete");
                        return true;
                    }
                    return false;
                }

                public static List<string> GetAllStorItems()
                {
                    List<string> result = new List<string>();
                    DirectoryInfo rootInfo = new DirectoryInfo(PATH_DEPOT_ROOT);
                    LoadAllStorItems_LoadDirItem(false, rootInfo, ref result);
                    return result;
                }
                private static void LoadAllStorItems_LoadDirItem(bool recThisDir, DirectoryInfo dir, ref List<string> list)
                {
                    if (dir.Parent.Name.StartsWith(PREFIX_DEPOT_IO)) return;
                    foreach (DirectoryInfo subDir in dir.GetDirectories())
                    {
                        LoadAllStorItems_LoadDirItem(true, subDir, ref list);
                    }
                    if (recThisDir)
                    {
                        if (dir.FullName.Length > PATH_DEPOT_ROOT.Length)
                        {
                            string item = dir.FullName.Substring(PATH_DEPOT_ROOT.Length);
                            string type = item.Contains(PREFIX_DEPOT_IO) ? "P->" : "D->";
                            item = item.Replace(PREFIX_DEPOT_IO, "");
                            list.Add(type + item);
                        }
                    }
                }

                public static bool DelStorItem(string path, string op)
                {
                    string rootPath = PATH_DEPOT_ROOT;
                    while (path.EndsWith("\\")) path = path.Substring(0, path.Length - 1);
                    string dir = rootPath + "\\" + path;
                    string pot = dir.Substring(0, dir.LastIndexOf('\\')) + "\\" + PREFIX_DEPOT_IO + dir.Substring(dir.LastIndexOf('\\') + 1);
                    string backupItem = rootPath.Substring(0, rootPath.LastIndexOf('\\')) + ".backup";
                    if (!Directory.Exists(backupItem)) Directory.CreateDirectory(backupItem);
                    int count = 1;
                    if (Directory.Exists(dir))
                    {
                        backupItem += "\\" + dir.Substring(dir.LastIndexOf('\\') + 1);
                        if (Directory.Exists(backupItem))
                        {
                            backupItem += "-" + count;
                            while (Directory.Exists(backupItem))
                            {
                                count++;
                                backupItem = backupItem.Substring(0, backupItem.Length - 1) + count;
                            }
                        }
                        Directory.Move(dir, backupItem);
                        IOWorks.WebSite.WriteLog("User[" + op + "] Delete[" + path + "] to Backup[" + backupItem.Substring(rootPath.Length) + "]");
                        return true;
                    }
                    else if (Directory.Exists(pot))
                    {
                        backupItem += "\\" + pot.Substring(pot.LastIndexOf('\\') + 1);
                        if (Directory.Exists(backupItem))
                        {
                            backupItem += "-" + count;
                            while (Directory.Exists(backupItem))
                            {
                                count++;
                                backupItem = backupItem.Substring(0, backupItem.Length - 1) + count;
                            }
                        }
                        Directory.Move(pot, backupItem);
                        IOWorks.WebSite.WriteLog("User[" + op + "] Delete[" + path + "] to Backup[" + backupItem.Substring(rootPath.Length) + "]");
                        return true;
                    }
                    return false;
                }


                //private static string DEPOT_IMAGE_DIRNAME = "Images";
                public static string DEPOT_DBDETAIL_NAME = "DB_Detail.txt";
                public static string DEPOT_DB_NAME = "DB.txt";
                public static string GetDBDetailFullPath(string relatePath, bool giveShadow)
                {
                    string target = Storage.PATH_DEPOT_ROOT + "\\" + relatePath;
                    while (target.EndsWith("\\")) target = target.Substring(0, target.Length - 1);
                    target = target.Substring(0, target.LastIndexOf('\\')) + "\\" + Storage.PREFIX_DEPOT_IO + target.Substring(target.LastIndexOf("\\") + 1);
                    if (!Directory.Exists(target)) return null;
                    target += "\\" + DEPOT_DBDETAIL_NAME;
                    if (!File.Exists(target) && !giveShadow) return null;
                    return target;
                }
                public static string GetDBFullPath(string relatePath, bool giveShadow)
                {
                    string target = Storage.PATH_DEPOT_ROOT + "\\" + relatePath;
                    while (target.EndsWith("\\")) target = target.Substring(0, target.Length - 1);
                    target = target.Substring(0, target.LastIndexOf('\\')) + "\\" + Storage.PREFIX_DEPOT_IO + target.Substring(target.LastIndexOf("\\") + 1);
                    if (!Directory.Exists(target)) return null;
                    target += "\\" + DEPOT_DB_NAME;
                    if (!File.Exists(target) && !giveShadow) return null;
                    return target;
                }
                public static string GetDBImageDirPath(string relatePath, bool giveShadow)
                {
                    //string imagePath = GetDBFullPath(relatePath, false);
                    //if (imagePath == null) return null;
                    //while (imagePath.EndsWith("\\")) imagePath = imagePath.Substring(0, imagePath.Length - 1);
                    //imagePath = imagePath.Substring(0, imagePath.LastIndexOf('\\'));
                    //imagePath = imagePath + "\\" + DEPOT_IMAGE_DIRNAME;
                    //if (!Directory.Exists(imagePath))
                    //{
                    //    if (!giveShadow) return null;
                    //    Directory.CreateDirectory(imagePath);
                    //}
                    return Storage.PATH_DEPOT_ROOT + "Images";
                }

                public static string PATH_DIR_BACKUP
                {
                    get
                    {
                        string result = Storage.PATH_DEPOT_ROOT + ".backup";
                        if (!Directory.Exists(result)) Directory.CreateDirectory(result);
                        return result;
                    }
                }
            }

            private DataProcessing.Depot _data;
            public DataProcessing.Depot data
            {
                get { return _data; }
            }
            public Depot(string relatePath, string op)
            {
                string depotIOContent = Load_Depot(relatePath, op);
                _data = new DataProcessing.Depot(depotIOContent);
            }


            public static bool SaveDepotDetail(string path, DataProcessing.Depot.Detail detail)
            {
                string target = Storage.GetDBDetailFullPath(path, true);
                if (target == null) return false;
                if (detail.creater == null || detail.creater.Length == 0 || detail.modifier == null || detail.modifier.Length == 0)
                {
                    return false;
                }
                string orgIOContent = "";
                if (!File.Exists(target))
                {
                    StreamWriter sw = File.CreateText(target);
                    sw.Close();
                }
                else orgIOContent = File.ReadAllText(target);
                DataProcessing.Depot.Detail helper = new DataProcessing.Depot.Detail();
                helper.IOContent = orgIOContent;
                if (helper.title == null || helper.title.Length == 0) helper.title = detail.title;
                helper.remark = detail.remark;
                if (helper.creater == null || helper.creater.Length == 0) helper.creater = detail.creater;
                if (helper.createTime == null || helper.createTime == new DateTime()) helper.createTime = detail.createTime;
                helper.modifier = detail.modifier;
                helper.modifyTime = detail.modifyTime;
                File.WriteAllText(target, helper.IOContent);
                return true;
            }
            public static List<string> LoadDepotDetail(string path)
            {
                string target = Storage.GetDBDetailFullPath(path, false);
                if (target == null) return null;
                DataProcessing.Depot.Detail helper = new DataProcessing.Depot.Detail();
                helper.IOContent = File.ReadAllText(target);
                return helper.LineContent;
            }
            public static bool Save_Depot(string path, string ioContent_subjects, string op)
            {
                string target = Storage.GetDBFullPath(path, true);
                if (target == null) return false;
                string depotRoot = Storage.PATH_DEPOT_ROOT;
                if (File.Exists(target))
                {
                    string backPath = Storage.PATH_DIR_BACKUP;
                    while (target.Contains("\\\\")) target = target.Replace("\\\\", "\\");
                    string depotRelat = target.Substring(depotRoot.Length).Replace("\\", " @ ");
                    depotRelat = depotRelat.Substring(0, depotRelat.LastIndexOf(Storage.DEPOT_DB_NAME) - 3);
                    int count = 0;
                    string backupItem = backPath + "\\" + Storage.DEPOT_DB_NAME + depotRelat + " -" + count;
                    while (File.Exists(backupItem))
                    {
                        count++;
                        backupItem = backPath + "\\" + Storage.DEPOT_DB_NAME + depotRelat + " -" + count;
                    }
                    File.Move(target, backupItem);
                    IOWorks.WebSite.WriteLog("User[" + op + "] moveOldDDB[" + target.Substring(depotRoot.Length) + "] toBackup[" + backupItem.Substring(depotRoot.Length) + "]");
                }
                StreamWriter sw = File.AppendText(target);
                DataProcessing.Depot depot = new DataProcessing.Depot(ioContent_subjects);
                for (int i = 0; i < depot.subjects.Count; i++)
                {
                    sw.WriteLine(depot.subjects[i].IOContent);
                }
                sw.Flush();
                sw.Close();
                DataProcessing.Depot.Detail header = new DataProcessing.Depot.Detail();
                header.LineContent = LoadDepotDetail(path);
                if (header.creater == null || header.creater.Length == 0)
                {
                    header.creater = op;
                    header.createTime = DateTime.Now;
                }
                header.modifyTime = DateTime.Now;
                header.modifier = op;
                SaveDepotDetail(path, header);
                IOWorks.WebSite.WriteLog("User[" + op + "] savedDB[" + target.Substring(depotRoot.Length) + "]");
                return true;
            }
            //public static bool AppendDepot(string path, List<List<List<string>>> content, string op)
            //{
            //    string target = GetDBFullPath(path, true);
            //    if (target == null) return false;
            //    StreamWriter sw;
            //    if (!File.Exists(target)) sw = File.CreateText(target);
            //    else sw = File.AppendText(target);
            //    Subject helper;
            //    for (int i = 0; i < content.Count; i++)
            //    {
            //        helper = new Subject(content[i]);
            //        sw.WriteLine(helper.IOContent);
            //    }
            //    sw.Flush();
            //    sw.Close();
            //    return true;
            //}
            public static string Load_Depot(string path, string op)
            {
                string target = IOWorks.Depot.Storage.GetDBFullPath(path, true);
                if (target == null) return null;
                if (!File.Exists(target))
                {
                    StreamWriter sw = File.CreateText(target);
                    sw.Close();
                }
                string result = "";
                string[] dbLines = File.ReadAllLines(target);
                string line;
                DataProcessing.Depot depot = new DataProcessing.Depot();
                for (int i = 0; i < dbLines.Length; i++)
                {
                    line = dbLines[i];
                    if (line.Length == 0) continue;
                    depot.subjects.Add(new DataProcessing.Depot.Subject(line));
                }
                result = depot.IOContent_Subjects;
                IOWorks.WebSite.WriteLog("User[" + op + "] loadDepot[" + target.Substring(Storage.PATH_DEPOT_ROOT.Length) + "]");
                return result;
            }

            public static bool Drop_Depot(string path, string op)
            {
                string target = IOWorks.Depot.Storage.GetDBFullPath(path, false);
                if (target == null) return false;
                string backItem = IOWorks.Depot.Storage.PATH_DIR_BACKUP + "\\" + target.Substring(target.LastIndexOf('\\') + 1);
                int count = 1;
                if (Directory.Exists(backItem))
                {
                    backItem += "-" + count;
                    while (Directory.Exists(backItem))
                    {
                        count++;
                        backItem = backItem.Substring(0, backItem.LastIndexOf('-') + 1) + count;
                    }
                }
                Directory.Move(target, backItem);
                string depotRoot = Storage.PATH_DEPOT_ROOT;
                IOWorks.WebSite.WriteLog("User[" + op + "] DelDepot[" + target.Substring(depotRoot.Length) + "] toBackup[" + backItem.Substring(depotRoot.Length) + "]");
                return true;
            }

            public static bool Save_DepotImage(string fileName, byte[] data, bool isAppend, string op)
            {
                string imagePath = Storage.PATH_DEPOT_ROOT + "Images";
                if (!Directory.Exists(imagePath)) Directory.CreateDirectory(imagePath);
                string fileFullName = imagePath + "\\" + fileName;

                FileStream writer;
                int offSet = 0;
                if (!isAppend && File.Exists(fileFullName)) File.Delete(fileFullName);
                if (isAppend)
                {
                    offSet = (int)new FileInfo(fileFullName).Length - 1;
                    writer = new FileStream(fileFullName, FileMode.Append, FileAccess.Write, FileShare.None);
                }
                else writer = new FileStream(fileFullName, FileMode.CreateNew, FileAccess.Write, FileShare.None);
                //if (isAppend) writer.Write(data, offSet, data.Length);
                //else writer.Write(data, 0, data.Length);
                writer.Write(data, 0, data.Length);
                writer.Close();
                IOWorks.WebSite.WriteLog("User[" + op + "] upload Image[" + fileName + "]");
                return true;
            }
            public static List<string> Get_DepotImageList()
            {
                //string imagePath = GetDBImageDirPath(relatePath, false);
                string imagePath = Storage.PATH_DEPOT_ROOT + "Images";
                List<string> result = new List<string>();
                //if (imagePath == null) return result;
                DirectoryInfo dirInfo = new DirectoryInfo(imagePath);
                foreach (FileInfo file in dirInfo.GetFiles())
                {
                    result.Add(file.Name);
                }
                return result;
            }

        }

        public class AuditPaper
        {
            private static List<string> GetAllExamerList()
            {
                List<string> result = new List<string>();
                string hallRootPath = IOWorks.ExamHall.IO_ROOT_PATH;
                DirectoryInfo hallRoot = new DirectoryInfo(hallRootPath);
                foreach (DirectoryInfo hall in hallRoot.GetDirectories())
                {
                    foreach (DirectoryInfo user in hall.GetDirectories())
                    {
                        result.Add(HttpUtility.UrlDecode(user.FullName.Substring(hallRootPath.Length + 1)));
                    }
                }
                return result;
            }
            public static List<string> GetMyExamerList(string op)
            {
                List<string> iId = new List<string>(); iId.Add(op);
                DataProcessing.UserRegister.UserInfo im = IOWorks.UserRegister.UserInfo.GetUsers(iId)[0];
                if (!im.couldAuditPaper) return null;
                string[] myAuditPathes = im.auditOrgPathList();

                List<string> myExamers = GetAllExamerList();
                List<string> allExamersId = new List<string>();
                foreach (string examer in myExamers)
                {
                    allExamersId.Add(examer);
                }
                List<DataProcessing.UserRegister.UserInfo> outExamers = IOWorks.UserRegister.UserInfo.GetUsers(allExamersId);
                if (myAuditPathes != null && myAuditPathes.Length != 0)
                {
                    bool userIn;
                    for (int i = outExamers.Count - 1; i >= 0; i--)
                    {
                        userIn = false;
                        foreach (string path in myAuditPathes)
                        {
                            if (path.Length > 0 && outExamers[i].orgPath.StartsWith(path))
                            {
                                userIn = true;
                                break;
                            }
                        }
                        if (userIn)
                        {
                            outExamers.RemoveAt(i);
                        }
                    }
                    for (int i = myExamers.Count - 1; i >= 0; i--)
                    {
                        foreach (DataProcessing.UserRegister.UserInfo outUser in outExamers)
                        {
                            if (myExamers[i].EndsWith("\\" + HttpUtility.UrlEncode(outUser.id)))
                            {
                                myExamers.RemoveAt(i);
                                break;
                            }
                        }
                    }
                }
                for (int i = myExamers.Count - 1; i >= 0; i--)
                {
                    string[] parts = myExamers[i].Split(new string[] { "\\" }, StringSplitOptions.RemoveEmptyEntries);
                    DataProcessing.ExamHall.UserExam.Info examInfo = new IOWorks.ExamHall.UserExam.Info(parts[0], parts[1]).data;
                    if (examInfo.isAudited)
                    {
                        myExamers.RemoveAt(i);
                        break;
                    }
                }
                return myExamers;
            }

            public static void Auditing_Set(string op, string examerPath)
            {
                AuditingRecord(op, examerPath, true);
            }
            public static void Auditing_Drop(string op, string examerPath)
            {
                AuditingRecord(op, examerPath, false);
            }

            public static string IO_AUDIT_REGFILE_FULLPATH
            {
                get
                {
                    return IOWorks.WebSite.Path_App_Data + "\\AuditingList.txt";
                }
            }
            private static void AuditingRecord(string op, string examerPath, bool isSet)
            {
                string ioFileFullName = IO_AUDIT_REGFILE_FULLPATH;
                if (!File.Exists(ioFileFullName)) File.WriteAllText(ioFileFullName, "");
                DataProcessing.AuditPaper.AuditingItem helper = new DataProcessing.AuditPaper.AuditingItem();
                string[] recs = File.ReadAllLines(ioFileFullName);
                bool auditingFound = false;
                for (int i = recs.Length - 1; i >= 0; i--)
                {
                    helper.IOContent = recs[i];
                    if (helper.op == op && helper.examerPath == examerPath)
                    {
                        auditingFound = true;
                        if (isSet) return;
                        else recs[i] = "";
                    }
                }
                List<string> newIOContentLines = new List<string>();
                if (!auditingFound && isSet)
                {
                    helper.op = op;
                    helper.examerPath = examerPath;
                    newIOContentLines.Add(helper.IOContent);
                }
                foreach (string rec in recs)
                {
                    if (rec.Length > 0) newIOContentLines.Add(rec);
                }
                string ioContent = "";
                foreach (string line in newIOContentLines)
                {
                    if (ioContent.Length > 0) ioContent += "\r\n";
                    ioContent += line;
                }
                File.WriteAllText(ioFileFullName, ioContent);
            }

            public static List<string> GetMyAuditingExamerList(string op)
            {
                List<string> result = new List<string>();
                string fileFName = IO_AUDIT_REGFILE_FULLPATH;
                if (!File.Exists(fileFName)) return result;
                string[] recs = File.ReadAllLines(fileFName);
                DataProcessing.AuditPaper.AuditingItem helper = new DataProcessing.AuditPaper.AuditingItem();
                foreach (string rec in recs)
                {
                    helper.IOContent = rec;
                    if (helper.op == op) result.Add(helper.examerPath);
                }
                return result;
            }

            public static void Auditing_SetComplete(string op, string examerPath)
            {
                Auditing_Drop(op, examerPath);
                string[] parts = examerPath.Split(new string[] { "\\" }, StringSplitOptions.RemoveEmptyEntries);
                IOWorks.ExamHall.UserExam.Info ueInfoOper = new IOWorks.ExamHall.UserExam.Info(parts[0], parts[1]);
                DataProcessing.ExamHall.UserExam.Info ueInfo = ueInfoOper.data;
                ueInfo.isAudited = true;
                ueInfoOper.data = ueInfo;
                ueInfoOper.Save();
            }

        }

        public class Announcement
        {
            public static string PATH_ANNOUNCEMENT_ROOT
            {
                get
                {
                    string rootPath = AppDomain.CurrentDomain.BaseDirectory + "\\App_Data\\Announcements";
                    rootPath = rootPath.Replace("\\\\", "\\");
                    if (!Directory.Exists(rootPath)) Directory.CreateDirectory(rootPath);
                    return rootPath;
                }
            }
            public static string PATH_ANNOUNCEMENT_ROOT_BACKUP
            {
                get
                {
                    return PATH_ANNOUNCEMENT_ROOT + ".backup";
                }
            }
            private static DirectoryInfo ROOT_DIR_INFO
            {
                get
                {
                    List<DataProcessing.Announcement.Info> result = new List<DataProcessing.Announcement.Info>();
                    DirectoryInfo dirRoot = new DirectoryInfo(PATH_ANNOUNCEMENT_ROOT);
                    return dirRoot;
                }
            }
            public static string Get_AnnouncementPath(string announcementName)
            {
                return PATH_ANNOUNCEMENT_ROOT + "//" + HttpUtility.UrlEncode(announcementName);
            }
            public static string CheckExists_AndReturn_AnnouncementPath(string announcementName, bool checkNotExist)
            {
                string anumPath = Get_AnnouncementPath(announcementName);
                if (Directory.Exists(anumPath))
                {
                    if (checkNotExist)
                    {
                        throw new Exception("This Announcement [" + announcementName + "] is already exists!");
                    }
                }
                else
                {
                    if (!checkNotExist)
                    {
                        throw new Exception("This Announcement [" + announcementName + "] is not exists!");
                    }
                }
                return anumPath;
            }
            public static string Get_UserData_FileFullName(string anumName, string op)
            {
                string userDataPath = Get_AnnouncementPath(anumName) + "\\" + DIRNAME_USERDATA;
                if (!Directory.Exists(userDataPath)) Directory.CreateDirectory(userDataPath);
                return userDataPath + "\\" + HttpUtility.UrlEncode(op) + ".txt";
            }

            public static string FILENAME_INFO = "info.txt";
            public static string FILENAME_INVITION_LIST = "invitionList.txt";
            public static string FILENAME_CONTENT = "content.txt";
            public static string DIRNAME_USERDATA = "UserData";

            public static bool CheckExists(string op, string announcementName)
            {
                try
                {
                    CheckExists_AndReturn_AnnouncementPath(announcementName, false);
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }
            public static void Create(string op, string announcementName)
            {
                _Create_Info(op, announcementName);
            }

            public static void Modify(string modifier, string announcementName, DateTime startTime, DateTime endTime)
            {
                string dirPath = CheckExists_AndReturn_AnnouncementPath(announcementName, false);

                DataProcessing.Announcement.Info info = new DataProcessing.Announcement.Info();
                info.IOContent = File.ReadAllText(dirPath + "\\" + FILENAME_INFO);
                info.modifier = modifier;
                info.modifyTime = DateTime.Now;
                info.startTime = startTime;
                info.endTime = endTime;
                File.WriteAllText(dirPath + "\\" + FILENAME_INFO, info.IOContent);
            }
            public static void Modify(string modifier, string announcementName, DataProcessing.Announcement.Content content)
            {
                _Set_Content(announcementName, content);
                _Modify_Info(modifier, announcementName);
            }
            public static void Modify(string modifier, string announcementName, DataProcessing.Announcement.InvitedUserList invitionList)
            {
                _Set_InvitionList(announcementName, invitionList);
                _Modify_Info(modifier, announcementName);
            }
            public static void Publish(string opOrModifier, string announcementName)
            {
                string dirPath = CheckExists_AndReturn_AnnouncementPath(announcementName, false);
                DataProcessing.Announcement.Info info = new DataProcessing.Announcement.Info();
                info.IOContent = File.ReadAllText(dirPath + "\\" + FILENAME_INFO);
                info.modifier = opOrModifier;
                info.publicTime = DateTime.Now;
                File.WriteAllText(dirPath + "\\" + FILENAME_INFO, info.IOContent);
            }

            private static void _Create_Info(string op, string announcementName)
            {
                string dirPath = CheckExists_AndReturn_AnnouncementPath(announcementName, true);
                Directory.CreateDirectory(dirPath);

                DataProcessing.Announcement.Info info = new DataProcessing.Announcement.Info();
                info.op = op;
                info.name = announcementName;
                info.publicTime = info.modifyTime = info.createTime = DateTime.Now;
                info.startTime = info.createTime.AddDays(7.0);
                info.endTime = info.startTime.AddDays(7.0);
                File.WriteAllText(dirPath + "\\" + FILENAME_INFO, info.IOContent);
            }
            private static void _Modify_Info(string modifier, string announcementName)
            {
                string dirPath = CheckExists_AndReturn_AnnouncementPath(announcementName, false);

                DataProcessing.Announcement.Info info = new DataProcessing.Announcement.Info();
                info.IOContent = File.ReadAllText(dirPath + "\\" + FILENAME_INFO);
                info.modifier = modifier;
                info.modifyTime = DateTime.Now;
                File.WriteAllText(dirPath + "\\" + FILENAME_INFO, info.IOContent);
            }
            private static void _Set_InvitionList(string announcementName, DataProcessing.Announcement.InvitedUserList invitionList)
            {
                string anumPath = Get_AnnouncementPath(announcementName);
                if (!Directory.Exists(anumPath)) Directory.CreateDirectory(anumPath);
                File.WriteAllText(anumPath + "\\" + FILENAME_INVITION_LIST, invitionList.IOContent);
            }
            private static void _Set_Content(string announcementName, DataProcessing.Announcement.Content content)
            {
                string anumPath = Get_AnnouncementPath(announcementName);
                if (!Directory.Exists(anumPath)) Directory.CreateDirectory(anumPath);
                File.WriteAllText(anumPath + "\\" + FILENAME_CONTENT, content.IOContent);
            }
            private static void _Save_UserAnumPaper(string announcementName, string op, DataProcessing.ExamHall.UserExam.UserPaper userData)
            {
                File.WriteAllText(Get_UserData_FileFullName(announcementName, op), userData.IOContent);
            }

            public static DataProcessing.Announcement.Info Load_Info(string announcementName)
            {
                string anumPath = CheckExists_AndReturn_AnnouncementPath(announcementName, false);
                DataProcessing.Announcement.Info result = new DataProcessing.Announcement.Info();
                string filePath = anumPath + "\\" + FILENAME_INFO;
                if (File.Exists(filePath))
                {
                    result.IOContent = File.ReadAllText(filePath);
                    return result;
                }
                return null;
            }
            public static DataProcessing.Announcement.InvitedUserList Load_InvitionList(string announcementName)
            {
                string anumPath = CheckExists_AndReturn_AnnouncementPath(announcementName, false);
                DataProcessing.Announcement.InvitedUserList result = new DataProcessing.Announcement.InvitedUserList();
                string filePath = anumPath + "\\" + FILENAME_INVITION_LIST;
                if (File.Exists(filePath))
                {
                    result.IOContent = File.ReadAllText(filePath);
                }
                return result;
            }
            public static DataProcessing.Announcement.Content Load_Content(string announcementName)
            {
                string anumPath = CheckExists_AndReturn_AnnouncementPath(announcementName, false);
                DataProcessing.Announcement.Content result = new DataProcessing.Announcement.Content();
                string filePath = anumPath + "\\" + FILENAME_CONTENT;
                if (File.Exists(filePath))
                {
                    result.IOContent = File.ReadAllText(filePath);
                }
                return result;
            }
            public static DataProcessing.ExamHall.UserExam.UserPaper Load_MyAnnouncementPaper(string op, string anumName)
            {
                DataProcessing.ExamHall.UserExam.UserPaper result = new DataProcessing.ExamHall.UserExam.UserPaper();
                string paperFileFullName = Get_UserData_FileFullName(anumName, op);
                if (File.Exists(paperFileFullName))
                {
                    result.IOContent = File.ReadAllText(paperFileFullName);
                }
                else
                {
                    DataProcessing.Announcement.Content paperContent = Load_Content(anumName);
                    for (int i = 0; i < paperContent.paperContent.Count; i++)
                    {
                        result.elements.Add(new DataProcessing.ExamHall.UserExam.UserPaper.Element(paperContent.paperContent[i], null));
                    }
                }
                return result;
            }

            public static bool Check_AnnouncementVoted(string op, string anouName)
            {
                return File.Exists(Get_UserData_FileFullName(anouName, op));
            }

            public static void User_Submit(string op, string annoucementName, DataProcessing.ExamHall.UserExam.UserPaper userData)
            {
                if (Check_AnnouncementVoted(op, annoucementName))
                {
                    throw new Exception("Annoucement[" + annoucementName + "] for User[" + op + "] is Already Voted!");
                }
                _Save_UserAnumPaper(annoucementName, op, userData);
                DataProcessing.Announcement.InvitedUserList invitationsDataHelper = Load_InvitionList(annoucementName);
                List<DataProcessing.Announcement.InvitedUserList.Invitation> invitations = invitationsDataHelper.data;
                DataProcessing.Announcement.InvitedUserList.Invitation oneInvitation;
                for (int i = invitations.Count - 1; i >= 0; i--)
                {
                    oneInvitation = invitations[i];
                    if (oneInvitation.userId == op)
                    {
                        oneInvitation.isVoted = true;
                        invitations[i] = oneInvitation;
                        break;
                    }
                }
                invitationsDataHelper.data = invitations;
                _Set_InvitionList(annoucementName, invitationsDataHelper);
            }

            public static void Drop(string op, string announcementName)
            {
                string anumPath = CheckExists_AndReturn_AnnouncementPath(announcementName, false);
                DataProcessing.Announcement.Info info = Load_Info(announcementName);
                if (info.isPublished && info.publicTime >= DateTime.Now)
                {
                    throw new Exception("This Announcement is Distributed, Can Not Be Dropped Now!");
                }
                string backFullPath = PATH_ANNOUNCEMENT_ROOT_BACKUP + "\\" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + "_" + HttpUtility.UrlEncode(announcementName);
                Directory.Move(anumPath, backFullPath);
            }

            // 信息统计

            public static List<DataProcessing.Announcement.Info> Get_AllAnnouncementInfo(string op)
            {
                List<DataProcessing.Announcement.Info> result = new List<DataProcessing.Announcement.Info>();
                foreach (DirectoryInfo anumDir in ROOT_DIR_INFO.GetDirectories())
                {
                    result.Add(Load_Info(HttpUtility.UrlDecode(anumDir.Name)));
                }
                return result;
            }

            public static List<DataProcessing.Announcement.Info> Get_AllMyAnnouncementInfo(string op)
            {
                List<DataProcessing.Announcement.Info> result = new List<DataProcessing.Announcement.Info>();
                string anumName;
                DataProcessing.Announcement.InvitedUserList invitation;
                foreach (DirectoryInfo anumDir in ROOT_DIR_INFO.GetDirectories())
                {
                    anumName = HttpUtility.UrlDecode(anumDir.Name);
                    invitation = Load_InvitionList(anumName);
                    foreach (DataProcessing.Announcement.InvitedUserList.Invitation ivt in invitation.data)
                    {
                        if (ivt.userId == op)
                        {
                            result.Add(Load_Info(anumName));
                            break;
                        }
                    }
                }
                return result;
            }
            public static List<string> Get_AllMyHadVotedAnumNames(string op)
            {
                string anumName;
                List<string> result = new List<string>();
                DataProcessing.Announcement.InvitedUserList invitation;
                foreach (DirectoryInfo anumDir in ROOT_DIR_INFO.GetDirectories())
                {
                    anumName = HttpUtility.UrlDecode(anumDir.Name);
                    invitation = Load_InvitionList(anumName);
                    DataProcessing.Announcement.InvitedUserList.Invitation ivt;
                    for (int i = invitation.data.Count - 1; i >= 0; i--)
                    {
                        ivt = invitation.data[i];
                        if (ivt.userId == op && ivt.isVoted)
                        {
                            result.Add(anumName);
                            break;
                        }
                    }
                }
                return result;
            }

            public static bool Check_HaveAnums2Vote(string op)
            {
                DataProcessing.Announcement.InvitedUserList invitations;
                DataProcessing.Announcement.InvitedUserList.Invitation ivt;
                DataProcessing.Announcement.Info info;
                string anumName;
                foreach (DirectoryInfo anumDir in ROOT_DIR_INFO.GetDirectories())
                {
                    anumName = HttpUtility.UrlDecode(anumDir.Name);
                    info = Load_Info(anumName);
                    if (!info.isPublished || info.isDated || !info.isStart) continue;
                    invitations = Load_InvitionList(anumName);
                    for (int i = invitations.data.Count - 1; i >= 0; i--)
                    {
                        ivt = invitations.data[i];
                        if (ivt.userId == op && !ivt.isVoted)
                        {
                            return true;
                        }
                    }
                }
                return false;
            }

        }
    }
}
