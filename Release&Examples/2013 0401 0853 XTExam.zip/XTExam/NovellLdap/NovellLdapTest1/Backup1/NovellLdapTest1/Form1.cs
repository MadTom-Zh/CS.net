﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Novell.Directory.Ldap;
using Novell.Directory.Ldap.Utilclass;

namespace NovellLdapTest1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //if (args.Length != 5)
            //{
            //    Console.Error.WriteLine("Usage:   mono List <host name> <login dn>"
            //        + " <password> <search base>\n"
            //        + "         <search filter>");
            //    Console.Error.WriteLine("Example: mono List Acme.com \"cn=admin,o=Acme\""
            //        + " secret \"ou=sales,o=Acme\"\n"
            //        + "         \"(objectclass=*)\"");
            //    Environment.Exit(1);
            //}

            int LdapPort = LdapConnection.DEFAULT_PORT;
            int searchScope = LdapConnection.SCOPE_ONE;
            int LdapVersion = LdapConnection.Ldap_V3;
            LdapConnection lc = new LdapConnection();

            bool attributeOnly = true;
            String[] attrs = { LdapConnection.NO_ATTRS };
            String ldapHost = txt_Host.Text;
            String loginDN = txt_Dn.Text;
            String password = txt_Pswd.Text;
            String searchBase = txt_SerchBase.Text;
            String searchFilter = txt_SearchFilter.Text;
            

            try
            {
                // connect to the server
                lc.Connect(ldapHost, LdapPort);
                // bind to the server
                lc.Bind(LdapVersion, loginDN, password);

                LdapSearchResults searchResults =
                    lc.Search(searchBase,      // container to search
                    searchScope,     // search scope
                    searchFilter,    // search filter
                    attrs,           // "1.1" returns entry name only
                    attributeOnly);  // no attributes are returned

                // print out all the objects
                while (searchResults.hasMore())
                {
                    LdapEntry nextEntry = null;
                    try
                    {
                        nextEntry = searchResults.next();

                        
                    }
                    catch (LdapException ex)
                    {
                        Console.WriteLine("Error: " + ex.ToString());

                        // Exception is thrown, go for next entry
                    }

                    //Console.WriteLine("\n" + nextEntry.DN + nextEntry.getAttribute("fullNamevalue").ToString());
                    Console.WriteLine("\n" + nextEntry.DN );
                    LdapAttributeSet attributeSet = nextEntry.getAttributeSet();
                    System.Collections.IEnumerator ienum = attributeSet.GetEnumerator();
                    while (ienum.MoveNext())
                    {
                        LdapAttribute attribute = (LdapAttribute)ienum.Current;
                        string attributeName = attribute.Name;
                        string attributeVal = attribute.StringValue;
                        //if(!Base64.isLDIFSafe(attributeVal))
                        //{
                        //    byte[] tbyte=SupportClass.ToByteArray(attributeVal);
                        //    attributeVal=Base64.encode(SupportClass.ToSByteArray(tbyte));
                        //}
                        Console.WriteLine(attributeName + "value:" + attributeVal);
                    }
                }
                // disconnect with the server
                lc.Disconnect();
            }
            catch (LdapException e1)
            {
                Console.WriteLine("Error: " + e1.ToString());
            }
            catch (Exception e2)
            {
                Console.WriteLine("Error: " + e2.ToString());
            }
            //Environment.Exit(0);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int LdapPort = LdapConnection.DEFAULT_PORT;
            //int searchScope = LdapConnection.SCOPE_SUB;
            //int LdapVersion = LdapConnection.Ldap_V3; ;
            //bool attributeOnly = true;
            String[] attrs = { LdapConnection.NO_ATTRS };
            String ldapHost = txt_Host.Text;
            String loginDN = txt_Dn.Text;
            String password = txt_Pswd.Text;
            String searchBase = txt_SerchBase.Text;
            String searchFilter = txt_SearchFilter.Text;
            //LdapConnection lc = new LdapConnection();

            try
            {
                LdapConnection conn = new LdapConnection();
                Console.WriteLine("Connecting to:" + ldapHost);
                conn.Connect(ldapHost, LdapPort);
                conn.Bind(loginDN, password);
                LdapSearchResults lsc = conn.Search(searchBase,
                                                    LdapConnection.SCOPE_SUB,
                                                    searchFilter,
                                                    null,
                                                    false);

                while (lsc.hasMore())
                {
                    LdapEntry nextEntry = null;
                    try
                    {
                        nextEntry = lsc.next();
                    }
                    catch (LdapException e1)
                    {
                        Console.WriteLine("Error: " + e1.LdapErrorMessage);
                        // Exception is thrown, go for next entry
                        continue;
                    }
                    Console.WriteLine("\n" + nextEntry.DN);
                    LdapAttributeSet attributeSet = nextEntry.getAttributeSet();
                    System.Collections.IEnumerator ienum = attributeSet.GetEnumerator();
                    while (ienum.MoveNext())
                    {
                        LdapAttribute attribute = (LdapAttribute)ienum.Current;

                        string attributeName = attribute.Name;
                        string attributeVal = attribute.StringValue;
                        //if(!Base64.isLDIFSafe(attributeVal))
                        //{
                        //    byte[] tbyte=SupportClass.ToByteArray(attributeVal);
                        //    attributeVal=Base64.encode(SupportClass.ToSByteArray(tbyte));
                        //}
                        Console.WriteLine(attributeName + "value:" + attributeVal);
                    }
                }
                conn.Disconnect();
            }
            catch (LdapException e2)
            {
                Console.WriteLine("Error:" + e2.LdapErrorMessage);
                return;
            }
            catch (Exception e3)
            {
                Console.WriteLine("Error:" + e3.Message);
                return;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int LdapPort = LdapConnection.DEFAULT_PORT;
            //int searchScope = LdapConnection.SCOPE_SUB;
            //int LdapVersion = LdapConnection.Ldap_V3; ;
            //bool attributeOnly = true;
            String[] attrs = { LdapConnection.NO_ATTRS };
            String ldapHost = txt_Host.Text;
            String loginDN = txt_Dn.Text;
            String password = txt_Pswd.Text;
            String searchBase = txt_SerchBase.Text;
            String searchFilter = txt_SearchFilter.Text;
            //LdapConnection lc = new LdapConnection();
            try
            {
                LdapConnection conn = new LdapConnection();
                Console.WriteLine("Connecting to:" + ldapHost);
                conn.Connect(ldapHost, LdapPort);
                conn.Bind(loginDN, password);
                LdapSchema dirschema = conn.FetchSchema(conn.GetSchemaDN());
                LdapSearchResults lsc = conn.Search(searchBase,
                    LdapConnection.SCOPE_ONE,
                    searchFilter,
                    null,
                    false);
                while (lsc.hasMore())
                {
                    LdapEntry nextEntry = null;
                    try
                    {
                        nextEntry = lsc.next();
                    }
                    catch (LdapException e1)
                    {
                        Console.WriteLine("Error: " + e1.LdapErrorMessage);
                        // Exception is thrown, go for next entry
                        continue;
                    }
                    Console.WriteLine("\n\n\n");
                    Console.WriteLine("\n" + nextEntry.DN);
                    LdapAttributeSet attributeSet = nextEntry.getAttributeSet();
                    System.Collections.IEnumerator ienum = attributeSet.GetEnumerator();
                    while (ienum.MoveNext())
                    {
                        LdapAttribute attribute = (LdapAttribute)ienum.Current;
                        string attributeName = attribute.Name;
                        Console.WriteLine(attributeName + ":  " + dirschema.getAttributeSchema(attributeName).ToString());
                    }
                }
                conn.Disconnect();
            }
            catch (LdapException ex)
            {
                Console.WriteLine("Error:" + ex.LdapErrorMessage);
                return;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error:" + ex.Message);
                return;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

            LdapConnection conn = new LdapConnection();

            int ldapPort = LdapConnection.DEFAULT_PORT;
            //int searchScope = LdapConnection.SCOPE_SUB;
            int ldapVersion = LdapConnection.Ldap_V3; 
            //bool attributeOnly = true;
            String[] attrs = { LdapConnection.NO_ATTRS };
            String ldapHost = txt_Host.Text;
            String loginDN = txt_Dn.Text;
            String password = txt_Pswd.Text;
            String searchBase = txt_SerchBase.Text;
            String searchFilter = txt_SearchFilter.Text;

            try
            {
                // connect to the server
                conn.Connect(ldapHost, ldapPort);

                // authenticate to the server
                conn.Bind(ldapVersion, loginDN, password);

                LdapAttribute attr = new LdapAttribute("userPassword", this.textBox1.Text);
                String sss = this.textBox2.Text +"," +searchBase;
                bool correct = conn.Compare(sss, attr);

                System.Console.Out.WriteLine(correct ? "The password is correct." : "The password is incorrect.\n");

                // disconnect with the server
                conn.Disconnect();
            }
            catch (LdapException e1)
            {
                if (e1.ResultCode == LdapException.NO_SUCH_OBJECT)
                {
                    System.Console.Error.WriteLine("Error: No such entry");
                }
                else if (e1.ResultCode == LdapException.NO_SUCH_ATTRIBUTE)
                {
                    System.Console.Error.WriteLine("Error: No such attribute");
                }
                else
                {
                    System.Console.Error.WriteLine("Error: " + e.ToString());
                }
            }
            catch (System.IO.IOException e2)
            {
                System.Console.Out.WriteLine("Error: " + e2.ToString());
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        

        private void button5_Click(object sender, EventArgs e)
        {
            
            String ldapHost = txt_Host.Text;
            String loginDN = txt_Dn.Text;
            String password = txt_Pswd.Text;
            String dn = txt_SerchBase.Text;
            int ldapPort = LdapConnection.DEFAULT_PORT;
            String searchFilter = txt_SearchFilter.Text;

            
                
                
                LdapConnection conn = new LdapConnection();
            try
            {
                
                Console.WriteLine("Connecting to:" + ldapHost);
                conn.Connect(ldapHost, ldapPort);
                conn.Bind(loginDN, password);
                LdapSearchResults lsc = conn.Search(dn,
                                                    LdapConnection.SCOPE_SUB,
                                                    searchFilter,
                                                    null,
                                                    false);

                
                    LdapEntry nextEntry = null;
                    try
                    {
                        nextEntry = lsc.next();
                    }
                    catch (LdapException e1)
                    {
                        Console.WriteLine("Error: " + e1.LdapErrorMessage);
                    }
                    Console.WriteLine("\n" + nextEntry.DN);
                    System.Collections.ArrayList modList = new System.Collections.ArrayList();

                    modList.Add(new LdapAttribute("nxMWAccount", "HQ_aihu-fan"));
                    modList.Add(new LdapAttribute("nxMWLoginEnable", "TRUE"));

                    modList.Add(new LdapAttribute("nxCOAAccount", "HQ_aihu-fan"));

                    modList.Add(new LdapAttribute("nxCOALoginEnable", "TRUE"));
                    modList.Add(new LdapAttribute("COA1LoginEnable", "TRUE"));

                    //modList.Add(new LdapAttribute("nxMWSyncStatus"));
                    modList.Add(new LdapAttribute("nxHRGKLoginEnable", "TRUE"));

                    modList.Add(new LdapAttribute("nxYJZHLoginEnable", "TRUE"));
                    modList.Add(new LdapAttribute("nxSAPEPLoginEnable", "TRUE"));
                    modList.Add(new LdapAttribute("nxYXFZJCLoginEnable", "TRUE"));
                    modList.Add(new LdapAttribute("nxHRFZJCLoginEnable", "TRUE"));
                    modList.Add(new LdapAttribute("nxZHJHLoginEnable", "TRUE"));

                    modList.Add(new LdapAttribute("nxGJHZLoginEnable", "TRUE"));
                    modList.Add(new LdapAttribute("nxSJGLLoginEnable", "TRUE"));
                    modList.Add(new LdapAttribute("nxSCTJLoginEnable", "TRUE"));
                    modList.Add(new LdapAttribute("nxAQJDLoginEnable", "TRUE"));
                    modList.Add(new LdapAttribute("nxDC2LoginEnable", "TRUE"));
                    modList.Add(new LdapAttribute("uid", "HQ_aihu-fan"));
                    modList.Add(new LdapAttribute("nxBIDLoginEnable", "TRUE"));
                    modList.Add(new LdapAttribute("nxTZJHLoginEnable", "TRUE"));

                    LdapAttributeSet attributeSet = nextEntry.getAttributeSet();

                    for (int i = 0; i < modList.Count; i++)
                    {
                        String name = ((LdapAttribute)modList[i]).Name;
                        LdapAttribute attribute = attributeSet.getAttribute(name);

                        if (attribute != null)
                        {
                            conn.Modify(dn, new LdapModification(LdapModification.REPLACE,(LdapAttribute)modList[i]));
                            Console.WriteLine(" Entry: " + dn + ":" + name + "Modified REPLACE Successfully");
                        }else
                        {
                            conn.Modify(dn, new LdapModification(LdapModification.ADD,(LdapAttribute)modList[i]));
                            Console.WriteLine(" Entry: " + dn + ":" + name + "Modified ADD Successfully");
                        }
                    }
                       
                    Console.WriteLine(" Entry: " + dn + "Modified Successfully");
                

            }
            catch (LdapException ex1)
            {
                Console.WriteLine("Error:" + ex1.LdapErrorMessage);
                return;
            }
            catch (Exception ex2)
            {
                Console.WriteLine("Error:" + ex2.Message);
                return;
            }finally
            {
                conn.Disconnect();
            }
        }
    }
}
