﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace NovellLdapTest1
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new FuncTest());

            Application.Run(new Form3());
        }
    }

    //public class Base
    //{
    //    public static Db db;
    //    static Base()
    //    {
    //        string dbconn = AppConfig.GetValue("ConnectionString");
    //        db = new Database(dbconn);
    //    }

    //    public static bool FindTreeNode(TreeNodeCollection nodes, TreeNode find, ref TreeNode result)
    //    {
    //        bool b_result = false;
    //        for (int i = 0; i < nodes.Count; i++)
    //        {
    //            string[] s1 = nodes[i].Value.Split(':');
    //            string[] s2 = find.Value.Split(':');

    //            if (FindTreeNode(nodes[i].ChildNodes, find, ref result)) return true;
    //            if (s1[0].Equals(s2[1]))
    //            {
    //                result = nodes[i];
    //                return true;
    //            }
    //        }


    //        return b_result;
    //    }


    //    public static void TreeView_TXL_Load(ref TreeView TreeView_TXL)
    //    {
    //        TreeView_ZZJG_Load(ref TreeView_TXL);

    //        string SQL = "SELECT ZZJG.JGMC, RYXX.SSJG,RYXX.RYID, RYXX.GWMC || '    ' || RYXX.XM AS RYXX FROM RYXX LEFT OUTER JOIN ZZJG ON RYXX.SSJG = ZZJG.JGID";
    //        string[] cn = new string[] { "RYXX" };
    //        string[,] img = new string[,] { { "6", "6" } };
    //        string[] nodelab = new string[] { "aa" };
    //        TreeNode root = TreeView_TXL.Nodes[0];
    //        TreeNode find = new TreeNode();
    //        DataView dv = Base.db.GetDataView("TXL", SQL, CommandType.Text);
    //        foreach (DataRowView drv in dv)
    //        {
    //            TreeNode treenode = new TreeNode(drv["RYXX"].ToString(), "-1:" + drv["SSJG"].ToString() + ":" + drv["RYID"].ToString());
    //            if (Base.FindTreeNode(root.ChildNodes, treenode, ref find))
    //            {
    //                find.ChildNodes.Add(treenode);
    //            }
    //            else
    //            {
    //                root.ChildNodes.Add(treenode);
    //            }
    //        }
    //    }

    //    public static void TreeView_ZZJG_Load(ref TreeView TreeView_ZZJG)
    //    {
    //        string SQL = "SELECT DISTINCT ZZJG.JGID, ZZJG.JGMC, ZZJG.SJJG FROM RYXX RIGHT OUTER JOIN ZZJG ON ZZJG.JGID = RYXX.SSJG ORDER BY TO_NUMBER(ZZJG.JGID)";
    //        string[] cn = new string[] { "JGMC" };
    //        string[,] img = new string[,] { { "6", "6" } };
    //        string[] nodelab = new string[] { "aa" };
    //        TreeNode root = new TreeNode("通信录", "0:0");
    //        TreeNode find = new TreeNode();
    //        DataView dv = Base.db.GetDataView("ZZJG", SQL, CommandType.Text);
    //        foreach (DataRowView drv in dv)
    //        {
    //            TreeNode treenode = new TreeNode(drv["JGMC"].ToString(), drv["JGID"].ToString() + ":" + drv["SJJG"].ToString());
    //            if (Base.FindTreeNode(root.ChildNodes, treenode, ref find))
    //            {
    //                find.ChildNodes.Add(treenode);
    //            }
    //            else
    //            {
    //                root.ChildNodes.Add(treenode);
    //            }
    //        }

    //        root.CollapseAll();
    //        root.Expand();
    //        for (int i = 0; i < root.ChildNodes.Count; i++)
    //        {
    //            root.ChildNodes[i].Expand();
    //        }
    //        TreeView_ZZJG.Nodes.Add(root);


    //    }

    //}
}
