﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Novell.Directory.Ldap;

namespace NovellLdapTest1
{
    public partial class FuncTest : Form
    {
        string ldapHost ;
        int ldapPort;
        String loginDN;
        String password ;
        String containerName ;

        public FuncTest()
        {
            InitializeComponent();

            ldapHost = txt_Host.Text;

            ldapPort = LdapConnection.DEFAULT_PORT;
            loginDN = txt_Dn.Text ;
            password = txt_Pswd.Text;
            
        }

        private void btn_AddEntry_Click(object sender, EventArgs e)
        {

            containerName = txt_ContainerName.Text;
            try
            {
                LdapAttributeSet attributeSet = new LdapAttributeSet();
                attributeSet.Add(new LdapAttribute(
                                    "objectclass",new string[]{ "organizationalUnit", "SgccOUExt"}));
                                //attributeSet.Add(new LdapAttribute("cn",
                //new string[] { "James Smith", "Jim Smith", "Jimmy Smith" }));
                attributeSet.Add(new LdapAttribute("sgccChnName","运行维护部"));
                attributeSet.Add(new LdapAttribute("sgccParentDeptCode", "29110000"));
                attributeSet.Add(new LdapAttribute("sgccDeptCode", "29110300"));
                attributeSet.Add(new LdapAttribute("sgccOrgNodeType", "1"));
                attributeSet.Add(new LdapAttribute("ou", "29110300"));
                attributeSet.Add(new LdapAttribute("sgccOrgCode", "-1"));

                //attributeSet.Add(new LdapAttribute("telephonenumber", "1 801 555 1212"));
                //attributeSet.Add(new LdapAttribute("mail", "JSmith@Acme.com"));
                //attributeSet.Add(new LdapAttribute("userpassword", "newpassword"));

                //string dn = "cn=KSmith," + containerName;
                string dn = containerName;
                
                LdapEntry newEntry = new LdapEntry(dn, attributeSet);
                LdapConnection conn = new LdapConnection();
                Console.WriteLine("Connecting to:" + ldapHost);
                conn.Connect(ldapHost, ldapPort);
                conn.Bind(LdapConnection.Ldap_V3,loginDN,password);
                //conn.Bind(loginDN, password);
                conn.Add(newEntry);
                Console.WriteLine("Entry:" + dn + "  Added Successfully");
                conn.Disconnect();
            }
            catch (LdapException e1)
            {
                Console.WriteLine("Error:" + e1.LdapErrorMessage);
                return;
            }
            catch (Exception e2)
            {
                Console.WriteLine("Error:" + e2.Message);
                return;
            }
        }


    }
}
