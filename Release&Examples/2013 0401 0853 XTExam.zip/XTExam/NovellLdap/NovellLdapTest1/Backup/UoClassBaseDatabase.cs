using System;
using System.Data;
using System.Data.OleDb;
using System.Threading;

namespace Uo.Class.Base.Database
{
    #region һЩ���õ�����ת����������ַ�����DbUtil��
    public class DbUtil
    {
        DbUtil() { }
        public static void DateTime_to_Db()
        {

        }
    }
    #endregion
    #region ���в������ݿ���Ľӿڹ���
    public interface Db
    {
        object GetOneDate(String querySql);
        int ExecuteSql(String executeSql);
        void FillDataSet(ref DataSet dataSet, String tableName, String querySql, CommandType commandType);
        int[] FillDataSet(ref DataSet dataSet, String[,] querySql, CommandType commandType);
        DataSet GetDataSet(String datasetName, String tableName, String querySql, CommandType commandType);
        DataTable GetDataTable(String tableName, String querySql, CommandType commandType);
        DataView GetDataView(String tableName, String querySql, CommandType commandType);
        DataRow GetDataRow(String tableName, String querySql, CommandType commandType);
        DataSet UpdateDataBase(DataSet changedDataSet, string tableName, string strSQL);
    }
    #endregion
    #region ���в������ݿ���ĸ���
    public class SuperDb
    {
        #region �����OleDbConnection����
        //protected OleDbConnection dbConnection;
        #endregion
        #region Ĭ�Ϲ��캯��
        public SuperDb()
        {
        }
        #endregion


        #region ��̬������ʹ�ø������ַ������������ݿ������Ƿ������ͨ
        public static bool CheckDBLink(String connectionString)
        {
            bool result = false;
            using (OleDbConnection dbConnection = new OleDbConnection(connectionString))
            {
                try
                {
                    dbConnection.Open();
                    result = (ConnectionState.Open == dbConnection.State) ? true : false;
                }
                catch (Exception e)
                {
                    throw (new Exception("���ݿ����Ӵ���!  ERROR:" + e.Message));
                }
                finally
                {
                    dbConnection.Close();
                }
            }
            return result;
        }
        #endregion

        #region ��̬����:�Ӹ�����DataSet�У�ȡ��ĳһ�еĵ�һ�е�ֵ���������GetDataRow��,����Object����
        public static object GetField(ref DataSet ds, string tablename, string columnname)
        {
            object obj = null;
            DataTable myDataTable = ds.Tables[tablename];
            if (myDataTable.DefaultView.Count > 0)
            {
                obj = myDataTable.Rows[0][columnname];
            }
            return obj;
        }
        #endregion

        #region ��̬����:�Ӹ�����DataSet�У�ȡ��ĳһ�е�����ֵ�������γ������˵����б����ݣ�,����Object����
        public static object[] GetObjectFieldArray(ref DataSet ds, string tablename, string columnname)
        {
            DataTable myDataTable = ds.Tables[tablename];
            int n = myDataTable.DefaultView.Count;
            object[] obj = new object[n];
            if (n > 0)
            {
                for (int i = 0; i < n; i++)
                {
                    obj[i] = myDataTable.Rows[i][columnname];
                }
            }
            return obj;
        }
        #endregion

        #region ��̬����:�Ӹ�����DataSet�У�ȡ��ĳһ�е�����ֵ�������γ������˵����б����ݣ�,����string����
        public static string[] GetStringFieldArray(ref DataSet ds, string tablename, string columnname)
        {
            DataTable myDataTable = ds.Tables[tablename];
            int n = myDataTable.DefaultView.Count;
            string[] str = new string[n];
            if (n > 0)
            {
                for (int i = 0; i < n; i++)
                {
                    str[i] = ((myDataTable.Rows[i])[columnname]).ToString();
                }
            }
            return str;
        }
        #endregion
    }
    #endregion
    #region OleDbʵ�ֵ����ݿ�ִ��������̳���(SuperDb,Db)
    public class Database : SuperDb, Db
    {
        string connectionString;
        #region Ĭ�Ϲ��캯��
        private Database()
        {
        }
        #endregion

        #region �ø�����connectionString������
        public Database(String connectionString)
        {
            this.connectionString = connectionString;
        }
        #endregion



        #region GetOneDate ���һ��SQL��䣬ȡ��ִ�к�Ľ��λ�ڵ�һ�е�һ�е����ݣ����������ݿ���ȡ��ĳ���ض���ֵ��
        public object GetOneDate(String querySql)
        {
            Object obj = new object();
            using (OleDbConnection dbConnection = new OleDbConnection(this.connectionString))
            {
                try
                {
                    OleDbCommand selectCommand = new OleDbCommand(querySql, dbConnection);
                    selectCommand.CommandType = CommandType.Text;

                    if (dbConnection.State != ConnectionState.Open)
                        dbConnection.Open();

                    obj = selectCommand.ExecuteScalar();
                }
                catch (Exception ex)
                {
                    throw (new Exception("��ȡ���ݴ���\n SQL=" + querySql + "\n ERROR:" + ex.Message));
                }
                finally
                {
                    //if(dbConnection.State!=ConnectionState.Closed)
                    dbConnection.Close();

                }
            }

            return obj;
        }
        #endregion

        #region ���һ��SQL��䣬��ִ�к�Ľ����䵽ֵ������ָ��һ��DataSet
        public void FillDataSet(ref DataSet dataSet, String tableName, String querySql, CommandType commandType)
        {
            //Console.WriteLine(querySql);
            using (OleDbConnection dbConnection = new OleDbConnection(this.connectionString))
            {
                try
                {
                    OleDbCommand selectCommand = new OleDbCommand(querySql, dbConnection);
                    selectCommand.CommandType = commandType;
                    OleDbDataAdapter myAdapter = new OleDbDataAdapter(selectCommand);
                    myAdapter.Fill(dataSet, tableName);
                }
                catch (Exception ex)
                {

                    throw (new Exception("��ȡ���ݴ��� SQL=" + querySql + " ERROR:" + ex.Message));
                }
                finally
                {
                }
            }

        }
        #endregion

        #region ���ݿ����ݸ���(��DataSet��DataTable�Ķ����SELECT SQL)
        /// <summary>
        /// ���ݿ����ݸ���(��DataSet��DataTable�Ķ���),�ñ�����������
        /// </summary>
        /// <param name="changedDataSet"></param>
        /// <param name="tableName"></param>
        /// <param name="strSQL"></param>
        /// <returns></returns>
        public DataSet UpdateDataBase(DataSet changedDataSet, string tableName, string strSQL)
        {
            using (OleDbConnection dbConnection = new OleDbConnection(this.connectionString))
            {

                OleDbDataAdapter da = new OleDbDataAdapter(strSQL, dbConnection);
                OleDbCommandBuilder sqlCmdBld = new OleDbCommandBuilder(da);
                da.Update(changedDataSet, tableName);
            }
            return changedDataSet;//���ظ����˵����ݿ��
        }
        #endregion

        #region �����SQL��䣨SQL���飩����ִ�к�Ľ����䵽ֵ������ָ��ͬһ��DataSet
        public int[] FillDataSet(ref DataSet dataSet, String[,] querySql, CommandType commandType)
        {
            int len = querySql.Length / (querySql.Rank + 1);
            int[] ls_rownum = new int[len];
            using (OleDbConnection dbConnection = new OleDbConnection(this.connectionString))
            {
                try
                {
                    for (int i = 0; i < len; i++)
                    {
                        OleDbCommand selectCommand = new OleDbCommand(querySql[i, 2], dbConnection);
                        selectCommand.CommandType = commandType;
                        OleDbDataAdapter myAdapter = new OleDbDataAdapter(selectCommand);
                        ls_rownum[i] = myAdapter.Fill(dataSet, querySql[i, 1]);
                        //Console.WriteLine(i+":"+querySql[i,2]);
                    }
                }
                catch (Exception ex)
                {
                    throw (new Exception("��ȡ���ݴ���\n SQL=" + querySql + "\n ERROR:" + ex.Message));
                }
                finally
                {
                }
            }
            return ls_rownum;
        }
        #endregion

        #region �õ�SQL���ִ�к��DataSet
        public DataSet GetDataSet(String datasetName, String tableName, String querySql, CommandType commandType)
        {
            DataSet myDataSet = new DataSet(datasetName);
            FillDataSet(ref myDataSet, tableName, querySql, commandType);
            return myDataSet;
        }
        #endregion



        #region �õ�SQL���ִ�к��DataTable
        public DataTable GetDataTable(String tableName, String querySql, CommandType commandType)
        {
            DataSet myDataSet = new DataSet();
            FillDataSet(ref myDataSet, tableName, querySql, commandType);
            DataTable myDataTable = myDataSet.Tables[tableName];
            return myDataTable;
        }
        #endregion

        #region �õ�SQL���ִ�к��DataView�������ѯ��
        public DataView GetDataView(String tableName, String querySql, CommandType commandType)
        {
            return GetDataTable(tableName, querySql, commandType).DefaultView;
        }
        #endregion

        #region �õ�SQL���ִ�к��һ�����ݣ���SQL���Ľ��������һ�У����򷵻ز���ȡ��Ψһ���ݣ�
        public DataRow GetDataRow(String tableName, String querySql, CommandType commandType)
        {
            DataTable myDataTable = GetDataTable(tableName, querySql, commandType);
            DataRow myDataRow = null;
            if (myDataTable.DefaultView.Count == 1)
            {
                myDataRow = myDataTable.Rows[0];
            }
            else if (myDataTable.DefaultView.Count > 1)
            {
                throw (new Exception("������ȡ��Ψһһ�����ݣ�"));
            }
            return myDataRow;
        }
        #endregion

        #region ����ִ��SQL��䣨INSERT��DELETE��UPDATE����COMMIT��ROLLBACK����
        public int[] ExecuteSql(String[] executeSql)
        {

            int[] ls_rownum = new int[executeSql.Length];
            using (OleDbConnection dbConnection = new OleDbConnection(this.connectionString))
            {

                dbConnection.Open();

                OleDbCommand ls_Command = dbConnection.CreateCommand();
                OleDbTransaction ls_Trans;
                ls_Trans = dbConnection.BeginTransaction(IsolationLevel.ReadCommitted);
                ls_Command.Connection = dbConnection;
                ls_Command.Transaction = ls_Trans;

                try
                {
                    for (int i = 0; i < executeSql.Length; i++)
                    {
                        ls_Command.CommandText = executeSql[i];
                        ls_rownum[i] = ls_Command.ExecuteNonQuery();
                    }
                    ls_Trans.Commit();
                }
                catch (Exception e)
                {
                    try
                    {
                        ls_Trans.Rollback();
                    }
                    catch (OleDbException ex)
                    {
                        if (dbConnection != null)
                        {
                            new Exception("�ع�����\n ERROR:" + ex.Message);
                        }
                    }
                    new Exception("����ִ��SQL����\n ERROR:" + e.Message);
                }
                finally
                {
                    dbConnection.Close();
                }
            }

            return ls_rownum;
        }
        #endregion

        #region ExecuteSql  ִ��SQL��䣨INSERT��DELETE��UPDATE��
        public int ExecuteSql(String executeSql)
        {
            //Console.WriteLine(executeSql);
            int n = 0;
            using (OleDbConnection dbConnection = new OleDbConnection(this.connectionString))
            {
                try
                {
                    OleDbCommand cmd = new OleDbCommand(executeSql, dbConnection);
                    if (dbConnection.State != ConnectionState.Open) dbConnection.Open();
                    n = cmd.ExecuteNonQuery();
                }
                catch (Exception e)
                {
                    throw (new Exception("����������\n SQL=" + executeSql + "\n ERROR:" + e.Message));
                }
                finally
                {
                    //dbConnection.Close();
                }
            }
            return n;
        }
        #endregion

        public int ExecuteSql(String executeSql, int a)
        {
            //Console.WriteLine(executeSql);
            int n = 0;
            using (OleDbConnection dbConnection = new OleDbConnection(this.connectionString))
            {
                try
                {
                    OleDbCommand cmd = new OleDbCommand(executeSql, dbConnection);
                    dbConnection.Open();
                    n = cmd.ExecuteNonQuery();
                }
                catch (Exception e)
                {
                    throw (new Exception("����������\n SQL=" + executeSql + "\n ERROR:" + e.Message));
                }
                finally
                {
                    dbConnection.Close();
                }
            }
            return n;
        }
    }
    #endregion
}
