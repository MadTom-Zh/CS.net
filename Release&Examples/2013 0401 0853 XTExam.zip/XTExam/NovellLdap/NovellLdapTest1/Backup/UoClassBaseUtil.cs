using System;
using System.Collections;
using System.IO;
using System.Resources;
using Uo.Class.Base.Io;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Diagnostics;
namespace Uo.Class.Base.Util
{

    public class Log
    {
        /// <summary>
        /// д��ϵͳ��־
        /// </summary>
        /// <param name="message">�¼�����</param>
        public static void WriteLogEvent(string eventSourceName, EventLogEntryType errType ,string message)
        {
            if (!EventLog.SourceExists(eventSourceName))
            {
                EventLog.CreateEventSource(eventSourceName, "Application");
            }
            EventLog.WriteEntry(eventSourceName,message, EventLogEntryType.Error );
        }
    }


    /// <summary>
    /// UoClassBaseUtil ��ժҪ˵����
    /// </summary>
    public class AppConfig
    {

        public static string GetValue(string AppKey)
        {
            try
            {
                string AppKeyValue;
                AppKeyValue = System.Configuration.ConfigurationManager.AppSettings.Get(AppKey);
                //System.Configuration.ConfigurationManager.AppSettings.Set("ssss","bbbb");
                return AppKeyValue;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //д
        public static void SetValue(string AppKey, string AppValue)
        {
            //System.Configuration.ConfigurationSettings.AppSettings.Set(AppKey,AppValue);
            XmlDocument xDoc = new XmlDocument();
            xDoc.Load(System.Windows.Forms.Application.ExecutablePath + ".config");

            XmlNode xNode;
            XmlElement xElem1;
            XmlElement xElem2;

            xNode = xDoc.SelectSingleNode("//appSettings");

            xElem1 = (XmlElement)xNode.SelectSingleNode("//add[@key='" + AppKey + "']");
            if (xElem1 != null) xElem1.SetAttribute("value", AppValue);
            else
            {
                xElem2 = xDoc.CreateElement("add");
                xElem2.SetAttribute("key", AppKey);
                xElem2.SetAttribute("value", AppValue);
                xNode.AppendChild(xElem2);
            }
            xDoc.Save(System.Windows.Forms.Application.ExecutablePath + ".config");
        }


    }

    public class StringUtil
    {
        public static string StringPick(string strsource, char start, char end)
        {
            CharEnumerator cenum = strsource.GetEnumerator();
            char char_ls;
            int i = 0, s = 0, e = 0;
            while (cenum.MoveNext())
            {
                char_ls = cenum.Current;
                if (char_ls == start) s = i + 1;
                if (char_ls == end)
                {
                    e = i;
                    break;
                };
                i++;
            }
            return strsource.Substring(s, e - s);
        }
    }

    

    /*
    ���ݴ��ݵ����ݱ������γɽ����
     str_ColumeName ���ݱ�����Ҫ��ȡ�������ֶ���
     int_ImageInedx ��Ӧ�ڵ���Ҫ��ʾ��ͼ������
     object         �ڵ���Ҫ���ӵ�����
     curr_node      ��Ҫ���д����Ľڵ㣨���ã�
	
    */
    public class TreeNodeUtil
    {
        public static void FillTreeNode(DataView dv_Table, string[] str_ColumeName, int[,] int_ImageInedx, object[] obj_Tag, ref TreeNode node)
        {
            TreeNode curr_node = new TreeNode();
            foreach (DataRowView drv in dv_Table)
            {
                curr_node = node;//=node_Parent;
                for (int i = 0; i < str_ColumeName.Length; i++)
                {
                    IEnumerator ls_nodeenum = curr_node.Nodes.GetEnumerator();
                    TreeNode ls_treenode = new TreeNode(drv[(str_ColumeName[i])].ToString(), int_ImageInedx[i, 0], int_ImageInedx[i, 1]);

                    ls_treenode.Tag = obj_Tag[i];
                    Object ls_obj = FindObj(ls_nodeenum, ls_treenode);
                    if (ls_obj != null)
                    {
                        curr_node = (TreeNode)ls_obj;
                    }
                    else
                    {
                        curr_node.Nodes.Add(ls_treenode);
                        curr_node = ls_treenode;
                    }
                }
            }
            //return curr_node;
        }

        public static void FillTreeNode(DataView dv_Table, string[] str_ColumeName, int[,] int_ImageInedx, string[] nodelab, ref TreeNode node)
        {
            TreeNode curr_node = new TreeNode();
            foreach (DataRowView drv in dv_Table)
            {
                curr_node = node;//=node_Parent;
                for (int i = 0; i < str_ColumeName.Length; i++)
                {
                    IEnumerator ls_nodeenum = curr_node.Nodes.GetEnumerator();
                    TreeNode ls_treenode = new TreeNode(nodelab[i] + drv[(str_ColumeName[i])].ToString(), int_ImageInedx[i, 0], int_ImageInedx[i, 1]);

                    ls_treenode.Tag = new string[] { str_ColumeName[i], drv[(str_ColumeName[i])].ToString() };
                    Object ls_obj = FindObj(ls_nodeenum, ls_treenode);
                    if (ls_obj != null)
                    {
                        curr_node = (TreeNode)ls_obj;
                    }
                    else
                    {
                        curr_node.Nodes.Add(ls_treenode);
                        curr_node = ls_treenode;
                    }
                }
            }
            //return curr_node;
        }



        private static Object FindObj(IEnumerator obj_enum, Object obj_find)
        {
            Object ls_obj = new Object();
            bool result = false;
            while (obj_enum.MoveNext())
            {
                ls_obj = obj_enum.Current;
                if (ls_obj.ToString() == obj_find.ToString())
                {
                    result = true;
                    break;
                }
            }
            return (result) ? ls_obj : null;
        }
    }
    public class Content
    {
        public Hashtable ht_Content;
        public Hashtable ht_Parm;
        public Content()
        {
            ht_Content = new Hashtable();
            ht_Parm = new Hashtable();
        }
        public static void PrintKeysAndValues(Hashtable ht_Content)
        {
            IDictionaryEnumerator myEnumerator = ht_Content.GetEnumerator();
            Console.WriteLine("\t-KEY-\t-VALUE-");
            while (myEnumerator.MoveNext())
                Console.WriteLine("\t{0}:\t{1}", myEnumerator.Key, myEnumerator.Value);
            Console.WriteLine();
        }
    }
    public class Config
    {
        public String str_ConnString, parm_PathStr, config_PathStr;
        public Content uo_Content;
        public Config()
        {
            uo_Content = new Content();
        }
        public Config(string config_PathStr, string parm_PathStr)
        {
            uo_Content = new Content();
            Init(config_PathStr, parm_PathStr);
        }
        public virtual void Init(string config_PathStr, string parm_PathStr)
        {
            this.config_PathStr = config_PathStr;
            this.parm_PathStr = parm_PathStr;
            str_ConnString = IniFileRW.GetProperty("�������ݿ�", "ConnString", "Provider=MSDAORA.1;Password=manager;User ID=system;Data Source=szsyd", config_PathStr);
            uo_Content.ht_Parm = IniFileRW.GetParm(parm_PathStr);
        }
        public virtual bool SaveProperty()
        {
            return IniFileRW.SetProperty("�������ݿ�", "ConnString", str_ConnString, config_PathStr);
            //IniFileRW.SetParm(parm_PathStr,uo_Content.ht_Parm);
        }
        public virtual bool SaveParm()
        {
            //IniFileRW.SetProperty("�������ݿ�","ConnString",str_ConnString,config_PathStr);
            return IniFileRW.SetParm(parm_PathStr, uo_Content.ht_Parm);
        }
    }
    //public class  
    /*
    public class Resource
    {
        public String path;
        public String filename;
        public String directory;
        public Resource()
        {
        }
        public Resource(String resourcefilename)
        {
            String path=Directory.GetCurrentDirectory()+"\\"+resourcefilename;
            if(File.Exists(path))
            {
                this.path=path;
                this.filename=resourcefilename;
                this.directory=Directory.GetCurrentDirectory();
            }
            else
            {
                throw(new Exception("��Դ���ʼ��ʧ�ܣ���Դ�ļ�·������"));
            }
        }
        public Resource(String path,String resourcefilename)
        {
            String lspath=path+"\\"+resourcefilename;
            if(File.Exists(lspath))
            {
                this.path=lspath;
                this.filename=resourcefilename;
                this.directory=path;
            }
            else
            {
                throw(new Exception("��Դ���ʼ��ʧ�ܣ���Դ�ļ�·������"));
            }
        }
        public bool SetProperty(String name,Object propertyvalue)
        {
            bool result=false;
            if(File.Exists(path))
            {
                try
                {
                    ResourceWriter rw = new ResourceWriter (path) ;
                    try
                    {
                        rw.AddResource(name,propertyvalue) ;
                        rw.Generate () ;
                        result=true;
                    }
                    catch(Exception ex)
                    {
                        throw(new Exception("д����Դ�ļ�����\n"+ex.Message));
                    }
                    finally
                    {
                        rw.Close () ;
                    }
                }
                catch(Exception ioex)
                {
                    throw(new Exception("����Դ�ļ�����\n"+ioex.Message));
                }
            }
            else
            {
                throw(new Exception("û�з�����Դ�ļ���\n"+path));
            }
            return result;
        }
        public bool SetProperty(String name,String propertyvalue)
        {
            bool result=false;
            if(File.Exists(path))
            {
                try
                {
                    ResourceWriter rw = new ResourceWriter ( path ) ;
                    try
                    {
                        rw.AddResource(name,propertyvalue) ;
                        rw.Generate ( ) ;
                        result=true;
                    }
                    catch(Exception ex)
                    {
                        throw(new Exception("д����Դ�ļ�����\n"+ex.Message));
                    }
                    finally
                    {
                        rw.Close () ;
                    }
                }
                catch(Exception ioex)
                {
                    throw(new Exception("����Դ�ļ�����\n"+ioex.Message));
                }
            }
            else
            {
                throw(new Exception("û�з�����Դ�ļ���\n"+path));
            }
            return result;
        }
        public bool SetProperty(String name,byte[] propertyvalue)
        {
            bool result=false;
            if(File.Exists(path))
            {
                try
                {
                    ResourceWriter rw = new ResourceWriter (path) ;
                    try
                    {
                        rw.AddResource(name,propertyvalue) ;
                        rw.Generate ( ) ;
                        result=true;
                    }
                    catch(Exception ex)
                    {
                        throw(new Exception("д����Դ�ļ�����\n"+ex.Message));
                    }
                    finally
                    {
                        rw.Close () ;
                    }
                }
                catch(Exception ioex)
                {
                    throw(new Exception("����Դ�ļ�����\n"+ioex.Message));
                }
            }
            else
            {
                throw(new Exception("û�з�����Դ�ļ���\n"+path));
            }
            return result;
        }
        /*
        public Object GetProperty(String name,Object propertyvalue)
        { 
            Object obj=null;
            if(File.Exists(path))
            {
                try
                {
                    ResourceManager rm =ResourceManager.CreateFileBasedResourceManager(File.,) ;
                    try
                    {
                        obj=rm.GetObject(name) ;
                    }
                    catch(Exception ex)
                    {
                        throw(new Exception("��ȡ���Դ���\n"+ex.Message));
                    }
                    finally
                    {
                        rm.Close () ;
                    }
                }
                catch(Exception ioex)
                {
                    throw(new Exception("��ȡ��Դ�ļ�����\n"+ioex.Message));
                }
            }
            else
            {
                throw(new Exception("û�з�����Դ�ļ���\n"+path));
            }
            return obj;
        }
        */


    public class ControlItem
    {
        /*
    ��������ΪCombox,Listbox�����ṩItem��ֵ
            ArrayList ControlItem = new ArrayList();
            ControlItem.Add(new ControlItem("ȫ��"," "));
            ControlItem.Add(new ControlItem("�绰","TEL_TYPE LIKE '�绰'"));
            ControlItem.Add(new ControlItem("�ֻ�","TEL_TYPE LIKE '�ֻ�'"));
            ControlItem.Add(new ControlItem("����","TEL_TYPE LIKE '����'"));
            ControlItem.Add(new ControlItem("����","TEL_TYPE NOT IN ('�绰','�ֻ�','����')"));

            //this.tel_type.SelectedValueChanged += new EventHandler(ListBox1_SelectedValueChanged);
            this.tel_type.DataSource = ControlItem;
            this.tel_type.DisplayMember = "ShowItem";
            this.tel_type.ValueMember = "ValueItem";

    */
        private string showitem;
        private string valueitem;

        public ControlItem(string showitem, string valueitem)
        {
            this.showitem = showitem;
            this.valueitem = valueitem;
        }

        public string ValueItem
        {
            get
            {
                return valueitem;
            }
        }

        public string ShowItem
        {
            get
            {
                return showitem;
            }
        }

        public override string ToString()
        {
            return this.ShowItem + " - " + this.ValueItem;
        }
    }

}
