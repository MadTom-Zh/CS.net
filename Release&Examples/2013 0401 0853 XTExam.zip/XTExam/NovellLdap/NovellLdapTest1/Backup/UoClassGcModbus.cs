﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO.Ports;
using Uo.Class.Gc.Crc;
using System.Threading;

namespace Uo.Class.Gc.Modbus
{
    public class ReadPort
    {
        private int status = 0;      //0:写入串口 1:读取数据　２:判断读取数据
        public  bool Read(ReadInfo readinfo)
        {
            int read = 0;
            bool Reading = true;
            int _l = readinfo.Len > 1 ? readinfo.Len * 2 : 1;
            byte[] buffer = new byte[_l + 5];
            DateTime dt = DateTime.Now.AddMilliseconds(readinfo.READ_TIMEOUT);

            while (Reading)
            {
                switch (status)
                {
                    case 0:     //写入串口

                        if (!readinfo.serialport.IsOpen)
                        {
                            readinfo.serialport.Open();
                        }
                        readinfo.serialport.DiscardInBuffer();
                        readinfo.serialport.DiscardOutBuffer();
                        readinfo.serialport.Write(readinfo.w_Buffer, 0, readinfo.w_Buffer.Length);
                        status = 1;
                        break;
                    case 1:
                        int count = readinfo.serialport.BytesToRead;
                        if (count > 0)
                        {
                            read += readinfo.serialport.Read(buffer, read, count);
                        }

                        if (read >= 5 && Convert.ToInt32(buffer[0]) == readinfo.Sb_Id &&
                            Convert.ToInt32(buffer[1]) > 0x80)
                        {
                            Reading = false;
                            readinfo.ErrorCode = 2;
                        }

                        if (read >= _l + 5)
                        {
                            status = 2;
                        }
                        break;
                    case 2:
                        if (Convert.ToInt32(buffer[0]) == readinfo.Sb_Id &&
                            Convert.ToInt32(buffer[1]) == readinfo.Function &&
                            Convert.ToInt32(buffer[2]) == _l)
                        {
                            readinfo.IsRead = CRC16.CRC16Check(buffer);
                            readinfo.ErrorCode = 0;
                        } 
                        Reading = false;
                        status = 0;
                        break;
                    
                }
                readinfo.r_Buffer = buffer;
                if (dt < DateTime.Now)
                {
                    readinfo.ex = new Exception("读取串口数据超时!");
                    Reading = false;
                    readinfo.ErrorCode = 1;
                }
                Thread.Sleep(0);
            }

            return readinfo.IsRead;
        }
    }
    public class ReadInfo
    {
        public SerialPort serialport;
        public int READ_TIMEOUT = 5000;
        public Exception ex;
        public int ErrorCode = -1;  //0:正常　1:超时　2:读取异常
        public bool IsRead = false;
        public int Sb_Id;
        public int Modbus_Address;
        public int Function;
        public int Len;
        public int Sb_Type = 0;            //1:恒温恒湿空调　２:温湿度传感器
        public string Sb_Description = "";
        public string Sb_Name = "";
        string _Result = "";
        public byte[] r_Buffer ;     //存储从串口读取的数据
        public byte[] w_Buffer = new byte[8];      //存储写入串口的数据

        public ReadInfo(ref SerialPort serialport, int Sb_Id, int Modbus_Address, int Function, int Len)
        {
            this.serialport = serialport;
            this.Sb_Id = Sb_Id;
            this.Modbus_Address = Modbus_Address;
            this.Function = Function;
            this.Len = Len;

            w_Buffer[0] = Convert.ToByte(Sb_Id);                   //请求应答的设备485地址
            byte[] address = BitConverter.GetBytes(Modbus_Address);    //设备Modbus地址

            w_Buffer[1] = Convert.ToByte(Function);   　            //功能码
            w_Buffer[2] = address[1];             　            //固定 
            w_Buffer[3] = address[0];   　　　　　　            //固定 

            w_Buffer[4] = 0x00;                  　　           //固定 
            w_Buffer[5] = Convert.ToByte(Len);  　 　           //数据长度

            w_Buffer[6] = 0x00;   //CRC 高 
            w_Buffer[7] = 0x00;   //CRC 低 

            if (!CRC16.CRC16Check(CRC16.CRCCalc(w_Buffer)))
            {
                throw (new Exception("生成校验码失败！"));
            }
        }

        public string Result
        {
            get
            {
                if (IsRead && ErrorCode == 0)
                {
                    if (Len < 2)
                    {
                        _Result = r_Buffer[3].ToString();
                    }
                    else
                    {
                        byte[] a = new byte[4];
                        a[0] = r_Buffer[6];
                        a[1] = r_Buffer[5];
                        a[2] = r_Buffer[4];
                        a[3] = r_Buffer[3];
                        //_Result = Convert.ToString(BitConverter.ToSingle(a, 0));
                        _Result = Convert.ToString(BitConverter.ToSingle(a, 0));

                    }
                }
                return _Result;
            }
        }

    }
}
