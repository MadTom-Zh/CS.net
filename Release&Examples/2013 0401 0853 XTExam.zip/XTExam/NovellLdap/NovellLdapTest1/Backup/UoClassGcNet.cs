using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.IO;
using System.Net.Sockets;
using System.Threading;
using System.Collections;
using Uo.Class.Base.Database;
using System.Data.OleDb;
using System.Net.NetworkInformation;

namespace Uo.Class.Gc.NetScan
{
    //public class ScanEventArgs:EventArgs 
    //{
    //    public ScanEventArgs(IScan scan)
    //    {
    //        this._scan = scan;
    //    }

    //    private IScan _scan;
    //    public IScan scan
    //    {
    //        get { return _scan; }
    //    }
    //}

    public class Sb
    {
        /// <summary>
        /// IP��ַ
        /// </summary>
        public IPAddress Ip;
        /// <summary>
        /// ���м���ʱ��
        /// </summary>
        public DateTime ScanTime;

        /// <summary>
        /// ����
        /// </summary>
        public string Name;

        /// <summary>
        /// ���ڻ���
        /// </summary>
        public string Jf;

        /// <summary>
        /// ����(�������������豸�����ݿ⡢WEBӦ��)
        /// </summary>
        public string Type;
        /// <summary>
        /// ������Ϣ
        /// </summary>
        public System.Exception Err;
        /// <summary>
        /// ������Ϣ
        /// </summary>
        public string Msg;
        public bool IsOk;
        public string Id;
        public string IsScan;       //�Ƿ�ɨ��


        public int ScanTimes = 0;   //ɨ�����
        //public DateTime ScanTime;   //ɨ��ʱ��

        //public DateTime PreScanTime;//ǰһ��ɨ��ʱ��
        public bool PreScanResult;  //ǰһ��ɨ����

        public DateTime PreWriteSmsTime;
        public bool IsWriteSms = false;
        public string WriteSmsSql = "INSERT INTO SMS_SEND_LIST (SEND_ID, SEND_HP_NO, SMS,SEND_TYPE,XSEND_TYPE) VALUES (SMS_SEND_ID.NEXTVAL,'{0}','{1}','1', '���')";
        /// <summary>
        /// �豸���캯��
        /// </summary>
        /// <param name="Ip">IP��ַ</param>
        /// <param name="Name">�豸����</param>
        /// <param name="Jf">���ڻ���</param>
        /// <param name="Type">���ͷ������������豸�����ݿ⡢WEBӦ��</param>
        public Sb(string Id,IPAddress Ip, string Name, string Jf, string Type)
        {
            this.Id = Id;
            this.Ip = Ip;
            this.Name = Name;
            this.Jf = Jf;
            this.Type = Type;

            //throw new System.NotImplementedException();
        }
        public Sb()
        {
            //throw new System.NotImplementedException();
        }
        public string SmsInfo()
        {
            string _str = String.Format("{0}{1}����{2}", Name, Ip, Err.Message);
            return _str.Length > 70 ? _str.Substring(0, 70) : _str;
        }
        public void WriteSmsToDb(Uo.Class.Base.Database.Db db, int ScanInterval, string[] WorkMan)
        {
            if (this.ScanTimes > 1)//ɨ�賬��һ��
            {
                if (!this.IsOk && !this.PreScanResult)//����ɨ���ǰһ�ξ�����
                {
                    if (this.IsWriteSms)//��ǰ����
                    {
                        //�ж�ʱ���Ƿ񳬹�24Сʱ���������ٴ�д���ݿ�
                        if ((DateTime.Now - PreWriteSmsTime) > System.TimeSpan.FromHours(24))
                        {
                            //д���ݿ�
                            for (int i = 0; i < WorkMan.Length; i++)
                            {
                                db.ExecuteSql(String.Format(WriteSmsSql, WorkMan[i], SmsInfo()));
                            }
                            //����д��ʱ��
                            PreWriteSmsTime = DateTime.Now;
                        }
                    }
                    else//��ǰû�з���
                    {
                        //д���ݿ�
                        for (int i = 0; i < WorkMan.Length; i++)
                        {
                            db.ExecuteSql(String.Format(WriteSmsSql, WorkMan[i], SmsInfo()));
                            //д���ŷ��ʹ�����־
                            string _ErrSql = String.Format("INSERT INTO ERR_LOG (ID, TYPE, ERRMSG, ERRTIME) VALUES ('{0}','{1}','{2}{3}����{4}',SYSDATE)", Guid.NewGuid().ToString(), this.Type,this.Name,this.Ip,this.Err.Message);
                            db.ExecuteSql(_ErrSql);
                        }
                        //����д��ʱ��
                        PreWriteSmsTime = DateTime.Now;
                        //������ǰ�Ƿ���
                        IsWriteSms = true;
                    }
                }
                else if (this.IsOk && this.PreScanResult)//����ɨ���ǰһ�ξ���ȷ
                {
                    //������ǰ�Ƿ���
                    IsWriteSms = false;
                }
            }
        }
    }
    public class Db : Sb, IScan
    {
        /// <summary>
        /// ���ݿ������ַ���
        /// </summary>
        public string ConnStr;
        /// <summary>
        /// ���ݿ��������
        /// </summary>
        public string ServerName;
        /// <summary>
        /// ���ݿ�����(Oracle��Sql��Db2��Mysql)
        /// </summary>
        public string DbType;

        public Db()
        {
            throw new System.NotImplementedException();
        }
        /// <summary>
        /// ���캯��
        /// </summary>
        /// <param name="Id">Id��</param>
        /// <param name="Ip">IP��ַ</param>
        /// <param name="Name">�豸����</param>
        /// <param name="Jf">���ڻ���</param>
        /// <param name="Type">���ͷ������������豸�����ݿ⡢WEBӦ��</param>
        /// <param name="ConnStr">���ݿ����Ӵ�</param>
        /// <param name="ServerName">���ݿ��������</param>
        /// <param name="DbType">���ݿ�����(Oracle��Sql��Db2��Mysql)</param>
        public Db(string Id,IPAddress Ip, string Name, string Jf, string Type,string ConnStr,string ServerName,string DbType):base(Id,Ip,Name,Jf,Type)
        {
            this.ConnStr = ConnStr;
            this.ServerName = ServerName;
            this.DbType = DbType;
        }
        #region IScan ��Ա

        public void Scan()
        {
            bool result = false;
            this.ScanTimes++;

            using (OleDbConnection dbConnection = new OleDbConnection(ConnStr))
            {
                for (int i = 0; i < 5; i++)
                {
                    try
                    {
                        OleDbCommand selectCommand = new OleDbCommand("SELECT 1 FROM DUAL", dbConnection);
                        selectCommand.CommandType = System.Data.CommandType.Text;
                        dbConnection.Open();
                        result = (Convert.ToInt32(selectCommand.ExecuteScalar()) == 1) ? true : false;
                    }
                    catch (Exception ex)
                    {
                        this.Err = ex;
                        Uo.Class.Base.Util.Log.WriteLogEvent("Db.Scan", System.Diagnostics.EventLogEntryType.Error, ex.Message);
                    }
                    finally
                    {
                        dbConnection.Close();
                    }

                    if (result) break;

                }

            }
            if (this.ScanTimes > 1)//ɨ�賬��һ��
            {
                //PreScanTime = this.ScanTime;//����ǰһ��ɨ��ʱ��
                PreScanResult = this.IsOk;  //����ǰһ��ɨ����
            }
            this.ScanTime = DateTime.Now;
            this.IsOk = result;
        }

        public string ShowInfo()
        {
            return String.Format("IP:{0} ����:{1} ����:{2} �豸����:{3} ���ݿ�����:{4} ���ݿ��������:{5} �Ƿ�����:{6} \n", Ip, Name.PadRight(20), Jf.PadRight(10), Type.PadRight(10), DbType.PadRight(20), ServerName.PadRight(20), this.IsOk);
        }

        public string[] ShowInfoPro()
        {
            return new String[] {ScanTime.ToLongTimeString(),Ip.ToString(), Name, Jf, Type, DbType, ServerName, this.IsOk.ToString()};//"IP:{0} ����:{1} ����:{2} �豸����:{3} ���ݿ�����:{4} ���ݿ��������:{5} �Ƿ�����:{6} \n", Ip, Name.PadRight(20), Jf.PadRight(10), Type.PadRight(10), DbType.PadRight(20), ServerName.PadRight(20), this.IsOk);
        }

        #endregion

        //#region IScan ��Ա


        //public void WriteSmsToDb(Uo.Class.Base.Database.Db db, int ScanInterval, string[] WorkMan)
        //{
        //    if (this.ScanTimes > 1)//ɨ�賬��һ��
        //    {
        //        if (!this.IsOk && !this.PreScanResult)//����ɨ���ǰһ�ξ�����
        //        {
        //            if (this.IsWriteSms)//��ǰ����
        //            {
        //                �ж�ʱ���Ƿ񳬹�24Сʱ���������ٴ�д���ݿ�
        //                if ((DateTime.Now - PreWriteSmsTime) > System.TimeSpan.FromHours(24))
        //                {
        //                    д���ݿ�
        //                    for (int i = 0; i < WorkMan.Length; i++)
        //                    {
        //                        db.ExecuteSql(String.Format(WriteSmsSql, WorkMan[i], SmsInfo()));
        //                    }
        //                    ����д��ʱ��
        //                    PreWriteSmsTime = DateTime.Now;
        //                }
        //            }
        //            else//��ǰû�з���
        //            {
        //                д���ݿ�
        //                for (int i = 0; i < WorkMan.Length; i++)
        //                {
        //                    db.ExecuteSql(String.Format(WriteSmsSql, WorkMan[i], SmsInfo()));
        //                }
        //                ����д��ʱ��
        //                PreWriteSmsTime = DateTime.Now;
        //                ������ǰ�Ƿ���
        //                IsWriteSms = true;
        //            }
        //        }
        //        else if (this.IsOk && this.PreScanResult)//����ɨ���ǰһ�ξ���ȷ
        //        {
        //            ������ǰ�Ƿ���
        //            IsWriteSms = false;
        //        }
        //    }
        //}

        //#endregion

        
    }

    public class Web : Sb, IScan
    {
        /// <summary>
        /// WEB��ַ
        /// </summary>
        private string Uri;
        /// <summary>
        /// WEB������
        /// </summary>
        private string ServerName;
        /// <summary>
        /// ����(WEB)
        /// </summary>
        private string WebType;

        private object Image;
        /// <summary>
        /// ����
        /// </summary>
        private string Encoding;
        /// <summary>
        /// �ж�����
        /// </summary>
        private string Judge;

        public Web()
        {
            throw new System.NotImplementedException();
        }
        /// <summary>   
        /// ���캯��
        /// </summary>
        /// <param name="Ip">IP��ַ</param>
        /// <param name="Name">�豸����</param>
        /// <param name="Jf">���ڻ���</param>
        /// <param name="Type">���ͷ������������豸�����ݿ⡢WEBӦ��</param>
        /// <param name="Uri">WEB��ַ</param>
        /// <param name="ServerName">WEB������</param>
        /// <param name="WebType">����(WEB)</param>
        /// <param name="Image">WEB���ͽ���</param>
        public Web(string Id,IPAddress Ip, string Name, string Jf, string Type,string Uri,string ServerName,string WebType,object Image,string encoding,string judge):base(Id,Ip,Name,Jf,Type)
        {
            this.Uri = Uri;
            this.WebType = WebType;
            this.Image = Image;
            this.ServerName = ServerName;
            this.Encoding = encoding;
            this.Judge = judge;
        }

        public static string GetWebContext(Uri url,string encoding)
        {
            String result = null;
            HttpWebResponse myHttpWebResponse = null;
            StreamReader readStream = null;
            try
            {
                // Creates an HttpWebRequest with the specified URL. 
                HttpWebRequest myHttpWebRequest = (HttpWebRequest)WebRequest.Create(url);
                // Sends the HttpWebRequest and waits for the response.            
                myHttpWebResponse = (HttpWebResponse)myHttpWebRequest.GetResponse();
                Stream receiveStream = myHttpWebResponse.GetResponseStream();

                Encoding encode = System.Text.Encoding.GetEncoding(encoding);
                // Pipes the stream to a higher level stream reader with the required encoding format. 
                readStream = new StreamReader(receiveStream, encode);

                Char[] read = new Char[512];

                int count = readStream.Read(read, 0, 512);

                while (count > 0)
                {
                    String str = new String(read, 0, count);

                    result = result + str;
                    count = readStream.Read(read, 0, 512);
                }
            }
            catch (Exception ex)
            {
                //throw (new Exception(String.Format("������վ����{0} ��Ϣ��{1}", url, ex.Message)));
                Uo.Class.Base.Util.Log.WriteLogEvent("Web.GetWebContext", System.Diagnostics.EventLogEntryType.Error, ex.Message);
            }
            finally
            {
                if (myHttpWebResponse != null)
                    myHttpWebResponse.Close();

                if (readStream != null)
                    readStream.Close();
            }
            return result;
        }

        public static bool WebTest(Uri url,string encoding,string judge)
        {
            bool result = false ;
            HttpWebResponse myHttpWebResponse = null;
            StreamReader readStream = null;
            try
            {
                // Creates an HttpWebRequest with the specified URL. 
                HttpWebRequest myHttpWebRequest = (HttpWebRequest)WebRequest.Create(url);
                // Sends the HttpWebRequest and waits for the response.            
                myHttpWebResponse = (HttpWebResponse)myHttpWebRequest.GetResponse();
                Stream receiveStream = myHttpWebResponse.GetResponseStream();

                Encoding encode = System.Text.Encoding.GetEncoding(encoding);
                // Pipes the stream to a higher level stream reader with the required encoding format. 
                readStream = new StreamReader(receiveStream, encode);

                Char[] read = new Char[512];

                int count = readStream.Read(read, 0, read.Length);
                //int len = 0;
                StringBuilder str = new StringBuilder();
                while (count > 0)
                {
                    str.Append(read, 0, count);
                    count = readStream.Read(read, 0, 512);
                    //int index = str.ToString().IndexOf(judge);
                    //Console.WriteLine(index);
                    if (str.ToString().IndexOf(judge)>0)
                    {
                        result = true;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                Uo.Class.Base.Util.Log.WriteLogEvent("WebTest", System.Diagnostics.EventLogEntryType.Error, ex.Message);
                //throw (new Exception(String.Format("������վ����{0} ��Ϣ��{1}", url, ex.Message)));
            }
            finally
            {
                if (myHttpWebResponse != null)
                    myHttpWebResponse.Close();

                if (readStream != null)
                    readStream.Close();
            }
            return result;
        }

        #region IScan ��Ա

        public void Scan()
        {
            this.ScanTimes++;
            if (this.ScanTimes > 1)//ɨ�賬��һ��
            {
                //PreScanTime = this.ScanTime;//����ǰһ��ɨ��ʱ��
                PreScanResult = this.IsOk;  //����ǰһ��ɨ����
            }
            for (int i = 0; i < 4; i++)
            {
                this.IsOk = Web.WebTest(new Uri(this.Uri),Encoding,Judge);
                if (this.IsOk) break;
            }
            this.ScanTime = DateTime.Now;
            if (!IsOk) this.Err = new Exception("��վ����ʧ��");
        }

        public string ShowInfo()
        {
            return String.Format("IP:{0} ����:{1} ����:{2} �豸����:{3} ����(WEB):{4} WEB��������:{5} �Ƿ�����:{6} \n", Ip, Name.PadRight(20), Jf.PadRight(10), Type.PadRight(10), WebType.PadRight(20), ServerName.PadRight(20), this.IsOk);
        }

        public string[] ShowInfoPro()
        {
            return new String[] { ScanTime.ToLongTimeString(),Ip.ToString(), Name, Jf, Type, WebType, ServerName, this.IsOk.ToString() };
        }

        #endregion



        #region IScan ��Ա


        #endregion

        #region IScan ��Ա


        //public string SmsInfo()
        //{
        //    throw new Exception("The method or operation is not implemented.");
        //}

        #endregion
    }

    public class Server : Sb, IScan
    {
        /// <summary>
        /// MAC��ַ
        /// </summary>
        public string Mac;
        /// <summary>
        /// ������
        /// </summary>
        public string WorkGroup;
        /// <summary>
        /// ����������(��ʽ������ʽ����Ƭ)
        /// </summary>
        private string ServerType;
        /// <summary>
        /// ��������
        /// </summary>
        private string ModeType;
        /// <summary>
        /// ��������ţ����ң�
        /// </summary>
        private string Sn;
        /// <summary>
        /// �����������еĳ���
        /// </summary>
        private object[] Program;

        private object Image;

        private const int timeout = 200;

        public Server()
        {
            throw new System.NotImplementedException();
        }
        /// <summary>
        /// ���캯��
        /// </summary>
        /// <param name="Ip">IP��ַ</param>
        /// <param name="Name">�豸����</param>
        /// <param name="Jf">���ڻ���</param>
        /// <param name="Type">���ͷ������������豸�����ݿ⡢WEBӦ��</param>
        /// <param name="Mac">MAC��ַ</param>
        /// <param name="WorkGroup">������</param>
        /// <param name="ServerType">����������(��ʽ������ʽ����Ƭ)</param>
        /// <param name="ModeType">�������ͱ��</param>
        /// <param name="Sn">��������ţ����ң�</param>
        /// <param name="Program">�����������еĳ���</param>
        public Server(string Id,IPAddress Ip, string Name, string Jf, string Type,string Mac,string WorkGroup,string ServerType,string ModeType,string Sn,object[] Program):base(Id,Ip,Name,Jf,Type)
        {
            this.Mac = Mac;
            this.WorkGroup = WorkGroup;
            this.ServerType = ServerType;
            this.ModeType = ModeType;
            this.Sn = Sn;
            this.Program = Program;
        }
        #region IScan ��Ա

        public Server(IPAddress Ip)
        {
            this.Ip = Ip;
        }

        public void Scan()
        {
            this.ScanTimes++;
            if (this.ScanTimes > 1)//ɨ�賬��һ��
            {
                //PreScanTime = this.ScanTime;//����ǰһ��ɨ��ʱ��
                PreScanResult = this.IsOk;  //����ǰһ��ɨ����
            }
            this.IsOk = false;
            for (int r = 0; r < 4; r++)
            {
                //UDP����
                IPEndPoint lep = new IPEndPoint(this.Ip, 137);
                Socket socket = new Socket(this.Ip.AddressFamily, SocketType.Dgram, ProtocolType.Udp);
                socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.SendTimeout, timeout);
                socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReceiveTimeout, timeout);
                Byte[] Buf = new Byte[500];
                EndPoint senderRemote = (EndPoint)lep;
                try
                {
                    Monitor.Enter(socket);
                    socket.SendTo(_bs, _bs.Length, SocketFlags.None, lep);

                    int size = socket.ReceiveFrom(Buf, ref senderRemote);
                    ArrayList al = new ArrayList();

                    for (int i = 57; i < size; i = i + 18)
                    {
                        if (Buf[i] == 0x00 && Buf[i + 1] == 0x00 && Buf[i + 10] == 0x00) break;

                        byte[] b = new byte[18];
                        for (int n = 0; n < 16; n++)
                        {
                            if (Buf[i + n] == 0x20 && Buf[i + n + 1] == 0x20) break;
                            b[n] = Buf[i + n];
                        }
                        al.Add(b);
                    }

                    if (al[0] != null)
                    {
                        this.IsOk = true;
                        this.ScanTime = DateTime.Now;
                        this.Mac = BitConverter.ToString((Byte[])al[al.Count - 1]).Remove(17);
                        this.Name = Encoding.Default.GetString((Byte[])al[0]).Replace((char)0x00, (char)0x20).TrimEnd();
                        this.WorkGroup = Encoding.Default.GetString((Byte[])al[1]).Replace((char)0x00, (char)0x20).TrimEnd();
                    }
                }
                catch (Exception ex)
                {
                    this.Err = ex;
                    //Uo.Class.Base.Util.Log.WriteLogEvent("Server.Scan", System.Diagnostics.EventLogEntryType.Error, ex.StackTrace);
                }
                finally
                {
                    Monitor.Exit(socket);
                }
                if (this.IsOk) break;

                //Ping�������
                Ping pingSender = new Ping();
                PingOptions options = new PingOptions();
                options.DontFragment = true;

                string data = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
                byte[] buffer = Encoding.ASCII.GetBytes(data);
                try
                {
                    PingReply reply = pingSender.Send(this.Ip, timeout, buffer, options);
                    if (reply.Status == IPStatus.Success)
                    {
                        this.IsOk = true;
                    }
                    else
                    {
                        this.Err = new Exception("UDP&Ping ʧ��");
                    }
                }
                catch (Exception ex)
                {
                    this.Err = ex;
                    //Uo.Class.Base.Util.Log.WriteLogEvent("Server.Scan", System.Diagnostics.EventLogEntryType.Error, ex.StackTrace);
                }
                finally
                {
                    this.ScanTime = DateTime.Now;
                }
                if (this.IsOk) break;
            }
        }

        public string ShowInfo()
        {
            return String.Format("IP:{0} ����:{1} ����:{2} �豸����:{3} MAC:{4} ������:{5} �Ƿ�����:{6} \n", Ip, Name.PadRight(20), Jf.PadRight(10), Type.PadRight(10), Mac.PadRight(20), WorkGroup.PadRight(20), IsOk);
        }

        public string[] ShowInfoPro()
        {
            return new String[] { ScanTime.ToLongTimeString(), Ip.ToString(), Name, Jf, Type, Mac, WorkGroup, IsOk.ToString() };
        }

        #endregion

        private static Byte[] _bs = new Byte[] { 0x0, 0x00, 0x0, 0x10, 0x0, 0x1, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x20, 0x43, 0x4b, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x0, 0x0, 0x21, 0x0, 0x1 };
        public static bool ScanGetInfo(ref Server server,int timeout)
        {
            bool result = false;
            IPEndPoint lep = new IPEndPoint(server.Ip, 137);
            Socket socket = new Socket(server.Ip.AddressFamily, SocketType.Dgram, ProtocolType.Udp);
            socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.SendTimeout, timeout);
            socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReceiveTimeout, timeout);
            Byte[] Buf = new Byte[500];
            EndPoint senderRemote = (EndPoint)lep;
            try
            {
                Monitor.Enter(socket);
                socket.SendTo(_bs, _bs.Length, SocketFlags.None, lep);

                int size = socket.ReceiveFrom(Buf, ref senderRemote);
                ArrayList al = new ArrayList();

                for (int i = 57; i < size; i = i + 18)
                {
                    if (Buf[i] == 0x00 && Buf[i + 1] == 0x00 && Buf[i + 10] == 0x00) break;

                    byte[] b = new byte[18];
                    for (int n = 0; n < 16; n++)
                    {
                        if (Buf[i + n] == 0x20 && Buf[i + n + 1] == 0x20) break;
                        b[n] = Buf[i + n];
                    }
                    al.Add(b);
                }
                
                if (al[0] != null)
                {
                    result = true;
                    server.Mac = BitConverter.ToString((Byte[])al[al.Count - 1]).Remove(17);
                    server.Name = Encoding.Default.GetString((Byte[])al[0]).Replace((char)0x00, (char)0x20).TrimEnd();
                    server.WorkGroup = Encoding.Default.GetString((Byte[])al[1]).Replace((char)0x00, (char)0x20).TrimEnd();
                
                
                }
            }
            catch (Exception ex)
            {
                server.Err = ex;
               // Uo.Class.Base.Util.Log.WriteLogEvent("Server.ScanGetInfo", System.Diagnostics.EventLogEntryType.Error, ex.StackTrace);
                
            }
            finally
            {
                Monitor.Exit(socket);
            }
            server.IsOk = result;
            return result;
        }



        #region IScan ��Ա


        #endregion

        #region IScan ��Ա


        //public string SmsInfo()
        //{
        //    throw new Exception("The method or operation is not implemented.");
        //}

        #endregion
    }
    public interface IScan
    {

        string ShowInfo();

        string SmsInfo();

        string[] ShowInfoPro();
    }

    

    public struct Info
    {
        /// <summary>
        /// ������Ϣ
        /// </summary>
        public String Msg;
        /// <summary>
        /// ������Ϣ
        /// </summary>
        public Exception Err;
        /// <summary>
        /// ָʾ�Ƿ�ɹ�
        /// </summary>
        public bool IsOk;
        /// <summary>
        /// Դ����
        /// </summary>
        public Object SourceObj;
    }
    public class Net : Sb, IScan
    {

        /// <summary>
        /// �豸����(Router:Switch)
        /// </summary>
        private string SbType;
        /// <summary>
        /// �豸�ͺ�
        /// </summary>
        private string ModeType;
        private object Image;
        private StringBuilder Config;
        private long RoundtripTime;
        private static int timeout = 100;
        /// <summary>
        /// ���캯��
        /// </summary>
        /// <param name="Ip">IP��ַ</param>
        /// <param name="Name">�豸����</param>
        /// <param name="Jf">���ڻ���</param>
        /// <param name="Type">���ͷ������������豸�����ݿ⡢WEBӦ�á������豸</param>
        /// <param name="SbType">�豸����:˼�ơ���Ϊ������������</param>
        /// <param name="ModeType">�豸�ͺ�</param>
        /// <param name="Config">�豸�����ļ�</param>
        /// <param name="Image">�豸ͼƬ</param>
        public Net(String Id,IPAddress Ip, string Name, string Jf, string Type, string SbType, string ModeType, StringBuilder Config, object Image)
            : base(Id,Ip, Name, Jf, Type)
        {
            this.SbType = SbType;
            this.ModeType = ModeType;
            this.Config = Config;
            this.Image = Image;
        }

        public Net()
        {
            throw new System.NotImplementedException();
        }
        #region IScan ��Ա

        public void Scan()
        {
            this.ScanTimes++;
            if (this.ScanTimes > 1)//ɨ�賬��һ��
            {
                //PreScanTime = this.ScanTime;//����ǰһ��ɨ��ʱ��
                PreScanResult = this.IsOk;  //����ǰһ��ɨ����
            }
            this.IsOk = false;
            Ping pingSender = new Ping();
            PingOptions options = new PingOptions();
            options.DontFragment = true;

            string data = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
            byte[] buffer = Encoding.ASCII.GetBytes(data);
            
                try
                {
                    for (int i = 0; i < 4; i++)
                    {
                        PingReply reply = pingSender.Send(this.Ip, timeout, buffer, options);
                        if (reply.Status == IPStatus.Success)
                        {
                            this.RoundtripTime = reply.RoundtripTime;

                            this.IsOk = true;
                        }
                        else
                        {
                            this.Err = new Exception("Ping ʧ��");
                        }
                        if (IsOk) break;
                    }
                }
                catch (Exception ex)
                {
                    this.Err = ex;
                    Uo.Class.Base.Util.Log.WriteLogEvent("Net.Scan", System.Diagnostics.EventLogEntryType.Error, ex.StackTrace);
                }
                finally
                {
                    this.ScanTime = DateTime.Now;
                }
            
            
        }

        public string ShowInfo()
        {
            return String.Format("IP:{0} ����:{1} ����:{2} �豸����:{3} �豸����:{4} �豸�ͺ�:{5} �Ƿ�����:{6} \n", Ip, Name.PadRight(20), Jf.PadRight(10), Type.PadRight(10), SbType.PadRight(20), ModeType.PadRight(20), IsOk);
        }

        public string[] ShowInfoPro()
        {
            return new String[] { ScanTime.ToLongTimeString(), Ip.ToString(), Name, Jf, Type, SbType, ModeType, IsOk.ToString() };
        }

        #endregion


        #region IScan ��Ա


        #endregion

        #region IScan ��Ա


        //public string SmsInfo()
        //{
        //    throw new Exception("The method or operation is not implemented.");
        //}

        #endregion
    }

    public class Equipment : Sb, IScan
    {

        /// <summary>
        /// �豸����(Smscat:�յ�:������:KVM��)
        /// </summary>
        private string SbType;
        /// <summary>
        /// �豸�ͺ�
        /// </summary>
        private string ModeType;
        /// <summary>
        /// �豸��;ע��
        /// </summary>
        private string Remark;

        private object Image;

        /// <summary>
        /// ���캯��
        /// </summary>
        /// <param name="Ip">IP��ַ</param>
        /// <param name="Name">�豸����</param>
        /// <param name="Jf">���ڻ���</param>
        /// <param name="Type">���ͷ������������豸�����ݿ⡢WEBӦ�á������豸</param>
        /// <param name="SbType">�����豸���ͣ�Smscat:�յ�:������:KVM��</param>
        /// <param name="ModeType">�豸�ͺ�</param>
        /// <param name="Remark">�豸��;ע��</param>
        /// <param name="Image">�豸ͼƬ</param>
        public Equipment(string Id,IPAddress Ip, string Name, string Jf, string Type,string SbType,string ModeType,string Remark,object Image):base(Id,Ip,Name,Jf,Type)
        {
            this.SbType = SbType;
            this.ModeType = ModeType;
            this.Remark = Remark;
            this.Image = Image;
        }
        public Equipment()
        {
            throw new System.NotImplementedException();
        }
        #region IScan ��Ա

        public void Scan()
        {
            this.ScanTimes++;
            if (this.ScanTimes > 1)//ɨ�賬��һ��
            {
                //PreScanTime = this.ScanTime;//����ǰһ��ɨ��ʱ��
                PreScanResult = this.IsOk;  //����ǰһ��ɨ����
            }
        }

        public string ShowInfo()
        {
            throw new Exception("The method or operation is not implemented.");
        }
        public string[] ShowInfoPro()
        {
            return null;
        }

        #endregion

        #region IScan ��Ա


        #endregion

        #region IScan ��Ա


        //public string SmsInfo()
        //{
        //    throw new Exception("The method or operation is not implemented.");
        //}

        #endregion
    }

    
}
