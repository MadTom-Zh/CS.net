﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Uo.Class.Gc.Crc
{
    using System;

    



        public class CRC16
        {
            /// <summary>
            /// 计算CRC16校验码
            ///     int crc = CRC.CRC16.CRCCalc(w_buffer, w_buffer.Length - 2);
            ///     w_buffer[w_buffer.Length - 2] = (byte)((crc >> 8) & 0xff);
            ///     w_buffer[w_buffer.Length - 1] = (byte)((crc & 0xff));
            /// </summary>
            /// <param name="crcbuf">计算数据</param>
            /// <param name="len">数据长度</param>
            /// <returns>返回值</returns>
            public static int CRCCalc(byte[] crcbuf, int len)
            {
                int crc = 0xffff;
                for (int n = 0; n < len; n++)
                {
                    byte i;
                    crc = crc ^ crcbuf[n];
                    for (i = 0; i < 8; i++)
                    {
                        int TT;
                        TT = crc & 1;
                        crc = crc >> 1;
                        crc = crc & 0x7fff;
                        if (TT == 1)
                            crc = crc ^ 0xa001;
                        crc = crc & 0xffff;
                    }
                }
                return crc;
            }

            /// <summary>
            /// 计算CRC16校验码
            /// </summary>
            /// <param name="crcbuf">需计算数据，包含需要填入校验码的两位字节</param>
            /// <returns>返回已经计算好的整个校验数据</returns>
            public static byte[] CRCCalc(byte[] crcbuf)
            {
                int crc = 0xffff;
                int len = crcbuf.Length - 2;
                for (int n = 0; n < len; n++)
                {
                    byte i;
                    crc = crc ^ crcbuf[n];
                    for (i = 0; i < 8; i++)
                    {
                        int TT;
                        TT = crc & 1;
                        crc = crc >> 1;
                        crc = crc & 0x7fff;
                        if (TT == 1)
                            crc = crc ^ 0xa001;
                        crc = crc & 0xffff;
                    }
                }
                crcbuf[len + 1] = (byte)((crc >> 8) & 0xff);
                crcbuf[len] = (byte)((crc & 0xff));
                return crcbuf;
            }
            /// <summary>
            /// 进行CRC交验
            /// </summary>
            /// <param name="buffer">需要交验的数据</param>
            /// <returns>返回true为交验成功</returns>
            public static bool CRC16Check(byte[] buffer)
            {
                UInt16 CRC = 0xFFFF, temp = 0xA001;
                for (int k = 0; k < buffer.Length; k++)
                {
                    CRC ^= buffer[k];
                    for (int i = 0; i < 8; i++)
                    {
                        int j = CRC & 1;
                        CRC >>= 1;
                        CRC &= 0x7FFF;
                        if (j == 1)
                            CRC ^= temp;
                    }
                }
                return (CRC == 0) ? true : false;
            }
        }
    } 




