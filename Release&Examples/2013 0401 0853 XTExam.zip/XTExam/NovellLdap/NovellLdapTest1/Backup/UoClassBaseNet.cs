using System;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Remoting.Messaging;
using System.Threading;
using System.Text;
using System.Collections;
using System.IO;

namespace Uo.Class.Base.Net
{
    public class Net
	{
        public static Byte[] bs = new Byte[]{0x0,0x00,0x0,0x10,0x0,0x1,0x0,0x0,0x0,0x0,0x0,0x0,0x20,0x43,0x4b,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x41,0x0,0x0,0x21,0x0,0x1};
        public static PcInfo GetPcInfo(IPAddress ip, int timeout)
        {
            PcInfo info = new PcInfo();
            info.ip = ip;
            IPEndPoint lep = new IPEndPoint(ip,137);
            Socket socket = new Socket(ip.AddressFamily, SocketType.Dgram, ProtocolType.Udp);
            socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.SendTimeout, timeout);
            socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReceiveTimeout, timeout);
            Byte[] Buf = new Byte[500];
            EndPoint senderRemote = (EndPoint)lep;
            try
            {
                Monitor.Enter(socket);
                socket.SendTo(bs, bs.Length, SocketFlags.None, lep);

                int size = socket.ReceiveFrom(Buf, ref senderRemote);
                ArrayList al = new ArrayList();

                for (int i = 57; i < size; i = i + 18)
                {
                    if (Buf[i] == 0x00 && Buf[i + 1] == 0x00 && Buf[i + 10] == 0x00) break;

                    byte[] b = new byte[18];
                    for (int n = 0; n < 16; n++)
                    {
                        if (Buf[i + n] == 0x20 && Buf[i + n + 1] == 0x20) break;
                        b[n] = Buf[i + n];
                    }
                    al.Add(b);
                    //als.Add(Encoding.Default.GetString(b).Replace((char)0x00, (char)0x20));
                }
                info.IsOk = true;
                info.buf = al;
            }
            catch (Exception ex)
            {
                info.Error = ex;
                info.IsOk = false;
            }
            finally
            {
                Monitor.Exit(socket);
            }

            return info;
        }
        public static string WEBTest(Uri url)
        {
            String result = null;
            HttpWebResponse myHttpWebResponse = null;
            StreamReader readStream = null;
            try
            {
                // Creates an HttpWebRequest with the specified URL. 
                HttpWebRequest myHttpWebRequest = (HttpWebRequest)WebRequest.Create(url);
                // Sends the HttpWebRequest and waits for the response.            
                myHttpWebResponse = (HttpWebResponse)myHttpWebRequest.GetResponse();
                Stream receiveStream = myHttpWebResponse.GetResponseStream();

                Encoding encode = System.Text.Encoding.GetEncoding("GB2312");
                // Pipes the stream to a higher level stream reader with the required encoding format. 
                readStream = new StreamReader(receiveStream, encode);

                Char[] read = new Char[512];

                int count = readStream.Read(read, 0, 512);

                while (count > 0)
                {
                    String str = new String(read, 0, count);

                    result = result + str;
                    count = readStream.Read(read, 0, 512);
                }
            }
            catch (Exception ex)
            {
                throw (new Exception(String.Format("������վ����{0} ��Ϣ��{1}", url, ex.Message)));
            }
            finally
            {
                if (myHttpWebResponse != null)
                    myHttpWebResponse.Close();

                if (readStream != null)
                    readStream.Close();
            }
            return result;
        }
        public static String[] ListIp(String startipString, String endipString)
        {
            String[] listip;
            String[] array_startipString, array_endipString;
            array_startipString = startipString.Split(".".ToCharArray(0, 1));
            array_endipString = endipString.Split(".".ToCharArray(0, 1));
            try
            {
                long[] int_startipString = new long[] { Convert.ToInt64(array_startipString[0]), Convert.ToInt64(array_startipString[1]), Convert.ToInt64(array_startipString[2]), Convert.ToInt64(array_startipString[3]) };
                long[] int_endipString = new long[] { Convert.ToInt64(array_endipString[0]), Convert.ToInt64(array_endipString[1]), Convert.ToInt64(array_endipString[2]), Convert.ToInt64(array_endipString[3]) };

                long n = (int_endipString[3] - int_startipString[3]) + (int_endipString[2] - int_startipString[2]) * 255 + 1;
                if (!(n < 2000 && (int_endipString[1] - int_startipString[1]) == 0 && (int_endipString[0] - int_startipString[0]) == 0))
                {
                    throw (new Exception("ϵͳֻ����IP��ַ�����λ��\n����IP��ַ̫�࣬��ϵͳ�ܾ�����"));
                }
                listip = new String[n];

                for (long i = 0; i < n; i++)
                {
                    long m = int_startipString[3] + i;
                    long[] s = new long[4];
                    if (m < 256)
                    {
                        s[3] = m;
                        s[2] = int_startipString[2];
                        s[1] = int_startipString[1];
                        s[0] = int_startipString[0];
                    }
                    else
                    {
                        s[3] = m % 255;
                        long ls1 = int_startipString[2] + Convert.ToInt32((m / 255));
                        if (s[3] == 0)
                        {
                            Console.WriteLine(s.ToString());
                        }
                        if (ls1 < 256)
                        {
                            if (s[3] == 0)
                            {
                                s[3] = 255;
                                s[2] = ls1 - 1;
                                s[1] = int_startipString[1];
                                s[0] = int_startipString[0];
                            }
                            else
                            {
                                s[2] = ls1;
                                s[1] = int_startipString[1];
                                s[0] = int_startipString[0];
                            }
                        }
                        else
                        {
                            return null;
                        }
                    }
                    listip[i] = Convert.ToString(s[0]) + "." + Convert.ToString(s[1]) + "." + Convert.ToString(s[2]) + "." + Convert.ToString(s[3]);
                }
                return listip;
            }
            catch (Exception ex)
            {
                throw (new Exception("�����������IP��ʼ����ֹ��ַ�Ƿ���ȷ��\n" + ex.Message));
            }
        }

        public static string TelnetSc(IPAddress ip,int port, int timeout)
        {
            //PcInfo info = new PcInfo();
            //info.ip = ip;
            IPEndPoint lep = new IPEndPoint(ip, port);
            Socket socket = new Socket(ip.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
            socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.SendTimeout, timeout);
            socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReceiveTimeout, timeout);
            Byte[] Buf = new Byte[500];
            EndPoint senderRemote = (EndPoint)lep;
            try
            {
                Monitor.Enter(socket);
                socket.Connect(senderRemote);
                socket.SendTo(bs, bs.Length, SocketFlags.None, lep);

                socket.ReceiveFrom(Buf, ref senderRemote);
                
                //ArrayList al = new ArrayList();
                //ArrayList als = new ArrayList();

                //for (int i = 0; i < 500; i++)
                //{
                    
                    //if (Buf[i] == 0x00 && Buf[i + 1] == 0x00 && Buf[i + 10] == 0x00) break;

                    //byte[] b = new byte[18];
                    //for (int n = 0; n < 18; n++)
                    //{
                    //    if (Buf[i + n] == 0x20) break;
                    //    b[n] = Buf[i + n];
                    //}
                    //al.Add(b);
                    //als.Add(Encoding.Default.GetString(b).Replace((char)0x00, (char)0x20));
                //}

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                
                socket.Disconnect(false);
                Monitor.Exit(socket);
            }

            return Encoding.Default.GetString(Buf);
        }
    }

    public struct PcInfo
    {
        public bool IsOk;           //�Ƿ�õ�����
        public IPAddress ip;        //IP��ַ
        public Exception Error;     //����
        public ArrayList buf;       //��������

        public string MAC //MAC��ַ
        {
            get
            {
                return buf[0] != null ? BitConverter.ToString((Byte[])buf[buf.Count - 1]).Remove(17):"";
            }
        }

        public string PcName //����
        {
            get
            {
                return buf[0] != null ? Encoding.Default.GetString((Byte[])buf[0]).Replace((char)0x00, (char)0x20).TrimEnd():"";
            }
        }
        public string WorkGroup //������
        {
            get
            {
                return buf[0] != null ? Encoding.Default.GetString((Byte[])buf[1]).Replace((char)0x00, (char)0x20).TrimEnd():"";
            }
        }

        public string User //������:������
        {
            get
            {
                if (buf[0] != null) return "";
                switch (buf.Count )
                {
                    case 3:
                        return "";
                    case 4:
                        return Encoding.Default.GetString((Byte[])buf[2]).Replace((char)0x00, (char)0x20).Trim();
                    default:
                        return Encoding.Default.GetString((Byte[])buf[2]).Replace((char)0x00, (char)0x20).Trim() + "\\" + Encoding.Default.GetString((Byte[])buf[3]).Replace((char)0x00, (char)0x20).Trim();
                }               
            }
        }


    }
	

    //public class Ping
    //{
    //    const int SOCKET_ERROR = -1;         
    //    const int ICMP_ECHO = 8; 
    //    public Ping()
    //    {
    //    }
		
    //    public static PingContent GetIP(String hostName)
    //    {
    //        PingContent pingContent=new PingContent();
    //        pingContent.HostName=hostName;
    //        pingContent.Result=false;
    //        IPHostEntry myHost=new IPHostEntry();
    //        if(hostName!=null && hostName!="")
    //        {
    //            try
    //            {
    //                myHost=Dns.Resolve(hostName);
    //                pingContent.Ip=myHost.AddressList;
    //                if(myHost.AddressList.Length>0)
    //                {
    //                    pingContent.Result=true;
    //                }
    //                pingContent.Message="�ɹ����������IP��ַ";
    //            }
    //            catch(Exception ex)
    //            {
    //                pingContent.Message="���������IP����\n"+ex.Message;
    //            }
    //        }
    //        else
    //        {
    //            pingContent.Message="����������������";
    //        }
    //        return pingContent;
    //    }
    //    public static PingContent GetHostName(String ip)
    //    {
    //        PingContent pingContent=new PingContent();
    //        pingContent.Result=false;
    //        if(ip!=null && ip!="")
    //        {
    //            try
    //            {
    //                IPAddress myIP = IPAddress.Parse(ip);
    //                IPHostEntry myHost = Dns.GetHostByAddress(myIP);
    //                pingContent.Ip=myHost.AddressList;
    //                pingContent.HostName=myHost.HostName;
    //                pingContent.Message="����IP��ַ "+pingContent.Ip +"  �������Ϊ"+pingContent.HostName;
    //                pingContent.Result=true;
    //            }
    //            catch(Exception ex)
    //            {
    //                pingContent.Message="IP��ַ "+ip +"���������������\n"+ex.Message;
    //            }
    //        }
    //        else
    //        {
    //            pingContent.Message="������IP��ַ!!";
    //        }
    //        return pingContent;
    //    }
    //    public static PingContent PingHost(string hostName,int dataSize) 
    //    { 
    //        PingContent pingContent=new PingContent();
    //        pingContent.Result=false;
    //        pingContent.HostName=hostName;
    //        IPHostEntry serverHE, fromHE; 
    //        int nBytes = 0; 
    //        int dwStart = 0;
    //        Socket socket =new Socket(new AddressFamily(), SocketType.Raw, ProtocolType.Icmp); 
    //        try 
    //        { 
    //            serverHE = Dns.GetHostByName(hostName);  
    //        } 
    //        catch(Exception) 
    //        { 
    //            pingContent.Message="����� "+hostName+" �޷�����IP��ַ��";
    //            return pingContent; 
    //        }
    //        IPEndPoint ipepServer = new IPEndPoint(serverHE.AddressList[0], 0); 
    //        EndPoint epServer = (ipepServer);  
    //        pingContent.Ip=serverHE.AddressList;
    //        fromHE = Dns.GetHostByName(Dns.GetHostName()); 
    //        IPEndPoint ipEndPointFrom = new IPEndPoint(fromHE.AddressList[0], 0);         
    //        EndPoint EndPointFrom = (ipEndPointFrom); 
    //        int PacketSize = 0; 
    //        IcmpPacket packet = new IcmpPacket(); 
    //        packet.Type = ICMP_ECHO; 
    //        packet.SubCode = 0; 
    //        packet.CheckSum = UInt16.Parse("0"); 
    //        packet.Identifier   = UInt16.Parse("45");  
    //        packet.SequenceNumber  = UInt16.Parse("0");  
    //        packet.Data = new Byte[dataSize]; 
    //        for (int i = 0; i < dataSize; i++) 
    //        { 
    //            packet.Data[i] = (byte)'#'; 
    //        } 
    //        PacketSize = dataSize + 8; 
    //        Byte [] icmp_pkt_buffer = new Byte[ PacketSize ];  
    //        Int32 index = 0; 
    //        index = Serialize(packet,icmp_pkt_buffer,PacketSize,dataSize); 
    //        if( index == -1 ) 
    //        { 
    //            pingContent.Message="Error in Making Packet";
    //            return pingContent; 
    //        } 
    //        Double double_length = Convert.ToDouble(index); 
    //        Double dtemp = Math.Ceiling( double_length / 2);  
    //        int cksum_buffer_length = Convert.ToInt32(dtemp); 
    //        UInt16 [] cksum_buffer = new UInt16[cksum_buffer_length]; 
    //        int icmp_header_buffer_index = 0; 
    //        for( int i = 0; i < cksum_buffer_length; i++ ) 
    //        { 
    //            cksum_buffer[i] =  
    //                BitConverter.ToUInt16(icmp_pkt_buffer,icmp_header_buffer_index); 
    //            icmp_header_buffer_index += 2; 
    //        }              
    //        UInt16 u_cksum = checksum(cksum_buffer, cksum_buffer_length); 
    //        packet.CheckSum  = u_cksum;  
    //        Byte [] sendbuf = new Byte[ PacketSize ];  
    //        index = Serialize(packet,sendbuf,PacketSize,dataSize ); 
    //        if( index == -1 ) 
    //        {  
    //            pingContent.Message="�������ݰ��������"; 
    //            return pingContent; 
    //        } 
    //        pingContent.SendSize=PacketSize;
    //        int RecBuf=PacketSize+20;
    //        dwStart = System.Environment.TickCount;
    //        if ((nBytes = socket.SendTo(sendbuf, PacketSize, 0, epServer)) == SOCKET_ERROR)  
    //        {   
    //            pingContent.Message="Socket Error���ܷ������ݰ�";
    //            return pingContent; 
    //        }
    //        Byte [] ReceiveBuffer = new Byte[RecBuf];  
    //        int timeout=0;
    //        nBytes=0;
    //        nBytes = socket.ReceiveFrom(ReceiveBuffer, RecBuf,0 , ref EndPointFrom); 
    //        timeout=System.Environment.TickCount - dwStart; 
    //        socket.Close();  
    //        if(timeout>1000) 
    //        { 
    //            pingContent.Message="���糬ʱ";
    //            pingContent.ReceiveSize=nBytes;
    //            return pingContent;
    //        }
    //        if(nBytes>8) 
    //        { 
    //            pingContent.SpaceTime=timeout;
    //            pingContent.ReceiveSize=nBytes;
    //            pingContent.Result=true;
    //            pingContent.Message="��Զ�̼������"+hostName+" IP "+epServer.ToString()+"����"+PacketSize+" ����"+nBytes+"�ֽڣ���ʱ" 
    //                +timeout+"MS";
    //            return pingContent;
    //        }
    //        else
    //        {
    //            pingContent.Message="�����û�лش�";
    //            return pingContent; 
    //        }
    //    } 
    //    public static Int32 Serialize(IcmpPacket icmpPacket, Byte[] buffer,Int32 packetSize, Int32 dataSize ) 
    //    { 
    //        Int32 cbReturn = 0; 
    //        // serialize the struct into the array 
    //        int index=0; 

    //        Byte [] b_type = new Byte[1]; 
    //        b_type[0] = (icmpPacket.Type); 

    //        Byte [] b_code = new Byte[1]; 
    //        b_code[0] = (icmpPacket.SubCode); 

    //        Byte [] b_cksum = BitConverter.GetBytes(icmpPacket.CheckSum); 
    //        Byte [] b_id = BitConverter.GetBytes(icmpPacket.Identifier); 
    //        Byte [] b_seq = BitConverter.GetBytes(icmpPacket.SequenceNumber); 
         
    //        // Console.WriteLine("Serialize type "); 
    //        Array.Copy( b_type, 0, buffer, index, b_type.Length ); 
    //        index += b_type.Length; 
         
    //        // Console.WriteLine("Serialize code "); 
    //        Array.Copy( b_code, 0, buffer, index, b_code.Length ); 
    //        index += b_code.Length; 

    //        // Console.WriteLine("Serialize cksum "); 
    //        Array.Copy( b_cksum, 0, buffer, index, b_cksum.Length ); 
    //        index += b_cksum.Length; 

    //        // Console.WriteLine("Serialize id "); 
    //        Array.Copy( b_id, 0, buffer, index, b_id.Length ); 
    //        index += b_id.Length; 

    //        Array.Copy( b_seq, 0, buffer, index, b_seq.Length ); 
    //        index += b_seq.Length; 

    //        // copy the data          
    //        Array.Copy( icmpPacket.Data, 0, buffer, index, dataSize ); 
    //        index += dataSize; 
    //        if( index != packetSize/* sizeof(IcmpPacket)  */) 
    //        { 
    //            cbReturn = -1; 
    //            return cbReturn; 
    //        } 

    //        cbReturn = index; 
    //        return cbReturn; 
    //    } 
    //    public static UInt16 checksum( UInt16[] buffer, int size ) 
    //    { 
    //        Int32 cksum = 0; 
    //        int counter = 0; 

    //        while ( size > 0 ) 
    //        { 
    //            UInt16 val = buffer[counter]; 

    //            cksum += Convert.ToInt32( buffer[counter] ); 
    //            counter += 1; 
    //            size -= 1; 
    //        } 

    //        cksum = (cksum >> 16) + (cksum & 0xffff); 
    //        cksum += (cksum >> 16); 
    //        return (UInt16)(~cksum); 
    //    } 
    //}
    //public struct PingContent
    //{
    //    public String Message;		//���Խ��
    //    public IPAddress[] Ip;
    //    public String HostName;		
    //    public int    SpaceTime;	
    //    public int    ReceiveSize;		
    //    public int    SendSize;
    //    public bool   Result;
    //}
    //public class IcmpPacket  
    //{  
    //    public Byte  Type;    // type of message 
    //    public Byte  SubCode;    // type of sub code 
    //    public UInt16 CheckSum;   // ones complement checksum of struct 
    //    public UInt16 Identifier;      // identifier 
    //    public UInt16 SequenceNumber;     // sequence number   
    //    public Byte [] Data; 
    //} 
	
}
