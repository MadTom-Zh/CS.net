﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using Novell.Directory.Ldap;

namespace NovellLdapTools
{
    public partial class FormQx_Nx : Form
    {
        public FormQx_Nx()
        {
            InitializeComponent();
        }

        public FormQx_Nx(DataTable dt)
        {
            InitializeComponent();
            this.dataGridView_Qx.DataSource = dt;
        }
        

        private void button_Read_Click(object sender, EventArgs e)
        {
            string strConn;
            if (this.openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string FilePath = openFileDialog1.FileName;
                strConn = "Provider=Microsoft.Jet.OLEDB.4.0;" + "Data Source=" + FilePath + ";Extended Properties=Excel 8.0;";
                OleDbConnection conn = new OleDbConnection(strConn);
                OleDbDataAdapter myCommand = new OleDbDataAdapter("SELECT * FROM [Sheet1$]", strConn);
                DataSet myDataSet = new DataSet();
                try
                {
                    myCommand.Fill(myDataSet);
                    DataTable dt = myDataSet.Tables[0];
                    this.dataGridView_Qx.DataSource = dt;
                    MainForm.dt_Qx = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }

            }

        }

        private void button_List_Click(object sender, EventArgs e)
        {
            StringBuilder str = new StringBuilder();
            for (int i = 0; i < this.dataGridView_Qx.SelectedRows.Count; i++)
            {
                for(int l = 0;l<dataGridView_Qx.SelectedRows[i].Cells.Count;l++)
                {
                    
                    str.Append(this.dataGridView_Qx.SelectedRows[i].Cells[l].Value.ToString());
                }
                
                Console.WriteLine(this.dataGridView_Qx.SelectedRows[i].Cells["用户编码:cn"].Value.ToString());
                
                str.Append("\n");
            }
            this.richTextBox_Show.Text = str.ToString();
        }

        private void button_Set_Click(object sender, EventArgs e)
        {
            string host = "10.216.247.20";
            string logindn = "cn=root,o=services";
            string pswd = "n0v3ll";

            //string host = "10.217.2.213";
            //string logindn = "cn=root,o=services";
            //string pswd = "xtfgs00544";

            string dn = "ou=NX,o=SGCC";
            string dn_one="";
            string fullname = "";
            string sgccdeptname = "";
            
            LdapConnection conn = new LdapConnection();
            try
            {
                conn.Connect(host, LdapConnection.DEFAULT_PORT);
                conn.Bind(LdapConnection.Ldap_V3, logindn, pswd);

                for (int i = 0; i < this.dataGridView_Qx.SelectedRows.Count; i++)
                {

                    System.Collections.ArrayList modList = new System.Collections.ArrayList();
                    string cn = this.dataGridView_Qx.SelectedRows[i].Cells["用户编码:cn"].Value.ToString();
                     dn_one= "CN=" + cn + "," + dn;
                    
                    fullname = this.dataGridView_Qx.SelectedRows[i].Cells["用户名称:fullname"].Value.ToString();
                    sgccdeptname = this.dataGridView_Qx.SelectedRows[i].Cells["岗位名称:deptname"].Value.ToString();
                    
                    //string nxCOALoginEnable = this.dataGridView_Qx.SelectedRows[i].Cells["协同办公:nxCOALoginEnable"].Value.ToString();
                    string nxSAPEPLoginEnable = this.dataGridView_Qx.SelectedRows[i].Cells["企业资源计划:nxSAPEPLoginEnable"].Value.ToString();
                    //string nxMWLoginEnable = this.dataGridView_Qx.SelectedRows[i].Cells["生产管理:nxMWLoginEnable"].Value.ToString();
                    //string nxAQJDLoginEnable = this.dataGridView_Qx.SelectedRows[i].Cells["安全监督:nxAQJDLoginEnable"].Value.ToString();
                    string nxDC2LoginEnable = this.dataGridView_Qx.SelectedRows[i].Cells["数据中心:nxDC2LoginEnable"].Value.ToString();
                    //string nxYJZHLoginEnable = this.dataGridView_Qx.SelectedRows[i].Cells["应急指挥:nxYJZHLoginEnable"].Value.ToString();
                    //string nxSCTJLoginEnable = this.dataGridView_Qx.SelectedRows[i].Cells["生产统计:nxSCTJLoginEnable"].Value.ToString();
                    //string nxYXFZJCLoginEnable = this.dataGridView_Qx.SelectedRows[i].Cells["营销辅助决策:nxYXFZJCLoginEnable"].Value.ToString();
                    //string nxBIDLoginEnable = this.dataGridView_Qx.SelectedRows[i].Cells["招投标:nxBIDLoginEnable"].Value.ToString();
                    //string nxTZJHLoginEnable = this.dataGridView_Qx.SelectedRows[i].Cells["投资计划:nxTZJHLoginEnable"].Value.ToString();
                    //string nxHRGKLoginEnable = this.dataGridView_Qx.SelectedRows[i].Cells["人资管控:nxHRGKLoginEnable"].Value.ToString();
                    //string nxSJGLLoginEnable = this.dataGridView_Qx.SelectedRows[i].Cells["审计管理:nxSJGLLoginEnable"].Value.ToString();
                    //string nxZHJHLoginEnable = this.dataGridView_Qx.SelectedRows[i].Cells["综合计划:nxZHJHLoginEnable"].Value.ToString();
                    //string nxGJHZLoginEnable = this.dataGridView_Qx.SelectedRows[i].Cells["国际合作:nxGJHZLoginEnable"].Value.ToString();
                    //string nxHRFZJCLoginEnable = this.dataGridView_Qx.SelectedRows[i].Cells["人资辅助决策:nxHRFZJCLoginEnable"].Value.ToString();

                    //modList.Add(new LdapAttribute("nxMWAccount", cn));
                    //modList.Add(new LdapAttribute("nxMWLoginEnable", nxMWLoginEnable));
                    //modList.Add(new LdapAttribute("uid", cn));
                    //modList.Add(new LdapAttribute("nxCOAAccount", cn));
                    //modList.Add(new LdapAttribute("nxCOALoginEnable", nxCOALoginEnable));
                    //modList.Add(new LdapAttribute("COA1LoginEnable", nxCOALoginEnable));
                    //modList.Add(new LdapAttribute("nxHRGKLoginEnable", nxHRGKLoginEnable));
                    //modList.Add(new LdapAttribute("nxYJZHLoginEnable", nxYJZHLoginEnable));
                    modList.Add(new LdapAttribute("nxSAPEPLoginEnable", nxSAPEPLoginEnable));
                    //modList.Add(new LdapAttribute("nxYXFZJCLoginEnable", nxYXFZJCLoginEnable));
                    //modList.Add(new LdapAttribute("nxHRFZJCLoginEnable", nxHRFZJCLoginEnable));
                    //modList.Add(new LdapAttribute("nxZHJHLoginEnable", nxZHJHLoginEnable));
                    //modList.Add(new LdapAttribute("nxGJHZLoginEnable", nxGJHZLoginEnable));
                    //modList.Add(new LdapAttribute("nxSJGLLoginEnable", nxSJGLLoginEnable));
                    //modList.Add(new LdapAttribute("nxSCTJLoginEnable", nxSCTJLoginEnable));
                    //modList.Add(new LdapAttribute("nxAQJDLoginEnable", nxAQJDLoginEnable));
                    modList.Add(new LdapAttribute("nxDC2LoginEnable", nxDC2LoginEnable));
                    //modList.Add(new LdapAttribute("nxBIDLoginEnable", nxBIDLoginEnable));
                    //modList.Add(new LdapAttribute("nxTZJHLoginEnable", nxTZJHLoginEnable));

                    LdapSearchResults lsc = conn.Search(dn_one,
                                                         LdapConnection.SCOPE_SUB,
                                                         "",
                                                         null,
                                                         false);
                    LdapEntry nextEntry = null;
                    try
                    {
                        nextEntry = lsc.next();
                        LdapAttributeSet attributeSet = nextEntry.getAttributeSet();
                        LdapAttribute attribute_cn = attributeSet.getAttribute("CN");

                        StringBuilder xg = new StringBuilder();
                        for (int l = 0; l < modList.Count; l++)
                        {
                            String name = ((LdapAttribute)modList[l]).Name;
                            String value = ((LdapAttribute)modList[l]).StringValue;
                            LdapAttribute attribute = attributeSet.getAttribute(name);

                            if (attribute != null)
                            {
                                conn.Modify(dn_one, new LdapModification(LdapModification.REPLACE, (LdapAttribute)modList[l]));
                                xg.Append("\n属性: " + dn_one + ":" + name + "---" + value + "---修改成功！\n");
                            }
                            else
                            {
                                conn.Modify(dn_one, new LdapModification(LdapModification.ADD, (LdapAttribute)modList[l]));
                                xg.Append("\n属性: " + dn_one + ":" + name + "---" + value + "---添加成功！\n");
                            }
                            
                        }
                        //richTextBox_Show.Text = richTextBox_Show.Text + fullname + "  " + sgccdeptname + "   "+dn_one+"操作成功！\n";
                        //MessageBox.Show("修改结果 \n" + xg);
                    }
                    catch (Exception ex1)
                    {
                        String err = "Error1:  " + fullname + "  " + sgccdeptname +"    " +dn_one + "    " + ex1.Message + "\n";
                        richTextBox_Show.Text = richTextBox_Show.Text + err;
                        MessageBox.Show(err);
                        continue;
                    }
                }
            }
            catch (Exception ex2)
            {
                String err = "Error2:  " + fullname + "  " + sgccdeptname + "    " + dn_one + "    " + ex2.Message + "\n";
                richTextBox_Show.Text = richTextBox_Show.Text + err;
                MessageBox.Show(err);
            }
            finally
            {
                conn.Disconnect();
            }
        }

        
        
    }
}
