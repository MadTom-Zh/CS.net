﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Novell.Directory.Ldap;
using Novell.Directory.Ldap.Utilclass;
using System.IO;
using System.Data.OleDb;

namespace NovellLdapTools
{
    public partial class MainForm : Form
    {
        internal static string ROOT_NAME = Uo.Class.Base.Util.AppConfig.GetValue("ROOT_NAME");  //主机

        internal static string QYZY_TREE_LDAPHOST = Uo.Class.Base.Util.AppConfig.GetValue("QYZY_TREE_LDAPHOST");  //主机
        internal static string QYZY_TREE_LOGINDN = Uo.Class.Base.Util.AppConfig.GetValue("QYZY_TREE_LOGINDN");  //
        internal static string QYZY_TREE_PASSWORD = Uo.Class.Base.Util.AppConfig.GetValue("QYZY_TREE_PASSWORD");  //密码
        internal static string QYZY_TREE_SEARCHBASE = Uo.Class.Base.Util.AppConfig.GetValue("QYZY_TREE_SEARCHBASE");  //搜索根

        internal static string SF_TREE_LDAPHOST = Uo.Class.Base.Util.AppConfig.GetValue("SF_TREE_LDAPHOST");  //主机
        internal static string SF_TREE_LOGINDN = Uo.Class.Base.Util.AppConfig.GetValue("SF_TREE_LOGINDN");  //
        internal static string SF_TREE_PASSWORD = Uo.Class.Base.Util.AppConfig.GetValue("SF_TREE_PASSWORD");  //密码
        internal static string SF_TREE_SEARCHBASE = Uo.Class.Base.Util.AppConfig.GetValue("SF_TREE_SEARCHBASE");  //搜索根

        internal static string RZ_TREE_LDAPHOST = Uo.Class.Base.Util.AppConfig.GetValue("RZ_TREE_LDAPHOST");  //主机
        internal static string RZ_TREE_LOGINDN = Uo.Class.Base.Util.AppConfig.GetValue("RZ_TREE_LOGINDN");  //
        internal static string RZ_TREE_PASSWORD = Uo.Class.Base.Util.AppConfig.GetValue("RZ_TREE_PASSWORD");  //密码
        internal static string RZ_TREE_SEARCHBASE = Uo.Class.Base.Util.AppConfig.GetValue("RZ_TREE_SEARCHBASE");  //搜索根

        internal static string CS_TREE_LDAPHOST = Uo.Class.Base.Util.AppConfig.GetValue("CS_TREE_LDAPHOST");  //主机
        internal static string CS_TREE_LOGINDN = Uo.Class.Base.Util.AppConfig.GetValue("CS_TREE_LOGINDN");  //
        internal static string CS_TREE_PASSWORD = Uo.Class.Base.Util.AppConfig.GetValue("CS_TREE_PASSWORD");  //密码
        internal static string CS_TREE_SEARCHBASE = Uo.Class.Base.Util.AppConfig.GetValue("CS_TREE_SEARCHBASE");  //搜索根

        TreeNode Qyzy_Tree = new TreeNode(Uo.Class.Base.Util.AppConfig.GetValue("Qyzy_ROOT_NAME"), 1, 1);

        TreeNode Sf_Tree = new TreeNode(Uo.Class.Base.Util.AppConfig.GetValue("Sf_ROOT_NAME"), 2, 2);
        TreeNode Rz_Tree = new TreeNode(Uo.Class.Base.Util.AppConfig.GetValue("Rz_ROOT_NAME"), 3, 3);
        TreeNode Cs_Tree = new TreeNode(Uo.Class.Base.Util.AppConfig.GetValue("Cs_ROOT_NAME"), 6, 6);
        public static DataTable dt_Qx = new DataTable();

        public MainForm()
        {
            InitializeComponent();

            TreeNode root = new TreeNode(ROOT_NAME,0,0);
            treeView_Ldap.Nodes.Add(root);

            NodeTag nodetag = new NodeTag();
            nodetag.dn = QYZY_TREE_SEARCHBASE;
            nodetag.host = QYZY_TREE_LDAPHOST;
            nodetag.pswd = QYZY_TREE_PASSWORD;
            nodetag.logindn = QYZY_TREE_LOGINDN;
            Qyzy_Tree.Tag = nodetag;

            //NodeTag nodetag = new NodeTag();
            nodetag.dn = SF_TREE_SEARCHBASE;
            nodetag.host = SF_TREE_LDAPHOST ;
            nodetag.pswd = SF_TREE_PASSWORD;
            nodetag.logindn = SF_TREE_LOGINDN;
            Sf_Tree.Tag = nodetag;

            //NodeTag nodetag = new NodeTag();
            nodetag.dn = RZ_TREE_SEARCHBASE;
            nodetag.host = RZ_TREE_LDAPHOST;
            nodetag.pswd = RZ_TREE_PASSWORD;
            nodetag.logindn = RZ_TREE_LOGINDN;
            Rz_Tree.Tag = nodetag;

            //NodeTag nodetag = new NodeTag();
            nodetag.dn = CS_TREE_SEARCHBASE;
            nodetag.host = CS_TREE_LDAPHOST;
            nodetag.pswd = CS_TREE_PASSWORD;
            nodetag.logindn = CS_TREE_LOGINDN;
            Cs_Tree.Tag = nodetag;

            root.Nodes.Add(Qyzy_Tree);
            root.Nodes.Add(Sf_Tree);
            root.Nodes.Add(Rz_Tree);
            root.Nodes.Add(Cs_Tree);
        }


        struct NodeTag
        {
            public LdapAttributeSet attributeSet;
            public string dn;
            public string host;
            public string logindn;
            public string pswd;
            public string cn;
        }

        public void GetTree(TreeNode p_node, string host, string logindn, string pswd, int searchScope, string searchFilter)
        {
            LdapConnection lc = new LdapConnection();
            try
            {
                // connect to the server
                lc.Connect(host, LdapConnection.DEFAULT_PORT);
                // bind to the server
                lc.Bind(LdapConnection.Ldap_V3, logindn, pswd );

                NodeTag p_nodetag = (NodeTag)p_node.Tag;

                LdapSearchResults lsc = lc.Search(p_nodetag.dn,
                                                    searchScope,
                                                    searchFilter,
                                                    null,
                                                    false);

                while (lsc.hasMore())
                {
                    LdapEntry nextEntry = null;
                    try
                    {
                        nextEntry = lsc.next();
                    }
                    catch (Exception e1)
                    {
                        MessageBox.Show("Error1: " + e1.Message);
                        
                    }
                    
                    LdapAttributeSet attributeSet = nextEntry.getAttributeSet();

                    TreeNode t_node = new TreeNode();
                    NodeTag nodetag = new NodeTag();
                    nodetag.dn = nextEntry.DN;

                    nodetag.attributeSet = attributeSet;

                    //nodetag.attributeSet = (LdapAttributeSet)attributeSet.Clone();

                    nodetag.host = host;
                    nodetag.pswd = pswd;
                    nodetag.logindn = logindn;

                    t_node.Tag = nodetag;
                    if (nodetag.dn.StartsWith("cn"))
                    {
                        LdapAttribute attribute = attributeSet.getAttribute("FULLNAME");
                        t_node.Text = attribute != null ? attribute.StringValue : "未设置";
                        t_node.ToolTipText = nodetag.dn;
                        t_node.ImageIndex = 5;
                        t_node.SelectedImageIndex = 5;
                        nodetag.cn = attributeSet.getAttribute("CN").Name;

                        //Console.WriteLine("属性" + attribute.Name+attribute.StringValue);
                    }
                    else if (nodetag.dn.StartsWith("ou"))
                    {
                        LdapAttribute attribute = attributeSet.getAttribute("SGCCCHNNAME");
                        t_node.Text = attribute!=null?attribute.StringValue:"未设置";
                        t_node.ToolTipText = nodetag.dn;
                        t_node.ImageIndex = 4;
                        t_node.SelectedImageIndex = 4;

                        //Console.WriteLine("属性" + attribute.Name + attribute.StringValue);
                    }
                    p_node.Nodes.Add(t_node);
                    //GetTree(t_node, host, logindn, pswd, searchScope, searchFilter);
                }

            }
            catch (LdapException e2)
            {
                MessageBox.Show("Error2:" + e2.LdapErrorMessage);
                //return;
            }
            catch (Exception e3)
            {
                MessageBox.Show("Error3:" + e3.StackTrace);
                //return;
            }
            finally
            {
                lc.Disconnect();
            }
        }

        private void treeView_Ldap_AfterSelect(object sender, TreeViewEventArgs e)
        {
            TreeNode node = treeView_Ldap.SelectedNode;

            if(node.Tag !=null )
            {
                NodeTag nodetag = (NodeTag)node.Tag;
                node.Nodes.Clear();
                GetTree(node,nodetag.host ,nodetag.logindn,nodetag.pswd, LdapConnection.SCOPE_ONE, "");

                if (nodetag.attributeSet != null)
                {
                    this.dataGridView1.Rows.Clear();

                    


                    LdapConnection conn = new LdapConnection();
                    try
                    {

                        //Console.WriteLine("Connecting to:" + nodetag.host);
                        conn.Connect(nodetag.host, LdapConnection.DEFAULT_PORT);
                        conn.Bind(LdapConnection.Ldap_V3, nodetag.logindn, nodetag.pswd);
                        LdapSearchResults lsc = conn.Search(nodetag.dn,
                                                            LdapConnection.SCOPE_SUB,
                                                            "",
                                                            null,
                                                            false);


                        LdapEntry nextEntry = null;
                        try
                        {
                            nextEntry = lsc.next();
                        }
                        catch (LdapException e1)
                        {
                            MessageBox.Show("Error: " + e1.LdapErrorMessage);
                        }
                        //Console.WriteLine("\n" + nextEntry.DN);



                        LdapAttributeSet attributeSet = nextEntry.getAttributeSet();

                        System.Collections.IEnumerator ienum = attributeSet.GetEnumerator();


                        while (ienum.MoveNext())
                        {
                            LdapAttribute attribute = (LdapAttribute)ienum.Current;
                            string attributeName = attribute.Name;
                            string attributeVal = attribute.StringValue;

                            this.dataGridView1.Rows.Add(new string[] { attributeName, attributeVal });
                            //Console.WriteLine(attributeName + "value:" + attributeVal);
                        }

                        //this.dataGridView1.DataSource =nodetag.attributeSet.ToArray();
                    }

                    catch (LdapException ex1)
                    {
                        MessageBox.Show("Error:" + ex1.LdapErrorMessage);
                        //return;
                    }
                    catch (Exception ex2)
                    {
                        MessageBox.Show("Error:" + ex2.Message);
                        //return;
                    }
                    finally
                    {
                        conn.Disconnect();
                    }
                }
            }
        }

        private void toolStripButton_Exp_XmGh_Click(object sender, EventArgs e)
        {
            TreeNode node = treeView_Ldap.SelectedNode;
            if (node.Tag != null)
            {
                NodeTag nodetag = (NodeTag)node.Tag;
                if (this.folderBrowserDialog_Txt.ShowDialog() == DialogResult.OK)
                {
                    if (!File.Exists(folderBrowserDialog_Txt.SelectedPath))
                    {
                        // Create a file to write to.
                        string path = folderBrowserDialog_Txt.SelectedPath + node.Text + ".txt";
                        using (StreamWriter sw = File.CreateText(path ))
                        {
                            String[] attrs = { LdapConnection.NO_ATTRS };
                            try
                            {
                                LdapConnection conn = new LdapConnection();
                                //Console.WriteLine("Connecting to:" + nodetag.host);
                                conn.Connect(nodetag.host, LdapConnection.DEFAULT_PORT);
                                conn.Bind(nodetag.logindn, nodetag.pswd);
                                LdapSearchResults lsc = conn.Search(nodetag.dn,
                                                                    LdapConnection.SCOPE_SUB,
                                                                    "",
                                                                    null,
                                                                    false);
                                StringBuilder _str = new StringBuilder();

                                while (lsc.hasMore())
                                {
                                    _str = new StringBuilder();
                                    LdapEntry nextEntry = null;
                                    try
                                    {
                                        nextEntry = lsc.next();
                                    }
                                    catch (LdapException e1)
                                    {
                                        MessageBox.Show("Error: " + e1.LdapErrorMessage);
                                        // Exception is thrown, go for next entry
                                        continue;
                                    }
                                    //Console.WriteLine("\n" + nextEntry.DN);


                                    if (nextEntry.DN.StartsWith("cn"))
                                    {
                                        LdapAttributeSet attributeSet = nextEntry.getAttributeSet();
                                        LdapAttribute attribute = attributeSet.getAttribute("FULLNAME");
                                        _str .Append (attribute.StringValue);
                                        
                                        attribute = attributeSet.getAttribute("CN");
                                        _str .Append("," + attribute.StringValue);
                                        sw.WriteLine(_str);

                                    }
                                }

                                conn.Disconnect();
                            }
                            catch (LdapException e2)
                            {
                                MessageBox.Show("Error:" + e2.LdapErrorMessage);
                                return;
                            }
                            catch (Exception e3)
                            {
                                MessageBox .Show("Error:" + e3.Message);
                            }
                            MessageBox.Show("导出完成！\n"+path );
                        }
                    }

                }
                else
                {
                    MessageBox.Show("请选择导出文件保存的位置");
                }
                
            }
        }


        private void toolStripButton_SetQx_Click(object sender, EventArgs e)
        {
       
            //String ldapHost = txt_Host.Text;
            //String loginDN = txt_Dn.Text;
            //String password = txt_Pswd.Text;
            //String dn = txt_SerchBase.Text;
            //int ldapPort = LdapConnection.DEFAULT_PORT;
            //String searchFilter = txt_SearchFilter.Text;

             TreeNode node = treeView_Ldap.SelectedNode;

             if (node.Tag != null)
             {
                 NodeTag nodetag = (NodeTag)node.Tag;


                 LdapConnection conn = new LdapConnection();
                 try
                 {

                     //Console.WriteLine("Connecting to:" + nodetag.host);
                     conn.Connect(nodetag.host, LdapConnection.DEFAULT_PORT );
                     conn.Bind(LdapConnection.Ldap_V3, nodetag.logindn, nodetag.pswd);
                     LdapSearchResults lsc = conn.Search(nodetag.dn ,
                                                         LdapConnection.SCOPE_SUB,
                                                         "",
                                                         null,
                                                         false);


                     LdapEntry nextEntry = null;
                     try
                     {
                         nextEntry = lsc.next();
                     }
                     catch (LdapException e1)
                     {
                         MessageBox.Show ("Error: " + e1.LdapErrorMessage);
                     }
                     //Console.WriteLine("\n" + nextEntry.DN);
                     
                     

                     LdapAttributeSet attributeSet = nextEntry.getAttributeSet();
                     LdapAttribute attribute_cn = attributeSet.getAttribute("CN");

                     System.Collections.ArrayList modList = new System.Collections.ArrayList();

                     modList.Add(new LdapAttribute("nxMWAccount", attribute_cn.StringValue));
                     modList.Add(new LdapAttribute("nxMWLoginEnable", "TRUE"));
                     modList.Add(new LdapAttribute("uid", attribute_cn.StringValue));

                     modList.Add(new LdapAttribute("nxCOAAccount", attribute_cn.StringValue));

                     modList.Add(new LdapAttribute("nxCOALoginEnable", "TRUE"));
                     modList.Add(new LdapAttribute("COA1LoginEnable", "TRUE"));

                     //modList.Add(new LdapAttribute("nxMWSyncStatus"));
                     modList.Add(new LdapAttribute("nxHRGKLoginEnable", "TRUE"));

                     modList.Add(new LdapAttribute("nxYJZHLoginEnable", "TRUE"));
                     modList.Add(new LdapAttribute("nxSAPEPLoginEnable", "TRUE"));
                     modList.Add(new LdapAttribute("nxYXFZJCLoginEnable", "TRUE"));
                     modList.Add(new LdapAttribute("nxHRFZJCLoginEnable", "TRUE"));
                     modList.Add(new LdapAttribute("nxZHJHLoginEnable", "TRUE"));

                     modList.Add(new LdapAttribute("nxGJHZLoginEnable", "TRUE"));
                     modList.Add(new LdapAttribute("nxSJGLLoginEnable", "TRUE"));
                     modList.Add(new LdapAttribute("nxSCTJLoginEnable", "TRUE"));
                     modList.Add(new LdapAttribute("nxAQJDLoginEnable", "TRUE"));
                     modList.Add(new LdapAttribute("nxDC2LoginEnable", "TRUE"));
                    
                     modList.Add(new LdapAttribute("nxBIDLoginEnable", "TRUE"));
                     modList.Add(new LdapAttribute("nxTZJHLoginEnable", "TRUE"));

                     StringBuilder xg=new StringBuilder();
                     for (int i = 0; i < modList.Count; i++)
                     {
                         String name = ((LdapAttribute)modList[i]).Name;
                         String value = ((LdapAttribute)modList[i]).StringValue;
                         LdapAttribute attribute = attributeSet.getAttribute(name);

                         if (attribute != null)
                         {
                             conn.Modify(nodetag.dn, new LdapModification(LdapModification.REPLACE, (LdapAttribute)modList[i]));
                             xg.Append(" 属性: " + nodetag.dn + ":" + name + "---" + value + "---修改成功！\n");
                         }
                         else
                         {
                             conn.Modify(nodetag.dn, new LdapModification(LdapModification.ADD, (LdapAttribute)modList[i]));
                             xg.Append(" 属性: " + nodetag.dn + ":" + name + "---" + value + "---添加成功！\n");
                         }
                     }
                                          
                     MessageBox.Show("修改结果 \n"+xg);
                 }
                 catch (LdapException ex1)
                 {
                     MessageBox.Show("Error:" + ex1.LdapErrorMessage);
                 }
                 catch (Exception ex2)
                 {
                     MessageBox.Show("Error:" + ex2.Message);
                 }
                 finally
                 {
                     conn.Disconnect();
                 }
             }
        
        }

        private void toolStripButton_ReadQx_Click(object sender, EventArgs e)
        {
            string strConn;
            if (this.openFileDialog_ExcelQx.ShowDialog() ==  DialogResult.OK)
            {
                string FilePath = openFileDialog_ExcelQx.FileName;
                strConn = "Provider=Microsoft.Jet.OLEDB.4.0;" + "Data Source=" + FilePath + ";Extended Properties=Excel 8.0;";
                OleDbConnection conn = new OleDbConnection(strConn);
                OleDbDataAdapter myCommand = new OleDbDataAdapter("SELECT * FROM [Sheet1$]", strConn);
                DataSet myDataSet = new DataSet();
                try
                {
                    myCommand.Fill(myDataSet);
                    dt_Qx = myDataSet.Tables[0];
                    FormQx fromqx = new FormQx(dt_Qx);
                    fromqx.ShowDialog();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }

        private void toolStripButton_NxQx_Click(object sender, EventArgs e)
        {
            //修改宁夏信息系统权限

            string strConn;
            if (this.openFileDialog_ExcelQx.ShowDialog() == DialogResult.OK)
            {
                string FilePath = openFileDialog_ExcelQx.FileName;
                strConn = "Provider=Microsoft.Jet.OLEDB.4.0;" + "Data Source=" + FilePath + ";Extended Properties=Excel 8.0;";
                OleDbConnection conn = new OleDbConnection(strConn);
                OleDbDataAdapter myCommand = new OleDbDataAdapter("SELECT * FROM [Sheet1$]", strConn);
                DataSet myDataSet = new DataSet();
                try
                {
                    myCommand.Fill(myDataSet);
                    dt_Qx = myDataSet.Tables[0];
                    FormQx_Nx fromqx_nx = new FormQx_Nx(dt_Qx);
                    fromqx_nx.ShowDialog();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
