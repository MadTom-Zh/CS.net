﻿namespace NovellLdapTools
{
    partial class FormQx
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.dataGridView_Qx = new System.Windows.Forms.DataGridView();
            this.button_Read = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button_List = new System.Windows.Forms.Button();
            this.button_Set = new System.Windows.Forms.Button();
            this.button_Write = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.richTextBox_Show = new System.Windows.Forms.RichTextBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Qx)).BeginInit();
            this.panel1.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // dataGridView_Qx
            // 
            this.dataGridView_Qx.AllowUserToAddRows = false;
            this.dataGridView_Qx.AllowUserToDeleteRows = false;
            this.dataGridView_Qx.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Qx.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_Qx.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_Qx.Name = "dataGridView_Qx";
            this.dataGridView_Qx.ReadOnly = true;
            this.dataGridView_Qx.RowTemplate.Height = 23;
            this.dataGridView_Qx.Size = new System.Drawing.Size(558, 186);
            this.dataGridView_Qx.TabIndex = 1;
            // 
            // button_Read
            // 
            this.button_Read.Location = new System.Drawing.Point(19, 18);
            this.button_Read.Name = "button_Read";
            this.button_Read.Size = new System.Drawing.Size(139, 40);
            this.button_Read.TabIndex = 0;
            this.button_Read.Text = "重新读取权限表";
            this.button_Read.UseVisualStyleBackColor = true;
            this.button_Read.Click += new System.EventHandler(this.button_Read_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.button_List);
            this.panel1.Controls.Add(this.button_Set);
            this.panel1.Controls.Add(this.button_Write);
            this.panel1.Controls.Add(this.button_Read);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(558, 75);
            this.panel1.TabIndex = 2;
            // 
            // button_List
            // 
            this.button_List.Location = new System.Drawing.Point(309, 18);
            this.button_List.Name = "button_List";
            this.button_List.Size = new System.Drawing.Size(86, 40);
            this.button_List.TabIndex = 3;
            this.button_List.Text = "权限列表";
            this.button_List.UseVisualStyleBackColor = true;
            this.button_List.Click += new System.EventHandler(this.button_List_Click);
            // 
            // button_Set
            // 
            this.button_Set.Location = new System.Drawing.Point(401, 18);
            this.button_Set.Name = "button_Set";
            this.button_Set.Size = new System.Drawing.Size(86, 40);
            this.button_Set.TabIndex = 2;
            this.button_Set.Text = "设置权限";
            this.button_Set.UseVisualStyleBackColor = true;
            this.button_Set.Click += new System.EventHandler(this.button_Set_Click);
            // 
            // button_Write
            // 
            this.button_Write.Location = new System.Drawing.Point(164, 18);
            this.button_Write.Name = "button_Write";
            this.button_Write.Size = new System.Drawing.Size(139, 40);
            this.button_Write.TabIndex = 1;
            this.button_Write.Text = "从目录生成权限表";
            this.button_Write.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 75);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.dataGridView_Qx);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.richTextBox_Show);
            this.splitContainer1.Size = new System.Drawing.Size(558, 323);
            this.splitContainer1.SplitterDistance = 186;
            this.splitContainer1.TabIndex = 3;
            // 
            // richTextBox_Show
            // 
            this.richTextBox_Show.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox_Show.Location = new System.Drawing.Point(0, 0);
            this.richTextBox_Show.Name = "richTextBox_Show";
            this.richTextBox_Show.Size = new System.Drawing.Size(558, 133);
            this.richTextBox_Show.TabIndex = 0;
            this.richTextBox_Show.Text = "";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(493, 27);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(53, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FormQx
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(558, 398);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.panel1);
            this.Name = "FormQx";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Qx)).EndInit();
            this.panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.DataGridView dataGridView_Qx;
        private System.Windows.Forms.Button button_Read;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button_Write;
        private System.Windows.Forms.Button button_Set;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.RichTextBox richTextBox_Show;
        private System.Windows.Forms.Button button_List;
        private System.Windows.Forms.Button button1;
    }
}