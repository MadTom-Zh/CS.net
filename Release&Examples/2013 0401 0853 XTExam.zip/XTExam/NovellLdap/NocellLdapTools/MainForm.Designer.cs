﻿namespace NovellLdapTools
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton_Exp_XmGh = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton_SetQx = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton_ReadQx = new System.Windows.Forms.ToolStripButton();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.treeView_Ldap = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.folderBrowserDialog_Txt = new System.Windows.Forms.FolderBrowserDialog();
            this.openFileDialog_ExcelQx = new System.Windows.Forms.OpenFileDialog();
            this.toolStripButton_NxQx = new System.Windows.Forms.ToolStripButton();
            this.toolStrip1.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 500);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(700, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.White;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton_Exp_XmGh,
            this.toolStripButton_SetQx,
            this.toolStripButton_ReadQx,
            this.toolStripButton_NxQx});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(700, 39);
            this.toolStrip1.TabIndex = 3;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton_Exp_XmGh
            // 
            this.toolStripButton_Exp_XmGh.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton_Exp_XmGh.Image = global::NocellLdapTools.Properties.Resources.folderdrop;
            this.toolStripButton_Exp_XmGh.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_Exp_XmGh.Name = "toolStripButton_Exp_XmGh";
            this.toolStripButton_Exp_XmGh.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton_Exp_XmGh.Text = "导出姓名工号";
            this.toolStripButton_Exp_XmGh.ToolTipText = "导出姓名工号";
            this.toolStripButton_Exp_XmGh.Click += new System.EventHandler(this.toolStripButton_Exp_XmGh_Click);
            // 
            // toolStripButton_SetQx
            // 
            this.toolStripButton_SetQx.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton_SetQx.Image = global::NocellLdapTools.Properties.Resources.bookmark;
            this.toolStripButton_SetQx.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_SetQx.Name = "toolStripButton_SetQx";
            this.toolStripButton_SetQx.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton_SetQx.Text = "设置用户权限";
            this.toolStripButton_SetQx.Click += new System.EventHandler(this.toolStripButton_SetQx_Click);
            // 
            // toolStripButton_ReadQx
            // 
            this.toolStripButton_ReadQx.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton_ReadQx.Image = global::NocellLdapTools.Properties.Resources.foldersystem;
            this.toolStripButton_ReadQx.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_ReadQx.Name = "toolStripButton_ReadQx";
            this.toolStripButton_ReadQx.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton_ReadQx.Text = "读取用户权限表";
            this.toolStripButton_ReadQx.Click += new System.EventHandler(this.toolStripButton_ReadQx_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 39);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.treeView_Ldap);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.dataGridView1);
            this.splitContainer1.Size = new System.Drawing.Size(700, 461);
            this.splitContainer1.SplitterDistance = 232;
            this.splitContainer1.TabIndex = 4;
            // 
            // treeView_Ldap
            // 
            this.treeView_Ldap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView_Ldap.ImageIndex = 0;
            this.treeView_Ldap.ImageList = this.imageList1;
            this.treeView_Ldap.Location = new System.Drawing.Point(0, 0);
            this.treeView_Ldap.Name = "treeView_Ldap";
            this.treeView_Ldap.SelectedImageIndex = 0;
            this.treeView_Ldap.Size = new System.Drawing.Size(232, 461);
            this.treeView_Ldap.TabIndex = 0;
            this.treeView_Ldap.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView_Ldap_AfterSelect);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "System iTools.ico");
            this.imageList1.Images.SetKeyName(1, "IF haloween.ico");
            this.imageList1.Images.SetKeyName(2, "aqua icq.ico");
            this.imageList1.Images.SetKeyName(3, "firewire disk.ico");
            this.imageList1.Images.SetKeyName(4, "the doghouse.ico");
            this.imageList1.Images.SetKeyName(5, "Msnger.ico");
            this.imageList1.Images.SetKeyName(6, "36.ico");
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(464, 461);
            this.dataGridView1.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Column1";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 72;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Column2";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 72;
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton4.Text = "toolStripButton4";
            // 
            // openFileDialog_ExcelQx
            // 
            this.openFileDialog_ExcelQx.FileName = "目录权限表";
            this.openFileDialog_ExcelQx.Filter = "Excle 2003 文件|*.xls|Excel 2007文件|*.xlsx|所有文件|*.*";
            // 
            // toolStripButton_NxQx
            // 
            this.toolStripButton_NxQx.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton_NxQx.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_NxQx.Image")));
            this.toolStripButton_NxQx.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_NxQx.Name = "toolStripButton_NxQx";
            this.toolStripButton_NxQx.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton_NxQx.Text = "数据中心权限设置";
            this.toolStripButton_NxQx.Click += new System.EventHandler(this.toolStripButton_NxQx_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 522);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.IsMdiContainer = true;
            this.Name = "MainForm";
            this.Text = "目录管理工具";
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TreeView treeView_Ldap;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton_Exp_XmGh;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog_Txt;
        private System.Windows.Forms.ToolStripButton toolStripButton_SetQx;
        private System.Windows.Forms.ToolStripButton toolStripButton_ReadQx;
        private System.Windows.Forms.OpenFileDialog openFileDialog_ExcelQx;
        private System.Windows.Forms.ToolStripButton toolStripButton_NxQx;

    }
}

