﻿namespace MadTomDev.App
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label_states = new System.Windows.Forms.Label();
            this.checkBox_isScanFolders = new System.Windows.Forms.CheckBox();
            this.checkBox_isIgnoreFolderInfo = new System.Windows.Forms.CheckBox();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.FileName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IsChanged = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Extension = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Length = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CreationTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LastWriteTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LastAccessTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Normal = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dgvSystem = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Archive = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dgvDirectory = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.ReadOnly = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Hidden = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Compressed = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Encrypted = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dgvDevice = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Offline = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.IntegrityStream = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.NoScrubDate = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.NotContentIndexed = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.ReparsePoint = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.SparseFile = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.FullName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button_apply = new System.Windows.Forms.Button();
            this.textBox_filesInfo = new System.Windows.Forms.TextBox();
            this.textBox_DropZone = new System.Windows.Forms.TextBox();
            this.button_clear = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // label_states
            // 
            this.label_states.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label_states.AutoSize = true;
            this.label_states.Location = new System.Drawing.Point(9, 472);
            this.label_states.Name = "label_states";
            this.label_states.Size = new System.Drawing.Size(38, 13);
            this.label_states.TabIndex = 13;
            this.label_states.Text = "Ready";
            // 
            // checkBox_isScanFolders
            // 
            this.checkBox_isScanFolders.AutoSize = true;
            this.checkBox_isScanFolders.Checked = true;
            this.checkBox_isScanFolders.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_isScanFolders.Location = new System.Drawing.Point(185, 37);
            this.checkBox_isScanFolders.Name = "checkBox_isScanFolders";
            this.checkBox_isScanFolders.Size = new System.Drawing.Size(191, 17);
            this.checkBox_isScanFolders.TabIndex = 12;
            this.checkBox_isScanFolders.Text = "遍历目录 (也修改文件夹中内容)";
            this.checkBox_isScanFolders.UseVisualStyleBackColor = true;
            // 
            // checkBox_isIgnoreFolderInfo
            // 
            this.checkBox_isIgnoreFolderInfo.AutoSize = true;
            this.checkBox_isIgnoreFolderInfo.Location = new System.Drawing.Point(185, 14);
            this.checkBox_isIgnoreFolderInfo.Name = "checkBox_isIgnoreFolderInfo";
            this.checkBox_isIgnoreFolderInfo.Size = new System.Drawing.Size(191, 17);
            this.checkBox_isIgnoreFolderInfo.TabIndex = 11;
            this.checkBox_isIgnoreFolderInfo.Text = "忽略文件夹 (不修改文件夹属性)";
            this.checkBox_isIgnoreFolderInfo.UseVisualStyleBackColor = true;
            // 
            // dataGridView
            // 
            this.dataGridView.AllowUserToAddRows = false;
            this.dataGridView.AllowUserToDeleteRows = false;
            this.dataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.FileName,
            this.IsChanged,
            this.Extension,
            this.Length,
            this.CreationTime,
            this.LastWriteTime,
            this.LastAccessTime,
            this.Normal,
            this.dgvSystem,
            this.Archive,
            this.dgvDirectory,
            this.ReadOnly,
            this.Hidden,
            this.Compressed,
            this.Encrypted,
            this.dgvDevice,
            this.Offline,
            this.IntegrityStream,
            this.NoScrubDate,
            this.NotContentIndexed,
            this.ReparsePoint,
            this.SparseFile,
            this.FullName});
            this.dataGridView.Location = new System.Drawing.Point(12, 87);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.Size = new System.Drawing.Size(1106, 372);
            this.dataGridView.TabIndex = 10;
            this.dataGridView.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dataGridView_CellBeginEdit);
            this.dataGridView.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_CellEndEdit);
            this.dataGridView.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.dataGridView_CellValidating);
            // 
            // FileName
            // 
            this.FileName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.FileName.Frozen = true;
            this.FileName.HeaderText = "FileName";
            this.FileName.Name = "FileName";
            this.FileName.ReadOnly = true;
            this.FileName.Width = 5;
            // 
            // IsChanged
            // 
            this.IsChanged.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.IsChanged.HeaderText = "IsChanged";
            this.IsChanged.Name = "IsChanged";
            this.IsChanged.ReadOnly = true;
            this.IsChanged.Width = 5;
            // 
            // Extension
            // 
            this.Extension.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.Extension.HeaderText = "Extension";
            this.Extension.Name = "Extension";
            this.Extension.ReadOnly = true;
            this.Extension.Width = 5;
            // 
            // Length
            // 
            this.Length.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.Length.DefaultCellStyle = dataGridViewCellStyle1;
            this.Length.HeaderText = "Length";
            this.Length.Name = "Length";
            this.Length.ReadOnly = true;
            this.Length.Width = 5;
            // 
            // CreationTime
            // 
            this.CreationTime.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.CreationTime.HeaderText = "CreationTime";
            this.CreationTime.Name = "CreationTime";
            this.CreationTime.Width = 5;
            // 
            // LastWriteTime
            // 
            this.LastWriteTime.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.LastWriteTime.HeaderText = "LastWriteTime";
            this.LastWriteTime.Name = "LastWriteTime";
            this.LastWriteTime.Width = 5;
            // 
            // LastAccessTime
            // 
            this.LastAccessTime.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.LastAccessTime.HeaderText = "LastAccessTime";
            this.LastAccessTime.Name = "LastAccessTime";
            this.LastAccessTime.Width = 5;
            // 
            // Normal
            // 
            this.Normal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.Normal.HeaderText = "Normal";
            this.Normal.Name = "Normal";
            this.Normal.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Normal.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Normal.Width = 5;
            // 
            // dgvSystem
            // 
            this.dgvSystem.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.dgvSystem.HeaderText = "System";
            this.dgvSystem.Name = "dgvSystem";
            this.dgvSystem.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSystem.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgvSystem.Width = 5;
            // 
            // Archive
            // 
            this.Archive.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.Archive.HeaderText = "Archive";
            this.Archive.Name = "Archive";
            this.Archive.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Archive.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Archive.Width = 5;
            // 
            // dgvDirectory
            // 
            this.dgvDirectory.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.dgvDirectory.HeaderText = "Directory";
            this.dgvDirectory.Name = "dgvDirectory";
            this.dgvDirectory.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDirectory.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgvDirectory.Width = 5;
            // 
            // ReadOnly
            // 
            this.ReadOnly.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.ReadOnly.HeaderText = "ReadOnly";
            this.ReadOnly.Name = "ReadOnly";
            this.ReadOnly.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ReadOnly.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.ReadOnly.Width = 5;
            // 
            // Hidden
            // 
            this.Hidden.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.Hidden.HeaderText = "Hidden";
            this.Hidden.Name = "Hidden";
            this.Hidden.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Hidden.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Hidden.Width = 5;
            // 
            // Compressed
            // 
            this.Compressed.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.Compressed.HeaderText = "Compressed";
            this.Compressed.Name = "Compressed";
            this.Compressed.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Compressed.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Compressed.Width = 5;
            // 
            // Encrypted
            // 
            this.Encrypted.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.Encrypted.HeaderText = "Encrypted";
            this.Encrypted.Name = "Encrypted";
            this.Encrypted.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Encrypted.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Encrypted.Width = 5;
            // 
            // dgvDevice
            // 
            this.dgvDevice.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.dgvDevice.HeaderText = "Device";
            this.dgvDevice.Name = "dgvDevice";
            this.dgvDevice.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDevice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgvDevice.Width = 5;
            // 
            // Offline
            // 
            this.Offline.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.Offline.HeaderText = "Offline";
            this.Offline.Name = "Offline";
            this.Offline.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Offline.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Offline.Width = 5;
            // 
            // IntegrityStream
            // 
            this.IntegrityStream.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.IntegrityStream.HeaderText = "IntegrityStream";
            this.IntegrityStream.Name = "IntegrityStream";
            this.IntegrityStream.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.IntegrityStream.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.IntegrityStream.Width = 5;
            // 
            // NoScrubDate
            // 
            this.NoScrubDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.NoScrubDate.HeaderText = "NoScrubDate";
            this.NoScrubDate.Name = "NoScrubDate";
            this.NoScrubDate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.NoScrubDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.NoScrubDate.Width = 5;
            // 
            // NotContentIndexed
            // 
            this.NotContentIndexed.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.NotContentIndexed.HeaderText = "NotContentIndexed";
            this.NotContentIndexed.Name = "NotContentIndexed";
            this.NotContentIndexed.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.NotContentIndexed.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.NotContentIndexed.Width = 5;
            // 
            // ReparsePoint
            // 
            this.ReparsePoint.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.ReparsePoint.HeaderText = "ReparsePoint";
            this.ReparsePoint.Name = "ReparsePoint";
            this.ReparsePoint.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ReparsePoint.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.ReparsePoint.Width = 5;
            // 
            // SparseFile
            // 
            this.SparseFile.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.SparseFile.HeaderText = "SparseFile";
            this.SparseFile.Name = "SparseFile";
            this.SparseFile.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.SparseFile.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.SparseFile.Width = 5;
            // 
            // FullName
            // 
            this.FullName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.FullName.FillWeight = 300F;
            this.FullName.HeaderText = "FullName";
            this.FullName.Name = "FullName";
            this.FullName.ReadOnly = true;
            this.FullName.Width = 76;
            // 
            // button_apply
            // 
            this.button_apply.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_apply.Location = new System.Drawing.Point(1040, 465);
            this.button_apply.Name = "button_apply";
            this.button_apply.Size = new System.Drawing.Size(78, 36);
            this.button_apply.TabIndex = 9;
            this.button_apply.Text = "&Apply";
            this.button_apply.UseVisualStyleBackColor = true;
            this.button_apply.Click += new System.EventHandler(this.button_apply_Click);
            // 
            // textBox_filesInfo
            // 
            this.textBox_filesInfo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_filesInfo.Location = new System.Drawing.Point(382, 12);
            this.textBox_filesInfo.Multiline = true;
            this.textBox_filesInfo.Name = "textBox_filesInfo";
            this.textBox_filesInfo.ReadOnly = true;
            this.textBox_filesInfo.Size = new System.Drawing.Size(736, 69);
            this.textBox_filesInfo.TabIndex = 8;
            // 
            // textBox_DropZone
            // 
            this.textBox_DropZone.AllowDrop = true;
            this.textBox_DropZone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_DropZone.Location = new System.Drawing.Point(12, 12);
            this.textBox_DropZone.Multiline = true;
            this.textBox_DropZone.Name = "textBox_DropZone";
            this.textBox_DropZone.ReadOnly = true;
            this.textBox_DropZone.Size = new System.Drawing.Size(167, 69);
            this.textBox_DropZone.TabIndex = 7;
            this.textBox_DropZone.Text = "\r\n\r\n将(多个)文件拖入这里";
            this.textBox_DropZone.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_DropZone.DragDrop += new System.Windows.Forms.DragEventHandler(this.textBox_DropZone_DragDrop);
            this.textBox_DropZone.DragEnter += new System.Windows.Forms.DragEventHandler(this.textBox_DropZone_DragEnter);
            this.textBox_DropZone.DragOver += new System.Windows.Forms.DragEventHandler(this.textBox_DropZone_DragOver);
            // 
            // button_clear
            // 
            this.button_clear.Location = new System.Drawing.Point(185, 58);
            this.button_clear.Name = "button_clear";
            this.button_clear.Size = new System.Drawing.Size(53, 23);
            this.button_clear.TabIndex = 14;
            this.button_clear.Text = "清空";
            this.button_clear.UseVisualStyleBackColor = true;
            this.button_clear.Click += new System.EventHandler(this.button_clear_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1130, 513);
            this.Controls.Add(this.button_clear);
            this.Controls.Add(this.label_states);
            this.Controls.Add(this.checkBox_isScanFolders);
            this.Controls.Add(this.checkBox_isIgnoreFolderInfo);
            this.Controls.Add(this.dataGridView);
            this.Controls.Add(this.button_apply);
            this.Controls.Add(this.textBox_filesInfo);
            this.Controls.Add(this.textBox_DropZone);
            this.Name = "FormMain";
            this.Text = "文件属性修改器 by longtombbj 2020 1030";
            this.Load += new System.EventHandler(this.FormMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_states;
        private System.Windows.Forms.CheckBox checkBox_isScanFolders;
        private System.Windows.Forms.CheckBox checkBox_isIgnoreFolderInfo;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.Button button_apply;
        private System.Windows.Forms.TextBox textBox_filesInfo;
        private System.Windows.Forms.TextBox textBox_DropZone;
        private System.Windows.Forms.Button button_clear;
        private System.Windows.Forms.DataGridViewTextBoxColumn FileName;
        private System.Windows.Forms.DataGridViewCheckBoxColumn IsChanged;
        private System.Windows.Forms.DataGridViewTextBoxColumn Extension;
        private System.Windows.Forms.DataGridViewTextBoxColumn Length;
        private System.Windows.Forms.DataGridViewTextBoxColumn CreationTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn LastWriteTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn LastAccessTime;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Normal;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dgvSystem;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Archive;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dgvDirectory;
        private System.Windows.Forms.DataGridViewCheckBoxColumn ReadOnly;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Hidden;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Compressed;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Encrypted;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dgvDevice;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Offline;
        private System.Windows.Forms.DataGridViewCheckBoxColumn IntegrityStream;
        private System.Windows.Forms.DataGridViewCheckBoxColumn NoScrubDate;
        private System.Windows.Forms.DataGridViewCheckBoxColumn NotContentIndexed;
        private System.Windows.Forms.DataGridViewCheckBoxColumn ReparsePoint;
        private System.Windows.Forms.DataGridViewCheckBoxColumn SparseFile;
        private System.Windows.Forms.DataGridViewTextBoxColumn FullName;
    }
}

