﻿using MadTomDev.CommonClasses;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadTomDev.App
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
        }
        private delegate void SetStateDelegateMsg(string msg);
        private delegate void SetStateDelegateErr(Exception err);
        public void SetState(string msg)
        {
            if (InvokeRequired)
            {
                SetStateDelegateMsg callback = new FormMain.SetStateDelegateMsg(SetState);
                Invoke(callback, msg);
            }
            else
            {
                label_states.Text = msg;
            }
        }
        public void SetState(Exception err)
        {
            if (InvokeRequired)
            {
                SetStateDelegateErr callback = new FormMain.SetStateDelegateErr(SetState);
                Invoke(callback, err);
            }
            else
            {
                label_states.Text = err.Message;
                MessageBox.Show(this, err.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #region drop files and load to grid
        private void button_clear_Click(object sender, EventArgs e)
        {
            dataGridView.Rows.Clear();
            textBox_filesInfo.Text = "已清空载入的文件";
        }
        private void textBox_DropZone_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
                e.Effect = DragDropEffects.Link;
            else
                e.Effect = DragDropEffects.None;
        }
        private void textBox_DropZone_DragOver(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
                e.Effect = DragDropEffects.Link;
            else
                e.Effect = DragDropEffects.None;
        }

        private int countFiles, countDirs;
        private void textBox_DropZone_DragDrop(object sender, DragEventArgs e)
        {
            if (e.Effect != DragDropEffects.Link)
                return;

            countFiles = 0;
            countDirs = 0;
            dataGridView.Rows.Clear();
            foreach (string fileOrDir in (string[])e.Data.GetData(DataFormats.FileDrop))
            {
                if (File.Exists(fileOrDir))
                {
                    AddRow(new FileInfo(fileOrDir));
                    countFiles++;
                }
                else if (Directory.Exists(fileOrDir))
                    LoadFileInfosLoop(new DirectoryInfo(fileOrDir));
            }
            textBox_filesInfo.Text = $"已加载[{countFiles}]个文件和[{countDirs}]个文件夹。";
        }
        private void LoadFileInfosLoop(DirectoryInfo di)
        {
            if (!checkBox_isIgnoreFolderInfo.Checked)
            {
                AddRow(di);
                countDirs++;
            }
            if (checkBox_isScanFolders.Checked)
            {
                foreach (FileInfo fi in di.GetFiles())
                {
                    AddRow(fi);
                    countFiles++;

                }
                foreach (DirectoryInfo idi in di.GetDirectories())
                {
                    LoadFileInfosLoop(idi);
                }
            }
        }

        private void AddRow(FileInfo fi)
        {
            DataGridViewRow dgvRow = dataGridView.Rows[dataGridView.Rows.Add()];
            dgvRow.Tag = new FlagedTagData()
            { fi = fi, };
            SetRow(dgvRow, fi.Name, fi.Extension,
                fi.FullName, fi.Length);
            SetRow(dgvRow, fi.CreationTime, fi.LastWriteTime, fi.LastAccessTime);
            SetRow(dgvRow, false);
            SetRow(dgvRow, fi.Attributes);
        }
        private void AddRow(DirectoryInfo di)
        {
            DataGridViewRow dgvRow = dataGridView.Rows[dataGridView.Rows.Add()];
            dgvRow.Tag = new FlagedTagData()
            { di = di, };
            SetRow(dgvRow, di.Name, di.Extension,
                di.FullName);
            SetRow(dgvRow, di.CreationTime, di.LastWriteTime, di.LastAccessTime);
            SetRow(dgvRow, false);
            SetRow(dgvRow, di.Attributes);
        }
        private void SetRow(DataGridViewRow dgvRow, bool isChanged)
        {
            dgvRow.Cells[1].Value = isChanged;
        }
        private void SetRow(DataGridViewRow dgvRow, string name, string extension,
            string fullName, long length = -1)
        {
            dgvRow.Cells[0].Value = name;
            dgvRow.Cells[2].Value = extension;
            dgvRow.Cells[3].Value = length < 0 ?
                "-"
                : SimpleStringHelper.UnitsOfMeasure.GetShortString(length, "B", 1024, 0, true);
            dgvRow.Cells[22].Value = fullName;
        }
        private void SetRow(DataGridViewRow dgvRow,
            DateTime creationTime, DateTime lastWriteTime, DateTime lastAccessTime)
        {
            dgvRow.Cells[4].Value = creationTime.ToString("yyyy-MM-dd HH:mm:ss.fffffff");
            dgvRow.Cells[5].Value = lastWriteTime.ToString("yyyy-MM-dd HH:mm:ss.fffffff");
            dgvRow.Cells[6].Value = lastAccessTime.ToString("yyyy-MM-dd HH:mm:ss.fffffff");
        }
        private void SetRow(DataGridViewRow dgvRow, FileAttributes fileAttris)
        {
            dgvRow.Cells[7].Value = fileAttris.HasFlag(FileAttributes.Normal);
            dgvRow.Cells[8].Value = fileAttris.HasFlag(FileAttributes.System);
            dgvRow.Cells[9].Value = fileAttris.HasFlag(FileAttributes.Archive);
            dgvRow.Cells[10].Value = fileAttris.HasFlag(FileAttributes.Directory);
            dgvRow.Cells[11].Value = fileAttris.HasFlag(FileAttributes.ReadOnly);
            dgvRow.Cells[12].Value = fileAttris.HasFlag(FileAttributes.Hidden);
            dgvRow.Cells[13].Value = fileAttris.HasFlag(FileAttributes.Compressed);
            dgvRow.Cells[14].Value = fileAttris.HasFlag(FileAttributes.Encrypted);
            dgvRow.Cells[15].Value = fileAttris.HasFlag(FileAttributes.Device);
            dgvRow.Cells[16].Value = fileAttris.HasFlag(FileAttributes.Offline);
            dgvRow.Cells[17].Value = fileAttris.HasFlag(FileAttributes.IntegrityStream);
            dgvRow.Cells[18].Value = fileAttris.HasFlag(FileAttributes.NoScrubData);
            dgvRow.Cells[19].Value = fileAttris.HasFlag(FileAttributes.NotContentIndexed);
            dgvRow.Cells[20].Value = fileAttris.HasFlag(FileAttributes.ReparsePoint);

            dgvRow.Cells[21].Value = fileAttris.HasFlag(FileAttributes.SparseFile);
        }
        private void ReSetRow(DataGridViewRow dgvRow)
        {
        }

        private class FlagedTagData
        {
            public FileInfo fi;
            public DirectoryInfo di;
            public DateTime newCTime = DateTime.MinValue;
            public DateTime newWTime = DateTime.MinValue;
            public DateTime newATime = DateTime.MinValue;
            public bool isChanged = false;
        }



        #endregion

        #region value change and check
        private void dataGridView_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if (e.ColumnIndex >= 4 && e.ColumnIndex <= 6)
            {
                try
                {
                    DateTime curTime = DateTime.Parse(e.FormattedValue.ToString());
                }
                catch (Exception)
                {
                    SystemSounds.Hand.Play();
                    SetState("这里必须输入日期");
                    e.Cancel = true;
                }
            }
        }

        private string preDateStr = null;
        private bool? preBool = null;
        private void dataGridView_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            object value = dataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;
            if (value is bool)
                preBool = (bool)value;
            else
                preDateStr = value.ToString();
        }

        private void dataGridView_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow dgvRow = dataGridView.Rows[e.RowIndex];
            FlagedTagData ftData = (FlagedTagData)dgvRow.Tag;
            object value = dgvRow.Cells[e.ColumnIndex].Value;

            if (value is bool)
            {
                if (preBool != (bool)value)
                {
                    ftData.isChanged = true;
                    SetRow(dgvRow, true);
                    SetState("已标记");
                }
            }
            else if (e.ColumnIndex >= 4 && e.ColumnIndex <= 6)
            {
                string curStr = value.ToString();
                if (preDateStr != curStr)
                {
                    ftData.isChanged = true;
                    switch (e.ColumnIndex)
                    {
                        case 4:// creation time
                            ftData.newCTime = DateTime.Parse(curStr);
                            break;
                        case 5:// write time
                            ftData.newWTime = DateTime.Parse(curStr);
                            break;
                        case 6:// access time
                            ftData.newATime = DateTime.Parse(curStr);
                            break;
                    }
                }
                if (!ftData.isChanged)
                    return;

                SetRow(dgvRow, true);
                SetState("已标记");

                DateTime curTime = DateTime.Parse(value.ToString());
                if (e.ColumnIndex == 5 || e.ColumnIndex == 6)
                {
                    DateTime cTime = DateTime.Parse(dataGridView.Rows[e.RowIndex].Cells[4].Value.ToString());
                    if (cTime > curTime)
                    {
                        string changedTimeLable = "最后修改时间";
                        if (e.ColumnIndex == 6)
                            changedTimeLable = "最后访问时间";
                        MessageBox.Show(this,
                                $"输入的[{changedTimeLable}]时间早于[创建时间]！", "提醒",
                                MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                }
                else if (e.ColumnIndex == 4)
                {
                    DateTime wTime = DateTime.Parse(dataGridView.Rows[e.RowIndex].Cells[5].Value.ToString());
                    DateTime aTime = DateTime.Parse(dataGridView.Rows[e.RowIndex].Cells[6].Value.ToString());
                    if (wTime < curTime && aTime < curTime)
                        MessageBox.Show(this,
                            $"输入的创建时间晚于[最后修改时间]和[最后访问时间]！", "提醒",
                            MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    else if (wTime < curTime)
                        MessageBox.Show(this,
                            $"输入的创建时间晚于[最后修改时间]！", "提醒",
                            MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    else if (aTime < curTime)
                        MessageBox.Show(this,
                            $"输入的创建时间晚于[最后访问时间]！", "提醒",
                            MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
            }
            else
            {
                SetState("不支持修改的列");
                return;
            }

        }

        #endregion

        private void button_apply_Click(object sender, EventArgs e)
        {
            // collect changed rows
            List<DataGridViewRow> changedRows = new List<DataGridViewRow>();
            FlagedTagData ftData;
            foreach (DataGridViewRow dgvRow in dataGridView.Rows)
            {
                ftData = (FlagedTagData)dgvRow.Tag;
                if (ftData.isChanged)
                    changedRows.Add(dgvRow);
            }

            // change and show info
            ThreadPool.QueueUserWorkItem(new WaitCallback((stat) =>
            {
                if (changedRows.Count == 0)
                    SetState("没有需要修改的文件、文件夹。");
                int counter = 0;
                foreach (DataGridViewRow dgvRow in changedRows)
                {
                    try
                    {
                        ftData = (FlagedTagData)dgvRow.Tag;
                        FileAttributes fa;
                        bool changed = false;
                        if (ftData.fi != null)
                            fa = ftData.fi.Attributes;
                        else //if (ftData.di != null)                        
                            fa = ftData.di.Attributes;


                        if (fa.HasFlag(FileAttributes.Normal) != (bool)dgvRow.Cells[7].Value)
                        { SwitchAttribute(ref fa, FileAttributes.Normal); changed = true; }
                        if (fa.HasFlag(FileAttributes.System) != (bool)dgvRow.Cells[8].Value)
                        { SwitchAttribute(ref fa, FileAttributes.System); changed = true; }
                        if (fa.HasFlag(FileAttributes.Archive) != (bool)dgvRow.Cells[9].Value)
                        { SwitchAttribute(ref fa, FileAttributes.Archive); changed = true; }
                        if (fa.HasFlag(FileAttributes.Directory) != (bool)dgvRow.Cells[10].Value)
                        { SwitchAttribute(ref fa, FileAttributes.Directory); changed = true; }

                        if (fa.HasFlag(FileAttributes.ReadOnly) != (bool)dgvRow.Cells[11].Value)
                        { SwitchAttribute(ref fa, FileAttributes.ReadOnly); changed = true; }
                        if (fa.HasFlag(FileAttributes.Hidden) != (bool)dgvRow.Cells[12].Value)
                        { SwitchAttribute(ref fa, FileAttributes.Hidden); changed = true; }
                        if (fa.HasFlag(FileAttributes.Compressed) != (bool)dgvRow.Cells[13].Value)
                        { SwitchAttribute(ref fa, FileAttributes.Compressed); changed = true; }
                        if (fa.HasFlag(FileAttributes.Encrypted) != (bool)dgvRow.Cells[14].Value)
                        { SwitchAttribute(ref fa, FileAttributes.Encrypted); changed = true; }
                        if (fa.HasFlag(FileAttributes.Device) != (bool)dgvRow.Cells[15].Value)
                        { SwitchAttribute(ref fa, FileAttributes.Device); changed = true; }

                        if (fa.HasFlag(FileAttributes.Offline) != (bool)dgvRow.Cells[16].Value)
                        { SwitchAttribute(ref fa, FileAttributes.Offline); changed = true; }
                        if (fa.HasFlag(FileAttributes.IntegrityStream) != (bool)dgvRow.Cells[17].Value)
                        { SwitchAttribute(ref fa, FileAttributes.IntegrityStream); changed = true; }
                        if (fa.HasFlag(FileAttributes.NoScrubData) != (bool)dgvRow.Cells[18].Value)
                        { SwitchAttribute(ref fa, FileAttributes.NoScrubData); changed = true; }
                        if (fa.HasFlag(FileAttributes.NotContentIndexed) != (bool)dgvRow.Cells[19].Value)
                        { SwitchAttribute(ref fa, FileAttributes.NotContentIndexed); changed = true; }
                        if (fa.HasFlag(FileAttributes.ReparsePoint) != (bool)dgvRow.Cells[20].Value)
                        { SwitchAttribute(ref fa, FileAttributes.ReparsePoint); changed = true; }

                        if (fa.HasFlag(FileAttributes.SparseFile) != (bool)dgvRow.Cells[21].Value)
                        { SwitchAttribute(ref fa, FileAttributes.SparseFile); changed = true; }

                        if (changed)
                        {
                            if (ftData.fi != null)
                            {
                                ftData.fi.Attributes = fa;
                                SetRow(dgvRow, ftData.fi.Attributes);
                            }
                            else
                            {
                                ftData.di.Attributes = fa;
                                SetRow(dgvRow, ftData.di.Attributes);
                            }
                        }
                        changed = false;
                        if (ftData.fi != null)
                        {
                            if (ftData.newCTime != DateTime.MinValue)
                            { ftData.fi.CreationTime = ftData.newCTime; changed = true; }
                            if (ftData.newATime != DateTime.MinValue)
                            { ftData.fi.LastAccessTime = ftData.newATime; changed = true; }
                            if (ftData.newWTime != DateTime.MinValue)
                            { ftData.fi.LastWriteTime = ftData.newWTime; changed = true; }
                            if (changed)
                                SetRow(dgvRow, ftData.fi.CreationTime,
                                    ftData.fi.LastWriteTime, ftData.fi.LastAccessTime);
                        }
                        else //if (ftData.di != null)
                        {
                            if (ftData.newCTime != DateTime.MinValue)
                            { ftData.di.CreationTime = ftData.newCTime; changed = true; }
                            if (ftData.newATime != DateTime.MinValue)
                            { ftData.di.LastAccessTime = ftData.newATime; changed = true; }
                            if (ftData.newWTime != DateTime.MinValue)
                            { ftData.di.LastWriteTime = ftData.newWTime; changed = true; }
                            if (changed)
                                SetRow(dgvRow, ftData.di.CreationTime,
                                    ftData.di.LastWriteTime, ftData.di.LastAccessTime);
                        }
                        ftData.isChanged = false;
                        SetRow(dgvRow, false);
                        counter++;
                    }
                    catch (Exception err)
                    {
                        SetState(err);
                    }
                }
                if (changedRows.Count > 0)
                    SetState($"成功修改[{counter}/{changedRows.Count}]个文件、文件夹。");
            }));
        }


        private void SwitchAttribute(ref FileAttributes target, FileAttributes value)
        {
            if (target.HasFlag(value))
                target -= value;
            else
                target |= value;
        }
    }
}
