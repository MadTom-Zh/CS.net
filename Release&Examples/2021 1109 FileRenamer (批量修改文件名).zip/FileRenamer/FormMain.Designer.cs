﻿namespace FileRenamer
{
    partial class FormMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.label5 = new System.Windows.Forms.Label();
            this.myRichTextBox_lineNo = new FileRenamer.MyRichTextBox();
            this.richTextBox_pathList = new FileRenamer.MyRichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.richTextBox_orgNameList = new FileRenamer.MyRichTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.richTextBox_newNameList = new FileRenamer.MyRichTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel_state = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar = new System.Windows.Forms.ToolStripProgressBar();
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.button_clearList = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox_lookingFor = new System.Windows.Forms.TextBox();
            this.button_replaceAll = new System.Windows.Forms.Button();
            this.textBox_replaceTo = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox_dropZone = new System.Windows.Forms.TextBox();
            this.button_removePrefix = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.numericUpDown_noStart = new System.Windows.Forms.NumericUpDown();
            this.button_addNoPrefix = new System.Windows.Forms.Button();
            this.numericUpDown_noWidth = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button_exe = new System.Windows.Forms.Button();
            this.button_sortName = new System.Windows.Forms.Button();
            this.button_sortTime = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.statusStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_noStart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_noWidth)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(12, 69);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.label5);
            this.splitContainer1.Panel1.Controls.Add(this.myRichTextBox_lineNo);
            this.splitContainer1.Panel1.Controls.Add(this.richTextBox_pathList);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(1060, 574);
            this.splitContainer1.SplitterDistance = 251;
            this.splitContainer1.SplitterWidth = 10;
            this.splitContainer1.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("SimSun", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(49, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 16);
            this.label5.TabIndex = 6;
            this.label5.Text = "路径";
            // 
            // myRichTextBox_lineNo
            // 
            this.myRichTextBox_lineNo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.myRichTextBox_lineNo.Font = new System.Drawing.Font("SimSun", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.myRichTextBox_lineNo.Location = new System.Drawing.Point(3, 21);
            this.myRichTextBox_lineNo.Name = "myRichTextBox_lineNo";
            this.myRichTextBox_lineNo.ReadOnly = true;
            this.myRichTextBox_lineNo.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.myRichTextBox_lineNo.Size = new System.Drawing.Size(40, 550);
            this.myRichTextBox_lineNo.TabIndex = 5;
            this.myRichTextBox_lineNo.Text = "";
            this.myRichTextBox_lineNo.WordWrap = false;
            // 
            // richTextBox_pathList
            // 
            this.richTextBox_pathList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBox_pathList.Font = new System.Drawing.Font("SimSun", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox_pathList.Location = new System.Drawing.Point(49, 21);
            this.richTextBox_pathList.Name = "richTextBox_pathList";
            this.richTextBox_pathList.ReadOnly = true;
            this.richTextBox_pathList.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.richTextBox_pathList.Size = new System.Drawing.Size(199, 550);
            this.richTextBox_pathList.TabIndex = 4;
            this.richTextBox_pathList.Text = "";
            this.richTextBox_pathList.WordWrap = false;
            this.richTextBox_pathList.KeyDown += new System.Windows.Forms.KeyEventHandler(this.RichTextBox_pathList_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("SimSun", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "序号";
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.IsSplitterFixed = true;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.richTextBox_orgNameList);
            this.splitContainer2.Panel1.Controls.Add(this.label2);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.richTextBox_newNameList);
            this.splitContainer2.Panel2.Controls.Add(this.label3);
            this.splitContainer2.Size = new System.Drawing.Size(799, 574);
            this.splitContainer2.SplitterDistance = 399;
            this.splitContainer2.TabIndex = 0;
            // 
            // richTextBox_orgNameList
            // 
            this.richTextBox_orgNameList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBox_orgNameList.Font = new System.Drawing.Font("SimSun", 9.75F);
            this.richTextBox_orgNameList.Location = new System.Drawing.Point(3, 21);
            this.richTextBox_orgNameList.Name = "richTextBox_orgNameList";
            this.richTextBox_orgNameList.ReadOnly = true;
            this.richTextBox_orgNameList.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox_orgNameList.Size = new System.Drawing.Size(393, 550);
            this.richTextBox_orgNameList.TabIndex = 5;
            this.richTextBox_orgNameList.Text = "";
            this.richTextBox_orgNameList.WordWrap = false;
            this.richTextBox_orgNameList.KeyDown += new System.Windows.Forms.KeyEventHandler(this.RichTextBox_orgNameList_KeyDown);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("SimSun", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "原名";
            // 
            // richTextBox_newNameList
            // 
            this.richTextBox_newNameList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBox_newNameList.Font = new System.Drawing.Font("SimSun", 9.75F);
            this.richTextBox_newNameList.Location = new System.Drawing.Point(3, 21);
            this.richTextBox_newNameList.Name = "richTextBox_newNameList";
            this.richTextBox_newNameList.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox_newNameList.Size = new System.Drawing.Size(390, 550);
            this.richTextBox_newNameList.TabIndex = 6;
            this.richTextBox_newNameList.Text = "";
            this.richTextBox_newNameList.WordWrap = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("SimSun", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "新名";
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel_state,
            this.toolStripProgressBar});
            this.statusStrip.Location = new System.Drawing.Point(0, 659);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(1084, 23);
            this.statusStrip.TabIndex = 3;
            this.statusStrip.Text = "statusStrip";
            // 
            // toolStripStatusLabel_state
            // 
            this.toolStripStatusLabel_state.Name = "toolStripStatusLabel_state";
            this.toolStripStatusLabel_state.Size = new System.Drawing.Size(967, 18);
            this.toolStripStatusLabel_state.Spring = true;
            this.toolStripStatusLabel_state.Text = "Ready";
            this.toolStripStatusLabel_state.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStripProgressBar
            // 
            this.toolStripProgressBar.Name = "toolStripProgressBar";
            this.toolStripProgressBar.Size = new System.Drawing.Size(100, 17);
            // 
            // button_clearList
            // 
            this.button_clearList.Location = new System.Drawing.Point(12, 12);
            this.button_clearList.Name = "button_clearList";
            this.button_clearList.Size = new System.Drawing.Size(43, 51);
            this.button_clearList.TabIndex = 7;
            this.button_clearList.Text = "清空";
            this.button_clearList.UseVisualStyleBackColor = true;
            this.button_clearList.Click += new System.EventHandler(this.Button_clearList_Click);
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(818, 15);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "搜索：";
            // 
            // textBox_lookingFor
            // 
            this.textBox_lookingFor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_lookingFor.Location = new System.Drawing.Point(865, 12);
            this.textBox_lookingFor.Name = "textBox_lookingFor";
            this.textBox_lookingFor.Size = new System.Drawing.Size(100, 20);
            this.textBox_lookingFor.TabIndex = 10;
            // 
            // button_replaceAll
            // 
            this.button_replaceAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_replaceAll.Location = new System.Drawing.Point(971, 12);
            this.button_replaceAll.Name = "button_replaceAll";
            this.button_replaceAll.Size = new System.Drawing.Size(46, 41);
            this.button_replaceAll.TabIndex = 11;
            this.button_replaceAll.Text = "全部替换";
            this.button_replaceAll.UseVisualStyleBackColor = true;
            this.button_replaceAll.Click += new System.EventHandler(this.Button_replaceAll_Click);
            // 
            // textBox_replaceTo
            // 
            this.textBox_replaceTo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_replaceTo.Location = new System.Drawing.Point(865, 33);
            this.textBox_replaceTo.Name = "textBox_replaceTo";
            this.textBox_replaceTo.Size = new System.Drawing.Size(100, 20);
            this.textBox_replaceTo.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(818, 36);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 13);
            this.label8.TabIndex = 12;
            this.label8.Text = "换为：";
            // 
            // textBox_dropZone
            // 
            this.textBox_dropZone.AllowDrop = true;
            this.textBox_dropZone.Location = new System.Drawing.Point(61, 12);
            this.textBox_dropZone.Multiline = true;
            this.textBox_dropZone.Name = "textBox_dropZone";
            this.textBox_dropZone.ReadOnly = true;
            this.textBox_dropZone.Size = new System.Drawing.Size(130, 51);
            this.textBox_dropZone.TabIndex = 14;
            this.textBox_dropZone.Text = "\r\n请将文件夹扔这里";
            this.textBox_dropZone.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_dropZone.DragDrop += new System.Windows.Forms.DragEventHandler(this.TextBox_dropZone_DragDrop);
            this.textBox_dropZone.DragEnter += new System.Windows.Forms.DragEventHandler(this.TextBox_dropZone_DragEnter);
            // 
            // button_removePrefix
            // 
            this.button_removePrefix.Location = new System.Drawing.Point(197, 12);
            this.button_removePrefix.Name = "button_removePrefix";
            this.button_removePrefix.Size = new System.Drawing.Size(43, 51);
            this.button_removePrefix.TabIndex = 15;
            this.button_removePrefix.Text = "消除前缀";
            this.button_removePrefix.UseVisualStyleBackColor = true;
            this.button_removePrefix.Click += new System.EventHandler(this.Button_removePrefix_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(247, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "编号前缀";
            // 
            // numericUpDown_noStart
            // 
            this.numericUpDown_noStart.Location = new System.Drawing.Point(308, 15);
            this.numericUpDown_noStart.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUpDown_noStart.Name = "numericUpDown_noStart";
            this.numericUpDown_noStart.Size = new System.Drawing.Size(58, 20);
            this.numericUpDown_noStart.TabIndex = 17;
            this.numericUpDown_noStart.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // button_addNoPrefix
            // 
            this.button_addNoPrefix.Location = new System.Drawing.Point(372, 12);
            this.button_addNoPrefix.Name = "button_addNoPrefix";
            this.button_addNoPrefix.Size = new System.Drawing.Size(43, 51);
            this.button_addNoPrefix.TabIndex = 18;
            this.button_addNoPrefix.Text = "添加前缀";
            this.button_addNoPrefix.UseVisualStyleBackColor = true;
            this.button_addNoPrefix.Click += new System.EventHandler(this.Button_addNoPrefix_Click);
            // 
            // numericUpDown_noWidth
            // 
            this.numericUpDown_noWidth.Location = new System.Drawing.Point(308, 41);
            this.numericUpDown_noWidth.Name = "numericUpDown_noWidth";
            this.numericUpDown_noWidth.Size = new System.Drawing.Size(58, 20);
            this.numericUpDown_noWidth.TabIndex = 20;
            this.numericUpDown_noWidth.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(247, 43);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 13);
            this.label9.TabIndex = 19;
            this.label9.Text = "宽度位数";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 646);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(330, 13);
            this.label4.TabIndex = 21;
            this.label4.Text = "* 光标在某个位置，或选中多行时按下Del可以消除这些条目；";
            // 
            // button_exe
            // 
            this.button_exe.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_exe.BackColor = System.Drawing.Color.DarkOrange;
            this.button_exe.Location = new System.Drawing.Point(1023, 12);
            this.button_exe.Name = "button_exe";
            this.button_exe.Size = new System.Drawing.Size(46, 41);
            this.button_exe.TabIndex = 22;
            this.button_exe.Text = "执行";
            this.button_exe.UseVisualStyleBackColor = false;
            this.button_exe.Click += new System.EventHandler(this.Button_exe_Click);
            // 
            // button_sortName
            // 
            this.button_sortName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_sortName.Location = new System.Drawing.Point(739, 12);
            this.button_sortName.Name = "button_sortName";
            this.button_sortName.Size = new System.Drawing.Size(73, 23);
            this.button_sortName.TabIndex = 23;
            this.button_sortName.Text = "Sort Name";
            this.button_sortName.UseVisualStyleBackColor = true;
            this.button_sortName.Click += new System.EventHandler(this.Button_sortName_Click);
            // 
            // button_sortTime
            // 
            this.button_sortTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_sortTime.Location = new System.Drawing.Point(739, 40);
            this.button_sortTime.Name = "button_sortTime";
            this.button_sortTime.Size = new System.Drawing.Size(73, 23);
            this.button_sortTime.TabIndex = 24;
            this.button_sortTime.Text = "Sort Time";
            this.button_sortTime.UseVisualStyleBackColor = true;
            this.button_sortTime.Click += new System.EventHandler(this.Button_sortTime_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1084, 682);
            this.Controls.Add(this.button_sortTime);
            this.Controls.Add(this.button_sortName);
            this.Controls.Add(this.button_exe);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.numericUpDown_noWidth);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.button_addNoPrefix);
            this.Controls.Add(this.numericUpDown_noStart);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button_removePrefix);
            this.Controls.Add(this.textBox_dropZone);
            this.Controls.Add(this.textBox_replaceTo);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.button_replaceAll);
            this.Controls.Add(this.textBox_lookingFor);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.button_clearList);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.splitContainer1);
            this.Name = "FormMain";
            this.Text = "文件名批量调整 by longtombbj 2021 1123";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_noStart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_noWidth)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel_state;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        private MyRichTextBox richTextBox_pathList;
        private MyRichTextBox richTextBox_orgNameList;
        private MyRichTextBox richTextBox_newNameList;
        private MyRichTextBox myRichTextBox_lineNo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button_clearList;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_lookingFor;
        private System.Windows.Forms.Button button_replaceAll;
        private System.Windows.Forms.TextBox textBox_replaceTo;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox_dropZone;
        private System.Windows.Forms.Button button_removePrefix;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown numericUpDown_noStart;
        private System.Windows.Forms.Button button_addNoPrefix;
        private System.Windows.Forms.NumericUpDown numericUpDown_noWidth;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button_exe;
        private System.Windows.Forms.Button button_sortName;
        private System.Windows.Forms.Button button_sortTime;
    }
}

