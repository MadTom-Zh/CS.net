﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;
using MadTomDev.Data;

namespace FileRenamer
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();

            richTextBox_pathList.SendMessageEvent += richTextBox_pathList_SendMessageEvent;
        }

        private void ShowStatues(string msg)
        {
            toolStripStatusLabel_state.Text = msg.Replace('\r', ' ').Replace('\n', ' ');
            Update();
        }
        private void ShowStatuesProgress(int cur, int all)
        {
            toolStripProgressBar.Maximum = all;
            toolStripProgressBar.Value = cur;
            Update();
        }




        private void RefreshRTBoxes()
        {
            StringBuilder strNo = new StringBuilder();
            StringBuilder strPath = new StringBuilder();
            StringBuilder strOri = new StringBuilder();
            StringBuilder strNew = new StringBuilder();
            string newLine = "\n";

            RenameItem ri;
            for (int i = 0; i < allRenameItems.Count; i++)
            {
                strNo.Append((i + 1) + newLine);

                ri = allRenameItems[i];
                strPath.Append(ri.fileDir + newLine);

                strOri.Append(ri.file.Name + newLine);
                strNew.Append(ri.newName + newLine);
            }

            myRichTextBox_lineNo.Text = strNo.ToString();
            richTextBox_pathList.Text = strPath.ToString();
            richTextBox_orgNameList.Text = strOri.ToString();
            richTextBox_newNameList.Text = strNew.ToString();
        }

        private List<RenameItem> allRenameItems = new List<RenameItem>();

        private void AddDir(DirectoryInfo bassDir)
        {
            foreach (DirectoryInfo dir in bassDir.GetDirectories())
            {
                AddDir(dir);
            }
            foreach (FileInfo file in bassDir.GetFiles())
            {
                AddFile(file);
            }
        }
        private void AddFile(FileInfo fileInfo)
        {
            RenameItem fount = allRenameItems.Find(a => a.file.FullName == fileInfo.FullName);
            if (fount == null)
            {
                allRenameItems.Add(
                    new RenameItem()
                    { file = fileInfo, newName = fileInfo.Name, });
            }
        }




        void richTextBox_pathList_SendMessageEvent(Message msg)
        {
            richTextBox_orgNameList.Scroll(msg);
            myRichTextBox_lineNo.Scroll(msg);
            richTextBox_newNameList.Scroll(msg);
        }



        private bool Rename_Check(ref List<string> newNameList)
        {
            newNameList.Clear();

            string[] newNames = richTextBox_newNameList.Text.Split(new string[] { "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);
            int filesCount = allRenameItems.Count;
            if (newNames.Length < filesCount)
                return false;

            string nn;
            for (int i = 0; i < filesCount; i++)
            {
                nn = newNames[i];
                if (Utilities.Checker.CheckIOName(nn))
                {
                    newNameList.Add(nn);
                }
                else return false;
            }
            return true;
        }


        private void Button_clearList_Click(object sender, EventArgs e)
        {
            allRenameItems.Clear();

            richTextBox_pathList.Clear();
            richTextBox_orgNameList.Clear();
            richTextBox_newNameList.Clear();
            myRichTextBox_lineNo.Clear();
        }

        private void RichTextBox_pathList_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                RemoveFiles((RichTextBox)sender);
            }
        }
        private void RichTextBox_orgNameList_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                RemoveFiles((RichTextBox)sender);
            }
        }
        private void RemoveFiles(RichTextBox tBox)
        {
            string text = tBox.Text;
            int charIndexStart = tBox.SelectionStart;
            int charSelectionLength = tBox.SelectionLength;

            int linesBefore = text.Substring(0, charIndexStart).Split(Environment.NewLine.ToArray()).Length - 1;
            int linesSelect = text.Substring(charIndexStart, charSelectionLength).Split(Environment.NewLine.ToArray()).Length;

            if (linesBefore + linesSelect > allRenameItems.Count)
            {
                linesSelect = allRenameItems.Count - linesBefore;
            }
            if (linesSelect < 1)
            {
                ShowStatues("未能删除记录，选取的行数小于1。");
                return;
            }

            List<string> newNameList = new List<string>();
            newNameList.AddRange(richTextBox_newNameList.Text.Split(new string[] { "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries));

            for (int i = linesBefore + linesSelect - 1; i >= linesBefore; i--)
            {
                allRenameItems.RemoveAt(i);
                newNameList.RemoveAt(i);
            }


            RefreshRTBoxes();
            StringBuilder newNames = new StringBuilder();
            string newLine = Environment.NewLine;
            foreach (string n in newNameList)
                newNames.Append(n + newLine);
            richTextBox_newNameList.Text = newNames.ToString();
        }

        private void Button_exe_Click(object sender, EventArgs e)
        {
            if (allRenameItems.Count == 0)
            {
                ShowStatues("没有要改名的文件");
                return;
            }

            List<string> newNameList = new List<string>();
            if (Rename_Check(ref newNameList))
            {
                Rename_Exe(newNameList);
            }
            else ShowStatues("文件名中存在错误，请检查");

        }
        private void Rename_Exe(List<string> newNameList)
        {
            int idx = 0;
            RenameItem ri;

            int countAll = allRenameItems.Count;
            int errorCount = 0;
            for (int i = 0; i < countAll; i++)
            {
                try
                {
                    idx = i;
                    ri = allRenameItems[i];
                    ri.file.MoveTo(ri.fileDir + newNameList[i]);
                    //fi.MoveTo(allItemNamesNew[i]);
                    ShowStatuesProgress((idx + 1), countAll);

                }
                catch (Exception err)
                {
                    errorCount++;
                    ShowStatues("[" + (idx + 1) + "] " + err.ToString());
                    ShowStatuesProgress(0, 0);
                }
            }
            if (errorCount > 1)
            {
                MessageBox.Show(this,
                    $"发生了({errorCount})个错误。", "多个错误",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }

            // re-sort



            if (errorCount > 0)
                ShowStatues("部分完成。");
            else
                ShowStatues("全部完成！！");
            ShowStatuesProgress(0, 0);
        }

        private List<string> dropedFiles = new List<string>();
        private void TextBox_dropZone_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                Array arr = (Array)e.Data.GetData(DataFormats.FileDrop);
                if (arr.Length > 0)
                    e.Effect = DragDropEffects.Link;
                else e.Effect = DragDropEffects.None;
            }
            else e.Effect = DragDropEffects.None;
        }
        private void TextBox_dropZone_DragDrop(object sender, DragEventArgs e)
        {
            if (e.Effect != DragDropEffects.Link)
                return;
            string[] filesNDirs = (string[])e.Data.GetData(DataFormats.FileDrop);

            this.Enabled = false;
            ShowStatues("开始扫描...");

            foreach (string i in filesNDirs)
            {
                if (Directory.Exists(i))
                    AddDir(new DirectoryInfo(i));
                else if (File.Exists(i))
                    AddFile(new FileInfo(i));
            }


            RefreshRTBoxes();

            ShowStatues("就绪");
            this.Enabled = true;
        }


        private List<string> NewNamesList_fromUI
        {
            get
            {
                string[] names = richTextBox_newNameList.Text.Split(new string[] { "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);
                List<string> result = new List<string>();
                int count = names.Length;
                string item;
                for (int i = 0; i < count; i++)
                {
                    item = names[i].Trim();
                    if (item.Length > 0)
                        result.Add(item);
                }
                return result;
            }
            set
            {
                StringBuilder text = new StringBuilder();
                string newLine = "\n";
                foreach (string s in value)
                {
                    text.Append(s + newLine);
                }
                richTextBox_newNameList.Text = text.ToString();
            }
        }
        private void NewNames_BackSetToAllRenameItems()
        {
            List<string> newNames = NewNamesList_fromUI;
            int maxIdx = Math.Min(newNames.Count, allRenameItems.Count) - 1;
            RenameItem ri;
            for (int i = 0; i <= maxIdx; i++)
            {
                ri = allRenameItems[i];
                ri.newName = newNames[i];
                allRenameItems[i] = ri;
            }
        }

        private void Button_removePrefix_Click(object sender, EventArgs e)
        {
            if (allRenameItems.Count == 0)
                return;

            List<string> list = NewNamesList_fromUI;
            string line;
            for (int i = list.Count - 1; i >= 0; i--)
            {
                line = list[i].Trim();
                if (line.Contains("."))
                {
                    line = line.Substring(line.IndexOf(".") + 1);
                    if (line.Length > 0)
                        list[i] = line;
                }
            }
            NewNamesList_fromUI = list;
        }

        private void Button_addNoPrefix_Click(object sender, EventArgs e)
        {
            if (allRenameItems.Count == 0)
                return;

            int startNo = (int)numericUpDown_noStart.Value;
            string format = "";
            for (int i = (int)numericUpDown_noWidth.Value; i > 0; i--)
            {
                format += "0";
            }

            List<string> list = NewNamesList_fromUI;
            int count = list.Count;
            for (int i = 0; i < count; i++)
            {
                list[i] = (startNo++).ToString(format) + "." + list[i].Trim();
            }
            NewNamesList_fromUI = list;
        }

        private void Button_replaceAll_Click(object sender, EventArgs e)
        {
            if (textBox_lookingFor.Text.Length == 0)
                return;

            string rText = richTextBox_newNameList.Text;
            if (rText.Contains(textBox_lookingFor.Text))
            {
                rText = rText.Replace(textBox_lookingFor.Text, textBox_replaceTo.Text);
                // check duplicated names;
                string dup = null;
                if (_ReplaceAll_CheckDuplicatedNames(rText, out dup))
                {
                    richTextBox_newNameList.Text = rText;
                    ShowStatues("Replace complete.");
                }
                else
                {
                    ShowStatues("Duplicated result detected:" + dup);
                }
            }
            else ShowStatues("Not found: " + textBox_lookingFor.Text);
        }
        private bool _ReplaceAll_CheckDuplicatedNames(string newNamesTxBlock, out string dupdNewName)
        {
            dupdNewName = null;
            List<string> newNameList = NewNamesList_fromUI;
            List<string> newFullnameList = new List<string>();
            int minCount = Math.Min(allRenameItems.Count, newNameList.Count);
            for (int i = 0; i < minCount; i++)
            {
                newFullnameList.Add(allRenameItems[i].fileDir + NewNamesList_fromUI[i]);
            }
            newFullnameList.Sort();
            string s1, s2;
            for (int i = newFullnameList.Count - 1; i > 0; i--)
            {
                s1 = newFullnameList[i].ToLower();
                s2 = newFullnameList[i - 1].ToLower();
                if (s1 == s2)
                {
                    dupdNewName = s1.Substring(s1.LastIndexOf("\\") + 1);
                    return false;
                }
            }
            return true;
        }


        private enum SortModes
        { None, NameASC, NameDESC, TimeASC, TimeDESC }
        private SortModes Sortmode = SortModes.None;
        private SortModes SortmodePreName, SortmodePreTime;
        private void Button_sortName_Click(object sender, EventArgs e)
        {
            if (SortmodePreName == SortModes.NameASC)
                Sortmode = SortModes.NameDESC;
            else
                Sortmode = SortModes.NameASC;

            SortmodePreName = Sortmode;
            SortList();
        }
        private void Button_sortTime_Click(object sender, EventArgs e)
        {
            if (SortmodePreTime == SortModes.TimeASC)
                Sortmode = SortModes.TimeDESC;
            else
                Sortmode = SortModes.TimeASC;

            SortmodePreTime = Sortmode;
            SortList();
        }
        private void SortList()
        {
            if (Sortmode == SortModes.None)
                return;

            NewNames_BackSetToAllRenameItems();
            switch (Sortmode)
            {
                case SortModes.NameASC:
                    allRenameItems.Sort(delegate (RenameItem v1, RenameItem v2)
                    {
                        if (v1.prefixNo >= 0 && v2.prefixNo >= 0)
                            return v1.prefixNo < v2.prefixNo ? 1 : -1;
                        else
                            return CompareText(v2.file.Name, v1.file.Name);
                    });
                    ShowStatues("Sort names, ASC.");
                    break;
                case SortModes.NameDESC:
                    allRenameItems.Sort(delegate (RenameItem v1, RenameItem v2)
                    {
                        if (v1.prefixNo >= 0 && v2.prefixNo >= 0)
                            return v1.prefixNo > v2.prefixNo ? 1 : -1;
                        return CompareText(v1.file.Name, v2.file.Name);
                    });
                    ShowStatues("Sort names, DESC.");
                    break;
                case SortModes.TimeASC:
                    allRenameItems.Sort(delegate (RenameItem v1, RenameItem v2)
                    {
                        if (v1.file.LastWriteTime < v2.file.LastWriteTime) return -1;
                        else if (v1.file.LastWriteTime > v2.file.LastWriteTime) return 1;
                        else return 0;
                    });
                    ShowStatues("Sort times, ASC.");
                    break;
                case SortModes.TimeDESC:
                    allRenameItems.Sort(delegate (RenameItem v1, RenameItem v2)
                    {
                        if (v1.file.LastWriteTime < v2.file.LastWriteTime) return 1;
                        else if (v1.file.LastWriteTime > v2.file.LastWriteTime) return -1;
                        else return 0;
                    });
                    ShowStatues("Sort times, DESC.");
                    break;
            }
            RefreshRTBoxes();
        }
        private int CompareText(string str1, string str2)
        {
            int maxIdx = Math.Min(str1.Length, str2.Length) - 1;
            if (maxIdx < 0)
            {
                if (str1.Length < str2.Length) return 1;
                else if (str1.Length > str2.Length) return -1;
                else return 0;
            }
            else
            {
                char c1, c2;
                for (int i = 0; i <= maxIdx; i++)
                {
                    c1 = str1[i]; c2 = str2[i];
                    if (c1 == c2)
                    {
                        if (i == maxIdx)
                        {
                            if (str1.Length < str2.Length) return 1;
                            else if (str1.Length > str2.Length) return -1;
                            else return 0;
                        }
                        else continue;
                    }
                    else if (c1 < c2) return 1;
                    else return -1;
                }
                return 0;
            }
        }

        private class RenameItem
        {
            public FileInfo file;
            public string fileDir
            {
                get
                {
                    if (file == null) return null;
                    return file.FullName.Substring(0, file.FullName.Length - file.Name.Length);
                }
            }
            public string newName;
            private long _prefixNo = -2;
            public long prefixNo
            {
                get
                {
                    if (_prefixNo == -2)
                    {
                        string fileName = file.Name;
                        StringBuilder textNo = new StringBuilder();
                        foreach (char c in fileName)
                        {
                            if (c >= '0' && c <= '9')
                                textNo.Append(c);
                            else
                                break;
                        }
                        if (textNo.Length > 0)
                            _prefixNo = int.Parse(textNo.ToString());
                        else
                            _prefixNo = - 1;
                    }
                    return _prefixNo;
                }
            }
        }
    }

    #region MyRichTextBox
    public class WindowsMessage
    {
        //WM_HSCROLL = 0x0114,
        //WM_VSCROLL = 0x0115
        public static int WM_HSCROLL = 0x0114;
        public static int WM_VSCROLL = 0x0115;
    }
    public delegate void SendMessage(Message msg);
    public class MyRichTextBox : System.Windows.Forms.RichTextBox
    {
        public event SendMessage SendMessageEvent;
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WindowsMessage.WM_HSCROLL || m.Msg == WindowsMessage.WM_VSCROLL)
            {
                if (SendMessageEvent != null)
                {
                    SendMessageEvent(m);
                }
            }
            base.WndProc(ref m);
        }
        public void Scroll(Message m)
        {
            m.HWnd = this.Handle;
            WndProc(ref m);
        }
    }
    #endregion
}
