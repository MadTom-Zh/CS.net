﻿namespace ScheduleSwitch
{
    partial class FormSetSSConfig
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox_month = new System.Windows.Forms.TextBox();
            this.textBox_week = new System.Windows.Forms.TextBox();
            this.textBox_dayTime = new System.Windows.Forms.TextBox();
            this.textBox_process = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.button_cancel = new System.Windows.Forms.Button();
            this.button_ok = new System.Windows.Forms.Button();
            this.button_brsFile = new System.Windows.Forms.Button();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // textBox_month
            // 
            this.textBox_month.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_month.Location = new System.Drawing.Point(59, 12);
            this.textBox_month.Name = "textBox_month";
            this.textBox_month.Size = new System.Drawing.Size(352, 21);
            this.textBox_month.TabIndex = 0;
            this.textBox_month.Text = "1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12";
            // 
            // textBox_week
            // 
            this.textBox_week.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_week.Location = new System.Drawing.Point(59, 39);
            this.textBox_week.Name = "textBox_week";
            this.textBox_week.Size = new System.Drawing.Size(352, 21);
            this.textBox_week.TabIndex = 1;
            this.textBox_week.Text = "1, 2, 3, 4, 5, 6, 7";
            // 
            // textBox_dayTime
            // 
            this.textBox_dayTime.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_dayTime.Location = new System.Drawing.Point(59, 66);
            this.textBox_dayTime.Name = "textBox_dayTime";
            this.textBox_dayTime.Size = new System.Drawing.Size(352, 21);
            this.textBox_dayTime.TabIndex = 2;
            this.textBox_dayTime.Text = "06:30:00,07:30:00 ; 13:50:00,14:20:00";
            // 
            // textBox_process
            // 
            this.textBox_process.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_process.Location = new System.Drawing.Point(59, 93);
            this.textBox_process.Name = "textBox_process";
            this.textBox_process.Size = new System.Drawing.Size(331, 21);
            this.textBox_process.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "月份";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "周数";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 1;
            this.label3.Text = "时间段";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 1;
            this.label4.Text = "进程";
            // 
            // textBox5
            // 
            this.textBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox5.Location = new System.Drawing.Point(14, 120);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox5.Size = new System.Drawing.Size(397, 103);
            this.textBox5.TabIndex = 6;
            this.textBox5.Text = "月份，例如 1, 2, 3, 4 ，其中逗号为半角；\r\n周天数，例如 1, 2, 3, 4, 5 （周一至至周七），同样用半角逗号；\r\n时间段，例如 00:00:" +
    "00,01:00:00 ，多个时间段，用半角分号 ; 来分隔。\r\n进程，例如 \"C:\\a 2012 0912.txt\" -readOnly ，如果后面参数有效的" +
    "话";
            // 
            // button_cancel
            // 
            this.button_cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button_cancel.Location = new System.Drawing.Point(336, 229);
            this.button_cancel.Name = "button_cancel";
            this.button_cancel.Size = new System.Drawing.Size(75, 23);
            this.button_cancel.TabIndex = 5;
            this.button_cancel.Text = "取消(&C)";
            this.button_cancel.UseVisualStyleBackColor = true;
            this.button_cancel.Click += new System.EventHandler(this.button_cancel_Click);
            // 
            // button_ok
            // 
            this.button_ok.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ok.Location = new System.Drawing.Point(255, 229);
            this.button_ok.Name = "button_ok";
            this.button_ok.Size = new System.Drawing.Size(75, 23);
            this.button_ok.TabIndex = 4;
            this.button_ok.Text = "确定(&O)";
            this.button_ok.UseVisualStyleBackColor = true;
            this.button_ok.Click += new System.EventHandler(this.button_ok_Click);
            // 
            // button_brsFile
            // 
            this.button_brsFile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_brsFile.Location = new System.Drawing.Point(396, 93);
            this.button_brsFile.Name = "button_brsFile";
            this.button_brsFile.Size = new System.Drawing.Size(15, 21);
            this.button_brsFile.TabIndex = 7;
            this.button_brsFile.Text = ".";
            this.button_brsFile.UseVisualStyleBackColor = true;
            this.button_brsFile.Click += new System.EventHandler(this.button_brsFile_Click);
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog1";
            this.openFileDialog.RestoreDirectory = true;
            // 
            // FormSetSSConfig
            // 
            this.AcceptButton = this.button_ok;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.button_cancel;
            this.ClientSize = new System.Drawing.Size(423, 264);
            this.Controls.Add(this.button_brsFile);
            this.Controls.Add(this.button_ok);
            this.Controls.Add(this.button_cancel);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox_process);
            this.Controls.Add(this.textBox_dayTime);
            this.Controls.Add(this.textBox_week);
            this.Controls.Add(this.textBox_month);
            this.KeyPreview = true;
            this.Name = "FormSetSSConfig";
            this.Text = "SetSSConfig";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SetSSConfig_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_month;
        private System.Windows.Forms.TextBox textBox_week;
        private System.Windows.Forms.TextBox textBox_dayTime;
        private System.Windows.Forms.TextBox textBox_process;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button button_cancel;
        private System.Windows.Forms.Button button_ok;
        private System.Windows.Forms.Button button_brsFile;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
    }
}