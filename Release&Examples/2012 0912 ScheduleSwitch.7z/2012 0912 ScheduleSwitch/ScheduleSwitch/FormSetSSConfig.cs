﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ScheduleSwitch
{
    public partial class FormSetSSConfig : Form
    {
        public FormSetSSConfig()
        {
            InitializeComponent();
        }

        private Core.SSConfigManager.Config _result = null;
        public Core.SSConfigManager.Config result
        {
            set
            {
                _result = value;
                if (_result != null)
                {
                    textBox_month.Text = _result.mouthSelection.IOContent;
                    textBox_week.Text = _result.weekSelection.IOContent;
                    textBox_dayTime.Text = _result.dayTimeSelection.IOContent;
                    textBox_process.Text = _result.processStartString;
                }
            }
            get
            {
                return _result;
            }
        }
        public new Core.SSConfigManager.Config ShowDialog(IWin32Window parent)
        {
            //this.Parent = parent;
            if (result == null)
            {
                textBox_month.Text = "1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12";
                textBox_week.Text = "1, 2, 3, 4, 5, 6, 7";
                textBox_dayTime.Text = "08:30:00, 12:00:00 ; 14:30:00, 18:00:00";
                textBox_process.Text = "";
            }
            this.ShowDialog();
            return result;
        }

        private void button_ok_Click(object sender, EventArgs e)
        {
            if (_result == null) _result = new Core.SSConfigManager.Config();
            _result.mouthSelection.IOContent = textBox_month.Text;
            _result.weekSelection.IOContent = textBox_week.Text;
            _result.dayTimeSelection.IOContent = textBox_dayTime.Text;
            _result.processStartString = textBox_process.Text;
            this.Hide();
        }

        private void button_cancel_Click(object sender, EventArgs e)
        {
            result = null;
            this.Hide();
        }
        private void SetSSConfig_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }

        private void button_brsFile_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
            {
                textBox_process.Text = "\"" + openFileDialog.FileName + "\"";
            }
        }
    }
}
