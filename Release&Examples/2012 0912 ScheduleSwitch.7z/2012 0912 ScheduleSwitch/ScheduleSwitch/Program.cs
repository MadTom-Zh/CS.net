﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ScheduleSwitch
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            bool isUIMode = true;
            if (args != null && args.Length > 0)
            {
                for (int i = 0; i < args.Length; i++)
                {
                    //MessageBox.Show(args[i]);
                    if (args[i] == "-switchMod")
                    {
                        isUIMode = false;
                    }
                }
            }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            if (isUIMode)
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new FormMain());
            }
            else
            {
                ScheduleSwitch.Core.SSConfigManager sscMgr = new Core.SSConfigManager();
                sscMgr.RunSS();
            }
        }
    }
}
