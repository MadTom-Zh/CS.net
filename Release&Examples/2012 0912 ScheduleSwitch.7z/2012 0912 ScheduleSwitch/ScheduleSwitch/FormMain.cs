﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ScheduleSwitch
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private Core.SSConfigManager _ssCfgMgr;
        private void FormMain_Shown(object sender, EventArgs e)
        {
            _ssCfgMgr = new Core.SSConfigManager();
            RefreshSSList();
            _winSssCfg = new FormSetSSConfig();
        }
        private void RefreshSSList()
        {
            listView.Items.Clear();
            Core.SSConfigManager.Config cfg;
            ListViewItem lvItem;
            for (int i = 0; i < _ssCfgMgr.cfgList.Count; i++)
            {
                cfg = _ssCfgMgr.cfgList[i];
                lvItem = new ListViewItem(new string[] { cfg.mouthSelection.IOContent, cfg.weekSelection.IOContent, cfg.dayTimeSelection.IOContent, cfg.processStartString });
                lvItem.Tag = i;
                listView.Items.Add(lvItem);
            }
            listView.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
        }

        private FormSetSSConfig _winSssCfg;
        private void button_add_Click(object sender, EventArgs e)
        {
            _winSssCfg.result = null;
            if (_winSssCfg.ShowDialog(this) != null)
            {
                _ssCfgMgr.Set_Config(_winSssCfg.result);
                RefreshSSList();
            }
        }
        private void listView_ItemActivate(object sender, EventArgs e)
        {
            _winSssCfg.result = _ssCfgMgr.cfgList[(int)listView.SelectedItems[0].Tag];
            if (_winSssCfg.ShowDialog(this) != null)
            {
                // will it change source automaticly???

                RefreshSSList();
            }
        }

        private void button_del_Click(object sender, EventArgs e)
        {
            if (listView.SelectedItems.Count <= 0) return;
            if (_ssCfgMgr.Del_Config(_ssCfgMgr.cfgList[(int)listView.SelectedItems[0].Tag]))
            {
                RefreshSSList();
            }
        }

        private void button_saveAndQuit_Click(object sender, EventArgs e)
        {
            _ssCfgMgr.Save();
            this.Close();
        }

        private void button_testRun_Click(object sender, EventArgs e)
        {
            _ssCfgMgr.RunSS();
        }
    }
}
