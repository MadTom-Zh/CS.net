﻿using System;
using System.Collections.Generic;
using System.Text;

using System.IO;
using System.Diagnostics;

namespace ScheduleSwitch
{
    public class Core
    {
        public class SSConfigManager
        {
            private string _cfgFileFullName;
            public SSConfigManager()
            {
                _cfgFileFullName = AppDomain.CurrentDomain.BaseDirectory + "\\SSConfig.txt";
                _Load();
            }

            private List<Config> _cfgList;
            public List<Config> cfgList
            {
                get { return _cfgList; }
            }
            public class Config
            {
                public class MouthSelection
                {
                    public MouthSelection()
                    {
                        _selection = new List<MouthType>();
                    }
                    public void Set(MouthType type)
                    {
                        bool isTarNotFound = true;
                        foreach (MouthType mt in _selection)
                        {
                            if (mt == type)
                            {
                                isTarNotFound = false;
                                break;
                            }
                        }
                        if (isTarNotFound)
                        {
                            _selection.Add(type);
                            //_selection.Sort();
                        }
                    }
                    public void Del(MouthType type)
                    {
                        foreach (MouthType mt in _selection)
                        {
                            if (mt == type)
                            {
                                _selection.Remove(mt);
                                break;
                            }
                        }
                    }

                    private List<MouthType> _selection;
                    public List<MouthType> selection
                    {
                        get { return _selection; }
                    }
                    public enum MouthType
                    {
                        M01 = 1,
                        M02 = 2,
                        M03 = 3,
                        M04 = 4,
                        M05 = 5,
                        M06 = 6,
                        M07 = 7,
                        M08 = 8,
                        M09 = 9,
                        M10 = 10,
                        M11 = 11,
                        M12 = 12
                    }

                    public bool Check_inPeriod()
                    {
                        return Check_inPeriod(DateTime.Now);
                    }
                    public bool Check_inPeriod(DateTime dateTime)
                    {
                        if (_selection.Count <= 0) return true;
                        for (int i = _selection.Count - 1; i >= 0; i--)
                        {
                            if ((int)_selection[i] == dateTime.Month) return true;
                        }
                        return false;
                    }

                    public string IOContent
                    {
                        get
                        {
                            string result = "";
                            SortSelection();
                            for (int i = 0; i < _selection.Count; i++)
                            {
                                if (result.Length > 0) result += ", ";
                                result += "" + (int)_selection[i];
                            }
                            return result;
                        }
                        set
                        {
                            _selection.Clear();
                            string longStr = "," + value + ",";
                            while (longStr.Contains(" ")) longStr = longStr.Replace(" ", "");
                            if (longStr.Contains(",1,")) _selection.Add(MouthType.M01);
                            if (longStr.Contains(",2,")) _selection.Add(MouthType.M02);
                            if (longStr.Contains(",3,")) _selection.Add(MouthType.M03);
                            if (longStr.Contains(",4,")) _selection.Add(MouthType.M04);
                            if (longStr.Contains(",5,")) _selection.Add(MouthType.M05);
                            if (longStr.Contains(",6,")) _selection.Add(MouthType.M06);
                            if (longStr.Contains(",7,")) _selection.Add(MouthType.M07);
                            if (longStr.Contains(",8,")) _selection.Add(MouthType.M08);
                            if (longStr.Contains(",9,")) _selection.Add(MouthType.M09);
                            if (longStr.Contains(",10,")) _selection.Add(MouthType.M10);
                            if (longStr.Contains(",11,")) _selection.Add(MouthType.M11);
                            if (longStr.Contains(",12,")) _selection.Add(MouthType.M12);
                        }
                    }
                    private void SortSelection()
                    {
                        MouthType si, sj, tmp;
                        for (int i = _selection.Count - 1; i > 0; i--)
                        {
                            si = _selection[i];
                            for (int j = i - 1; j >= 0; j--)
                            {
                                // if [i] < [j], swip
                                sj = _selection[j];
                                if (si < sj)
                                {
                                    tmp = si;
                                    _selection[i] = sj;
                                    _selection[j] = tmp;
                                }
                            }
                        }
                    }
                }
                public class WeekSelection
                {
                    public WeekSelection()
                    {
                        _selection = new List<WeekType>();
                    }
                    public void Set(WeekType type)
                    {
                        bool isTarNotFound = true;
                        foreach (WeekType mt in _selection)
                        {
                            if (mt == type)
                            {
                                isTarNotFound = false;
                                break;
                            }
                        }
                        if (isTarNotFound)
                        {
                            _selection.Add(type);
                        }
                    }
                    public void Del(WeekType type)
                    {
                        foreach (WeekType mt in _selection)
                        {
                            if (mt == type)
                            {
                                _selection.Remove(mt);
                                break;
                            }
                        }
                    }

                    private List<WeekType> _selection;
                    public List<WeekType> selection
                    {
                        get { return _selection; }
                    }
                    public enum WeekType
                    {
                        D1 = 1,
                        D2 = 2,
                        D3 = 3,
                        D4 = 4,
                        D5 = 5,
                        D6 = 6,
                        D7 = 7
                    }

                    public bool Check_inPeriod()
                    {
                        return Check_inPeriod(DateTime.Now);
                    }
                    public bool Check_inPeriod(DateTime dateTime)
                    {
                        if (_selection.Count <= 0) return true;
                        for (int i = _selection.Count - 1; i >= 0; i--)
                        {
                            if ((int)_selection[i] == (int)dateTime.DayOfWeek) return true;
                        }
                        return false;
                    }

                    public string IOContent
                    {
                        get
                        {
                            string result = "";
                            SortSelection();
                            if (_selection.Count > 1) _selection.Sort();
                            for (int i = 0; i < _selection.Count; i++)
                            {
                                if (result.Length > 0) result += ", ";
                                result += (int)_selection[i];
                            }
                            return result;
                        }
                        set
                        {
                            _selection.Clear();
                            string longStr = "," + value + ",";
                            while (longStr.Contains(" ")) longStr = longStr.Replace(" ", "");
                            if (longStr.Contains(",1,")) _selection.Add(WeekType.D1);
                            if (longStr.Contains(",2,")) _selection.Add(WeekType.D2);
                            if (longStr.Contains(",3,")) _selection.Add(WeekType.D3);
                            if (longStr.Contains(",4,")) _selection.Add(WeekType.D4);
                            if (longStr.Contains(",5,")) _selection.Add(WeekType.D5);
                            if (longStr.Contains(",6,")) _selection.Add(WeekType.D6);
                            if (longStr.Contains(",7,")) _selection.Add(WeekType.D7);
                        }
                    }
                    private void SortSelection()
                    {
                        WeekType si, sj, tmp;
                        for (int i = _selection.Count - 1; i > 0; i--)
                        {
                            si = _selection[i];
                            for (int j = i - 1; j >= 0; j--)
                            {
                                // if [i] < [j], swip
                                sj = _selection[j];
                                if (si < sj)
                                {
                                    tmp = si;
                                    _selection[i] = sj;
                                    _selection[j] = tmp;
                                }
                            }
                        }
                    }
                }
                public class DayTimeSelection
                {
                    public DayTimeSelection()
                    {
                        _selection = new List<DayTimeType>();
                    }
                    public void Set(DayTimeType type)
                    {
                        bool isTarNotFound = true;
                        foreach (DayTimeType mt in _selection)
                        {
                            if (mt == type)
                            {
                                isTarNotFound = false;
                                break;
                            }
                        }
                        if (isTarNotFound)
                        {
                            _selection.Add(type);
                        }
                    }
                    public void Del(DayTimeType type)
                    {
                        foreach (DayTimeType mt in _selection)
                        {
                            if (mt == type)
                            {
                                _selection.Remove(mt);
                                break;
                            }
                        }
                    }

                    private List<DayTimeType> _selection;
                    public List<DayTimeType> selection
                    {
                        get { return _selection; }
                    }
                    public class DayTimeType
                    {
                        public class DayTime
                        {
                            public int HH;
                            public int mm;
                            public int ss;
                            public DayTime(int HH, int mm, int ss)
                            {
                                this.HH = HH;
                                this.mm = mm;
                                this.ss = ss;
                            }
                            public DayTime(string IOContent)
                            {
                                this.IOContent = IOContent;
                            }

                            public static bool operator ==(DayTime d1, DayTime d2)
                            {
                                return _Equ(d1, d2);
                            }
                            public override bool Equals(object o)
                            {
                                try
                                {
                                    return _Equ(this, (DayTime)o);
                                }
                                catch (Exception)
                                {
                                    return false;
                                }
                            }
                            private static bool _Equ(DayTime d1, DayTime d2)
                            {
                                if (d1.HH == d2.HH && d1.mm == d2.mm && d1.ss == d2.ss) return true;
                                else return false;
                            }
                            public static bool operator !=(DayTime d1, DayTime d2)
                            {
                                return !_Equ(d1, d2);
                            }
                            public override int GetHashCode()
                            { return 0; }

                            public static bool operator >(DayTime d1, DayTime d2)
                            {
                                return _LaterThan(d1, d2);
                            }
                            public static bool operator <(DayTime d1, DayTime d2)
                            {
                                return !_LaterThan(d1, d2);
                            }
                            private static bool _LaterThan(DayTime d1, DayTime d2)
                            {
                                if (d1.HH > d2.HH) return true;
                                else if (d1.HH == d2.HH)
                                {
                                    if (d1.mm > d2.mm) return true;
                                    else if (d1.mm == d2.mm)
                                    {
                                        if (d1.ss > d2.ss) return true;
                                    }
                                }
                                return false;
                            }

                            public string IOContent
                            {
                                set
                                {
                                    string[] parts = value.Trim().Split(new char[] { ':' });
                                    HH = int.Parse(parts[0]);
                                    mm = int.Parse(parts[1]);
                                    ss = int.Parse(parts[2]);
                                }
                                get
                                {
                                    string result = HH.ToString("00") + ":";
                                    result += mm.ToString("00") + ":";
                                    result += ss.ToString("00") + "";
                                    return result;
                                }
                            }
                        }
                        public DayTime startTime, endTime;

                        public DayTimeType(int startHH, int startMm, int startSs, int endHH, int endMm, int endSs)
                        {
                            DayTime startTime = new DayTime(startHH, startMm, startSs);
                            DayTime endTime = new DayTime(endHH, endMm, endSs);
                            Init(startTime, endTime);
                        }
                        public DayTimeType(DayTime startTime, DayTime endTime)
                        {
                            Init(startTime, endTime);
                        }
                        public void Init(DayTime startTime, DayTime endTime)
                        {
                            this.startTime = startTime;
                            this.endTime = endTime;
                        }

                        public static bool operator ==(DayTimeType e1, DayTimeType e2)
                        {
                            return _Equ(e1, e2);
                        }
                        public override bool Equals(object o)
                        {
                            try
                            {
                                return _Equ(this, (DayTimeType)o);
                            }
                            catch (Exception)
                            {
                                return false;
                            }
                        }
                        private static bool _Equ(DayTimeType e1, DayTimeType e2)
                        {
                            if (e1.startTime == e2.startTime
                                && e1.endTime == e2.endTime)
                            {
                                return true;
                            }
                            return false;
                        }
                        public static bool operator !=(DayTimeType e1, DayTimeType e2)
                        {
                            return !_Equ(e1, e2);
                        }
                        public override int GetHashCode()
                        { return 0; }
                    }

                    public bool Check_inPeriod()
                    {
                        return Check_inPeriod(DateTime.Now);
                    }
                    public bool Check_inPeriod(DateTime dateTime)
                    {
                        if (_selection.Count <= 0) return true;
                        long longST, longNow, longET;
                        for (int i = _selection.Count - 1; i >= 0; i--)
                        {
                            longST = _selection[i].startTime.HH * 10000;
                            longST += _selection[i].startTime.mm * 100;
                            longST += _selection[i].startTime.ss;

                            longNow = dateTime.Hour * 10000;
                            longNow += dateTime.Minute * 100;
                            longNow += dateTime.Second;

                            longET = _selection[i].endTime.HH * 10000;
                            longET += _selection[i].endTime.mm * 100;
                            longET += _selection[i].endTime.ss;

                            if (longST <= longNow)
                            {
                                if (longNow <= longET)
                                {
                                    return true;
                                }
                            }
                        }
                        return false;
                    }

                    public string IOContent
                    {
                        get
                        {
                            string result = "";
                            SortSelection();
                            for (int i = 0; i < _selection.Count; i++)
                            {
                                if (result.Length > 0) result += ";";
                                result += _selection[i].startTime.IOContent + "," + _selection[i].endTime.IOContent;
                            }
                            return result;
                        }
                        set
                        {
                            _selection.Clear();
                            string[] pairTimes = value.Trim().Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);
                            string[] onePair;
                            for (int i = pairTimes.Length - 1; i >= 0; i--)
                            {
                                onePair = pairTimes[i].Split(new char[] { ',' });
                                _selection.Add(
                                    new DayTimeType(
                                        new DayTimeType.DayTime(onePair[0]),
                                        new DayTimeType.DayTime(onePair[1])));
                            }
                        }
                    }
                    private void SortSelection()
                    {
                        DayTimeType si, sj, tmp;
                        for (int i = _selection.Count - 1; i > 0; i--)
                        {
                            si = _selection[i];
                            for (int j = i - 1; j >= 0; j--)
                            {
                                // if [i] < [j], swip
                                sj = _selection[j];
                                if (si.startTime < sj.startTime)
                                {
                                    tmp = si;
                                    _selection[i] = sj;
                                    _selection[j] = tmp;
                                }
                            }
                        }
                    }
                }

                public MouthSelection mouthSelection;
                public WeekSelection weekSelection;
                public DayTimeSelection dayTimeSelection;
                private string _processStartString;
                public string processStartString
                {
                    set { _processStartString = value; }
                    get { return _processStartString; }
                }
                public Config()
                {
                    mouthSelection = new MouthSelection();
                    weekSelection = new WeekSelection();
                    dayTimeSelection = new DayTimeSelection();
                }

                public bool Check_inPeriod()
                {
                    return Check_inPeriod(DateTime.Now);
                }
                public bool Check_inPeriod(DateTime dateTime)
                {
                    if (mouthSelection.Check_inPeriod(dateTime))
                    {
                        if (weekSelection.Check_inPeriod(dateTime))
                        {
                            if (dayTimeSelection.Check_inPeriod(dateTime))
                            {
                                return true;
                            }
                        }
                    }
                    return false;
                }

                public string IOContent
                {
                    get
                    {
                        return mouthSelection.IOContent + "\t" + weekSelection.IOContent + "\t" + dayTimeSelection.IOContent + "\t" + processStartString;
                    }
                    set
                    {
                        string[] parts = value.Split(new char[] { '\t' });
                        mouthSelection.IOContent = parts[0];
                        weekSelection.IOContent = parts[1];
                        dayTimeSelection.IOContent = parts[2];
                        processStartString = parts[3];
                    }
                }
            }

            public void Set_Config(Config cfg)
            {
                if (!_cfgList.Contains(cfg))
                {
                    _cfgList.Add(cfg);
                }
            }
            public bool Del_Config(Config cfg)
            {
                return _cfgList.Remove(cfg);
            }

            private void _Load()
            {
                _cfgList = new List<Config>();
                if (!File.Exists(_cfgFileFullName))
                {
                    File.WriteAllText(_cfgFileFullName, "");
                }
                else
                {
                    string[] lines = File.ReadAllLines(_cfgFileFullName);
                    Config newCfg;
                    foreach (string line in lines)
                    {
                        try
                        {
                            newCfg = new Config();
                            newCfg.IOContent = line;
                            _cfgList.Add(newCfg);
                        }
                        catch (Exception) { }
                    }
                }
            }
            public void Save()
            {
                File.WriteAllText(_cfgFileFullName, "");
                for (int i = 0; i < _cfgList.Count; i++)
                {
                    File.AppendAllText(_cfgFileFullName, _cfgList[i].IOContent + "\r\n");
                }
            }

            public void RunSS()
            {
                RunSS(DateTime.Now);
            }
            public void RunSS(DateTime dateTimePoint)
            {
                Config iCfg;
                Process process;
                for (int i = 0; i < _cfgList.Count; i++)
                {
                    iCfg = _cfgList[i];
                    string pString;
                    int argStartIndex;
                    if (iCfg.mouthSelection.Check_inPeriod(dateTimePoint))
                    {
                        if (iCfg.weekSelection.Check_inPeriod(dateTimePoint))
                        {
                            if (iCfg.dayTimeSelection.Check_inPeriod(dateTimePoint))
                            {
                                process = new Process();
                                //process.PriorityClass = ProcessPriorityClass.BelowNormal;
                                pString = iCfg.processStartString.TrimStart();
                                if (pString.StartsWith("\"") && pString.LastIndexOf("\"") > 0)
                                {
                                    argStartIndex = pString.IndexOf("\"", 1);
                                    process.StartInfo.FileName = pString.Substring(1, argStartIndex - 1);
                                    process.StartInfo.Arguments = pString.Substring(argStartIndex + 1);
                                }
                                else if (pString.Contains(" "))
                                {
                                    argStartIndex = pString.IndexOf(" ", 1);
                                    process.StartInfo.FileName = pString.Substring(0, argStartIndex);
                                    process.StartInfo.Arguments = pString.Substring(argStartIndex + 1);
                                }
                                else process.StartInfo.FileName = pString;
                                process.Start();
                            }
                        }
                    }
                }
            }
        }
    }
}
