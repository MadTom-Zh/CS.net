﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.IO;

namespace TimerSS
{
    public partial class FormTimerSS : Form
    {
        public FormTimerSS()
        {
            InitializeComponent();
        }

        private ScheduleSwitch.Core.SSConfigManager _sscMgr;
        private string _argFileFullName = Application.StartupPath + "\\Timer.cfg";
        private void FormTimerSS_Load(object sender, EventArgs e)
        {
            notifyIcon.Visible = true;
            button_refresh_Click(sender, e);
        }
        private void button_refresh_Click(object sender, EventArgs e)
        {
            LoadArgsAndApply();
        }

        private void trackBar_timeInv_Scroll(object sender, EventArgs e)
        {
            textBox_timeInv.Text = "" + trackBar_timeInv.Value;
        }

        private void trackBar_timeInv_ValueChanged(object sender, EventArgs e)
        {
            timer.Interval = 1000 * trackBar_timeInv.Value;
            SaveArgs();
        }
        private void checkBox_active_CheckedChanged(object sender, EventArgs e)
        {
            timer.Enabled = checkBox_active.Checked;
            SaveArgs();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            _sscMgr.RunSS();
        }

        private static string _FLAG_TIME_INTV = "Timer intv: ";
        private static string _FLAG_IS_ENABLED = "Timer active: ";
        private void LoadArgsAndApply()
        {
            _sscMgr = new ScheduleSwitch.Core.SSConfigManager();
            if (File.Exists(_argFileFullName))
            {
                string[] lines = File.ReadAllLines(_argFileFullName);
                foreach (string line in lines)
                {
                    if (line.StartsWith(_FLAG_TIME_INTV))
                    {
                        int sec = int.Parse(line.Substring(_FLAG_TIME_INTV.Length));
                        timer.Interval = 1000 * sec;
                        trackBar_timeInv.Value = sec;
                        textBox_timeInv.Text = "" + sec;
                    }
                    if (line.StartsWith(_FLAG_IS_ENABLED)) checkBox_active.Checked = timer.Enabled = bool.Parse(line.Substring(_FLAG_IS_ENABLED.Length));
                }
            }
            else File.WriteAllText(_argFileFullName, "");
        }
        private void SaveArgs()
        {
            File.WriteAllText(_argFileFullName,
                _FLAG_TIME_INTV + (timer.Interval / 1000) + "\r\n"
                + _FLAG_IS_ENABLED + timer.Enabled.ToString());
        }

        private void notifyIcon_Click(object sender, EventArgs e)
        {
            this.Show();
            this.WindowState = FormWindowState.Normal;
        }

        private void FormTimerSS_Resize(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                this.Hide();
            }
        }
    }
}
