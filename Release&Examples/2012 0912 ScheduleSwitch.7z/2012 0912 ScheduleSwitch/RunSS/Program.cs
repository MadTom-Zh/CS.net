﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RunSS
{
    class Program
    {
        //[STAThread]
        static void Main(string[] args)
        {
            //System.Windows.Forms.Application.EnableVisualStyles();
            //System.Windows.Forms.Application.SetCompatibleTextRenderingDefault(false);
            //System.Windows.Forms.Application.Run(new FormRunner());

            ScheduleSwitch.Core.SSConfigManager sscMgr = new ScheduleSwitch.Core.SSConfigManager();
            sscMgr.RunSS();
        }
    }
}
