﻿using System;
using System.Collections.Generic;
using System.Text;

using System.IO;
using System.Runtime.InteropServices;


namespace IOSystem
{
    public class Local
    {

        /// <summary>
        /// 负责本地存储所有相关操作
        /// </summary>
        public class Manager
        {
            public static string LOCAL_BOOK_LIB_STOR_DIR_NAME = "LocalBookLib";
            public static string BOOK_NODE_DOC_FILENAME = "doc.htm";
            public static string BOOK_NODE_DOC_FILENAME_PER = "doc";
            public static string BOOK_NODE_DOC_FILENAME_SUF1 = "htm";
            public static string BOOK_NODE_DOC_FILENAME_SUF2 = "html";
            public static string BOOK_NODE_SUBDOCS_DIRNAME = "subDocs";

            private string localBookLib_DirFullName;
            private string localBookLib_EmptyDocFileFullName;

            public Manager()
            {
                Init();
                ReLoad_localLib();
            }
            private void Init()
            {
                localBookLib_DirFullName = AppDomain.CurrentDomain.BaseDirectory + "\\" + LOCAL_BOOK_LIB_STOR_DIR_NAME;
                if (!Directory.Exists(localBookLib_DirFullName))
                {
                    Directory.CreateDirectory(localBookLib_DirFullName);
                }
            }

            private List<DocNode> _localLib;
            public List<DocNode> localLib
            {
                get { return _localLib; }
            }
            /// <summary>
            /// 重新加载本地书库
            /// </summary>
            public void ReLoad_localLib()
            {
                if (_localLib == null)
                {
                    _localLib = new List<DocNode>();
                }
                _localLib.Clear();
                DirectoryInfo libRootDirInfo = new DirectoryInfo(localBookLib_DirFullName);
                foreach (DirectoryInfo libDir in libRootDirInfo.GetDirectories())
                {
                    _localLib.Add(new DocNode(null, libDir.FullName));
                }
            }


            /// <summary>
            /// 创建本地存储节点
            /// </summary>
            /// <param name="logicalPath">null或空字符串则在根节点下创建</param>
            /// <param name="nodeName"></param>
            public void Create_localDocNode(string logicalPath, string nodeName)
            {
                Create_localDocNode(logicalPath + "\\" + nodeName);
            }
            public DocNode Create_localDocNode(string nodelogicalFullName)
            {
                DocNode newDocNode;
                if (nodelogicalFullName.Contains("\\") == false)
                {
                    // 创建lib
                    string targetPhyFullName = localBookLib_DirFullName + "\\" + nodelogicalFullName;
                    targetPhyFullName = targetPhyFullName.Replace("\\\\","\\");
                    newDocNode = new DocNode(null, targetPhyFullName);
                    _localLib.Add(newDocNode);
                    if (DocNode_Created != null)
                    {
                        DocNode_Created(this, new DocNode_Created_EventArgs(newDocNode));
                    }
                    return newDocNode;
                }
                else
                {
                    //创建node
                    string[] logicalPathParts = nodelogicalFullName.Split(new string[] { "\\" }, StringSplitOptions.RemoveEmptyEntries);
                    string curlogicPath = logicalPathParts[1];
                    DocNode curDocNode = Get_DocNode(curlogicPath, false);
                    if (curDocNode == null)
                    {
                        curDocNode = Create_localDocNode(curlogicPath);
                    }
                    bool targetCreated = false;
                    DocNode curDocNode2;
                    for (int i = 1; i < logicalPathParts.Length; i++)
                    {
                        curlogicPath += "\\" + logicalPathParts[i];
                        curDocNode2 = Get_DocNode(curDocNode, curlogicPath, false);
                        if (curDocNode2 == null)
                        {
                            curDocNode2 = curDocNode.Add_SubNode(logicalPathParts[i]);
                            if (DocNode_Created != null)
                            {
                                DocNode_Created(this, new DocNode_Created_EventArgs(curDocNode2));
                            }
                            if (i == logicalPathParts.Length - 1)
                            {
                                targetCreated = true;
                            }
                        }
                        curDocNode = curDocNode2;
                    }
                    if (targetCreated)
                    {
                        return curDocNode;
                    }
                    else
                    {
                        throw new Exception("Node [" + nodelogicalFullName + "] is already Exist!");
                    }
                }
            }
            public event EventHandler<DocNode_Created_EventArgs> DocNode_Created;
            public class DocNode_Created_EventArgs : EventArgs
            {
                public DocNode_Created_EventArgs(DocNode newNode)
                {
                    this.newNode = newNode;
                }
                public DocNode newNode;
            }

            public void Delete_localDocNode(string libName)
            {
                DocNode tarDNode = null;
                for (int i = _localLib.Count - 1; i >= 0; i--)
                {
                    if (_localLib[i].name == libName)
                    {
                        tarDNode = _localLib[i];
                        _localLib.RemoveAt(i);
                        OSFunctions.Delete(tarDNode.physicalPath);
                        break;
                    }
                }
                if (tarDNode == null)
                {
                    throw new Exception("Target Lib [" + libName + "] is not exist!");
                }
            }

            public DocNode Get_DocNode(string nodeLogicalFullName, bool useNotFoundException)
            {
                DocNode curDocNode = null;
                string[] logicalPathParts = nodeLogicalFullName.Split(new string[] { "\\" }, StringSplitOptions.RemoveEmptyEntries);
                bool libFound = false;
                for (int i = _localLib.Count - 1; i >= 0; i--)
                {
                    curDocNode = _localLib[i];
                    if (curDocNode.name == logicalPathParts[0])
                    {
                        libFound = true;
                        break;
                    }
                }
                if (libFound)
                {
                    DocNode curDocNode_subNode = null;
                    for (int i = 1; i < logicalPathParts.Length; i++)
                    {
                        curDocNode_subNode = curDocNode.FindSubDocNode(logicalPathParts[i]);
                        if (curDocNode_subNode != null)
                        {
                            curDocNode = curDocNode_subNode;
                        }
                        else
                        {
                            if (useNotFoundException)
                            {
                                throw new Exception("No DocNode named [" + logicalPathParts[i] + "] in path [" + curDocNode.fullName + "]!");
                            }
                            else return null;
                        }
                    }
                    return curDocNode;
                }
                else if (useNotFoundException)
                {
                    throw new Exception("No lib named [" + logicalPathParts[0] + "]!");
                }
                return null;
            }
            public DocNode Get_DocNode(DocNode searchingDocNode, string nodeLogicalFullName, bool useNotFoundException)
            {
                if (nodeLogicalFullName.StartsWith(searchingDocNode.fullName))
                {
                    string[] logicalPathParts = nodeLogicalFullName.Substring(searchingDocNode.fullName.Length).Split(new string[] { "\\" }, StringSplitOptions.RemoveEmptyEntries);
                    DocNode curDocNode = searchingDocNode;
                    DocNode curDocNode_subNode = null;
                    bool subNodeFound;
                    for (int i = 0; i < logicalPathParts.Length; i++)
                    {
                        curDocNode_subNode = curDocNode.FindSubDocNode(logicalPathParts[i]);
                        if (curDocNode_subNode != null)
                        {
                            curDocNode = curDocNode_subNode;
                        }
                        else
                        {
                            if (useNotFoundException)
                            {
                                throw new Exception("No DocNode named [" + logicalPathParts[i] + "] in path [" + curDocNode_subNode.fullName + "]!");
                            }
                            return null;
                        }
                    }
                    return curDocNode;
                }
                else
                {
                    if (useNotFoundException)
                    {
                        throw new Exception("Can't find [" + nodeLogicalFullName + "] in [" + searchingDocNode.fullName + "]");
                    }
                    return null;
                }
            }
        }
        /// <summary>
        /// 本地文本节点
        /// 文档文件保存、读取、及提供相关信息
        /// </summary>
        public class DocNode
        {
            //文档1
            //    doc.htm
            //    subDocs
            //        【……】

            private DocNode _parent;
            public DocNode parent
            {
                get { return _parent; }
            }

            private List<DocNode> _subNodes;
            public List<DocNode> subNodes
            {
                get { return _subNodes; }
            }

            private string _name;
            public string name
            {
                get { return _name; }
            }

            public string fullName
            {
                get { return (parent == null) ? name : (parent.fullName + "\\" + name); }
            }

            private string _physicalPath;
            public string physicalPath
            {
                get { return _physicalPath; }
            }

            public string physicalDocFullName
            {
                get
                {
                    return _physicalPath + "\\" + Manager.BOOK_NODE_DOC_FILENAME;
                }
            }

            public DocNode(DocNode parent, string nodePhysicalPath)
            {
                _Init(ref parent, ref nodePhysicalPath);
            }
            public void _Init(ref DocNode parent, ref string nodePhysicalPath)
            {
                DirectoryInfo dir;
                if (Directory.Exists(nodePhysicalPath) == false)
                {
                    dir = Directory.CreateDirectory(nodePhysicalPath);
                }
                else
                {
                    dir = new DirectoryInfo(nodePhysicalPath);
                }
                _physicalPath = nodePhysicalPath;
                _name = dir.Name;
                _Check_parentRelationship(ref parent, ref dir);
                _Check_DocExists_CreateFile_AndLoad(ref dir);

                if (_subNodes != null) _subNodes.Clear();
                else _subNodes = new List<DocNode>();
            }
            public void ReInit()
            {
                _Init(ref _parent, ref _physicalPath);
            }
            private void _Check_parentRelationship(ref DocNode parent, ref DirectoryInfo storeDir)
            {
                // check parent relationship
                _parent = parent;
                if (parent != null && storeDir.FullName.StartsWith(parent.physicalPath) != true)
                {
                    throw new Exception("Node level should not be lower than parent!");
                }
            }
            private void _Check_DocExists_CreateFile_AndLoad(ref DirectoryInfo storeDir)
            {
                // check doc exists
                string fileFullName1 = storeDir.FullName + "\\" + Manager.BOOK_NODE_DOC_FILENAME_PER + "." + Manager.BOOK_NODE_DOC_FILENAME_SUF1;
                string fileFullName2 = storeDir.FullName + "\\" + Manager.BOOK_NODE_DOC_FILENAME_PER + "." + Manager.BOOK_NODE_DOC_FILENAME_SUF2;
                if (File.Exists(fileFullName2))
                {
                    File.Move(fileFullName2, fileFullName1);
                }
                else if (File.Exists(fileFullName1))
                {
                    // do nothing
                }
                else
                {
                    File.WriteAllText(fileFullName1, "");
                }
            }

            public void ReLoad_SubNodes()
            {
                string subNodePath = this._physicalPath + "\\" + Manager.BOOK_NODE_SUBDOCS_DIRNAME;
                if (!Directory.Exists(subNodePath)) return;
                DirectoryInfo subDocsDir = new DirectoryInfo(subNodePath);
                _subNodes.Clear();
                foreach (DirectoryInfo subDocDir in subDocsDir.GetDirectories())
                {
                    Add_SubNode(subDocDir.Name);
                }
            }

            public DocNode Add_SubNode(string rename)
            {
                string subNodesPath = this.physicalPath + "\\" + Manager.BOOK_NODE_SUBDOCS_DIRNAME;
                string subNodePhyFullPath = subNodesPath + "\\" + rename;
                DocNode newDocNode = new DocNode(this, subNodePhyFullPath);
                _subNodes.Add(newDocNode);
                return newDocNode;
            }
            public DocNode Delete_SubNode(string subNodeName)
            {
                DocNode subNode;
                for (int i = _subNodes.Count - 1; i >= 0; i--)
                {
                    subNode = _subNodes[i];
                    if (subNode.name == subNodeName)
                    {
                        _subNodes.RemoveAt(i);
                        OSFunctions.Delete(subNode.physicalPath);
                        return subNode;
                    }
                }
                return null;
            }
            public DocNode FindSubDocNode(string name)
            {
                ReLoad_SubNodes();
                for (int i = _subNodes.Count - 1; i >= 0; i--)
                {
                    if (_subNodes[i].name == name)
                    {
                        return _subNodes[i];
                    }
                }
                return null;
            }
        }

        public static class OSFunctions
        {
            [DllImport("shell32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
            private static extern bool SHFileOperation([In, Out]  SHFILEOPSTRUCT str);
            private const int FO_MOVE = 0x1;
            private const int FO_COPY = 0x2;
            private const int FO_DELETE = 0x3;
            private const ushort FOF_NOCONFIRMATION = 0x10;
            private const ushort FOF_ALLOWUNDO = 0x40;
            [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
            public class SHFILEOPSTRUCT
            {
                public IntPtr hwnd;
                /// <summary> 
                /// 设置操作方式，移动：FO_MOVE，复制：FO_COPY，删除：FO_DELETE 
                /// </summary> 
                public UInt32 wFunc;
                /// <summary> 
                /// 源文件路径 
                /// </summary> 
                public string pFrom;
                /// <summary> 
                /// 目标文件路径 
                /// </summary> 
                public string pTo;
                /// <summary> 
                /// 允许恢复 
                /// </summary> 
                public UInt16 fFlags;
                /// <summary> 
                /// 监测有无中止 
                /// </summary> 
                public Int32 fAnyOperationsAborted;
                public IntPtr hNameMappings;
                /// <summary> 
                /// 设置标题 
                /// </summary> 
                public string lpszProgressTitle;
            }

            /// <summary>
            /// 可用于复制文件或文件夹
            /// 注意两个参数必须同时是文件夹名 或 文件名
            /// </summary>
            /// <param name="sourceItemFullName">源对象全路径</param>
            /// <param name="targetItemFullName">目标对象全路径</param>
            /// <returns></returns>
            public static bool Copy(string sourceItemFullName, string targetItemFullName)
            {
                SHFILEOPSTRUCT pm = new SHFILEOPSTRUCT();
                pm.wFunc = FO_COPY;
                pm.pFrom = sourceItemFullName;
                pm.pTo = targetItemFullName;
                pm.fFlags = FOF_ALLOWUNDO; //允许恢复 
                //pm.lpszProgressTitle = "哈哈"; 
                return SHFileOperation(pm);
            }
            public static bool Move(string sourceItemFullName, string targetItemFullName)
            {
                SHFILEOPSTRUCT pm = new SHFILEOPSTRUCT();
                pm.wFunc = FO_MOVE;
                pm.pFrom = sourceItemFullName;
                pm.pTo = targetItemFullName;
                pm.fFlags = FOF_ALLOWUNDO; //允许恢复 
                //pm.lpszProgressTitle = "哈哈"; 
                return SHFileOperation(pm);
            }
            public static bool Delete(string sourceItemFullName)
            {
                SHFILEOPSTRUCT pm = new SHFILEOPSTRUCT();
                pm.wFunc = FO_DELETE;
                pm.pFrom = sourceItemFullName + '\0';
                pm.pTo = null;
                pm.fFlags = FOF_ALLOWUNDO | FOF_NOCONFIRMATION;
                return SHFileOperation(pm);
            }
        }
    }
}
