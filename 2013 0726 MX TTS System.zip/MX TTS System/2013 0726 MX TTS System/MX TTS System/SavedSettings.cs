﻿using System;
using System.Collections.Generic;
using System.Text;

using System.IO;

namespace MX_TTS_System
{
    public class SavedSettings
    {
        public static string CFG_FILE_FULLNAME
            = (AppDomain.CurrentDomain.BaseDirectory + "\\Settings.cfg").Replace("\\\\", "\\");

        public static string NewLine = "\r\n";
        public string MainVoice;
        public static string MainVoice_Flag = "MainVoice:";
        public int VoiceSpeed;
        public static string VoiceSpeed_Flag = "VoiceSpeed:";
        public string VoiceZh;
        public static string VoiceZh_Flag = "VoiceZh:";
        public string VoiceEn;
        public static string VoiceEn_Flag = "VoiceEn:";

        public bool CopyToRead_IsAutoGet;
        public static string CopyToRead_IsAutoGet_Flag = "CopyToRead_IsAutoGet:";
        public bool CopyToRead_IsIgnoreWords;
        public static string CopyToRead_IsIgnoreWords_Flag = "CopyToRead_IsIgnoreWords:";
        public bool CopyToRead_IsLog;
        public static string CopyToRead_IsLog_Flag = "CopyToRead_IsLog:";


        public void Load()
        {
            if (File.Exists(CFG_FILE_FULLNAME) == false)
            {
                File.WriteAllText(CFG_FILE_FULLNAME, "");
            }
            else
            {
                this.IOContent = File.ReadAllText(CFG_FILE_FULLNAME);
            }
        }
        public void Save()
        {
            File.WriteAllText(CFG_FILE_FULLNAME, this.IOContent);
        }

        public string IOContent
        {
            set
            {
                string[] lines = value.Split(new string[] { NewLine }, StringSplitOptions.RemoveEmptyEntries);
                foreach (string line in lines)
                {
                    if (line.StartsWith(MainVoice_Flag)) MainVoice = line.Substring(MainVoice_Flag.Length);
                    else if (line.StartsWith(VoiceSpeed_Flag)) VoiceSpeed = int.Parse(line.Substring(VoiceSpeed_Flag.Length));
                    else if (line.StartsWith(VoiceZh_Flag)) VoiceZh = line.Substring(VoiceZh_Flag.Length);
                    else if (line.StartsWith(VoiceEn_Flag)) VoiceEn = line.Substring(VoiceEn_Flag.Length);

                    else if (line.StartsWith(CopyToRead_IsAutoGet_Flag)) CopyToRead_IsAutoGet = bool.Parse(line.Substring(CopyToRead_IsAutoGet_Flag.Length));
                    else if (line.StartsWith(CopyToRead_IsIgnoreWords_Flag)) CopyToRead_IsIgnoreWords = bool.Parse(line.Substring(CopyToRead_IsIgnoreWords_Flag.Length));
                    else if (line.StartsWith(CopyToRead_IsLog_Flag)) CopyToRead_IsLog = bool.Parse(line.Substring(CopyToRead_IsLog_Flag.Length));
                }
            }
            get
            {
                string result = "";

                result += MainVoice_Flag + MainVoice + NewLine;
                result += VoiceSpeed_Flag + VoiceSpeed + NewLine;
                result += VoiceZh_Flag + VoiceZh + NewLine;
                result += VoiceEn_Flag + VoiceEn + NewLine;

                result += CopyToRead_IsAutoGet_Flag + CopyToRead_IsAutoGet.ToString() + NewLine;
                result += CopyToRead_IsIgnoreWords_Flag + CopyToRead_IsIgnoreWords.ToString() + NewLine;
                result += CopyToRead_IsLog_Flag + CopyToRead_IsLog.ToString() + NewLine;

                return result;
            }
        }
    }
}
