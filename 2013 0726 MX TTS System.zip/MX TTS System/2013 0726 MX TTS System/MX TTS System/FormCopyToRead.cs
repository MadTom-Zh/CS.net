﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.IO;

namespace MX_TTS_System
{
    public partial class FormCopyToRead : Form
    {
        public FormCopyToRead()
        {
            InitializeComponent();

            LoadVoicesUI();
            LoadIgnoreWords();
            SetSavedSettings();

            checkBox_autoGetClip_CheckedChanged(this, new EventArgs());
        }

        private T2S_HCore.Classes.BroadCaster broadCaster
             = new T2S_HCore.Classes.BroadCaster();
        private void LoadVoicesUI()
        {
            comboBox_voices.Items.Clear();
            for (int i = 0; i < broadCaster.Voices.Count; i++)
            {
                comboBox_voices.Items.Add(broadCaster.Voices[i].description);
            }
        }
        private SavedSettings settings = new SavedSettings();
        private void SetSavedSettings()
        {
            settings.Load();
            bool notFound = true;
            foreach (object vi in comboBox_voices.Items)
            {
                if (vi.ToString() == settings.MainVoice)
                {
                    comboBox_voices.SelectedItem = vi;
                    notFound = false;
                    break;
                }
            }
            if (notFound)
            {
                settings.MainVoice = "";
                settings.Save();
            }

            checkBox_autoGetClip.Checked = settings.CopyToRead_IsAutoGet;
            checkBox_noReadingWithSWords.Checked = settings.CopyToRead_IsIgnoreWords;
            checkBox_logToFile.Checked = settings.CopyToRead_IsLog;

            trackBar_speed.Value = settings.VoiceSpeed;
            trackBar_speed_Scroll(this, new EventArgs());
        }
        private void comboBox_voices_SelectedIndexChanged(object sender, EventArgs e)
        {
            for (int i = broadCaster.Voices.Count - 1; i >= 0; i--)
            {
                if (broadCaster.Voices[i].description == comboBox_voices.Text)
                {
                    broadCaster.voice = broadCaster.Voices[i];
                    settings.MainVoice = comboBox_voices.Text;
                    break;
                }
            }
        }

        private void checkBox_autoGetClip_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_autoGetClip.Checked == true) timer.Start();
            else timer.Stop();
            settings.CopyToRead_IsAutoGet = checkBox_autoGetClip.Checked;
        }
        private void checkBox_noReadingWithSWords_CheckedChanged(object sender, EventArgs e)
        {
            button_CfgSWords.Enabled = checkBox_noReadingWithSWords.Checked;
            settings.CopyToRead_IsIgnoreWords = checkBox_noReadingWithSWords.Checked;
        }
        private void checkBox_logToFile_CheckedChanged(object sender, EventArgs e)
        {
            settings.CopyToRead_IsLog = checkBox_logToFile.Checked;
        }

        private string clipBoardText;
        private void timer_Tick(object sender, EventArgs e)
        {
            clipBoardText = Clipboard.GetText().Trim();
            if (clipBoardText == null || clipBoardText.Length == 0) return;
            if (textBox.Text != clipBoardText)
            {
                textBox.Text = clipBoardText;
                if (checkBox_noReadingWithSWords.Checked == true)
                {
                    if (TextToRead_KeyWordsCheck() == true)
                    {
                        button_read_Click(sender, e);
                    }
                }
                else button_read_Click(sender, e);
            }
        }

        private string readText;
        private void button_read_Click(object sender, EventArgs e)
        {
            if (broadCaster.isPlaying || broadCaster.isPaused)
            {
                broadCaster.Stop();
            }
            if (checkBox_logToFile.Checked == true
                && readText != textBox.Text)
            {
                readText = textBox.Text;
                Log(readText);
            }
            broadCaster.Speek(textBox.Text);
        }

        private bool TextToRead_KeyWordsCheck()
        {
            string txt = textBox.Text;
            foreach (string word in IgnoreWords)
            {
                if (txt.Contains(word))
                {
                    return false;
                }
            }
            return true;
        }

        private string IgnoreWordsText;
        private List<string> IgnoreWords = new List<string>();
        private void button_CfgSWords_Click(object sender, EventArgs e)
        {
            UserControls.Form_CopyToRead_IgnoreWords win = new UserControls.Form_CopyToRead_IgnoreWords();
            win.IgnoreWordText = IgnoreWordsText;
            if (win.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
            {
                IgnoreWordsText = win.IgnoreWordText;
                SaveIgnoreWords();
                GetAllIgnoreWords_FromText();
            }
        }
        public static string IgnoreWordsListFileName
            = Application.StartupPath + "\\CopyToRead.IgnoreWords.txt";
        private void LoadIgnoreWords()
        {
            if (File.Exists(IgnoreWordsListFileName) == true)
            {
                IgnoreWordsText = File.ReadAllText(IgnoreWordsListFileName);
            }
            GetAllIgnoreWords_FromText();
        }
        private void GetAllIgnoreWords_FromText()
        {
            IgnoreWords.Clear();
            if (IgnoreWordsText == null) return;
            string[] lines = IgnoreWordsText.Split(new string[] { "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string word in lines)
            {
                if (word.StartsWith("//")) continue;
                IgnoreWords.Add(word);
            }
        }
        private void SaveIgnoreWords()
        {
            File.WriteAllText(IgnoreWordsListFileName, IgnoreWordsText);
        }

        public string CopyToRead_LogDir
            = Application.StartupPath + "\\CopyToRead_Log";
        private void Log(string text)
        {
            if (Directory.Exists(CopyToRead_LogDir) == false)
            {
                Directory.CreateDirectory(CopyToRead_LogDir);
            }
            DateTime now = DateTime.Now;
            File.AppendAllText(
                CopyToRead_LogDir + "\\" + now.ToString("yyyy-MM-dd HH mm") + ".txt",
                now.ToString("HH:mm:ss.fff") + " " + text);
        }
        private void button_explorerLogFiles_Click(object sender, EventArgs e)
        {
            if (Directory.Exists(CopyToRead_LogDir) == false)
            {
                Directory.CreateDirectory(CopyToRead_LogDir);
            }
            System.Diagnostics.Process.Start(CopyToRead_LogDir);
        }

        private void trackBar_speed_Scroll(object sender, EventArgs e)
        {
            textBox_speed.Text = trackBar_speed.Value.ToString();
            broadCaster.Rate = trackBar_speed.Value;
            settings.VoiceSpeed = trackBar_speed.Value;
        }

        private void FormCopyToRead_FormClosing(object sender, FormClosingEventArgs e)
        {
            settings.Save();
        }
    }
}
