﻿namespace MX_TTS_System
{
    partial class FormMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel_info = new System.Windows.Forms.ToolStripStatusLabel();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.panel_TreeView = new MX_TTS_System.UserControls.Panel_TreeView();
            this.panel_WorkPlace = new MX_TTS_System.UserControls.Panel_WorkPlace();
            this.statusStrip.SuspendLayout();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel_info});
            this.statusStrip.Location = new System.Drawing.Point(0, 450);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(946, 22);
            this.statusStrip.TabIndex = 1;
            this.statusStrip.Text = "statusStrip1";
            // 
            // toolStripStatusLabel_info
            // 
            this.toolStripStatusLabel_info.Name = "toolStripStatusLabel_info";
            this.toolStripStatusLabel_info.Size = new System.Drawing.Size(35, 17);
            this.toolStripStatusLabel_info.Text = "Ready";
            // 
            // splitContainer
            // 
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Name = "splitContainer";
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.panel_TreeView);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(this.panel_WorkPlace);
            this.splitContainer.Size = new System.Drawing.Size(946, 450);
            this.splitContainer.SplitterDistance = 296;
            this.splitContainer.TabIndex = 2;
            // 
            // panel_TreeView
            // 
            this.panel_TreeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_TreeView.Location = new System.Drawing.Point(0, 0);
            this.panel_TreeView.Margin = new System.Windows.Forms.Padding(4);
            this.panel_TreeView.Name = "panel_TreeView";
            this.panel_TreeView.Size = new System.Drawing.Size(296, 450);
            this.panel_TreeView.TabIndex = 0;
            // 
            // panel_WorkPlace
            // 
            this.panel_WorkPlace.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_WorkPlace.Location = new System.Drawing.Point(0, 0);
            this.panel_WorkPlace.Margin = new System.Windows.Forms.Padding(4);
            this.panel_WorkPlace.Name = "panel_WorkPlace";
            this.panel_WorkPlace.Size = new System.Drawing.Size(646, 450);
            this.panel_WorkPlace.TabIndex = 0;
            this.panel_WorkPlace.Visible = false;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(946, 472);
            this.Controls.Add(this.splitContainer);
            this.Controls.Add(this.statusStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormMain";
            this.Text = "MX读书";
            this.Shown += new System.EventHandler(this.FormMain_Shown);
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.SplitContainer splitContainer;
        private UserControls.Panel_TreeView panel_TreeView;
        private UserControls.Panel_WorkPlace panel_WorkPlace;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel_info;
    }
}

