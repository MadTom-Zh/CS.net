﻿namespace MX_TTS_System
{
    partial class FormCopyToRead
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormCopyToRead));
            this.label1 = new System.Windows.Forms.Label();
            this.textBox = new System.Windows.Forms.TextBox();
            this.checkBox_autoGetClip = new System.Windows.Forms.CheckBox();
            this.button_read = new System.Windows.Forms.Button();
            this.checkBox_noReadingWithSWords = new System.Windows.Forms.CheckBox();
            this.button_CfgSWords = new System.Windows.Forms.Button();
            this.checkBox_logToFile = new System.Windows.Forms.CheckBox();
            this.button_explorerLogFiles = new System.Windows.Forms.Button();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.comboBox_voices = new System.Windows.Forms.ComboBox();
            this.trackBar_speed = new System.Windows.Forms.TrackBar();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_speed = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_speed)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "选择语音";
            // 
            // textBox
            // 
            this.textBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox.Location = new System.Drawing.Point(14, 98);
            this.textBox.Multiline = true;
            this.textBox.Name = "textBox";
            this.textBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox.Size = new System.Drawing.Size(415, 145);
            this.textBox.TabIndex = 1;
            // 
            // checkBox_autoGetClip
            // 
            this.checkBox_autoGetClip.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.checkBox_autoGetClip.AutoSize = true;
            this.checkBox_autoGetClip.Checked = true;
            this.checkBox_autoGetClip.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_autoGetClip.Location = new System.Drawing.Point(12, 256);
            this.checkBox_autoGetClip.Name = "checkBox_autoGetClip";
            this.checkBox_autoGetClip.Size = new System.Drawing.Size(168, 16);
            this.checkBox_autoGetClip.TabIndex = 2;
            this.checkBox_autoGetClip.Text = "自动获取复制文本，并朗读";
            this.checkBox_autoGetClip.UseVisualStyleBackColor = true;
            this.checkBox_autoGetClip.CheckedChanged += new System.EventHandler(this.checkBox_autoGetClip_CheckedChanged);
            // 
            // button_read
            // 
            this.button_read.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_read.Location = new System.Drawing.Point(319, 249);
            this.button_read.Name = "button_read";
            this.button_read.Size = new System.Drawing.Size(110, 28);
            this.button_read.TabIndex = 3;
            this.button_read.Text = "  朗读";
            this.button_read.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_read.UseVisualStyleBackColor = true;
            this.button_read.Click += new System.EventHandler(this.button_read_Click);
            // 
            // checkBox_noReadingWithSWords
            // 
            this.checkBox_noReadingWithSWords.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.checkBox_noReadingWithSWords.AutoSize = true;
            this.checkBox_noReadingWithSWords.Checked = true;
            this.checkBox_noReadingWithSWords.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_noReadingWithSWords.Location = new System.Drawing.Point(12, 290);
            this.checkBox_noReadingWithSWords.Name = "checkBox_noReadingWithSWords";
            this.checkBox_noReadingWithSWords.Size = new System.Drawing.Size(204, 16);
            this.checkBox_noReadingWithSWords.TabIndex = 4;
            this.checkBox_noReadingWithSWords.Text = "不朗读含有指定关键字的拷贝内容";
            this.checkBox_noReadingWithSWords.UseVisualStyleBackColor = true;
            this.checkBox_noReadingWithSWords.CheckedChanged += new System.EventHandler(this.checkBox_noReadingWithSWords_CheckedChanged);
            // 
            // button_CfgSWords
            // 
            this.button_CfgSWords.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_CfgSWords.Location = new System.Drawing.Point(319, 283);
            this.button_CfgSWords.Name = "button_CfgSWords";
            this.button_CfgSWords.Size = new System.Drawing.Size(110, 28);
            this.button_CfgSWords.TabIndex = 5;
            this.button_CfgSWords.Text = "  配置关键字...";
            this.button_CfgSWords.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_CfgSWords.UseVisualStyleBackColor = true;
            this.button_CfgSWords.Click += new System.EventHandler(this.button_CfgSWords_Click);
            // 
            // checkBox_logToFile
            // 
            this.checkBox_logToFile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.checkBox_logToFile.AutoSize = true;
            this.checkBox_logToFile.Checked = true;
            this.checkBox_logToFile.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_logToFile.Location = new System.Drawing.Point(12, 324);
            this.checkBox_logToFile.Name = "checkBox_logToFile";
            this.checkBox_logToFile.Size = new System.Drawing.Size(96, 16);
            this.checkBox_logToFile.TabIndex = 6;
            this.checkBox_logToFile.Text = "启用日志记录";
            this.checkBox_logToFile.UseVisualStyleBackColor = true;
            this.checkBox_logToFile.CheckedChanged += new System.EventHandler(this.checkBox_logToFile_CheckedChanged);
            // 
            // button_explorerLogFiles
            // 
            this.button_explorerLogFiles.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_explorerLogFiles.Location = new System.Drawing.Point(319, 317);
            this.button_explorerLogFiles.Name = "button_explorerLogFiles";
            this.button_explorerLogFiles.Size = new System.Drawing.Size(110, 28);
            this.button_explorerLogFiles.TabIndex = 7;
            this.button_explorerLogFiles.Text = "  查看日志...";
            this.button_explorerLogFiles.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_explorerLogFiles.UseVisualStyleBackColor = true;
            this.button_explorerLogFiles.Click += new System.EventHandler(this.button_explorerLogFiles_Click);
            // 
            // timer
            // 
            this.timer.Interval = 300;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // comboBox_voices
            // 
            this.comboBox_voices.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox_voices.FormattingEnabled = true;
            this.comboBox_voices.Location = new System.Drawing.Point(71, 12);
            this.comboBox_voices.Name = "comboBox_voices";
            this.comboBox_voices.Size = new System.Drawing.Size(358, 20);
            this.comboBox_voices.TabIndex = 8;
            this.comboBox_voices.SelectedIndexChanged += new System.EventHandler(this.comboBox_voices_SelectedIndexChanged);
            // 
            // trackBar_speed
            // 
            this.trackBar_speed.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.trackBar_speed.LargeChange = 2;
            this.trackBar_speed.Location = new System.Drawing.Point(114, 38);
            this.trackBar_speed.Minimum = -10;
            this.trackBar_speed.Name = "trackBar_speed";
            this.trackBar_speed.Size = new System.Drawing.Size(315, 42);
            this.trackBar_speed.TabIndex = 9;
            this.trackBar_speed.Scroll += new System.EventHandler(this.trackBar_speed_Scroll);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 10;
            this.label2.Text = "调整语速";
            // 
            // textBox_speed
            // 
            this.textBox_speed.Location = new System.Drawing.Point(71, 43);
            this.textBox_speed.Name = "textBox_speed";
            this.textBox_speed.ReadOnly = true;
            this.textBox_speed.Size = new System.Drawing.Size(37, 21);
            this.textBox_speed.TabIndex = 11;
            this.textBox_speed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(371, 12);
            this.label3.TabIndex = 12;
            this.label3.Text = "* 配置好后，将程序最小化即可； 或者可以手动编辑文本进行朗读。";
            // 
            // FormCopyToRead
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(441, 357);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox_speed);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.trackBar_speed);
            this.Controls.Add(this.comboBox_voices);
            this.Controls.Add(this.button_explorerLogFiles);
            this.Controls.Add(this.checkBox_logToFile);
            this.Controls.Add(this.button_CfgSWords);
            this.Controls.Add(this.checkBox_noReadingWithSWords);
            this.Controls.Add(this.button_read);
            this.Controls.Add(this.checkBox_autoGetClip);
            this.Controls.Add(this.textBox);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormCopyToRead";
            this.Text = "拷即读";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormCopyToRead_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_speed)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox;
        private System.Windows.Forms.CheckBox checkBox_autoGetClip;
        private System.Windows.Forms.Button button_read;
        private System.Windows.Forms.CheckBox checkBox_noReadingWithSWords;
        private System.Windows.Forms.Button button_CfgSWords;
        private System.Windows.Forms.CheckBox checkBox_logToFile;
        private System.Windows.Forms.Button button_explorerLogFiles;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.ComboBox comboBox_voices;
        private System.Windows.Forms.TrackBar trackBar_speed;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_speed;
        private System.Windows.Forms.Label label3;
    }
}