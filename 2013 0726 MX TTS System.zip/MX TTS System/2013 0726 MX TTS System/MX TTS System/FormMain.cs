﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MX_TTS_System
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private IOSystem.Local.Manager _ioManager;
        private void FormMain_Shown(object sender, EventArgs e)
        {
            _ioManager = new IOSystem.Local.Manager();

            panel_WorkPlace.Init(ref _ioManager);
            panel_WorkPlace.SpeekStoped += new EventHandler<T2S_HCore.Classes.BroadCaster.StreamEnd_Args>(panel_WorkPlace_SpeekStoped);
            panel_WorkPlace.WebDocumentLoadCompleted += new EventHandler(panel_WorkPlace_WebDocumentLoadCompleted);

            panel_TreeView.TreeViewNodeSelected += new EventHandler<UserControls.Panel_TreeView.TreeViewNodeSelectedEventArgs>(panel_TreeView_TreeViewNodeSelected);
            panel_TreeView.Init(ref _ioManager);
        }

        bool goingToReadNextPage = false;
        void panel_WorkPlace_SpeekStoped(object sender, T2S_HCore.Classes.BroadCaster.StreamEnd_Args e)
        {
            if (e.IsUserStop == false
                && panel_WorkPlace.SpeekSelectionType != UserControls.Panel_WorkPlace.ReadSelectionType.OnlySelection
                && panel_WorkPlace.SpeekPageType == UserControls.Panel_WorkPlace.SpeekPageOverType.OverAndNext)
            {
                panel_TreeView.SelectNextOne();
                goingToReadNextPage = true;
            }
        }
        void panel_WorkPlace_WebDocumentLoadCompleted(object sender, EventArgs e)
        {
            if (goingToReadNextPage)
            {
                panel_WorkPlace.Speek();
                goingToReadNextPage = false;
            }
        }

        void panel_TreeView_TreeViewNodeSelected(object sender, UserControls.Panel_TreeView.TreeViewNodeSelectedEventArgs e)
        {
            switch (e.selectItem.type)
            {
                case UserControls.Panel_TreeView.Historian.ItemType.Local:
                    IOSystem.Local.DocNode tarLDNode = _ioManager.Get_DocNode(e.selectItem.fullName, true);
                    //tarLDNode.ReLoad_SubNodes();
                    panel_WorkPlace.LoadLocalDoc(tarLDNode);
                    break;
                case UserControls.Panel_TreeView.Historian.ItemType.Online:
                    break;
            }
        }

        private void toolStripButton_refresh_Click(object sender, EventArgs e)
        {
            FormMain_Shown(sender, e);
        }
    }
}
