﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

//using System.Diagnostics;

namespace MX_TTS_System
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            //foreach (Process p in Process.GetProcesses())
            //{
            //    if(p.ProcessName.ToLower().Contains("mx tts system")
            //        && Process.)
            //    {
            //        if (DialogResult.Yes == MessageBox.Show(null, "抱歉，MX TTS System 已经在运行了！\r\r是否重开？", "警告", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2))
            //        {
            //            p.Kill();
            //        }
            //        else
            //        {
            //            return;
            //        }
            //    }
            //}
            bool runone;
            string setName = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name;
            System.Threading.Mutex run = new System.Threading.Mutex(true, setName, out runone);
            if (runone)
            {
                run.ReleaseMutex();
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new FormLanucher());
            }
            else
            {
                MessageBox.Show(null, "抱歉，MX TTS System 已经在运行了！", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);
            }


        }
    }
}
