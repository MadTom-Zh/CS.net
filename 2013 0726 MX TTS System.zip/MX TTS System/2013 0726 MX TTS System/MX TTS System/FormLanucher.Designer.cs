﻿namespace MX_TTS_System
{
    partial class FormLanucher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormLanucher));
            this.button_MXTTS = new System.Windows.Forms.Button();
            this.button_CopyToRead = new System.Windows.Forms.Button();
            this.pictureBox_Mic = new System.Windows.Forms.PictureBox();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.imageList = new System.Windows.Forms.ImageList(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Mic)).BeginInit();
            this.SuspendLayout();
            // 
            // button_MXTTS
            // 
            this.button_MXTTS.Location = new System.Drawing.Point(12, 12);
            this.button_MXTTS.Name = "button_MXTTS";
            this.button_MXTTS.Size = new System.Drawing.Size(163, 33);
            this.button_MXTTS.TabIndex = 0;
            this.button_MXTTS.Text = "   启动 本地书库";
            this.button_MXTTS.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_MXTTS.UseVisualStyleBackColor = true;
            this.button_MXTTS.Click += new System.EventHandler(this.button_MXTTS_Click);
            // 
            // button_CopyToRead
            // 
            this.button_CopyToRead.Location = new System.Drawing.Point(12, 51);
            this.button_CopyToRead.Name = "button_CopyToRead";
            this.button_CopyToRead.Size = new System.Drawing.Size(163, 33);
            this.button_CopyToRead.TabIndex = 1;
            this.button_CopyToRead.Text = "   启动“拷即读”工具";
            this.button_CopyToRead.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_CopyToRead.UseVisualStyleBackColor = true;
            this.button_CopyToRead.Click += new System.EventHandler(this.button_CopyToRead_Click);
            // 
            // pictureBox_Mic
            // 
            this.pictureBox_Mic.Location = new System.Drawing.Point(184, 12);
            this.pictureBox_Mic.Name = "pictureBox_Mic";
            this.pictureBox_Mic.Size = new System.Drawing.Size(128, 128);
            this.pictureBox_Mic.TabIndex = 2;
            this.pictureBox_Mic.TabStop = false;
            this.pictureBox_Mic.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox_Mic_Paint);
            // 
            // timer
            // 
            this.timer.Enabled = true;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // imageList
            // 
            this.imageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
            this.imageList.ImageSize = new System.Drawing.Size(128, 128);
            this.imageList.TransparentColor = System.Drawing.Color.Fuchsia;
            // 
            // FormLanucher
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(324, 158);
            this.Controls.Add(this.pictureBox_Mic);
            this.Controls.Add(this.button_CopyToRead);
            this.Controls.Add(this.button_MXTTS);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormLanucher";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MX朗读 [版本日期]";
            this.Load += new System.EventHandler(this.FormLanucher_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Mic)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_MXTTS;
        private System.Windows.Forms.Button button_CopyToRead;
        private System.Windows.Forms.PictureBox pictureBox_Mic;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.ImageList imageList;
    }
}