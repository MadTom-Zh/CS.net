﻿namespace MX_TTS_System.UserControls
{
    partial class Panel_WorkPlace
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Panel_WorkPlace));
            this.toolStrip_webBrowser = new System.Windows.Forms.ToolStrip();
            this.toolStripButton_webBroScaleUp = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel_webBroScale = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton_webBroScaleDown = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton_speekAll = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton_speekAfterStartPoint = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton_speekSelection = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton_readCurrent = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton_readOverAndNext = new System.Windows.Forms.ToolStripButton();
            this.webBrowser = new System.Windows.Forms.WebBrowser();
            this.control_T2S = new MX_TTS_System.UserControls.Panel_WorkPlace_items.Control_T2S();
            this.statusStrip_WorkPlace = new MX_TTS_System.UserControls.Panel_WorkPlace_items.StatusStrip_WorkPlace();
            this.panel1 = new System.Windows.Forms.Panel();
            this.toolStrip_webBrowser.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip_webBrowser
            // 
            this.toolStrip_webBrowser.AutoSize = false;
            this.toolStrip_webBrowser.Dock = System.Windows.Forms.DockStyle.Right;
            this.toolStrip_webBrowser.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton_webBroScaleUp,
            this.toolStripLabel_webBroScale,
            this.toolStripButton_webBroScaleDown,
            this.toolStripSeparator1,
            this.toolStripButton_speekAll,
            this.toolStripButton_speekAfterStartPoint,
            this.toolStripButton_speekSelection,
            this.toolStripSeparator2,
            this.toolStripButton_readCurrent,
            this.toolStripButton_readOverAndNext});
            this.toolStrip_webBrowser.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.toolStrip_webBrowser.Location = new System.Drawing.Point(479, 0);
            this.toolStrip_webBrowser.Name = "toolStrip_webBrowser";
            this.toolStrip_webBrowser.Size = new System.Drawing.Size(24, 237);
            this.toolStrip_webBrowser.TabIndex = 4;
            this.toolStrip_webBrowser.Text = "Web Browser Tools";
            // 
            // toolStripButton_webBroScaleUp
            // 
            this.toolStripButton_webBroScaleUp.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton_webBroScaleUp.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_webBroScaleUp.Image")));
            this.toolStripButton_webBroScaleUp.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_webBroScaleUp.Name = "toolStripButton_webBroScaleUp";
            this.toolStripButton_webBroScaleUp.Size = new System.Drawing.Size(22, 20);
            this.toolStripButton_webBroScaleUp.Text = "+";
            this.toolStripButton_webBroScaleUp.Click += new System.EventHandler(this.toolStripButton_webBroScaleUp_Click);
            // 
            // toolStripLabel_webBroScale
            // 
            this.toolStripLabel_webBroScale.Name = "toolStripLabel_webBroScale";
            this.toolStripLabel_webBroScale.Size = new System.Drawing.Size(22, 12);
            this.toolStripLabel_webBroScale.Text = "1";
            // 
            // toolStripButton_webBroScaleDown
            // 
            this.toolStripButton_webBroScaleDown.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton_webBroScaleDown.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_webBroScaleDown.Image")));
            this.toolStripButton_webBroScaleDown.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_webBroScaleDown.Name = "toolStripButton_webBroScaleDown";
            this.toolStripButton_webBroScaleDown.Size = new System.Drawing.Size(22, 20);
            this.toolStripButton_webBroScaleDown.Text = "-";
            this.toolStripButton_webBroScaleDown.Click += new System.EventHandler(this.toolStripButton_webBroScaleDown_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(22, 6);
            // 
            // toolStripButton_speekAll
            // 
            this.toolStripButton_speekAll.Checked = true;
            this.toolStripButton_speekAll.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolStripButton_speekAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton_speekAll.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_speekAll.Image")));
            this.toolStripButton_speekAll.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_speekAll.Name = "toolStripButton_speekAll";
            this.toolStripButton_speekAll.Size = new System.Drawing.Size(22, 20);
            this.toolStripButton_speekAll.Text = "阅读全文";
            this.toolStripButton_speekAll.Click += new System.EventHandler(this.toolStripButton_speekAll_Click);
            // 
            // toolStripButton_speekAfterStartPoint
            // 
            this.toolStripButton_speekAfterStartPoint.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton_speekAfterStartPoint.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_speekAfterStartPoint.Image")));
            this.toolStripButton_speekAfterStartPoint.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_speekAfterStartPoint.Name = "toolStripButton_speekAfterStartPoint";
            this.toolStripButton_speekAfterStartPoint.Size = new System.Drawing.Size(22, 20);
            this.toolStripButton_speekAfterStartPoint.Text = "从开始位置开始阅读";
            this.toolStripButton_speekAfterStartPoint.Click += new System.EventHandler(this.toolStripButton_speekAfterStartPoint_Click);
            // 
            // toolStripButton_speekSelection
            // 
            this.toolStripButton_speekSelection.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton_speekSelection.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_speekSelection.Image")));
            this.toolStripButton_speekSelection.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_speekSelection.Name = "toolStripButton_speekSelection";
            this.toolStripButton_speekSelection.Size = new System.Drawing.Size(22, 20);
            this.toolStripButton_speekSelection.Text = "阅读选取";
            this.toolStripButton_speekSelection.Click += new System.EventHandler(this.toolStripButton_speekSelection_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(22, 6);
            // 
            // toolStripButton_readCurrent
            // 
            this.toolStripButton_readCurrent.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton_readCurrent.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_readCurrent.Image")));
            this.toolStripButton_readCurrent.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_readCurrent.Name = "toolStripButton_readCurrent";
            this.toolStripButton_readCurrent.Size = new System.Drawing.Size(22, 20);
            this.toolStripButton_readCurrent.Text = "仅阅读当前文章";
            this.toolStripButton_readCurrent.Click += new System.EventHandler(this.toolStripButton_readCurrent_Click);
            // 
            // toolStripButton_readOverAndNext
            // 
            this.toolStripButton_readOverAndNext.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton_readOverAndNext.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_readOverAndNext.Image")));
            this.toolStripButton_readOverAndNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_readOverAndNext.Name = "toolStripButton_readOverAndNext";
            this.toolStripButton_readOverAndNext.Size = new System.Drawing.Size(22, 20);
            this.toolStripButton_readOverAndNext.Text = "读完后接着读下一篇";
            this.toolStripButton_readOverAndNext.Click += new System.EventHandler(this.toolStripButton_readOverAndNext_Click);
            // 
            // webBrowser
            // 
            this.webBrowser.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.webBrowser.Location = new System.Drawing.Point(0, 0);
            this.webBrowser.Margin = new System.Windows.Forms.Padding(4);
            this.webBrowser.MinimumSize = new System.Drawing.Size(27, 25);
            this.webBrowser.Name = "webBrowser";
            this.webBrowser.Size = new System.Drawing.Size(478, 237);
            this.webBrowser.TabIndex = 5;
            this.webBrowser.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.webBrowser_DocumentCompleted);
            // 
            // control_T2S
            // 
            this.control_T2S.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.control_T2S.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.control_T2S.docNodeDir = null;
            this.control_T2S.isCompleteTextSet = false;
            this.control_T2S.Location = new System.Drawing.Point(0, 263);
            this.control_T2S.Margin = new System.Windows.Forms.Padding(5);
            this.control_T2S.Name = "control_T2S";
            this.control_T2S.Size = new System.Drawing.Size(503, 82);
            this.control_T2S.speekingText = null;
            this.control_T2S.TabIndex = 2;
            // 
            // statusStrip_WorkPlace
            // 
            this.statusStrip_WorkPlace.AutoSize = false;
            this.statusStrip_WorkPlace.Dock = System.Windows.Forms.DockStyle.Top;
            this.statusStrip_WorkPlace.Location = new System.Drawing.Point(0, 0);
            this.statusStrip_WorkPlace.model = MX_TTS_System.UserControls.Panel_WorkPlace_items.StatusStrip_WorkPlace.Model.LoadedOrSaved;
            this.statusStrip_WorkPlace.Name = "statusStrip_WorkPlace";
            this.statusStrip_WorkPlace.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusStrip_WorkPlace.ShowItemToolTips = true;
            this.statusStrip_WorkPlace.Size = new System.Drawing.Size(503, 26);
            this.statusStrip_WorkPlace.SizingGrip = false;
            this.statusStrip_WorkPlace.TabIndex = 0;
            this.statusStrip_WorkPlace.Text = "statusStrip_WorkPlace1";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.toolStrip_webBrowser);
            this.panel1.Controls.Add(this.webBrowser);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 26);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(503, 237);
            this.panel1.TabIndex = 6;
            // 
            // Panel_WorkPlace
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.control_T2S);
            this.Controls.Add(this.statusStrip_WorkPlace);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Panel_WorkPlace";
            this.Size = new System.Drawing.Size(503, 345);
            this.toolStrip_webBrowser.ResumeLayout(false);
            this.toolStrip_webBrowser.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Panel_WorkPlace_items.StatusStrip_WorkPlace statusStrip_WorkPlace;
        private Panel_WorkPlace_items.Control_T2S control_T2S;
        private System.Windows.Forms.ToolStrip toolStrip_webBrowser;
        private System.Windows.Forms.ToolStripButton toolStripButton_webBroScaleUp;
        private System.Windows.Forms.ToolStripLabel toolStripLabel_webBroScale;
        private System.Windows.Forms.ToolStripButton toolStripButton_webBroScaleDown;
        private System.Windows.Forms.WebBrowser webBrowser;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButton_speekAll;
        private System.Windows.Forms.ToolStripButton toolStripButton_speekAfterStartPoint;
        private System.Windows.Forms.ToolStripButton toolStripButton_speekSelection;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButton_readCurrent;
        private System.Windows.Forms.ToolStripButton toolStripButton_readOverAndNext;
    }
}
