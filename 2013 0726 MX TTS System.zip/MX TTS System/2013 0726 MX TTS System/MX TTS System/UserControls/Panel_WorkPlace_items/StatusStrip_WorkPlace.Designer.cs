﻿namespace MX_TTS_System.UserControls.Panel_WorkPlace_items
{
    partial class StatusStrip_WorkPlace : System.Windows.Forms.StatusStrip
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            //components = new System.ComponentModel.Container();


            this.toolStripStatusLabel_progressType = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar = new System.Windows.Forms.ToolStripProgressBar();
            this.toolStripStatusLabel_content = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel_blank = new System.Windows.Forms.ToolStripStatusLabel();
            //this.SuspendLayout();


            this.Dock = System.Windows.Forms.DockStyle.Top;
            this.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.toolStripStatusLabel_progressType,
                this.toolStripProgressBar,
                this.toolStripStatusLabel_content,
                this.toolStripStatusLabel_blank});
            this.ShowItemToolTips = true;
            this.SizingGrip = false;
            this.Text = "T2S Status";


            // 
            // toolStripStatusLabel_progressType
            // 
            this.toolStripStatusLabel_progressType.Name = "toolStripStatusLabel_progressType";
            this.toolStripStatusLabel_progressType.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never;
            this.toolStripStatusLabel_progressType.Size = new System.Drawing.Size(41, 17);
            this.toolStripStatusLabel_progressType.Text = "加载：";
            // 
            // toolStripProgressBar
            // 
            this.toolStripProgressBar.Name = "toolStripProgressBar";
            this.toolStripProgressBar.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never;
            this.toolStripProgressBar.Size = new System.Drawing.Size(100, 16);
            // 
            // toolStripStatusLabel_content
            // 
            this.toolStripStatusLabel_content.Name = "toolStripStatusLabel_content";
            this.toolStripStatusLabel_content.Size = new System.Drawing.Size(77, 17);
            this.toolStripStatusLabel_content.Text = "content name";
            // 
            // toolStripStatusLabel_blank
            // 
            this.toolStripStatusLabel_blank.Name = "toolStripStatusLabel_blank";
            this.toolStripStatusLabel_blank.Size = new System.Drawing.Size(63, 17);
            this.toolStripStatusLabel_blank.Spring = true;

            this.Update();
        }

        #endregion

        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel_progressType;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel_content;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel_blank;
    }
}
