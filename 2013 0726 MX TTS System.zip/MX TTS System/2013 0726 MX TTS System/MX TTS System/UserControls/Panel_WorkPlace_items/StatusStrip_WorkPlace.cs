﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Text;

using System.Windows.Forms;

namespace MX_TTS_System.UserControls.Panel_WorkPlace_items
{
    public partial class StatusStrip_WorkPlace : System.Windows.Forms.StatusStrip
    {
        public StatusStrip_WorkPlace()
        {
            InitializeComponent();
        }

        public void Init()
        {
            this.toolStripProgressBar.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            model = Model.None;
        }

        public enum Model
        {
            None,
            LoadingOrSaving,
            LoadedOrSaved
        }
        private Model _model = Model.LoadedOrSaved;
        public Model model
        {
            set
            {
                if (value == _model) return;
                else _model = value;
                switch (_model)
                {
                    default:
                    case Model.None:
                        toolStripStatusLabel_progressType.Visible
                            = toolStripProgressBar.Visible
                            = toolStripStatusLabel_content.Visible
                            = false;
                        break;
                    case Model.LoadingOrSaving:
                        toolStripStatusLabel_progressType.Visible
                            = toolStripProgressBar.Visible
                            = toolStripStatusLabel_content.Visible
                            = true;
                        break;
                    case Model.LoadedOrSaved:
                        toolStripStatusLabel_progressType.Visible
                            = toolStripProgressBar.Visible
                            = false;
                        toolStripStatusLabel_content.Visible
                            = true;
                        break;
                }
            }
            get { return _model; }
        }

        public void Set_Status_LoadingOrSaving(bool isLoading, string contentDescribe)
        {
            toolStripStatusLabel_progressType.Text = isLoading ? "读取：" : "保存：";
            toolStripStatusLabel_content.Text = contentDescribe;
            model = Model.LoadingOrSaving;
        }
        public void Set_Status_LoadedOrSaved(string contentDescribe)
        {
            toolStripStatusLabel_content.Text = contentDescribe;
            model = Model.LoadedOrSaved;
        }
    }
}
