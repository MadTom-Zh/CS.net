﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

using T2S_HCore.Classes;
using System.IO;

namespace MX_TTS_System.UserControls.Panel_WorkPlace_items
{
    public partial class Control_T2S : UserControl
    {
        public Control_T2S()
        {
            InitializeComponent();
        }

        private BroadCaster _broadCaster;
        private Image imgPlay, imgPause;
        SavedSettings settings = new SavedSettings();
        public void Init()
        {
            string imageStorPath = Application.StartupPath + "\\Icons\\";
            button_playOrPause.Image = imgPlay = Image.FromFile(imageStorPath + "audioStart.png");
            imgPause = Image.FromFile(imageStorPath + "audioPause.png");
            button_stop.Image = Image.FromFile(imageStorPath + "audioStop.png");

            _broadCaster = new BroadCaster();
            _broadCaster.StreamStart += new EventHandler(_broadCaster_StreamStart);
            _broadCaster.StreamEnd += new EventHandler<BroadCaster.StreamEnd_Args>(_broadCaster_StreamEnd);
            _broadCaster.Speeking_WordBoundary += new EventHandler<BroadCaster.Speeking_WordBoundaryEventArgs>(_broadCaster_Speeking_WordBoundary);
            _broadCaster.StreamEndAndJITListGend += new EventHandler<BroadCaster.StreamEndAndJITListGendEventArgs>(_broadCaster_StreamEndAndJITListGend);

            _acceptVoiceChange = false;
            comboBox_voices.Items.Clear();
            for (int i = 0; i < _broadCaster.Voices.Count; i++)
            {
                comboBox_voices.Items.Add(_broadCaster.Voices[i].description);
            }
            _acceptVoiceChange = true;

            button_playOrPause.Enabled = false;
            docNodeDir = null;

            settings.Load();
            bool voiceNotFound = true;
            foreach (object obj in comboBox_voices.Items)
            {
                if (obj.ToString() == settings.MainVoice)
                {
                    comboBox_voices.Text = settings.MainVoice;
                    voiceNotFound = false;
                    break;
                }
            }
            if (voiceNotFound == true)
            {
                comboBox_voices.Text = _broadCaster.voice.description;
            }
            trackBar_rate.Value = settings.VoiceSpeed;
            trackBar_rate_Scroll(this, new EventArgs());
        }

        public string docNodeDir
        {
            get;
            set;
        }
        void _broadCaster_StreamEndAndJITListGend(object sender, BroadCaster.StreamEndAndJITListGendEventArgs e)
        {
            //throw new NotImplementedException();
            if (isCompleteTextSet && docNodeDir != null && false)
            {
                string voiceDir = docNodeDir + "\\voices";
                if (!Directory.Exists(voiceDir))
                {
                    Directory.CreateDirectory(voiceDir);
                }
                //voices contents files, such as...
                //Lili.wav
                //Lili.nfo
                //Lili.tdx
                string filePre = _broadCaster.voice.description
                    + "_R" + (_broadCaster.Rate >= 0 ? "+" : "") + _broadCaster.Rate
                    + "_Vol" + _broadCaster.Volume.ToString("000");
                _broadCaster.SaveWave(speekingText, voiceDir + "\\" + filePre + ".wav");
                string idxFileFullName = voiceDir + "\\" + filePre + ".tdx";
                File.WriteAllText(idxFileFullName, "");
                for (int i = 0; i < e.completeJITEventList.Count; i++)
                {
                    File.AppendAllText(idxFileFullName, "\r\n" + e.completeJITEventList[i].IOContent);
                }
            }
        }

        public event EventHandler<BroadCaster.StreamEnd_Args> After_SpeekStoped;
        void _broadCaster_StreamStart(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            button_playOrPause.Image = imgPause;
            button_stop.Enabled = true;
        }
        void _broadCaster_StreamEnd(object sender, BroadCaster.StreamEnd_Args e)
        {
            //throw new NotImplementedException();
            button_playOrPause.Image = imgPlay;
            button_stop.Enabled = false;
            if (After_SpeekStoped != null) After_SpeekStoped(sender, e);
        }


        private bool _acceptVoiceChange;
        private void comboBox_voices_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_acceptVoiceChange && comboBox_voices.SelectedIndex >= 0)
            {
                button_stop_Click(sender, e);
                _broadCaster.voice = _broadCaster.Voices[comboBox_voices.SelectedIndex];

                settings.MainVoice = comboBox_voices.Text;
            }
        }

        private void trackBar_rate_Scroll(object sender, EventArgs e)
        {
            _broadCaster.Rate = trackBar_rate.Value;
            string valueStr = trackBar_rate.Value.ToString();
            while (valueStr.Length < 3) valueStr = " " + valueStr;
            label_rate.Text = valueStr;

            settings.VoiceSpeed = trackBar_rate.Value;
        }
        private void trackBar_volume_Scroll(object sender, EventArgs e)
        {
            _broadCaster.Volume = trackBar_volume.Value * 5;
            string valueStr = (_broadCaster.Volume).ToString() + " %";
            while (valueStr.Length < 5) valueStr = " " + valueStr;
            label_volume.Text = valueStr;
        }

        public event EventHandler Before_StopBtnClick;
        private void button_stop_Click(object sender, EventArgs e)
        {
            _broadCaster.Stop();
        }
        public void Stop()
        {
            if (Before_StopBtnClick != null) Before_StopBtnClick(this, new EventArgs());
            _broadCaster.Stop();
        }

        public bool isCompleteTextSet
        {
            get;
            set;
        }
        public string speekingText
        {
            set;
            get;
        }
        private int _selectionTextStartIndex = 0;
        public void Set_SpeekingText(string text, bool isCompleteText)
        {
            isCompleteTextSet = isCompleteText;
            if (speekingText != text)
            {
                speekingText = text;
                button_playOrPause.Enabled = (speekingText.Trim().Length > 0);
                _broadCaster.Stop();
            }
            if (isCompleteTextSet || webBrowserScroller == null) _selectionTextStartIndex = 0;
            else
            {
                string startStr = webBrowserScroller.Get_SelectionText_beforeStartPoint();
                //startStr = startStr == null ? "" : startStr.Replace("\r\n", "   ");
                //startStr = startStr == null ? "" : startStr.Replace("\r\n", "\r");
                startStr = startStr == null ? "" : startStr;
                _selectionTextStartIndex = startStr.Length;
            }
        }
        public event EventHandler Before_PlayBtnClick;
        public event EventHandler Before_PauseBtnClick;
        private void button_playOrPause_Click(object sender, EventArgs e)
        {
            if (_broadCaster.isPlaying)
            {
                if (Before_PauseBtnClick != null) Before_PauseBtnClick(sender, e);
                _broadCaster.Pause();
                button_playOrPause.Image = imgPlay;
            }
            else
            {
                if (Before_PlayBtnClick != null) Before_PlayBtnClick(sender, e);
                _broadCaster.Speek(speekingText);
                button_playOrPause.Image = imgPause;
            }
        }
        public void Speek()
        {
            if (_broadCaster.isPlaying == false)
            {
                button_playOrPause_Click(this, new EventArgs());
            }
        }

        public bool isPaused
        {
            get
            {
                return _broadCaster.isPaused;
            }
        }

        private WebBroswerScroller _webBrowserScroller;
        public WebBroswerScroller webBrowserScroller
        {
            get { return _webBrowserScroller; }
        }
        public void SetScrollTextUI(WebBrowser webBrowser)
        {
            if (_webBrowserScroller == null)
            {
                _webBrowserScroller = new WebBroswerScroller(ref webBrowser, true, 100, 100);
            }
        }
        void _broadCaster_Speeking_WordBoundary(object sender, BroadCaster.Speeking_WordBoundaryEventArgs e)
        {
            //throw new NotImplementedException();
            if (_webBrowserScroller != null)
            {
                int tmpSTSI = _selectionTextStartIndex;
                string gotText = _webBrowserScroller.Get_SubText(_selectionTextStartIndex + e.wordStartIndex, e.wordLength);
                gotText = gotText.Replace("\r\n", "\r");
                if (e.word != gotText)
                {
                    int shiftBack = (_selectionTextStartIndex + e.wordStartIndex < 50) ? (_selectionTextStartIndex + e.wordStartIndex) : 50;
                    gotText = _webBrowserScroller.Get_SubText(_selectionTextStartIndex + e.wordStartIndex - shiftBack, e.wordLength + (50 + shiftBack));
                    gotText = gotText.Replace("\r\n", "\r");
                    int inIdx = gotText.IndexOf(e.word);
                    //string subTextBefore = gotText.Substring(0, inIdx);
                    //while (subTextBefore.Contains("\r"))
                    //{
                    //    _selectionTextStartIndex += 1;
                    //    int tmpIdx = subTextBefore.IndexOf("\r");
                    //    subTextBefore = subTextBefore.Substring(0, tmpIdx) + subTextBefore.Substring(tmpIdx + 2);
                    //}
                    //_selectionTextStartIndex += (inIdx - shiftBack < 0) ? 0 : (inIdx - shiftBack);
                    _selectionTextStartIndex += inIdx - shiftBack;

                    gotText = _webBrowserScroller.Get_SubText(_selectionTextStartIndex + e.wordStartIndex, e.wordLength);
                    gotText = gotText.Replace("\r\n", "\r");
                    if (gotText != e.word)
                    {
                        int shifting = 1;
                        bool rightPosiFound = false;
                        int tmp_selectionTextStartIndex = _selectionTextStartIndex;
                        while (shifting < 30)
                        {
                            _selectionTextStartIndex = tmp_selectionTextStartIndex + shifting;
                            gotText = _webBrowserScroller.Get_SubText(_selectionTextStartIndex + e.wordStartIndex, e.wordLength);
                            gotText = gotText.Replace("\r\n", "\r");
                            if (gotText == e.word)
                            {
                                rightPosiFound = true;
                                break;
                            }
                            //_selectionTextStartIndex = tmp_selectionTextStartIndex - shifting;
                            //gotText = _webBrowserScroller.Get_SubText(_selectionTextStartIndex + e.wordStartIndex, e.wordLength);
                            //gotText = gotText.Replace("\r\n", "\r");
                            //if (gotText == e.word)
                            //{
                            //    rightPosiFound = true;
                            //    break;
                            //}
                            shifting++;
                        }
                        if (rightPosiFound == false)
                        {
                            _selectionTextStartIndex = tmp_selectionTextStartIndex;
                        }
                    }
                }
                gotText = _webBrowserScroller.Get_SubText(_selectionTextStartIndex + e.wordStartIndex, e.wordLength);
                gotText = gotText.Replace("\r\n", "\r");
                if (gotText == e.word)
                {
                    _webBrowserScroller.Set_Selection_AndScroll(_selectionTextStartIndex + e.wordStartIndex, e.wordLength);
                }
            }
        }

        private void Control_T2S_Leave(object sender, EventArgs e)
        {
            settings.Save();
        }
    }
}
