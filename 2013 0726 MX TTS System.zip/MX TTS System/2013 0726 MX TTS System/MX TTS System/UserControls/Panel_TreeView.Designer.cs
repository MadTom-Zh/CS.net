﻿namespace MX_TTS_System.UserControls
{
    partial class Panel_TreeView
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Panel_TreeView));
            this.toolStrip = new System.Windows.Forms.ToolStrip();
            this.toolStripButton_goUp = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton_goBack = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton_goForward = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton_prevOne = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton_nextOne = new System.Windows.Forms.ToolStripButton();
            this.treeView = new System.Windows.Forms.TreeView();
            this.imageList = new System.Windows.Forms.ImageList(this.components);
            this.contextMenuStrip_tree = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem_addLocalBookNode = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_delBookLib = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_editLocalBookNode = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator_con = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripMenuItem_explorer = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip.SuspendLayout();
            this.contextMenuStrip_tree.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip
            // 
            this.toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton_goUp,
            this.toolStripSeparator1,
            this.toolStripButton_goBack,
            this.toolStripButton_goForward,
            this.toolStripSeparator2,
            this.toolStripButton_prevOne,
            this.toolStripButton_nextOne});
            this.toolStrip.Location = new System.Drawing.Point(0, 0);
            this.toolStrip.Name = "toolStrip";
            this.toolStrip.Size = new System.Drawing.Size(153, 27);
            this.toolStrip.TabIndex = 0;
            this.toolStrip.Text = "toolStrip1";
            // 
            // toolStripButton_goUp
            // 
            this.toolStripButton_goUp.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_goUp.Image")));
            this.toolStripButton_goUp.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_goUp.Name = "toolStripButton_goUp";
            this.toolStripButton_goUp.Size = new System.Drawing.Size(59, 24);
            this.toolStripButton_goUp.Text = "上级";
            this.toolStripButton_goUp.Click += new System.EventHandler(this.toolStripButton_goUp_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripButton_goBack
            // 
            this.toolStripButton_goBack.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_goBack.Image")));
            this.toolStripButton_goBack.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_goBack.Name = "toolStripButton_goBack";
            this.toolStripButton_goBack.Size = new System.Drawing.Size(59, 24);
            this.toolStripButton_goBack.Text = "后退";
            this.toolStripButton_goBack.Click += new System.EventHandler(this.toolStripButton_goBack_Click);
            // 
            // toolStripButton_goForward
            // 
            this.toolStripButton_goForward.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_goForward.Image")));
            this.toolStripButton_goForward.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_goForward.Name = "toolStripButton_goForward";
            this.toolStripButton_goForward.Size = new System.Drawing.Size(59, 24);
            this.toolStripButton_goForward.Text = "前进";
            this.toolStripButton_goForward.Click += new System.EventHandler(this.toolStripButton_goForward_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // toolStripButton_prevOne
            // 
            this.toolStripButton_prevOne.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_prevOne.Image")));
            this.toolStripButton_prevOne.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_prevOne.Name = "toolStripButton_prevOne";
            this.toolStripButton_prevOne.Size = new System.Drawing.Size(74, 24);
            this.toolStripButton_prevOne.Text = "上一个";
            this.toolStripButton_prevOne.Click += new System.EventHandler(this.toolStripButton_prevOne_Click);
            // 
            // toolStripButton_nextOne
            // 
            this.toolStripButton_nextOne.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_nextOne.Image")));
            this.toolStripButton_nextOne.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_nextOne.Name = "toolStripButton_nextOne";
            this.toolStripButton_nextOne.Size = new System.Drawing.Size(74, 24);
            this.toolStripButton_nextOne.Text = "下一个";
            this.toolStripButton_nextOne.Click += new System.EventHandler(this.toolStripButton_nextOne_Click);
            // 
            // treeView
            // 
            this.treeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView.FullRowSelect = true;
            this.treeView.ImageIndex = 0;
            this.treeView.ImageList = this.imageList;
            this.treeView.Location = new System.Drawing.Point(0, 27);
            this.treeView.Margin = new System.Windows.Forms.Padding(4);
            this.treeView.Name = "treeView";
            this.treeView.SelectedImageIndex = 0;
            this.treeView.Size = new System.Drawing.Size(153, 102);
            this.treeView.TabIndex = 1;
            this.treeView.AfterCollapse += new System.Windows.Forms.TreeViewEventHandler(this.treeView_AfterCollapse);
            this.treeView.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeView_BeforeExpand);
            this.treeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView_AfterSelect);
            this.treeView.Leave += new System.EventHandler(this.treeView_Leave);
            this.treeView.MouseDown += new System.Windows.Forms.MouseEventHandler(this.treeView_MouseDown);
            // 
            // imageList
            // 
            this.imageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
            this.imageList.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // contextMenuStrip_tree
            // 
            this.contextMenuStrip_tree.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem_addLocalBookNode,
            this.toolStripMenuItem_delBookLib,
            this.toolStripMenuItem_editLocalBookNode,
            this.toolStripSeparator_con,
            this.ToolStripMenuItem_explorer});
            this.contextMenuStrip_tree.Name = "contextMenuStrip_tree";
            this.contextMenuStrip_tree.Size = new System.Drawing.Size(203, 98);
            this.contextMenuStrip_tree.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip_tree_Opening);
            // 
            // toolStripMenuItem_addLocalBookNode
            // 
            this.toolStripMenuItem_addLocalBookNode.Name = "toolStripMenuItem_addLocalBookNode";
            this.toolStripMenuItem_addLocalBookNode.Size = new System.Drawing.Size(202, 22);
            this.toolStripMenuItem_addLocalBookNode.Text = "(&A)添加本地书籍...";
            this.toolStripMenuItem_addLocalBookNode.Click += new System.EventHandler(this.toolStripMenuItem_addLocalBookNode_Click);
            // 
            // toolStripMenuItem_delBookLib
            // 
            this.toolStripMenuItem_delBookLib.Name = "toolStripMenuItem_delBookLib";
            this.toolStripMenuItem_delBookLib.Size = new System.Drawing.Size(202, 22);
            this.toolStripMenuItem_delBookLib.Text = "(&D)删除本地书籍";
            this.toolStripMenuItem_delBookLib.Click += new System.EventHandler(this.toolStripMenuItem_delLocalBookNode_Click);
            // 
            // toolStripMenuItem_editLocalBookNode
            // 
            this.toolStripMenuItem_editLocalBookNode.Name = "toolStripMenuItem_editLocalBookNode";
            this.toolStripMenuItem_editLocalBookNode.Size = new System.Drawing.Size(202, 22);
            this.toolStripMenuItem_editLocalBookNode.Text = "(&E)用Word编辑";
            this.toolStripMenuItem_editLocalBookNode.Click += new System.EventHandler(this.toolStripMenuItem_editLocalBookNode_Click);
            // 
            // toolStripSeparator_con
            // 
            this.toolStripSeparator_con.Name = "toolStripSeparator_con";
            this.toolStripSeparator_con.Size = new System.Drawing.Size(199, 6);
            // 
            // ToolStripMenuItem_explorer
            // 
            this.ToolStripMenuItem_explorer.Name = "ToolStripMenuItem_explorer";
            this.ToolStripMenuItem_explorer.Size = new System.Drawing.Size(202, 22);
            this.ToolStripMenuItem_explorer.Text = "浏览";
            this.ToolStripMenuItem_explorer.Click += new System.EventHandler(this.ToolStripMenuItem_explorer_Click);
            // 
            // Panel_TreeView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.treeView);
            this.Controls.Add(this.toolStrip);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Panel_TreeView";
            this.Size = new System.Drawing.Size(153, 129);
            this.toolStrip.ResumeLayout(false);
            this.toolStrip.PerformLayout();
            this.contextMenuStrip_tree.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip;
        private System.Windows.Forms.TreeView treeView;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip_tree;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_addLocalBookNode;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_delBookLib;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator_con;
        private System.Windows.Forms.ImageList imageList;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_explorer;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_editLocalBookNode;
        private System.Windows.Forms.ToolStripButton toolStripButton_goUp;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButton_goBack;
        private System.Windows.Forms.ToolStripButton toolStripButton_goForward;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButton_prevOne;
        private System.Windows.Forms.ToolStripButton toolStripButton_nextOne;
    }
}
