﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

using T2S_HCore.Classes;
using System.IO;

namespace MX_TTS_System.UserControls
{
    public partial class Panel_WorkPlace : UserControl
    {
        public Panel_WorkPlace()
        {
            InitializeComponent();

            //control_T2S.Width = this.Width;
        }

        public void Init(ref IOSystem.Local.Manager ioManager)
        {
            statusStrip_WorkPlace.Init();
            _Init_loadWebBrowserToolIcons();
            control_T2S.Init();
            control_T2S.Before_PlayBtnClick += new EventHandler(control_T2S_Before_PlayBtnClick);
            control_T2S.After_SpeekStoped += new EventHandler<BroadCaster.StreamEnd_Args>(control_T2S_After_SpeekStoped);

            T2S_HCore.Classes.BroadCaster _t2sBroadCaster = new T2S_HCore.Classes.BroadCaster();
            _t2sBroadCaster = null;

            this.Visible = false;

            Load_UserSettings();
        }
        private void _Init_loadWebBrowserToolIcons()
        {
            string iconPath = Application.StartupPath + "\\Icons\\webBrowserTools\\";
            toolStripButton_webBroScaleUp.Image = Image.FromFile(iconPath + "zoomUp.png");
            toolStripButton_webBroScaleDown.Image = Image.FromFile(iconPath + "zoomDown.png");
            toolStripButton_speekAll.Image = Image.FromFile(iconPath + "selectAll.png");
            toolStripButton_speekAfterStartPoint.Image = Image.FromFile(iconPath + "selectForward.png");
            toolStripButton_speekSelection.Image = Image.FromFile(iconPath + "selection.png");

            toolStripButton_readCurrent.Image = Image.FromFile(iconPath + "readCurrent.png");
            toolStripButton_readOverAndNext.Image = Image.FromFile(iconPath + "readOverAndNext.png");
        }

        private static string FileFullPath_UserReadHabitSetting = AppDomain.CurrentDomain.BaseDirectory + "\\UserReadHabit.cfg";
        private bool _isReadingUserReadHabitSetting;
        private static string Flag_WebBrowserScaleFactor = "WebBrowserScaleFactor:";
        private static string Flag_ReadSelectionType = "ReadSelectionType:";
        private static string Flag_ReadSelectionType_SpeekAll = "SpeekAll";
        private static string Flag_ReadSelectionType_SpeekAtSelection = "SpeekAtSelection";
        private static string Flag_ReadSelectionType_SpeekOnlySelection = "SpeekOnlySelection";
        private static string Flag_SpeekPageOverType = "SpeekPageOverType:";
        private static string Flag_SpeekPageOverType_SpeekCurrent = "SpeekCurrent";
        private static string Flag_SpeekPageOverType_SpeekOverAndNext = "SpeekOverAndNext";
        public void Load_UserSettings()
        {
            bool scaleSet = false;
            bool selectionTypeSet = false;
            bool speekPageTypeSet = false;
            if (File.Exists(FileFullPath_UserReadHabitSetting) == true)
            {
                _isReadingUserReadHabitSetting = true;
                string[] lines = File.ReadAllLines(FileFullPath_UserReadHabitSetting);
                foreach (string line in lines)
                {
                    if (line.StartsWith(Flag_WebBrowserScaleFactor))
                    {
                        _webBrowserScaleFactor = float.Parse(line.Substring(Flag_WebBrowserScaleFactor.Length));
                        _Set_webBrowserScale();
                        scaleSet = true;
                    }
                    else if (line.StartsWith(Flag_ReadSelectionType))
                    {
                        string valueStr = line.Substring(Flag_ReadSelectionType.Length);
                        if (valueStr == Flag_ReadSelectionType_SpeekAll)
                        {
                            toolStripButton_speekAll_Click(this, new EventArgs());
                            selectionTypeSet = true;
                        }
                        else if (valueStr == Flag_ReadSelectionType_SpeekAtSelection)
                        {
                            toolStripButton_speekAfterStartPoint_Click(this, new EventArgs());
                            selectionTypeSet = true;
                        }
                        else if (valueStr == Flag_ReadSelectionType_SpeekOnlySelection)
                        {
                            toolStripButton_speekSelection_Click(this, new EventArgs());
                            selectionTypeSet = true;
                        }
                    }
                    else if (line.StartsWith(Flag_SpeekPageOverType))
                    {
                        string valueStr = line.Substring(Flag_SpeekPageOverType.Length);
                        if (valueStr == Flag_SpeekPageOverType_SpeekCurrent)
                        {
                            toolStripButton_readCurrent_Click(this, new EventArgs());
                            speekPageTypeSet = true;
                        }
                        else if (valueStr == Flag_SpeekPageOverType_SpeekOverAndNext)
                        {
                            toolStripButton_readOverAndNext_Click(this, new EventArgs());
                            speekPageTypeSet = true;
                        }
                    }
                }
                _isReadingUserReadHabitSetting = false;
            }
            if (scaleSet == false)
            {
            }
            if (selectionTypeSet == false)
            {
                toolStripButton_speekAfterStartPoint_Click(this, new EventArgs());
            }
            if (speekPageTypeSet == false)
            {
                toolStripButton_readOverAndNext_Click(this, new EventArgs());
            }
        }
        public void Save_UserSettings()
        {
            if (_isReadingUserReadHabitSetting)
            {
                return;
            }
            string ioContnet = "";
            ioContnet += Flag_WebBrowserScaleFactor + _webBrowserScaleFactor + "\r\n";

            ioContnet += Flag_ReadSelectionType;
            if (toolStripButton_speekAll.Checked)
            {
                ioContnet += Flag_ReadSelectionType_SpeekAll;
            }
            else if (toolStripButton_speekAfterStartPoint.Checked)
            {
                ioContnet += Flag_ReadSelectionType_SpeekAtSelection;
            }
            else if (toolStripButton_speekSelection.Checked)
            {
                ioContnet += Flag_ReadSelectionType_SpeekOnlySelection;
            }
            ioContnet += "\r\n";

            ioContnet += Flag_SpeekPageOverType;
            if (toolStripButton_readCurrent.Checked)
            {
                ioContnet += Flag_SpeekPageOverType_SpeekCurrent;
            }
            else if (toolStripButton_readOverAndNext.Checked)
            {
                ioContnet += Flag_SpeekPageOverType_SpeekOverAndNext;
            }

            File.WriteAllText(FileFullPath_UserReadHabitSetting, ioContnet);
        }

        private IOSystem.Local.DocNode _localDocNode;
        public void LoadLocalDoc(IOSystem.Local.DocNode localDocNode)
        {
            StopAll();
            _localDocNode = localDocNode;
            statusStrip_WorkPlace.Set_Status_LoadingOrSaving(true, "Loading doc: " + _localDocNode.physicalDocFullName);
            Update();
            webBrowser.Url = new Uri(_localDocNode.physicalDocFullName);
            this.Visible = true;
        }
        public void StopAll()
        {
            control_T2S.Stop();
            if (control_T2S.webBrowserScroller != null)
            {
                control_T2S.webBrowserScroller.StopScroll();
            }
        }

        string _speekTextAfterStartPoint = "";
        //bool firstWebPageLoaded = false;
        void webBrowser_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            _speekTextAfterStartPoint = "";
            if (webBrowser.Url.LocalPath != _localDocNode.physicalDocFullName)
            {
                control_T2S.Enabled = false;
            }
            else
            {
                control_T2S.Enabled = true;
            }
            _SetUIScroller();
            statusStrip_WorkPlace.Set_Status_LoadedOrSaved(_localDocNode.fullName);
            _Set_webBrowserScale();
            _Set_SpeekSelection();

            //if (firstWebPageLoaded == false)
            //{
            //    firstWebPageLoaded = true;
            //    toolStripButton_speekAfterStartPoint_Click(this, new EventArgs());
            //    //toolStripButton_speekAll_Click(this, new EventArgs());
            //}
            if (WebDocumentLoadCompleted != null)
            {
                WebDocumentLoadCompleted(sender, e);
            }
        }
        private void _SetUIScroller()
        {
            control_T2S.SetScrollTextUI(webBrowser);
        }

        public event EventHandler WebDocumentLoadCompleted;

        private float _webBrowserScaleFactor = (float)1.0;
        private void toolStripButton_webBroScaleUp_Click(object sender, EventArgs e)
        {
            _webBrowserScaleFactor += (float)0.1;
            _Set_webBrowserScale();
        }
        private void toolStripButton_webBroScaleDown_Click(object sender, EventArgs e)
        {
            _webBrowserScaleFactor -= (float)0.1;
            _Set_webBrowserScale();
        }
        private void _Set_webBrowserScale()
        {
            if (webBrowser.Document == null)
            {
                return;
            }
            webBrowser.Document.Body.Style = "zoom:" + _webBrowserScaleFactor.ToString("0.0");
            toolStripLabel_webBroScale.Text = _webBrowserScaleFactor.ToString("#.#");
            Save_UserSettings();
        }

        private void toolStripButton_speekAll_Click(object sender, EventArgs e)
        {
            toolStripButton_speek_ClearCheckedStatues();
            if (webBrowser.Document != null)
            {
                control_T2S.Set_SpeekingText(webBrowser.Document.Body.InnerText.Replace("\r\n", "\r"), true);
                //control_T2S.Set_SpeekingText(webBrowser.Document.Body.InnerText, true);
            }
            toolStripButton_speekAll.Checked = true;
            Save_UserSettings();
        }
        private void toolStripButton_speekAfterStartPoint_Click(object sender, EventArgs e)
        {
            toolStripButton_speek_ClearCheckedStatues();
            string text;
            if (control_T2S.webBrowserScroller == null)
            {
                text = null;
            }
            else
            {
                text = control_T2S.webBrowserScroller.Get_SelectionText(true);
            }
            if (text == null)
            {
                //toolStripButton_speekAll_Click(sender, e);
                //return;
                if (_speekTextAfterStartPoint != null && _speekTextAfterStartPoint.Length > 0)
                {
                    text = _speekTextAfterStartPoint;
                }
                else
                {
                    if (webBrowser.Document != null)
                    {
                        text = webBrowser.Document.Body.InnerText;
                    }
                }
            }
            if (text == null) text = "";
            control_T2S.Set_SpeekingText(text.Replace("\r\n", "\r"), false);
            //control_T2S.Set_SpeekingText(text, false);
            toolStripButton_speekAfterStartPoint.Checked = true;
            Save_UserSettings();
        }
        private void toolStripButton_speekSelection_Click(object sender, EventArgs e)
        {
            toolStripButton_speek_ClearCheckedStatues();
            string text = control_T2S.webBrowserScroller == null ? null : control_T2S.webBrowserScroller.Get_SelectionText(false);
            if (text == null)
            {
                //toolStripButton_speekAll_Click(sender, e);
                //return;
                if (_speekTextAfterStartPoint != null && _speekTextAfterStartPoint.Length > 0)
                {
                    text = _speekTextAfterStartPoint;
                }
                else text = webBrowser.Document == null ? "" : webBrowser.Document.Body.InnerText;
            }
            control_T2S.Set_SpeekingText(text.Replace("\r\n", "\r"), false);
            //control_T2S.Set_SpeekingText(text, false);
            toolStripButton_speekSelection.Checked = true;
            Save_UserSettings();
        }
        private void toolStripButton_speek_ClearCheckedStatues()
        {
            toolStripButton_speekAll.Checked
                = toolStripButton_speekAfterStartPoint.Checked
                = toolStripButton_speekSelection.Checked
                    = false;
        }
        private void toolStripButton_speek_btnsEnabled(bool isEnabled)
        {
            toolStripButton_speekAll.Enabled
                = toolStripButton_speekAfterStartPoint.Enabled
                = toolStripButton_speekSelection.Enabled
                    = isEnabled;
        }
        private void _Set_SpeekSelection()
        {
            if (toolStripButton_speekAll.Checked)
            {
                toolStripButton_speekAll_Click(this, new EventArgs());
            }
            else if (toolStripButton_speekAfterStartPoint.Checked)
            {
                toolStripButton_speekAfterStartPoint_Click(this, new EventArgs());
            }
            else if (toolStripButton_speekSelection.Checked)
            {
                toolStripButton_speekSelection_Click(this, new EventArgs());
            }
        }

        public enum ReadSelectionType
        {
            All,
            AtSelection,
            OnlySelection,
        }
        public ReadSelectionType SpeekSelectionType
        {
            get
            {
                if (toolStripButton_speekAfterStartPoint.Checked == true) return ReadSelectionType.AtSelection;
                else if (toolStripButton_speekSelection.Checked == true) return ReadSelectionType.OnlySelection;
                else return ReadSelectionType.All;
            }
        }

        void control_T2S_Before_PlayBtnClick(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            if (control_T2S.isPaused) return;
            if (toolStripButton_speekAll.Checked) toolStripButton_speekAll_Click(sender, e);
            else if (toolStripButton_speekAfterStartPoint.Checked) toolStripButton_speekAfterStartPoint_Click(sender, e);
            else if (toolStripButton_speekSelection.Checked) toolStripButton_speekSelection_Click(sender, e);
            toolStripButton_speek_btnsEnabled(false);
        }
        void control_T2S_After_SpeekStoped(object sender, BroadCaster.StreamEnd_Args e)
        {
            _speekTextAfterStartPoint = control_T2S.webBrowserScroller.Get_SelectionText(true);
            toolStripButton_speek_btnsEnabled(true);
            if (SpeekStoped != null)
            {
                SpeekStoped(sender, e);
            }
        }

        public event EventHandler<BroadCaster.StreamEnd_Args> SpeekStoped;

        private void toolStripButton_readCurrent_Click(object sender, EventArgs e)
        {
            if (toolStripButton_readCurrent.Checked == false)
            {
                toolStripButton_readOverAndNext.Checked = false;
                toolStripButton_readCurrent.Checked = true;
                Save_UserSettings();
            }
        }
        private void toolStripButton_readOverAndNext_Click(object sender, EventArgs e)
        {
            if (toolStripButton_readOverAndNext.Checked == false)
            {
                toolStripButton_readCurrent.Checked = false;
                toolStripButton_readOverAndNext.Checked = true;
                Save_UserSettings();
            }
        }
        public enum SpeekPageOverType
        {
            Current,
            OverAndNext,
        }
        public SpeekPageOverType SpeekPageType
        {
            get
            {
                if (toolStripButton_readCurrent.Checked == true) return SpeekPageOverType.Current;
                else return SpeekPageOverType.OverAndNext;
            }
        }

        public void Speek()
        {
            control_T2S.Speek();
        }
    }
}
