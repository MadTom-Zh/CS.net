﻿namespace MX_TTS_System.UserControls
{
    partial class Form_AddLocalBookNode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radioButton_edit_word = new System.Windows.Forms.RadioButton();
            this.radioButton_edit_null = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_newBookNode = new System.Windows.Forms.TextBox();
            this.button_cancel = new System.Windows.Forms.Button();
            this.button_ok = new System.Windows.Forms.Button();
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // radioButton_edit_word
            // 
            this.radioButton_edit_word.AutoSize = true;
            this.radioButton_edit_word.Checked = true;
            this.radioButton_edit_word.Location = new System.Drawing.Point(130, 76);
            this.radioButton_edit_word.Margin = new System.Windows.Forms.Padding(4);
            this.radioButton_edit_word.Name = "radioButton_edit_word";
            this.radioButton_edit_word.Size = new System.Drawing.Size(105, 19);
            this.radioButton_edit_word.TabIndex = 6;
            this.radioButton_edit_word.TabStop = true;
            this.radioButton_edit_word.Text = "用Word编辑";
            this.radioButton_edit_word.UseVisualStyleBackColor = true;
            // 
            // radioButton_edit_null
            // 
            this.radioButton_edit_null.AutoSize = true;
            this.radioButton_edit_null.Location = new System.Drawing.Point(290, 76);
            this.radioButton_edit_null.Margin = new System.Windows.Forms.Padding(4);
            this.radioButton_edit_null.Name = "radioButton_edit_null";
            this.radioButton_edit_null.Size = new System.Drawing.Size(73, 19);
            this.radioButton_edit_null.TabIndex = 5;
            this.radioButton_edit_null.Text = "无操作";
            this.radioButton_edit_null.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(40, 47);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 15);
            this.label4.TabIndex = 4;
            this.label4.Text = "名称：";
            // 
            // textBox_newBookNode
            // 
            this.textBox_newBookNode.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_newBookNode.Location = new System.Drawing.Point(130, 43);
            this.textBox_newBookNode.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_newBookNode.Name = "textBox_newBookNode";
            this.textBox_newBookNode.Size = new System.Drawing.Size(588, 25);
            this.textBox_newBookNode.TabIndex = 3;
            this.textBox_newBookNode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_newBookNode_KeyDown);
            // 
            // button_cancel
            // 
            this.button_cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button_cancel.Location = new System.Drawing.Point(681, 124);
            this.button_cancel.Margin = new System.Windows.Forms.Padding(4);
            this.button_cancel.Name = "button_cancel";
            this.button_cancel.Size = new System.Drawing.Size(100, 29);
            this.button_cancel.TabIndex = 1;
            this.button_cancel.Text = "取消(&C)";
            this.button_cancel.UseVisualStyleBackColor = true;
            this.button_cancel.Click += new System.EventHandler(this.button_cancel_Click);
            // 
            // button_ok
            // 
            this.button_ok.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ok.Location = new System.Drawing.Point(573, 124);
            this.button_ok.Margin = new System.Windows.Forms.Padding(4);
            this.button_ok.Name = "button_ok";
            this.button_ok.Size = new System.Drawing.Size(100, 29);
            this.button_ok.TabIndex = 1;
            this.button_ok.Text = "确定(&O)";
            this.button_ok.UseVisualStyleBackColor = true;
            this.button_ok.Click += new System.EventHandler(this.button_ok_Click);
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog1";
            this.openFileDialog.Filter = "HTML Files|*.htm;*.html";
            // 
            // Form_AddLocalBookNode
            // 
            this.AcceptButton = this.button_ok;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.button_cancel;
            this.ClientSize = new System.Drawing.Size(797, 163);
            this.Controls.Add(this.radioButton_edit_word);
            this.Controls.Add(this.radioButton_edit_null);
            this.Controls.Add(this.button_ok);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button_cancel);
            this.Controls.Add(this.textBox_newBookNode);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form_AddLocalBookNode";
            this.Text = "增加本地书籍";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_AddBookNode_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_cancel;
        private System.Windows.Forms.Button button_ok;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_newBookNode;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.RadioButton radioButton_edit_word;
        private System.Windows.Forms.RadioButton radioButton_edit_null;
    }
}