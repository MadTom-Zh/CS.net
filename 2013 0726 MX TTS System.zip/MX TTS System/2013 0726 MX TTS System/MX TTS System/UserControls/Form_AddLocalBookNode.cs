﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Media;
using System.IO;
using System.Diagnostics;

namespace MX_TTS_System.UserControls
{
    public partial class Form_AddLocalBookNode : Form
    {
        public Form_AddLocalBookNode()
        {
            InitializeComponent();
        }

        public string newLocalDocNodeName
        {
            get
            {
                return textBox_newBookNode.Text;
            }
        }
        public bool isUsingWordEdit
        {
            get
            {
                return radioButton_edit_word.Checked;
            }
        }

        private void button_ok_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }
        private void button_cancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }
        private void textBox_newBookNode_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button_ok_Click(sender, new EventArgs());
            }
            else if (e.KeyCode == Keys.Escape)
            {
                button_cancel_Click(sender, new EventArgs());
            }
        }

        private void Form_AddBookNode_FormClosing(object sender, FormClosingEventArgs e)
        {
            //e.Cancel = true;
            this.Hide();
        }
    }
}
