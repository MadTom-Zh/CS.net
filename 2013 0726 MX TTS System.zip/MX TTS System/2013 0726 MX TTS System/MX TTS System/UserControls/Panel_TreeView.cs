﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

using System.IO;
using System.Diagnostics;
//using IOSystem;

namespace MX_TTS_System.UserControls
{
    public partial class Panel_TreeView : UserControl
    {
        public Panel_TreeView()
        {
            InitializeComponent();
        }

        private IOSystem.Local.Manager _ioManager;
        private Historian _historian;
        public void Init(ref IOSystem.Local.Manager ioManager)
        {
            _ioManager = ioManager;
            _Init_UI();

            TreeNode localLibTNode = treeView.Nodes[TreeNodeFunction.FunctionType.NODE_NAME_LOCALLIB];
            localLibTNode.Nodes.Clear();
            if (_ioManager.localLib.Count > 0)
            {
                localLibTNode.Nodes.Add("_blank");
            }

            localLibTNode.Expand();

            _historian = new Historian();
            TreeNode historyTNode = treeView.Nodes[TreeNodeFunction.FunctionType.NODE_NAME_VIEWHISTORY];
            historyTNode.Nodes.Add("_blank");
            historyTNode.Expand();

            _Set_toolStrip(null);
            SelectLocalLibItem(_historian.ReadLast().fullName);
        }
        private void _Init_UI()
        {
            imageList.Images.Clear();

            string iconStorePath = Application.StartupPath + "\\Icons\\treeView\\";
            imageList.Images.Add(TreeNodeFunction.FunctionType.NODE_NAME_VIEWHISTORY, Image.FromFile(iconStorePath + "viewHistory.ico"));
            imageList.Images.Add(TreeNodeFunction.FunctionType.NODE_NAME_LOCALLIB, Image.FromFile(iconStorePath + "localLib.ico"));
            imageList.Images.Add(TreeNodeFunction.FunctionType.NODE_NAME_LOCALROOM, Image.FromFile(iconStorePath + "localRoom.ico"));
            imageList.Images.Add(TreeNodeFunction.FunctionType.NODE_NAME_LOCALBOOKSET, Image.FromFile(iconStorePath + "localBookSet.ico"));
            imageList.Images.Add(TreeNodeFunction.FunctionType.NODE_NAME_LOCALBOOK, Image.FromFile(iconStorePath + "localBook.ico"));
            imageList.Images.Add(TreeNodeFunction.FunctionType.NODE_NAME_ONLINELIB, Image.FromFile(iconStorePath + "onlineLib.ico"));
            imageList.Images.Add(TreeNodeFunction.FunctionType.NODE_NAME_ONLINEMACHINE, Image.FromFile(iconStorePath + "onlineMachine.ico"));
            imageList.Images.Add(TreeNodeFunction.FunctionType.NODE_NAME_ONLINEROOM, Image.FromFile(iconStorePath + "onlineRoom.ico"));
            imageList.Images.Add(TreeNodeFunction.FunctionType.NODE_NAME_ONLINEBOOKSET, Image.FromFile(iconStorePath + "onlineBookSet.ico"));
            imageList.Images.Add(TreeNodeFunction.FunctionType.NODE_NAME_ONLINEBOOK, Image.FromFile(iconStorePath + "onlineBook.ico"));

            treeView.Nodes.Clear();

            TreeNode rootNode = new TreeNode();
            rootNode.Name = TreeNodeFunction.FunctionType.NODE_NAME_VIEWHISTORY;
            rootNode.Text = "浏览历史";
            rootNode.SelectedImageKey = rootNode.ImageKey = TreeNodeFunction.FunctionType.NODE_NAME_VIEWHISTORY;
            treeView.Nodes.Add(rootNode);

            rootNode = new TreeNode();
            rootNode.Name = TreeNodeFunction.FunctionType.NODE_NAME_LOCALLIB;
            rootNode.Text = "本地文库";
            rootNode.SelectedImageKey = rootNode.ImageKey = TreeNodeFunction.FunctionType.NODE_NAME_LOCALLIB;
            treeView.Nodes.Add(rootNode);

            //rootNode = new TreeNode();
            //rootNode.Name = TreeNodeFunction.FunctionType.NODE_NAME_ONLINELIB.ToString();
            //rootNode.Text = "在线文库";
            //rootNode.SelectedImageKey = rootNode.ImageKey = TreeNodeFunction.FunctionType.NODE_NAME_ONLINELIB;
            //treeView.Nodes.Add(rootNode);
        }
        private void _ReLoad_localLib()
        {
            IOSystem.Local.DocNode curIONode;
            TreeNode newTNode;
            TreeNode localLibTNode = treeView.Nodes[TreeNodeFunction.FunctionType.NODE_NAME_LOCALLIB];
            localLibTNode.Nodes.Clear();
            for (int i = 0; i < _ioManager.localLib.Count; i++)
            {
                curIONode = _ioManager.localLib[i];
                curIONode.ReLoad_SubNodes();
                newTNode = new TreeNode();
                newTNode.Text = newTNode.Name = curIONode.name;
                newTNode.SelectedImageKey = newTNode.ImageKey = TreeNodeFunction.FunctionType.NODE_NAME_LOCALROOM;
                if (curIONode.subNodes.Count > 0) newTNode.Nodes.Add("_blank");
                localLibTNode.Nodes.Add(newTNode);
            }
            //localLibTNode.Expand();
        }
        private void _ReLoad_localBookNode(TreeNode targetTNode, List<IOSystem.Local.DocNode> subNodes)
        {
            targetTNode.Nodes.Clear();
            IOSystem.Local.DocNode curIONode;
            TreeNode newTNode;
            for (int i = 0; i < subNodes.Count; i++)
            {
                curIONode = subNodes[i];
                curIONode.ReLoad_SubNodes();
                newTNode = new TreeNode();
                newTNode.Text = newTNode.Name = curIONode.name;
                newTNode.Tag = curIONode;
                if (curIONode.subNodes == null || curIONode.subNodes.Count <= 0)
                {
                    newTNode.SelectedImageKey = newTNode.ImageKey = TreeNodeFunction.FunctionType.NODE_NAME_LOCALBOOK;
                }
                else
                {
                    newTNode.SelectedImageKey = newTNode.ImageKey = TreeNodeFunction.FunctionType.NODE_NAME_LOCALBOOKSET;
                    newTNode.Nodes.Add("_blank");
                }
                targetTNode.Nodes.Add(newTNode);
            }
        }

        private void treeView_BeforeExpand(object sender, TreeViewCancelEventArgs e)
        {
            TreeNodeFunction iNodeFunction = new TreeNodeFunction(e.Node);
            if (iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_VIEWHISTORY)
            {
                // refresh view history
                e.Node.Nodes.Clear();
                TreeNode hisTNode;
                Historian.Item hisItem;
                for (int i = _historian.itemList.Count - 1; i >= 0; i--)
                {
                    hisItem = _historian.itemList[i];
                    hisTNode = new TreeNode();
                    if (hisItem.fullName.Contains("\\"))
                    {
                        hisTNode.Text = hisItem.fullName.Substring(hisItem.fullName.IndexOf('\\') + 1);
                    }
                    else
                    {
                        hisTNode.Text = hisItem.fullName;
                    }
                    hisTNode.ToolTipText = hisTNode.Text = hisItem.fullName;
                    hisTNode.Tag = hisItem;
                    e.Node.Nodes.Add(hisTNode);
                }
            }
            else if (iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_VIEWHISTORY_ITEM)
            {
                // read org nodes, do nothing
            }
            else if (iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_LOCALLIB)
            {
                _ReLoad_localLib();
            }
            else if (iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_LOCALROOM
                || iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_LOCALBOOKSET
                )
            {
                string nodePath = e.Node.FullPath;
                nodePath = nodePath.Substring(nodePath.IndexOf("\\") + 1);
                IOSystem.Local.DocNode tarLDNode = _ioManager.Get_DocNode(nodePath, true);
                tarLDNode.ReLoad_SubNodes();
                _ReLoad_localBookNode(e.Node, tarLDNode.subNodes);
            }
            else if (iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_ONLINELIB)
            {
                // refresh online machine connections
            }
            else if (iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_ONLINEMACHINE)
            {
                // get lib from a online machine
            }
            else if (iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_ONLINEROOM
                || iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_ONLINEBOOKSET
                )
            {
                // get lib content, or book set content
            }
        }
        public class TreeNodeFunction
        {
            private TreeNode _treeNode_source;
            public TreeNode treeNode_source
            {
                get { return _treeNode_source; }
            }

            private TreeNode _treeNode_level0;
            public TreeNode treeNode_level0
            {
                get { return _treeNode_level0; }
            }
            private TreeNode _treeNode_level1 = null;
            public TreeNode treeNode_level1
            {
                get { return _treeNode_level1; }
            }

            public TreeNodeFunction(TreeNode source)
            {
                _treeNode_level0 = _treeNode_source = source;
                while (_treeNode_level0.Level > 0)
                {
                    if (_treeNode_level0.Level == 1) _treeNode_level1 = _treeNode_level0;
                    _treeNode_level0 = _treeNode_level0.Parent;
                }
                if (source.Level == 0)
                {
                    if (source.Name == FunctionType.NODE_NAME_VIEWHISTORY)
                    {
                        _functionType = new FunctionType(FunctionType.NODE_NAME_VIEWHISTORY);
                    }
                    else if (source.Name == FunctionType.NODE_NAME_LOCALLIB)
                    {
                        _functionType = new FunctionType(FunctionType.NODE_NAME_LOCALLIB);
                    }
                    else if (source.Name == FunctionType.NODE_NAME_ONLINELIB)
                    {
                        _functionType = new FunctionType(FunctionType.NODE_NAME_ONLINELIB);
                    }
                }
                else // e.Node.Level > 0
                {
                    if (_treeNode_level0.Name == TreeNodeFunction.FunctionType.NODE_NAME_VIEWHISTORY)
                    {
                        _functionType = new FunctionType(FunctionType.NODE_NAME_VIEWHISTORY_ITEM);
                    }
                    else if (_treeNode_level0.Name == TreeNodeFunction.FunctionType.NODE_NAME_LOCALLIB)
                    {
                        if (source.Level == 1) _functionType = new FunctionType(FunctionType.NODE_NAME_LOCALROOM);
                        else if (source.Nodes.Count == 0) _functionType = new FunctionType(FunctionType.NODE_NAME_LOCALBOOK);
                        else _functionType = new FunctionType(FunctionType.NODE_NAME_LOCALBOOKSET);
                    }
                    else if (_treeNode_level0.Name == TreeNodeFunction.FunctionType.NODE_NAME_ONLINELIB)
                    {
                        if (source.Level == 1) _functionType = new FunctionType(FunctionType.NODE_NAME_ONLINEMACHINE);
                        else if (source.Level == 1) _functionType = new FunctionType(FunctionType.NODE_NAME_ONLINEROOM);
                        else if (source.Nodes.Count == 0) _functionType = new FunctionType(FunctionType.NODE_NAME_ONLINEBOOK);
                        else _functionType = new FunctionType(FunctionType.NODE_NAME_ONLINEBOOKSET);
                    }
                }
            }

            private FunctionType _functionType;
            public FunctionType functionType
            {
                get { return _functionType; }
            }
            public class FunctionType
            {
                public static string NODE_NAME_VIEWHISTORY = "viewHistory";
                public static string NODE_NAME_VIEWHISTORY_ITEM = "viewHistoryItem";
                public static string NODE_NAME_LOCALLIB = "localLib";
                public static string NODE_NAME_LOCALROOM = "localRoom";
                public static string NODE_NAME_LOCALBOOKSET = "localBookSet";
                public static string NODE_NAME_LOCALBOOK = "localBook";
                public static string NODE_NAME_ONLINELIB = "onlineLib";
                public static string NODE_NAME_ONLINEMACHINE = "onlineMachine";
                public static string NODE_NAME_ONLINEROOM = "onlineRoom";
                public static string NODE_NAME_ONLINEBOOKSET = "onlineBookSet";
                public static string NODE_NAME_ONLINEBOOK = "onlineBook";

                private string _myFunctionType;
                public string myFunctionType
                {
                    get { return _myFunctionType; }
                }
                public FunctionType(string myFunctionType)
                {
                    if (myFunctionType != NODE_NAME_VIEWHISTORY
                        && myFunctionType != NODE_NAME_VIEWHISTORY_ITEM
                        && myFunctionType != NODE_NAME_LOCALLIB
                        && myFunctionType != NODE_NAME_LOCALROOM
                        && myFunctionType != NODE_NAME_LOCALBOOKSET
                        && myFunctionType != NODE_NAME_LOCALBOOK
                        && myFunctionType != NODE_NAME_ONLINELIB
                        && myFunctionType != NODE_NAME_ONLINEMACHINE
                        && myFunctionType != NODE_NAME_ONLINEROOM
                        && myFunctionType != NODE_NAME_ONLINEBOOKSET
                        && myFunctionType != NODE_NAME_ONLINEBOOK
                        )
                    {
                        throw new Exception("Code[" + myFunctionType + "] is not accepted!");
                    }
                    _myFunctionType = myFunctionType;
                }
            }
        }

        private void treeView_AfterCollapse(object sender, TreeViewEventArgs e)
        {
            TreeNodeFunction iNodeFunction = new TreeNodeFunction(e.Node);
            if (//||iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_VIEWHISTORY
                iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_VIEWHISTORY_ITEM
                || iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_LOCALLIB
                || iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_LOCALROOM
                || iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_LOCALBOOKSET
                || iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_ONLINELIB
                || iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_ONLINEMACHINE
                || iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_ONLINEROOM
                || iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_ONLINEBOOKSET
                )
            {
                iNodeFunction.treeNode_source.Nodes.Clear();
                iNodeFunction.treeNode_source.Nodes.Add("_blank");
            }
        }

        private TreeNode _preSelectedTreeViewNode = null;
        private Color _selectedTreeViewNode_BackgroundColor = SystemColors.Highlight;
        private Color _selectedTreeViewNode_ForeColor = SystemColors.HighlightText;
        private void treeView_AfterSelect(object sender, TreeViewEventArgs e)
        {
            TreeNodeFunction iNodeFunction = new TreeNodeFunction(e.Node);
            if (iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_VIEWHISTORY)
            {
                // do nothing
            }
            else if (iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_VIEWHISTORY_ITEM)
            {
                // focus to org node
                Historian.Item hisItem = (Historian.Item)e.Node.Tag;
                SelectLocalLibItem(hisItem.fullName);
            }
            else if (iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_LOCALLIB)
            {
                //_ioManager.Radio_Select_LocalLib();
                // do nothing
            }
            else if (iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_LOCALROOM
                || iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_LOCALBOOKSET
                || iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_LOCALBOOK
                )
            {
                string itemLibPath = e.Node.FullPath;
                itemLibPath = itemLibPath.Substring(itemLibPath.IndexOf('\\') + 1);
                if (_isReadingHistory == false)
                {
                    _historian.SetHistory(Historian.ItemType.Local, itemLibPath);
                }
                TreeNode historyTNode = treeView.Nodes[TreeNodeFunction.FunctionType.NODE_NAME_VIEWHISTORY];
                historyTNode.Collapse();
                if (TreeViewNodeSelected != null)
                {
                    TreeViewNodeSelected(sender, new TreeViewNodeSelectedEventArgs(Historian.ItemType.Local, itemLibPath));
                }
            }
            else if (iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_ONLINELIB)
            {
            }
            else if (iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_ONLINEMACHINE)
            {
            }
            else if (iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_ONLINEROOM
                || iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_ONLINEBOOKSET
                || iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_ONLINEBOOK
                )
            {
            }
            treeView.SelectedNode.ContextMenuStrip = contextMenuStrip_tree;
            if (_preSelectedTreeViewNode != null)
            {
                _preSelectedTreeViewNode.BackColor = treeView.SelectedNode.BackColor;
                _preSelectedTreeViewNode.ForeColor = treeView.SelectedNode.ForeColor;
            }
            treeView.SelectedNode.BackColor = _selectedTreeViewNode_BackgroundColor;
            treeView.SelectedNode.ForeColor = _selectedTreeViewNode_ForeColor;
            _preSelectedTreeViewNode = treeView.SelectedNode;

            treeView.SelectedNode.EnsureVisible();

            _isReadingHistory = false;
            _Set_toolStrip(iNodeFunction);

            if (After_treeView_AfterSelect != null)
            {
                After_treeView_AfterSelect(sender, e);
            }
        }
        public event EventHandler After_treeView_AfterSelect;

        private void treeView_Leave(object sender, EventArgs e)
        {
            if (treeView.SelectedNode != null)
            {
                treeView.SelectedNode.BackColor = _selectedTreeViewNode_BackgroundColor;
                treeView.SelectedNode.ForeColor = _selectedTreeViewNode_ForeColor;
            }
        }
        public void SelectLocalLibItem(string fullName)
        {
            TreeNode localLibTNode = treeView.Nodes[TreeNodeFunction.FunctionType.NODE_NAME_LOCALLIB];
            localLibTNode.Expand();
            TreeNode subTNode = localLibTNode;
            TreeNode subTNode2;
            string[] parts = fullName.Split(new string[] { "\\" }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < parts.Length; i++)
            {
                for (int j = subTNode.Nodes.Count - 1; j >= 0; j--)
                {
                    subTNode2 = subTNode.Nodes[j];
                    if (subTNode2.Text == parts[i])
                    {
                        subTNode2.Expand();
                        subTNode = subTNode2;
                        break;
                    }
                }
            }
            treeView.SelectedNode = subTNode;
        }

        private void contextMenuStrip_tree_Opening(object sender, CancelEventArgs e)
        {
            if (_treeNode_MouseRightClicked == null && treeView.SelectedNode == null)
            {
                e.Cancel = true;
            }
            else if (_treeNode_MouseRightClicked != null)
            {
                _Set_ContextMenuItem(new TreeNodeFunction(_treeNode_MouseRightClicked));
            }
            else
            {
                // treeView.SelectedNode != null
                _Set_ContextMenuItem(new TreeNodeFunction(treeView.SelectedNode));
            }
            _treeNode_MouseRightClicked = null;
        }
        private void _Set_ContextMenuItem(TreeNodeFunction treeNodeFunction)
        {
            //if (treeNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_VIEWHISTORY)
            //{
            //    toolStripMenuItem_gotoHistory.Visible = true;
            //    toolStripMenuItem_clearHistory.Visible = true;
            //    toolStripMenuItem_lockHistoryItem.Visible = true;
            //    toolStripMenuItem_unlockHistoryItem.Visible = true;
            //    toolStripMenuItem_clearSubHistory.Visible = true;

            //    toolStripMenuItem_gotoHistory.Enabled = false;
            //    toolStripMenuItem_clearHistory.Enabled = true;
            //    toolStripMenuItem_lockHistoryItem.Enabled = false;
            //    toolStripMenuItem_unlockHistoryItem.Enabled = false;
            //    toolStripMenuItem_clearSubHistory.Enabled = false;

            //    toolStripSeparator_bookLib.Visible = false;
            //    toolStripMenuItem_addBookLib.Visible = false;
            //    toolStripMenuItem_delBookLib.Visible = false;
            //    toolStripMenuItem_addBookNode.Visible = false;
            //    toolStripMenuItem_delBookNode.Visible = false;

            //    toolStripSeparator_con.Visible = false;
            //    toolStripMenuItem_crtConnection.Visible = false;
            //    toolStripMenuItem_edtConnection.Visible = false;
            //    toolStripMenuItem_delConnection.Visible = false;
            //}
            //else if (treeNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_VIEWHISTORY_ITEM)
            //{
            //    toolStripMenuItem_gotoHistory.Visible = true;
            //    toolStripMenuItem_clearHistory.Visible = true;
            //    toolStripMenuItem_lockHistoryItem.Visible = true;
            //    toolStripMenuItem_unlockHistoryItem.Visible = true;
            //    toolStripMenuItem_clearSubHistory.Visible = true;

            //    toolStripMenuItem_gotoHistory.Enabled = true;
            //    toolStripMenuItem_clearHistory.Enabled = false;
            //    toolStripMenuItem_lockHistoryItem.Enabled = true;
            //    toolStripMenuItem_unlockHistoryItem.Enabled = true;
            //    toolStripMenuItem_clearSubHistory.Enabled = true;

            //    toolStripSeparator_bookLib.Visible = false;
            //    toolStripMenuItem_addBookLib.Visible = false;
            //    toolStripMenuItem_delBookLib.Visible = false;
            //    toolStripMenuItem_addBookNode.Visible = false;
            //    toolStripMenuItem_delBookNode.Visible = false;

            //    toolStripSeparator_con.Visible = false;
            //    toolStripMenuItem_crtConnection.Visible = false;
            //    toolStripMenuItem_edtConnection.Visible = false;
            //    toolStripMenuItem_delConnection.Visible = false;
            //}
            if (treeNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_VIEWHISTORY)
            {
                toolStripMenuItem_addLocalBookNode.Visible = false;
                toolStripMenuItem_delBookLib.Visible = false;
                toolStripMenuItem_editLocalBookNode.Visible = false;

                toolStripMenuItem_addLocalBookNode.Enabled = false;
                toolStripMenuItem_delBookLib.Enabled = false;
                toolStripMenuItem_editLocalBookNode.Enabled = false;

                toolStripSeparator_con.Visible = false;
                ToolStripMenuItem_explorer.Visible = true;
            }
            else if (treeNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_LOCALLIB)
            {
                toolStripMenuItem_addLocalBookNode.Visible = true;
                toolStripMenuItem_delBookLib.Visible = false;
                toolStripMenuItem_editLocalBookNode.Visible = false;

                toolStripMenuItem_addLocalBookNode.Enabled = true;
                toolStripMenuItem_delBookLib.Enabled = false;
                toolStripMenuItem_editLocalBookNode.Enabled = false;

                toolStripSeparator_con.Visible = false;
                ToolStripMenuItem_explorer.Visible = true;
            }
            else if (treeNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_LOCALROOM)
            {
                toolStripMenuItem_addLocalBookNode.Visible = true;
                toolStripMenuItem_delBookLib.Visible = true;
                toolStripMenuItem_editLocalBookNode.Visible = true;

                toolStripMenuItem_addLocalBookNode.Enabled = true;
                toolStripMenuItem_delBookLib.Enabled = true;
                toolStripMenuItem_editLocalBookNode.Enabled = true;

                toolStripSeparator_con.Visible = false;
                ToolStripMenuItem_explorer.Visible = true;
            }
            else if (treeNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_LOCALBOOKSET
                || treeNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_LOCALBOOK
                )
            {
                toolStripMenuItem_addLocalBookNode.Visible = true;
                toolStripMenuItem_delBookLib.Visible = true;
                toolStripMenuItem_editLocalBookNode.Visible = true;

                toolStripMenuItem_addLocalBookNode.Enabled = true;
                toolStripMenuItem_delBookLib.Enabled = true;
                toolStripMenuItem_editLocalBookNode.Enabled = true;

                toolStripSeparator_con.Visible = false;
                ToolStripMenuItem_explorer.Visible = true;
            }
            //else if (treeNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_ONLINELIB)
            //{
            //    toolStripMenuItem_gotoHistory.Visible = false;
            //    toolStripMenuItem_clearHistory.Visible = false;
            //    toolStripMenuItem_lockHistoryItem.Visible = false;
            //    toolStripMenuItem_unlockHistoryItem.Visible = false;
            //    toolStripMenuItem_clearSubHistory.Visible = false;

            //    toolStripSeparator_bookLib.Visible = false;
            //    toolStripMenuItem_addBookLib.Visible = false;
            //    toolStripMenuItem_delBookLib.Visible = false;
            //    toolStripMenuItem_addBookNode.Visible = false;
            //    toolStripMenuItem_delBookNode.Visible = false;

            //    toolStripSeparator_con.Visible = false;
            //    toolStripMenuItem_crtConnection.Visible = true;
            //    toolStripMenuItem_edtConnection.Visible = true;
            //    toolStripMenuItem_delConnection.Visible = true;

            //    toolStripSeparator_con.Enabled = true;
            //    toolStripMenuItem_crtConnection.Enabled = true;
            //    toolStripMenuItem_edtConnection.Enabled = false;
            //    toolStripMenuItem_delConnection.Enabled = false;
            //}
            //else if (treeNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_ONLINEMACHINE)
            //{
            //    toolStripMenuItem_gotoHistory.Visible = false;
            //    toolStripMenuItem_clearHistory.Visible = false;
            //    toolStripMenuItem_lockHistoryItem.Visible = false;
            //    toolStripMenuItem_unlockHistoryItem.Visible = false;
            //    toolStripMenuItem_clearSubHistory.Visible = false;

            //    toolStripSeparator_bookLib.Visible = false;
            //    toolStripMenuItem_addBookLib.Visible = false;
            //    toolStripMenuItem_delBookLib.Visible = false;
            //    toolStripMenuItem_addBookNode.Visible = false;
            //    toolStripMenuItem_delBookNode.Visible = false;

            //    toolStripSeparator_con.Visible = false;
            //    toolStripMenuItem_crtConnection.Visible = true;
            //    toolStripMenuItem_edtConnection.Visible = true;
            //    toolStripMenuItem_delConnection.Visible = true;

            //    toolStripSeparator_con.Enabled = false;
            //    toolStripMenuItem_crtConnection.Enabled = false;
            //    toolStripMenuItem_edtConnection.Enabled = true;
            //    toolStripMenuItem_delConnection.Enabled = true;
            //}
            //else if (treeNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_ONLINEROOM
            //    || treeNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_ONLINEBOOKSET
            //    || treeNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_ONLINEBOOK
            //    )
            //{
            //    toolStripMenuItem_gotoHistory.Visible = false;
            //    toolStripMenuItem_clearHistory.Visible = false;
            //    toolStripMenuItem_lockHistoryItem.Visible = false;
            //    toolStripMenuItem_unlockHistoryItem.Visible = false;
            //    toolStripMenuItem_clearSubHistory.Visible = false;

            //    toolStripSeparator_bookLib.Visible = false;
            //    toolStripMenuItem_addBookLib.Visible = false;
            //    toolStripMenuItem_delBookLib.Visible = false;
            //    toolStripMenuItem_addBookNode.Visible = false;
            //    toolStripMenuItem_delBookNode.Visible = false;

            //    toolStripSeparator_con.Visible = false;
            //    toolStripMenuItem_crtConnection.Visible = true;
            //    toolStripMenuItem_edtConnection.Visible = true;
            //    toolStripMenuItem_delConnection.Visible = true;

            //    toolStripSeparator_con.Enabled = true;
            //    toolStripMenuItem_crtConnection.Enabled = false;
            //    toolStripMenuItem_edtConnection.Enabled = false;
            //    toolStripMenuItem_delConnection.Enabled = true;
            //}
        }

        private TreeNode _treeNode_MouseRightClicked;
        private void treeView_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                _treeNode_MouseRightClicked = this.treeView.GetNodeAt(e.X, e.Y);
                treeView.SelectedNode = _treeNode_MouseRightClicked;
                TreeNodeFunction iNodeFunction = new TreeNodeFunction(_treeNode_MouseRightClicked);
                if (iNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_VIEWHISTORY_ITEM)
                {
                    return;
                }
                _treeNode_MouseRightClicked.ContextMenuStrip = contextMenuStrip_tree;
            }
        }

        public event EventHandler<TreeViewNodeSelectedEventArgs> TreeViewNodeSelected;
        public class TreeViewNodeSelectedEventArgs : EventArgs
        {
            public TreeViewNodeSelectedEventArgs(Historian.ItemType type, string fullName)
            {
                selectItem = new Historian.Item(type, fullName);
            }
            public Historian.Item selectItem;
        }




        #region toolStripMenu: History

        public event EventHandler Call_GotoHistory;
        public event EventHandler Call_ClearHistory;
        public event EventHandler Call_LockHistoryItem;
        public event EventHandler Call_UnLockHistoryItem;
        public event EventHandler Call_ClearSubHistory;
        private void toolStripMenuItem_gotoHistory_Click(object sender, EventArgs e)
        {
            if (Call_GotoHistory != null) Call_GotoHistory(sender, e);
        }
        private void toolStripMenuItem_clearHistory_Click(object sender, EventArgs e)
        {
            if (Call_ClearHistory != null) Call_ClearHistory(sender, e);
        }
        private void toolStripMenuItem_lockHistoryItem_Click(object sender, EventArgs e)
        {
            if (Call_LockHistoryItem != null) Call_LockHistoryItem(sender, e);
        }
        private void toolStripMenuItem_unlockHistoryItem_Click(object sender, EventArgs e)
        {
            if (Call_UnLockHistoryItem != null) Call_UnLockHistoryItem(sender, e);
        }
        private void toolStripMenuItem_clearSubHistory_Click(object sender, EventArgs e)
        {
            if (Call_ClearSubHistory != null) Call_ClearSubHistory(sender, e);
        }

        #endregion


        #region toolStripMenu: BookNode

        private Form_AddLocalBookNode formAddBookNode;
        public event EventHandler Call_DeleteBookNode;
        private void toolStripMenuItem_addLocalBookNode_Click(object sender, EventArgs e)
        {
            if (formAddBookNode == null || formAddBookNode.IsDisposed)
            {
                formAddBookNode = new Form_AddLocalBookNode();
            }
            if (formAddBookNode.ShowDialog(this) == DialogResult.OK)
            {
                string selectedLocalDocNodePath = treeView.SelectedNode.FullPath;
                IOSystem.Local.DocNode targetLDNode;
                string phyFullNameForWinWord;
                if (selectedLocalDocNodePath.Contains("\\") == false)
                {
                    targetLDNode = _ioManager.Create_localDocNode(formAddBookNode.newLocalDocNodeName);
                    phyFullNameForWinWord = targetLDNode.physicalDocFullName;
                    _ReLoad_localLib();
                }
                else
                {
                    selectedLocalDocNodePath = selectedLocalDocNodePath.Substring(selectedLocalDocNodePath.IndexOf('\\') + 1);
                    targetLDNode = _ioManager.Get_DocNode(selectedLocalDocNodePath, true);
                    phyFullNameForWinWord = targetLDNode.Add_SubNode(formAddBookNode.newLocalDocNodeName).physicalDocFullName;
                    targetLDNode.ReLoad_SubNodes();
                    _ReLoad_localBookNode(treeView.SelectedNode, targetLDNode.subNodes);
                }
                if (formAddBookNode.isUsingWordEdit)
                {
                    Process.Start("winword.exe", "\"" + phyFullNameForWinWord + "\"");
                }
            }
        }
        private void toolStripMenuItem_delLocalBookNode_Click(object sender, EventArgs e)
        {
            if (Call_DeleteBookNode != null)
            {
                Call_DeleteBookNode(sender, e);
            }
            string nodePath = treeView.SelectedNode.FullPath;
            nodePath = nodePath.Substring(nodePath.IndexOf("\\") + 1);
            IOSystem.Local.DocNode tarLDNode = _ioManager.Get_DocNode(nodePath, true);
            if (tarLDNode.parent == null)
            {
                _ioManager.Delete_localDocNode(tarLDNode.name);
            }
            else
            {
                tarLDNode.parent.Delete_SubNode(tarLDNode.name);
            }
            treeView.SelectedNode = treeView.SelectedNode.Parent;
            if (treeView.SelectedNode.IsExpanded)
            {
                treeView.SelectedNode.Collapse();
            }
            treeView.SelectedNode.Nodes.Add("_blank");
            treeView.SelectedNode.Expand();
        }
        private void toolStripMenuItem_editLocalBookNode_Click(object sender, EventArgs e)
        {
            string selectedLocalDocNodePath = treeView.SelectedNode.FullPath;
            if (selectedLocalDocNodePath.Contains("\\"))
            {
                selectedLocalDocNodePath = selectedLocalDocNodePath.Substring(selectedLocalDocNodePath.IndexOf("\\") + 1);
                Process.Start("winword.exe", "\"" + _ioManager.Get_DocNode(selectedLocalDocNodePath, true).physicalDocFullName + "\"");
            }
        }

        #endregion

        #region toolStripMenu: Connection

        public event EventHandler Call_CreateConnection;
        public event EventHandler Call_EditConnection;
        public event EventHandler Call_DeleteConnection;
        private void toolStripMenuItem_crtConnection_Click(object sender, EventArgs e)
        {
            if (Call_CreateConnection != null) Call_CreateConnection(sender, e);
        }
        private void toolStripMenuItem_edtConnection_Click(object sender, EventArgs e)
        {
            if (Call_EditConnection != null) Call_EditConnection(sender, e);
        }
        private void toolStripMenuItem_delConnection_Click(object sender, EventArgs e)
        {
            if (Call_DeleteConnection != null) Call_DeleteConnection(sender, e);
        }

        #endregion



        #region toolStripMenu: Explorer
        public event EventHandler Call_Explorer;
        private void ToolStripMenuItem_explorer_Click(object sender, EventArgs e)
        {
            if (Call_Explorer != null) Call_Explorer(sender, e);
            string nodePath = treeView.SelectedNode.FullPath;
            string path;
            if (nodePath.Contains("\\") == false)
            {
                path = Application.StartupPath + "\\" + IOSystem.Local.Manager.LOCAL_BOOK_LIB_STOR_DIR_NAME;
            }
            else
            {
                nodePath = nodePath.Substring(nodePath.IndexOf("\\") + 1);
                path = _ioManager.Get_DocNode(nodePath, true).physicalPath;
            }
            Process.Start("explorer.exe", "\"" + path + "\"");
        }

        #endregion

        public class Historian
        {
            public static string HisFileName = "ViewHistory.txt";
            public static int HisMaxItemsCount = 10;
            public class Item
            {
                public Item()
                {
                }
                public Item(ItemType type, string fullName)
                {
                    this.type = type;
                    this.fullName = fullName;
                }
                public Item(string ioContent)
                {
                    IOContent = ioContent;
                }

                public ItemType type;
                public string fullName;
                public string IOContent
                {
                    get
                    {
                        return type.ToString() + ":" + fullName;
                    }
                    set
                    {
                        string[] parts = value.Split(new char[] { ':' });
                        if (parts[0] == ItemType.Online.ToString())
                        {
                            type = ItemType.Online;
                        }
                        else
                        {
                            type = ItemType.Local;
                        }
                        fullName = parts[1];
                    }
                }
            }
            public enum ItemType
            {
                Local,
                Online,
            }
            private List<Item> _itemList;
            public List<Item> itemList
            {
                get
                {
                    return _itemList;
                }
            }

            public Historian()
            {
                _itemList = new List<Item>();
                Load();
            }
            private void Load()
            {
                _itemList.Clear();
                string hisFileFullName = AppDomain.CurrentDomain.BaseDirectory + "\\" + HisFileName;
                if (File.Exists(hisFileFullName) == false)
                {
                    File.WriteAllText(hisFileFullName, "");
                }
                string[] lines = File.ReadAllLines(hisFileFullName);
                for (int i = 0; i < lines.Length; i++)
                {
                    _itemList.Add(new Item(lines[i]));
                }
                _curHisItemIdx = _itemList.Count - 1;
            }
            private void Save()
            {
                string result = "";
                for (int i = 0; i < _itemList.Count; i++)
                {
                    if (result.Length > 0) result += "\r\n";
                    result += _itemList[i].IOContent;
                }
                File.WriteAllText(AppDomain.CurrentDomain.BaseDirectory + "\\" + HisFileName, result);
            }

            private int _curHisItemIdx;

            public bool CanGoBack
            {
                get
                {
                    return _curHisItemIdx > 0;
                }
            }
            public bool CanGoForward
            {
                get
                {
                    return _curHisItemIdx < (_itemList.Count - 1);
                }
            }
            public Item GoBack()
            {
                if (CanGoBack)
                {
                    _curHisItemIdx--;
                    return _itemList[_curHisItemIdx];
                }
                return null;
            }
            public Item ReadLast()
            {
                if (_itemList.Count > 0)
                {
                    return _itemList[_itemList.Count - 1];
                }
                else return null;
            }
            public Item GoForward()
            {
                if (CanGoBack)
                {
                    _curHisItemIdx++;
                    return _itemList[_curHisItemIdx];
                }
                return null;
            }

            public void SetHistory(ItemType type, string fullName)
            {
                bool itemFound = false;
                Item item;
                for (int i = _itemList.Count - 1; i >= 0; i--)
                {
                    item = _itemList[i];
                    if (item.type == type && item.fullName == fullName)
                    {
                        itemFound = true;
                        _itemList.RemoveAt(i);
                        _itemList.Add(item);
                        break;
                    }
                }
                if (itemFound == false)
                {
                    _itemList.Add(new Item(type, fullName));
                    while (_itemList.Count > HisMaxItemsCount)
                    {
                        _itemList.RemoveAt(0);
                    }
                }
                Save();
                _curHisItemIdx = _itemList.Count - 1;
            }
        }


        private void _Set_toolStrip(TreeNodeFunction treeNodeFunction)
        {
            toolStripButton_goBack.Enabled = _historian.CanGoBack;
            toolStripButton_goForward.Enabled = _historian.CanGoForward;
            if (treeNodeFunction == null)
            {
                toolStripButton_goUp.Enabled = false;
                toolStripButton_prevOne.Enabled = false;
                toolStripButton_nextOne.Enabled = false;
            }
            else if (treeNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_LOCALLIB)
            {
                toolStripButton_goUp.Enabled = false;
                toolStripButton_prevOne.Enabled = false;
                toolStripButton_nextOne.Enabled = true;
            }
            else if (treeNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_LOCALROOM
                || treeNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_LOCALBOOKSET
                || treeNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_LOCALBOOK)
            {
                toolStripButton_goUp.Enabled = true;
                toolStripButton_prevOne.Enabled = true;
                if (treeNodeFunction.functionType.myFunctionType == TreeNodeFunction.FunctionType.NODE_NAME_LOCALBOOK)
                {
                    bool isLastTNode = true;
                    TreeNode curTNode = treeView.SelectedNode;
                    TreeNode parentTNode = curTNode.Parent;
                    while (parentTNode != null)
                    {
                        if (curTNode.Index == parentTNode.Nodes.Count - 1)
                        {
                            curTNode = parentTNode;
                            parentTNode = curTNode.Parent;
                        }
                        else
                        {
                            isLastTNode = false;
                            break;
                        }
                    }

                    toolStripButton_nextOne.Enabled = !isLastTNode;
                }
                else
                {
                    toolStripButton_nextOne.Enabled = true;
                }
            }
        }

        private void toolStripButton_goUp_Click(object sender, EventArgs e)
        {
            treeView.SelectedNode = treeView.SelectedNode.Parent;
        }

        private bool _isReadingHistory = false;
        private void toolStripButton_goBack_Click(object sender, EventArgs e)
        {
            _isReadingHistory = true;
            SelectLocalLibItem(_historian.GoBack().fullName);
        }
        private void toolStripButton_goForward_Click(object sender, EventArgs e)
        {
            _isReadingHistory = true;
            SelectLocalLibItem(_historian.GoForward().fullName);
        }

        private void toolStripButton_prevOne_Click(object sender, EventArgs e)
        {
            if (treeView.SelectedNode.Index > 0)
            {
                TreeNode foundPrevOne = treeView.SelectedNode.PrevNode;
                if (foundPrevOne.Nodes.Count > 0)
                {
                    while (foundPrevOne.Nodes.Count > 0)
                    {
                        foundPrevOne.Expand();
                        foundPrevOne = foundPrevOne.Nodes[foundPrevOne.Nodes.Count - 1];
                    }
                    treeView.SelectedNode = foundPrevOne;
                }
                else
                {
                    treeView.SelectedNode = treeView.SelectedNode.PrevNode;
                }
            }
            else treeView.SelectedNode = treeView.SelectedNode.Parent;
        }
        private void toolStripButton_nextOne_Click(object sender, EventArgs e)
        {
            SelectNextOne();
        }
        public void SelectNextOne()
        {
            if (treeView.SelectedNode.Nodes.Count > 0)
            {
                if (treeView.SelectedNode.IsExpanded == false)
                {
                    treeView.SelectedNode.Expand();
                }
                treeView.SelectedNode = treeView.SelectedNode.Nodes[0];
            }
            else if (treeView.SelectedNode.Index == treeView.SelectedNode.Parent.Nodes.Count - 1)
            {
                treeView.SelectedNode = treeView.SelectedNode.Parent.NextNode;
            }
            else treeView.SelectedNode = treeView.SelectedNode.NextNode;
        }

    }
}
