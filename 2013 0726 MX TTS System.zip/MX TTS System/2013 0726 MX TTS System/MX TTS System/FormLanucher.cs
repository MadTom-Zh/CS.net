﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MX_TTS_System
{
    public partial class FormLanucher : Form
    {
        public FormLanucher()
        {
            InitializeComponent();

            imageList.Images.Add(Image.FromFile("LanucherPics\\mic.bmp"));
            imageList.Images.Add(Image.FromFile("LanucherPics\\mic eyes 1.bmp"));
            imageList.Images.Add(Image.FromFile("LanucherPics\\mic eyes 2.bmp"));
            imageList.Images.Add(Image.FromFile("LanucherPics\\mic eyes 3.bmp"));
        }

        private void FormLanucher_Load(object sender, EventArgs e)
        {
            this.Text = "MX朗读 2013 0726";
        }

        private void button_MXTTS_Click(object sender, EventArgs e)
        {
            FormMain mainWin = new FormMain();
            mainWin.FormClosed += mainWin_FormClosed;
            mainWin.Show();
            timer.Stop();
            this.Hide();
        }
        void mainWin_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
            //return;

            //GC.Collect();
            //timer.Start();
            //this.Show();
        }

        FormCopyToRead ctrWin;
        private void button_CopyToRead_Click(object sender, EventArgs e)
        {
            ctrWin = new FormCopyToRead();
            ctrWin.FormClosed += ctrWin_FormClosed;
            ctrWin.Show();
            this.Hide();
            timer.Stop();
        }
        void ctrWin_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
            //return;

            //GC.Collect();
            //timer.Start();
            //this.Show();
        }

        private int micEyesSignIdx;
        private int micEyes_WaitCounts = 4;
        private Random ran = new Random((int)DateTime.Now.ToFileTime());
        private void timer_Tick(object sender, EventArgs e)
        {
            if (micEyes_WaitCounts <= 0)
            {
                micEyes_WaitCounts = 1 + ran.Next(10);
                micEyesSignIdx = ran.Next(4);
                pictureBox_Mic.Refresh();
            }
            micEyes_WaitCounts--;
        }

        private void pictureBox_Mic_Paint(object sender, PaintEventArgs e)
        {
            imageList.Draw(e.Graphics, 0, 0, 0);
            if (micEyesSignIdx > 0)
            {
                imageList.Draw(e.Graphics, 0, 0, micEyesSignIdx);
            }
        }
    }
}
