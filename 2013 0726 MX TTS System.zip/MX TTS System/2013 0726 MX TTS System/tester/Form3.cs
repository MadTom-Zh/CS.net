﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using T2S_HCore.UI;

namespace tester
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            T2S_HCore.UI.Form_BroadCaster form = new Form_BroadCaster();
            form.ShowDialog();
        }
    }
}
