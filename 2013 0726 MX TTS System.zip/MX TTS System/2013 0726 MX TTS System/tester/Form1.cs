﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace tester
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //wordControl1.LoadDocument(@"C:\Users\LongTom2014\Desktop\C#使用WMP播放音频.docx");
        }

        T2S_HCore.Classes.WMPlayer _wmPlayer;
        private void button2_Click(object sender, EventArgs e)
        {
            _wmPlayer = new T2S_HCore.Classes.WMPlayer();
            _wmPlayer.URI = @"E:\!.休闲\1.music\陈珊妮-青春骊歌.mp3";
            _wmPlayer.Play();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            _wmPlayer.playingSpeed = -1.0;
        }
    }
}
