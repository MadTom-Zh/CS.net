﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace tester
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //wordControl1.LoadDocument(@"E:\0.tmp\1.htm");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //wordControl1.SaveFHTMLDocument();
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            //wordControl1.CloseControl();
        }
    }
}
