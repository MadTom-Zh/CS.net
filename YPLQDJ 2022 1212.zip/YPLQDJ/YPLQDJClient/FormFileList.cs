﻿using MadTomDev.CommonClasses;
using MadTomDev.UIs;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadTomDev.App.YPLQDJ
{
    public partial class FormFileList : Form
    {
        public FormFileList()
        {
            InitializeComponent();
        }

        public ClientCore core;
        private IconHelper iconHelper;
        private void FormFileList_Load(object sender, EventArgs e)
        {
            iconHelper = IconHelper.GetInstance();
        }
        private void FormFileList_FormClosing(object sender, FormClosingEventArgs e)
        { e.Cancel = true; this.Hide(); }

        public DataTempletes.SupplyList.Item Supply;
        public DataTempletes.SupplyList.FileTypes FileType;
        public long FileID;
        public void Init(DataTempletes.SupplyList.Item supply, DataTempletes.SupplyList.FileTypes fileType)
        {
            this.Supply = supply;
            this.FileType = fileType;
            FileID = -1;
            switch (fileType)
            {
                case DataTempletes.SupplyList.FileTypes.Contract:
                    FileID = supply.ContractID; break;
                case DataTempletes.SupplyList.FileTypes.Delivery:
                    FileID = supply.ProofDeliveryID; break;
                case DataTempletes.SupplyList.FileTypes.Acceptance:
                    FileID = supply.ProofAcceptanceID; break;
                case DataTempletes.SupplyList.FileTypes.SignOff:
                    FileID = supply.ProofSignOffID; break;
            }
            StringBuilder infoBdr = new StringBuilder();
            infoBdr.Append($"项目名称：{supply.ProjectName + Environment.NewLine}");
            infoBdr.Append($"项目定义：{supply.Definition + Environment.NewLine}");
            infoBdr.Append($"采购内容：{supply.Description + Environment.NewLine}");
            infoBdr.Append($"数量：{supply.Quantity}");
            infoBdr.Append($"  供应商：{supply.Supplier}");
            infoBdr.Append($"  交货期：{supply.DeliveryDate.ToString("yyyy-MM-dd") + Environment.NewLine}");
            infoBdr.Append($"记录创建人：{supply.Creator}");
            SupplyInfoText = infoBdr.ToString();
        }
        public void Init(string info , DataTempletes.SupplyList.FileTypes fileType)
        {
            FileType = fileType;
            StringBuilder infoBdr = new StringBuilder();
            infoBdr.Append($"当前文件集：");
            switch (fileType)
            {
                default:
                    infoBdr.Append($"未知"); break;
                case DataTempletes.SupplyList.FileTypes.None:
                    infoBdr.Append($"未选择"); break;
                case DataTempletes.SupplyList.FileTypes.Acceptance:
                    infoBdr.Append($"验收凭证"); break;
                case DataTempletes.SupplyList.FileTypes.Contract:
                    infoBdr.Append($"合同"); break;
                case DataTempletes.SupplyList.FileTypes.Delivery:
                    infoBdr.Append($"交货凭证"); break;
                case DataTempletes.SupplyList.FileTypes.ExcelTemplate:
                    infoBdr.Append($"领用模板"); break;
                case DataTempletes.SupplyList.FileTypes.SignOff:
                    infoBdr.Append($"领用凭证"); break;
            }
            infoBdr.Append(Environment.NewLine);
            infoBdr.Append(info);
            SupplyInfoText = infoBdr.ToString();
        }
        public string SupplyInfoText
        {
            set => textBox_supplyInfo.Text = value;
            get => textBox_supplyInfo.Text;
        }

        #region show info and error
        private delegate void ShowInfoNLogDelegate(string info, bool showPB);
        public void ShowInfoNLog(string info, bool showPB = false)
        {
            if (InvokeRequired)
            {
                ShowInfoNLogDelegate callback
                    = new ShowInfoNLogDelegate(ShowInfoNLog);
                this.Invoke(callback, info, showPB);
            }
            else
            {
                core.logger.Log(info);
                toolStripStatusLabel_info.Text = info;
                toolStripProgressBar_info.Visible = showPB;
                listView_files.Enabled = !showPB;
                Update();
            }
        }
        private delegate void ShowErrorNLogDelegate(Exception err, string info);
        public void ShowErrorNLog(Exception err, string info = null)
        {
            if (InvokeRequired)
            {
                ShowErrorNLogDelegate callback
                    = new ShowErrorNLogDelegate(ShowErrorNLog);
                this.Invoke(callback, err, info);
            }
            else
            {
                if (!string.IsNullOrEmpty(info))
                {
                    core.logger.Log(info);
                    toolStripStatusLabel_info.Text = info + " " + err.Message;
                }
                else
                {
                    toolStripStatusLabel_info.Text = err.Message;
                }
                core.logger.Log(err);
                toolStripProgressBar_info.Visible = false;
                Update();
            }
        }

        #endregion

        #region load file list
        private delegate void SetFilesDelegate(long? fileID, List<DataTempletes.FileInfo> fileNameList);
        internal void SetFiles(long? fileID, List<DataTempletes.FileInfo> fileNameList)
        {
            if (InvokeRequired)
            {
                SetFilesDelegate callback = new SetFilesDelegate(SetFiles);
                Invoke(callback, fileID, fileNameList);
            }
            else
            {
                // fileName  fileSize  ModifyTime  uploader  uploadTime
                listView_files.Items.Clear();
                if (fileID == null || fileID != FileID)
                {
                    ShowInfoNLog("反馈的文件ID和请求的不一致");
                    return;
                }
                if (fileNameList == null || fileNameList.Count == 0)
                {
                    ShowInfoNLog("没有文件");
                    return;
                }

                foreach (DataTempletes.FileInfo fi in fileNameList)
                    listView_files.Items.Add(GenerateListViewItem_withImage(fi));

                ShowInfoNLog("已载入文件清单");
            }
        }
        private ListViewItem GenerateListViewItem_withImage(DataTempletes.FileInfo fileInfo)
        {
            string suffix;
            ListViewItem result;
            suffix = Path.GetExtension(fileInfo.Name).ToLower();
            if (!imageList.Images.ContainsKey(suffix))
            {
                imageList.Images.Add(suffix, core.GetIcon(suffix));
            }
            result = new ListViewItem(new string[]
            {
                    fileInfo.Name,
                    SimpleStringHelper.UnitsOfMeasure.GetShortString(fileInfo.Size, "B", 1024, 2, true),
                    fileInfo.ModifyTime.ToString(),
                    fileInfo.Uploader,
                    fileInfo.UploadTime.ToString()
            })
            { Tag = fileInfo, ImageKey = suffix };
            return result;
        }



        #endregion

        private void listView_files_KeyDown(object sender, KeyEventArgs e)
        {
            if (!listView_files.Enabled)
                return;
            if (e.Control)
            {
                if (e.KeyCode == Keys.C)
                {
                    if (!CheckCanDownload())
                        return; 

                    if (listView_files.SelectedItems.Count == 1)
                    {
                        DownloadFile_fromCB(this,
                            (DataTempletes.FileInfo)listView_files.SelectedItems[0].Tag,
                            false, null);
                    }
                }
                else if (e.KeyCode == Keys.V)
                {
                    if (!CheckCanUpload())
                        return;

                    string[] files = (string[])Clipboard.GetDataObject().GetData(DataFormats.FileDrop);
                    if (files != null && files.Length == 1)
                    {
                        fileToUpload = new FileInfo(files[0]);
                        core.UploadFile_async(this, fileToUpload.FullName, FileID);
                    }
                }
            }
            else if (e.KeyCode == Keys.Delete)
            {
                if (!CheckCanDelete())
                    return;

                if (listView_files.SelectedItems.Count == 1
                    && DialogResult.Yes == MessageBox.Show(this,
                        "即将删除选中的文件，要继续吗？",
                        "警告",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Warning,
                        MessageBoxDefaultButton.Button2))
                {
                    ShowInfoNLog("正在删除文件...", true);
                    core.DeleteFile((DataTempletes.FileInfo)listView_files.SelectedItems[0].Tag);
                }
            }
        }


        #region upload file

        private bool CheckCanDelete()
        {
            if (FileType == DataTempletes.SupplyList.FileTypes.Acceptance
                || FileType == DataTempletes.SupplyList.FileTypes.Contract
                || FileType == DataTempletes.SupplyList.FileTypes.Delivery
                || FileType == DataTempletes.SupplyList.FileTypes.SignOff)
            {
                if (!core.LoginUser.Authorities.DeleteFilesSupplies)
                {
                    ShowInfoNLog("您无权删除凭证");
                    return false;
                }
            }
            else
            {
                if (!core.LoginUser.Authorities.ReUploadSignOffTempleteXlsx)
                {
                    ShowInfoNLog("您无权删除模板");
                    return false;
                }
            }
            return true;
        }
        private bool CheckCanUpload()
        {
            if (FileType == DataTempletes.SupplyList.FileTypes.Acceptance
                || FileType == DataTempletes.SupplyList.FileTypes.Contract
                || FileType == DataTempletes.SupplyList.FileTypes.Delivery
                || FileType == DataTempletes.SupplyList.FileTypes.SignOff)
            {
                if (!core.LoginUser.Authorities.UploadFilesSupplies)
                {
                    ShowInfoNLog("您无权上传凭证");
                    return false;
                }
            }
            else
            {
                if (!core.LoginUser.Authorities.ReUploadSignOffTempleteXlsx)
                {
                    ShowInfoNLog("您无权上传模板");
                    return false;
                }
            }
            return true;
        }

        private FileInfo fileToUpload;
        private void listView_files_DragEnter(object sender, DragEventArgs e)
        {
            if (!listView_files.Enabled)
            {
                e.Effect = DragDropEffects.None;
                return;
            }

            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
            if (files == null || files.Length != 1)
            {
                e.Effect = DragDropEffects.None;
                return;
            }

            e.Effect = DragDropEffects.Copy;
        }

        private void listView_files_DragDrop(object sender, DragEventArgs e)
        {
            if (!CheckCanUpload())
                return;

            if (e.Effect == DragDropEffects.Copy)
            {
                fileToUpload
                    = new FileInfo(((string[])e.Data.GetData(DataFormats.FileDrop))[0]);
                core.UploadFile_async(this,
                    fileToUpload.FullName,
                    FileID);
            }
        }

        #endregion

        #region download file, open?, and delete

        private bool CheckCanDownload()
        {
            if (FileType == DataTempletes.SupplyList.FileTypes.Acceptance
                || FileType == DataTempletes.SupplyList.FileTypes.Contract
                || FileType == DataTempletes.SupplyList.FileTypes.Delivery
                || FileType == DataTempletes.SupplyList.FileTypes.SignOff)
            {
                if (!core.LoginUser.Authorities.DownloadFilesSupplies)
                {
                    ShowInfoNLog("您无权下载凭证");
                    return false;
                }
            }
            else
            {
                if (!core.LoginUser.Authorities.DownloadFileTemplateXlsx)
                {
                    ShowInfoNLog("您无权下载模板");
                    return false;
                }
            }
            return true;
        }

        private bool isNotPressing = true;
        private Point pressingPoint;
        private void listView_files_MouseDown(object sender, MouseEventArgs e)
        {
            pressingPoint = e.Location;
            isNotPressing = false;
        }

        private void listView_files_MouseUp(object sender, MouseEventArgs e)
        { isNotPressing = true; }

        private void listView_files_MouseMove(object sender, MouseEventArgs e)
        {
            if (isNotPressing)
                return;

            if (!CheckCanDownload())
                return;

            if (listView_files.SelectedItems.Count != 1)
                return;

            if (System.Math.Abs(e.Location.X - pressingPoint.X) > 3
                || System.Math.Abs(e.Location.Y - pressingPoint.Y) > 3)
            {
                isNotPressing = true;
                DownloadFile_fromCB(this,
                    (DataTempletes.FileInfo)listView_files.SelectedItems[0].Tag,
                    true, (Control)sender);
            }
        }
        public void DownloadFile_fromCB(FormFileList receiver, DataTempletes.FileInfo fileInfo, bool dragOrCopy, Control dragingCtrl)
        {
            VirtualFilesOverClipboard vfoc = new VirtualFilesOverClipboard(
                (sa) => this.BeginInvoke((Action)(() =>
                {
                    ShowInfoNLog("开始传输文件数据", true);
                })),
                (se) => this.BeginInvoke((Action)(() =>
                {
                    ShowInfoNLog("完成文件传输", false);
                })));
            List<VirtualFilesOverClipboard.FileDescriptor>
                fileList = new List<VirtualFilesOverClipboard.FileDescriptor>();
            fileList.Add(new VirtualFilesOverClipboard.FileDescriptor()
            {
                Name = fileInfo.Name,
                Length = fileInfo.Size,
                ChangeTime = fileInfo.ModifyTime,
                StreamContents = () =>
                {
                    return new ClientCore.StreamOutFromServer(core, fileInfo);
                },
            });
            vfoc.SetData(fileList.ToArray());

            if (dragOrCopy)
            {
                VirtualFilesOverClipboard.DoDragDrop(dragingCtrl, vfoc, System.Windows.DragDropEffects.Copy);
            }
            else
            {
                vfoc.PreferredDropEffect = System.Windows.DragDropEffects.Copy;
                Clipboard.SetDataObject(vfoc);
            }
        }

        private void listView_files_ItemActivate(object sender, EventArgs e)
        {
            core.DownloadFileNOpen(this, (DataTempletes.FileInfo)listView_files.SelectedItems[0].Tag);
        }

        internal delegate void RemoveFileDelegate(long? fileID, long? fileNo);
        internal void RemoveFile(long? fileID, long? fileNo)
        {
            if (InvokeRequired)
            {
                RemoveFileDelegate callback
                    = new RemoveFileDelegate(RemoveFile);
                Invoke(callback, fileID, fileNo);
            }
            else
            {
                if (fileID == null || fileNo == null)
                {
                    ShowInfoNLog("无法删除文件，参数为空");
                    return;
                }

                DataTempletes.FileInfo fi;
                foreach (ListViewItem lvi in listView_files.Items)
                {
                    fi = (DataTempletes.FileInfo)lvi.Tag;
                    if (fi.ID == fileID && fi.No == fileNo)
                    {
                        listView_files.Items.Remove(lvi);
                        ShowInfoNLog("成功删除文件");
                        break;
                    }
                }
            }
        }

        #endregion

    }
}
