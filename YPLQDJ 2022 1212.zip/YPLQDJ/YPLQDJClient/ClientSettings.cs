﻿using MadTomDev.Data;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadTomDev.App.YPLQDJ
{
    public class ClientSettings : SettingsTxt
    {
        private ClientCore core;
        public ClientSettings(ClientCore core)
        {
            this.core = core;
            base.SettingsFileFullName = Path.Combine(
                Application.StartupPath, "Client.cfg"
                );
            ReLoad();
        }

        public bool SelectedServerIPV4orIPV6
        {
            set => base["SelectedServerIPV4orIPV6"] = value.ToString();
            get
            {
                string v = base["SelectedServerIPV4orIPV6"];
                bool result;
                if (bool.TryParse(v, out result))
                    return result;
                base["SelectedServerIPV4orIPV6"] = true.ToString();
                return true;
            }
        }
        public IPAddress ServerIPV4
        {
            set => base["ServerIPV4"] = value.ToString();
            get
            {
                string v = base["ServerIPV4"];
                if (!string.IsNullOrWhiteSpace(v))
                    return IPAddress.Parse(v);
                base["ServerIPV4"] = null;
                return null;
            }
        }
        public IPAddress ServerIPV6
        {
            set => base["ServerIPV6"] = value.ToString();
            get
            {
                string v = base["ServerIPV6"];
                if (!string.IsNullOrWhiteSpace(v))
                    return IPAddress.Parse(v);
                base["ServerIPV6"] = null;
                return null;
            }
        }
        public int? ServerPort
        {
            set => base["ServerPort"] = value.ToString();
            get
            {
                int result;
                if (int.TryParse(base["ServerPort"], out result))
                    return result;
                base["ServerPort"] = null;
                return null;
            }
        }
    }
}
