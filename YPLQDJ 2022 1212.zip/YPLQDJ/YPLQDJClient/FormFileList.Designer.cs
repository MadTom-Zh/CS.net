﻿namespace MadTomDev.App.YPLQDJ
{
    partial class FormFileList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.textBox_supplyInfo = new System.Windows.Forms.TextBox();
            this.listView_files = new System.Windows.Forms.ListView();
            this.columnHeader_fileName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader_fileSize = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader_uploadTime = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader_uploader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader_uploadeTime = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.imageList = new System.Windows.Forms.ImageList(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel_info = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar_info = new System.Windows.Forms.ToolStripProgressBar();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox_supplyInfo
            // 
            this.textBox_supplyInfo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_supplyInfo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_supplyInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox_supplyInfo.Location = new System.Drawing.Point(12, 12);
            this.textBox_supplyInfo.Multiline = true;
            this.textBox_supplyInfo.Name = "textBox_supplyInfo";
            this.textBox_supplyInfo.ReadOnly = true;
            this.textBox_supplyInfo.Size = new System.Drawing.Size(834, 98);
            this.textBox_supplyInfo.TabIndex = 0;
            this.textBox_supplyInfo.Text = "【信息】";
            // 
            // listView_files
            // 
            this.listView_files.AllowDrop = true;
            this.listView_files.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listView_files.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader_fileName,
            this.columnHeader_fileSize,
            this.columnHeader_uploadTime,
            this.columnHeader_uploader,
            this.columnHeader_uploadeTime});
            this.listView_files.FullRowSelect = true;
            this.listView_files.HideSelection = false;
            this.listView_files.LargeImageList = this.imageList;
            this.listView_files.Location = new System.Drawing.Point(12, 116);
            this.listView_files.MultiSelect = false;
            this.listView_files.Name = "listView_files";
            this.listView_files.Size = new System.Drawing.Size(834, 289);
            this.listView_files.SmallImageList = this.imageList;
            this.listView_files.TabIndex = 1;
            this.listView_files.UseCompatibleStateImageBehavior = false;
            this.listView_files.View = System.Windows.Forms.View.Details;
            this.listView_files.ItemActivate += new System.EventHandler(this.listView_files_ItemActivate);
            this.listView_files.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView_files_DragDrop);
            this.listView_files.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView_files_DragEnter);
            this.listView_files.KeyDown += new System.Windows.Forms.KeyEventHandler(this.listView_files_KeyDown);
            this.listView_files.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listView_files_MouseDown);
            this.listView_files.MouseMove += new System.Windows.Forms.MouseEventHandler(this.listView_files_MouseMove);
            this.listView_files.MouseUp += new System.Windows.Forms.MouseEventHandler(this.listView_files_MouseUp);
            // 
            // columnHeader_fileName
            // 
            this.columnHeader_fileName.Text = "文件名";
            this.columnHeader_fileName.Width = 500;
            // 
            // columnHeader_fileSize
            // 
            this.columnHeader_fileSize.Text = "尺寸";
            // 
            // columnHeader_uploadTime
            // 
            this.columnHeader_uploadTime.Text = "文件修改时间";
            this.columnHeader_uploadTime.Width = 120;
            // 
            // columnHeader_uploader
            // 
            this.columnHeader_uploader.Text = "上传人";
            this.columnHeader_uploader.Width = 80;
            // 
            // columnHeader_uploadeTime
            // 
            this.columnHeader_uploadeTime.Text = "上传时间";
            this.columnHeader_uploadeTime.Width = 120;
            // 
            // imageList
            // 
            this.imageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
            this.imageList.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 409);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(665, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "* 使用鼠标拖拽或快捷键Ctrl+C、V来上传、下载文件，一次仅允许一个文件；双击下载到临时目录并打开；选中后按Del删除；";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel_info,
            this.toolStripStatusLabel2,
            this.toolStripProgressBar_info});
            this.statusStrip1.Location = new System.Drawing.Point(0, 429);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(858, 22);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel_info
            // 
            this.toolStripStatusLabel_info.Name = "toolStripStatusLabel_info";
            this.toolStripStatusLabel_info.Size = new System.Drawing.Size(56, 17);
            this.toolStripStatusLabel_info.Text = "loading...";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(685, 17);
            this.toolStripStatusLabel2.Spring = true;
            // 
            // toolStripProgressBar_info
            // 
            this.toolStripProgressBar_info.Name = "toolStripProgressBar_info";
            this.toolStripProgressBar_info.Size = new System.Drawing.Size(100, 16);
            this.toolStripProgressBar_info.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            // 
            // FormFileList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(858, 451);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listView_files);
            this.Controls.Add(this.textBox_supplyInfo);
            this.Name = "FormFileList";
            this.Text = "文件列表";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormFileList_FormClosing);
            this.Load += new System.EventHandler(this.FormFileList_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_supplyInfo;
        private System.Windows.Forms.ListView listView_files;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ColumnHeader columnHeader_fileName;
        private System.Windows.Forms.ColumnHeader columnHeader_uploadTime;
        private System.Windows.Forms.ColumnHeader columnHeader_uploader;
        private System.Windows.Forms.ColumnHeader columnHeader_uploadeTime;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel_info;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar_info;
        private System.Windows.Forms.ColumnHeader columnHeader_fileSize;
        private System.Windows.Forms.ImageList imageList;
    }
}