﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Forms;
using MadTomDev.CommonClasses;
using MadTomDev.UIs.ExDialogs;
using Application = System.Windows.Forms.Application;
using MessageBox = System.Windows.Forms.MessageBox;

namespace MadTomDev.App.YPLQDJ
{
    public partial class FormSupplyList : Form
    {
        public FormSupplyList()
        {
            InitializeComponent();
        }

        public ClientCore core;

        private delegate void SetLoinUserTextDelegate(string userID);
        private void SetLoinUserText(string userID)
        {
            if (InvokeRequired)
            {
                SetLoinUserTextDelegate callback
                    = new SetLoinUserTextDelegate(SetLoinUserText);
                Invoke(callback, userID);
            }
            else
            {
                toolStripStatusLabel_userId.Text = userID;
            }
        }
        public string LoginUserText
        { set => SetLoinUserText(value); }

        private void FormPO_Shown(object sender, EventArgs e)
        {
            Application.ThreadException += (s1, e1) =>
            {
                if (core != null)
                {
                    _ShowNLogError(e1.Exception);
                }
                else
                {
                    MessageBox.Show(
                        this,
                        e1.Exception.ToString(),
                        "错误",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            };

            toolStripStatusLabel_info.Text = "正在初始化……";
            toolStripProgressBar_info.Visible = true;
            Update();


            core = new ClientCore(this);

            //Application.ThreadException += (s1, e1) =>
            //{
            //    core.logger.Log(e1.Exception);
            //    MessageBox.Show(e1.Exception.Message, "程序错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    Close();
            //};

            if ((core.settings.SelectedServerIPV4orIPV6 && core.settings.ServerIPV4 == null)
                || (!core.settings.SelectedServerIPV4orIPV6 && core.settings.ServerIPV6 == null))
            {
                ShowNLogInfo("没有找到服务器信息");
                if (core.ShowDialog_Config() != DialogResult.OK)
                { Close(); return; }
            }

            ShowNLogInfo("正在连接……", true);
            while (!core.ConnectServer())
            {
                ShowNLogInfo("连接失败");
                if (MessageBox.Show(this,
                    "无法连接到服务器，服务器应用可能未运行，或服务地址不正确，"
                        + Environment.NewLine + Environment.NewLine
                        + "是否重新配置连接地址？",
                    "警告", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1)
                    == DialogResult.Yes)
                {
                    ShowNLogInfo("重新配置服务器地址信息");
                    if (core.ShowDialog_Config() != DialogResult.OK)
                    { Close(); return; }
                }
                else
                { Close(); return; }
            }


            if (core.ShowDialog_Login() != DialogResult.OK)
            { Close(); return; }

            button_search_Click(sender, e);
        }

        private void FormPO_FormClosing(object sender, FormClosingEventArgs e)
        {
            ShowNLogInfo("关闭，正在回收资源……", true);
            core.Dispose();
        }


        #region show info and error

        private delegate void _ShowNLogInfoDelegate(string info, bool showProgressBar);
        public void ShowNLogInfo(string info, bool showProgressBar = false)
        {
            if (InvokeRequired)
            {
                _ShowNLogInfoDelegate callback
                    = new _ShowNLogInfoDelegate(ShowNLogInfo);
                this.Invoke(callback, info, showProgressBar);
            }
            else
            {
                core.logger.Log(info);
                toolStripStatusLabel_info.Text = info;
                toolStripProgressBar_info.Visible = showProgressBar;
                EnableCtrls(!showProgressBar);
                this.Cursor = showProgressBar ? Cursors.AppStarting : Cursors.Default;
                Update();
            }
        }
        private void EnableCtrls(bool enable = true)
        {
            button_search.Enabled = enable;
            textBox_quickSearch.Enabled = enable;
            button_save.Enabled = enable;
            button_OCRInput.Enabled = enable;
            bindingNavigator_goPages.Enabled = enable;
        }
        private delegate void _ShowNLogErrorDelegate(Exception err);
        private void _ShowNLogError(Exception err)
        {
            if (InvokeRequired)
            {
                _ShowNLogErrorDelegate callback
                    = new _ShowNLogErrorDelegate(_ShowNLogError);
                this.Invoke(callback, err);
            }
            else
            {
                core.logger.Log(err);
                toolStripStatusLabel_info.Text = err.Message;
                toolStripProgressBar_info.Visible = false;
                Update();
                MessageBoxAlone.Show(err.ToString(), "错误！", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private delegate void _ShowNLogErrorDelegate2(string preInfo, Exception err);
        private void _ShowNLogError(string preInfo, Exception err)
        {
            if (InvokeRequired)
            {
                _ShowNLogErrorDelegate2 callback
                    = new _ShowNLogErrorDelegate2(_ShowNLogError);
                this.Invoke(callback, preInfo, err);
            }
            else
            {
                core.logger.Log(preInfo);
                core.logger.Log(err);
                toolStripStatusLabel_info.Text = preInfo + " " + err.Message;
                toolStripProgressBar_info.Visible = false;
                Update();
                MessageBoxAlone.Show(
                    preInfo + Environment.NewLine + err.ToString(),
                    "错误！", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private delegate void StartDelegate();
        private bool isStarted = false;
        internal void Start()
        {
            if (isStarted)
            {
                isStarted = true;
                return;
            }
            //MessageBox.Show("start");
            if (InvokeRequired)
            {
                StartDelegate callback = new StartDelegate(Start);
                Invoke(callback);
            }
            else
            {
                if (core.LoginUser.Authorities.QuerySupplies)
                {
                    this.Enabled = true;
                    if (core.LoginUser.Authorities.MaintainSupplies)
                    {
                        dataGridView_list.AllowUserToAddRows = true;
                        dataGridView_list.AllowUserToDeleteRows = true;
                        dataGridView_list.ReadOnly = false;
                    }
                    else
                    {
                        dataGridView_list.AllowUserToAddRows = false;
                        dataGridView_list.AllowUserToDeleteRows = false;
                        dataGridView_list.ReadOnly = true;
                    }
                }
                if (core.LoginUser.Authorities.QuerySignOff)
                {
                    dataGridView_list.Columns[11].Visible = true;
                }
                else
                {
                    dataGridView_list.Columns[11].Visible = false;
                }
            }
        }

        #endregion


        #region search, basic user control

        private string curSearchPattern;
        private void button_search_Click(object sender, EventArgs e)
        {
            if (CheckNeedSaveNShowMessage())
                return;
            curSearchPattern = textBox_quickSearch.Text;
            ChangePage(1);
        }
        private void ChangePage(int targetPage)
        {
            if (CheckNeedSaveNShowMessage())
                return;
            ShowNLogInfo("正在请求物资...", true);
            core.SearchSupplies(curSearchPattern, targetPage);
        }

        private void FormSupplyList_KeyDown(object sender, KeyEventArgs e)
        {
            isControlKeyPressing = e.Control;
            if (isControlKeyPressing)
            {
                if (e.KeyCode == Keys.S)
                    button_save_Click(sender, null);
                else if (e.KeyCode == Keys.F)
                {
                    textBox_quickSearch.Focus();
                    textBox_quickSearch.SelectAll();
                }
            }
            else if (textBox_quickSearch.Focused && textBox_quickSearch.Enabled)
            {
                if (e.KeyCode == Keys.Enter)
                    button_search_Click(sender, null);
            }
            else if (bindingNavigatorPositionItem.Focused && bindingNavigatorPositionItem.Enabled)
            {
                if (e.KeyCode == Keys.Enter)
                {
                    try
                    {
                        int tp = int.Parse(bindingNavigatorPositionItem.Text);
                        ChangePage(tp);
                    }
                    catch (Exception err)
                    {
                        _ShowNLogError(err);
                    }
                }
            }
            else if (dataGridView_list.Focused && button_save.Enabled)
            {
                if (e.KeyCode == Keys.Delete)
                    DeleteSupply();
            }
        }
        private void FormSupplyList_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Control)
                isControlKeyPressing = false;
        }

        #endregion


        #region page control
        private void bindingNavigatorMoveFirstItem_Click(object sender, EventArgs e)
        { ChangePage(1); }
        private void bindingNavigatorMovePreviousItem_Click(object sender, EventArgs e)
        { ChangePage(curPage - 1); }
        private void bindingNavigatorMoveNextItem_Click(object sender, EventArgs e)
        { ChangePage(curPage + 1); }
        private void bindingNavigatorMoveLastItem_Click(object sender, EventArgs e)
        { ChangePage(totalPages); }

        #endregion


        #region show search result

        public class RowTagData
        {
            public DataTempletes.SupplyList.Item item = null;
            public bool modified = false;
        }
        public class CellTagData
        {
            public bool modified = false;
        }

        public string UIText_Requesting = "获取中";
        public string UIText_EnterSF = ">进入<";

        private int curPage, totalPages;
        private delegate void SetSearchResultDelegate(int? supplyList_TotalPages, int? supplyList_CurPage, DataTempletes.SupplyList supplyList_Data);
        internal void SetSearchResult(int? supplyList_TotalPages, int? supplyList_CurPage, DataTempletes.SupplyList supplyList_Data)
        {
            if (InvokeRequired)
            {
                SetSearchResultDelegate callback = new SetSearchResultDelegate(SetSearchResult);
                Invoke(callback, supplyList_TotalPages, supplyList_CurPage, supplyList_Data);
            }
            else
            {
                curPage = supplyList_CurPage == null ? 0 : (int)supplyList_CurPage;
                bindingNavigatorPositionItem.Text = curPage.ToString();
                totalPages = supplyList_TotalPages == null ? 0 : (int)supplyList_TotalPages;
                bindingNavigatorCountItem.Text = $"/ {totalPages}";

                bindingNavigatorMoveFirstItem.Enabled = curPage > 1;
                bindingNavigatorMovePreviousItem.Enabled = curPage > 1;
                bindingNavigatorMoveNextItem.Enabled = curPage < totalPages;
                bindingNavigatorMoveLastItem.Enabled = curPage < totalPages;

                dataGridView_list.Rows.Clear();
                if (supplyList_Data == null || supplyList_Data.Content.Count == 0)
                {
                    ShowNLogInfo("没有获取到物资，或数据库是空的。");
                    return;
                }
                int newRowIdx;
                DataGridViewRow newDGVRow;
                foreach (DataTempletes.SupplyList.Item item in supplyList_Data.Content)
                {
                    newRowIdx = dataGridView_list.Rows.Add(
                        item.ProjectName,
                        item.Definition,
                        UIText_Requesting,
                        item.Description,
                        item.Quantity,
                        item.Supplier,
                        item.DeliveryDate.ToString("yyyy-MM-dd"),
                        GetDeliveryAlarmText(item.DeliveryDate),
                        UIText_Requesting, UIText_Requesting, UIText_Requesting, UIText_EnterSF);
                    newDGVRow = dataGridView_list.Rows[newRowIdx];
                    newDGVRow.Tag = new RowTagData() { item = item };
                }
                ShowNLogInfo("物资载入完成");
                Start();

                //ShowNLogInfo("已获取物资列表，正在请求凭证信息...", true);
                if (supplyList_Data.Content.Count > 0)
                {
                    core.GetFileCountList(supplyList_Data.GetIDList());
                }
            }
        }
        private string GetDeliveryAlarmText(DateTime deliveryDate, bool haveDeliveryProof = false)
        {
            if (haveDeliveryProof)
                return "已交货";

            TimeSpan ts = DateTime.Now - deliveryDate;
            if (ts.TotalDays > 0)
                return "超期" + ts.TotalDays.ToString("0") + "天";
            else
                return "还剩" + (-ts.TotalDays).ToString("0") + "天";
        }
        private Color GetDeliveryAlarmColor(DateTime deliveryDate, bool haveDeliveryProof = false)
        {
            if (haveDeliveryProof)
                return Color.LightSeaGreen;

            TimeSpan ts = DateTime.Now - deliveryDate;
            if (ts.TotalDays > 0)
                return Color.OrangeRed;
            else
            {
                if (ts.TotalDays < -7)
                    return Color.Empty;
                else
                    return Color.Orange;
            }
        }

        private delegate void SetProofsDelegate(List<DataTempletes.SupplyList.FileCountInfo> supplyProofCountsList);
        internal void SetFiles(List<DataTempletes.SupplyList.FileCountInfo> supplyProofCountsList)
        {
            if (InvokeRequired)
            {
                SetProofsDelegate callback = new SetProofsDelegate(SetFiles);
                Invoke(callback, supplyProofCountsList);
            }
            else
            {
                RowTagData tag;
                DataTempletes.SupplyList.FileCountInfo pci;
                foreach (DataGridViewRow dgvRow in dataGridView_list.Rows)
                {
                    if (dgvRow.Tag != null && dgvRow.Tag is RowTagData)
                    {
                        tag = (RowTagData)dgvRow.Tag;
                        if (tag.item == null) continue;
                        pci = supplyProofCountsList.Where(a => a.SupplyID == tag.item.ID).FirstOrDefault();
                        if (pci != null && pci.SupplyID == tag.item.ID)
                        {
                            if (tag.item.ProofDeliveryID == tag.item.ProofAcceptanceID) // && tag.item.ProofAcceptanceID == tag.item.ProofSignOffID
                            {
                                // refresh new record
                                tag.item.ContractID = pci.ContractID;
                                tag.item.ProofDeliveryID = pci.ProofDeliveryID;
                                tag.item.ProofAcceptanceID = pci.ProofAcceptanceID;
                                tag.item.ProofSignOffID = pci.ProofSignOffID;
                            }

                            dgvRow.Cells[2].Value = pci.Contract;
                            dgvRow.Cells[8].Value = pci.ProofDelivery;
                            if (pci.ProofDelivery > 0)
                                dgvRow.Cells[7].Value = "已交货";
                            dgvRow.Cells[9].Value = pci.ProofAcceptance;
                            dgvRow.Cells[10].Value = pci.ProofSignOff;
                        }
                    }
                }
                dataGridView_list.Invalidate();
                //ShowNLogInfo("物资载入完成");
            }
        }

        internal delegate void ShowDeliveryWarmingDelegate(string deliveryWarningMessage);
        internal void ShowDeliveryWarming(string deliveryWarningMessage)
        {
            if (InvokeRequired)
            {
                ShowDeliveryWarmingDelegate callback
                    = new ShowDeliveryWarmingDelegate(ShowDeliveryWarming);
                Invoke(callback, deliveryWarningMessage);
            }
            else
            {
                MessageBox.Show(
                    this,
                    deliveryWarningMessage,
                    "物品交付时间",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        #endregion


        #region supply edit, create, and save

        private bool needSave = false;
        private DataGridViewRow editingRow;
        private bool CheckNeedSaveNShowMessage()
        {
            if (needSave)
            {
                MessageBox.Show(this, "请先保存！", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            return needSave;
        }


        private void dataGridView_list_NewRowNeeded(object sender, DataGridViewRowEventArgs e)
        {
            if (editingRow != null
                && e.Row != editingRow
                && CheckNeedSaveNShowMessage())
                return;

            // new not saved row, show light-blue color
            editingRow = e.Row;
            needSave = true;
            dataGridView_list.Invalidate();

        }

        private bool isControlKeyPressing = false;
        private string dataGridView_list_CellBeginEdit_value;
        private void dataGridView_list_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (!core.LoginUser.Authorities.MaintainSupplies)
            {
                ShowNLogInfo("您无权维护物资");
                return;
            }
            if (isControlKeyPressing)
            {
                e.Cancel = true;
                return;
            }
            if (editingRow != null
                && dataGridView_list.Rows[e.RowIndex] != editingRow
                && CheckNeedSaveNShowMessage())
            {
                e.Cancel = true;
                return;
            }
            object test = dataGridView_list.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;
            if (test == null)
                dataGridView_list_CellBeginEdit_value = null;
            else
                dataGridView_list_CellBeginEdit_value = test.ToString();
        }

        private void dataGridView_list_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            object test = dataGridView_list.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;
            string testStr = test == null ? null : test.ToString();
            if (dataGridView_list_CellBeginEdit_value == testStr)
            {
                return;
            }

            // modified row(from DB), show yellow color
            editingRow = dataGridView_list.Rows[e.RowIndex];
            if (editingRow.Tag != null && editingRow.Tag is RowTagData)
            {
                RowTagData rTag = (RowTagData)editingRow.Tag;
                rTag.modified = true;
            }
            editingRow.Cells[e.ColumnIndex].Tag
                = new CellTagData() { modified = true, };

            needSave = true;
            //editingRow.Invalidate();
        }

        private void button_OCRInput_Click(object sender, EventArgs e)
        {
            if (CheckNeedSaveNShowMessage())
                return;

            ShowNLogInfo("启动OCR...", true);
            core.ShowDialog_OCRInput();
        }
        internal void InputSupply_OCR(List<object> ocrResult)
        {
            int newRowIdx = dataGridView_list.Rows.Count - 1;
            DataGridViewRow newRow = (DataGridViewRow)dataGridView_list.Rows[newRowIdx].Clone();
            for (int i = 0, iv = ocrResult.Count; i < iv; i++)
            {
                if (i <= 1)
                    newRow.Cells[i].Value = ocrResult[i];
                else if (i > 1 && i < 5)
                    newRow.Cells[i + 1].Value = ocrResult[i];
                else if (i == 5)
                    newRow.Cells[i + 1].Value = ((DateTime)ocrResult[i]).ToString("yyyy-MM-dd");
            }

            dataGridView_list.Rows.Insert(newRowIdx, newRow);
            dataGridView_list.ClearSelection();
            dataGridView_list.CurrentCell = newRow.Cells[0];

            editingRow = newRow;
            needSave = true;
        }

        private void dataGridView_list_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0)
                return;

            DataGridViewRow paintingRow = dataGridView_list.Rows[e.RowIndex];
            DataGridViewCell curCell = paintingRow.Cells[e.ColumnIndex];
            if (dataGridView_list.SelectedCells.Contains(curCell))
                return;


            Rectangle cellBounds = e.CellBounds;
            cellBounds.Width--; cellBounds.Height--;
            Color bgColor = Color.Empty;
            if (paintingRow.Tag == null && paintingRow != dataGridView_list.Rows[dataGridView_list.Rows.Count - 1])
            {
                // new row
                if (e.ColumnIndex < 7)
                    bgColor = Color.AliceBlue;
                else
                    bgColor = Color.Gray;
            }
            else if (paintingRow.Tag is RowTagData)
            {
                RowTagData rTag = (RowTagData)paintingRow.Tag;
                if (rTag.modified)
                {
                    // modified row
                    if (e.ColumnIndex < 7)
                    {
                        if (e.ColumnIndex == 2)
                        { /* contract-count, do nothing*/ }
                        else if (curCell.Tag != null && curCell.Tag is CellTagData)
                        {
                            CellTagData cTag = (CellTagData)curCell.Tag;
                            if (cTag.modified)
                                bgColor = Color.Yellow;
                        }
                    }
                }

                // no matter modified or not
                if (e.ColumnIndex == 7)
                {
                    bgColor = GetDeliveryAlarmColor(
                        rTag.item.DeliveryDate,
                        SimpleValueHelper.TryGetInt(paintingRow.Cells[8].Value) > 0);
                }
                else if (e.ColumnIndex == 2 || e.ColumnIndex > 7)
                {
                    if (SimpleValueHelper.TryGetInt(curCell.Value) > 0)
                        bgColor = Color.LightSeaGreen;
                }
            }
            if (bgColor == Color.Empty)
                return;

            using (SolidBrush br = new SolidBrush(bgColor))
            {
                e.Graphics.FillRectangle(br, cellBounds);
                e.PaintContent(e.ClipBounds);
                e.Handled = true;
            }
        }

        private void button_save_Click(object sender, EventArgs e)
        {
            if (!needSave)
            {
                ShowNLogInfo("无需保存");
                return;
            }
            DialogResult dr = MessageBox.Show(
                this,
                "确定要提交内容吗？" + Environment.NewLine + Environment.NewLine
                + "是   - 提交内容" + Environment.NewLine
                + "否   - 放弃变动(重新载入)" + Environment.NewLine
                + "取消 - 返回(继续修改)",
                "即将保存",
                MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button3);
            switch (dr)
            {
                case DialogResult.Yes:
                    SubmitSupply(editingRow);
                    break;
                case DialogResult.No:
                    needSave = false;
                    editingRow = null;
                    ChangePage(curPage); // reload
                    break;
                case DialogResult.Cancel:
                    return;
            }
        }
        private void SubmitSupply(DataGridViewRow editingRow)
        {
            object test = editingRow.Cells[0].Value;
            bool isNotErr = true;
            string errTitle = "未知", errContent = "未获得错误原因";
            if (isNotErr)
            {
                if (test == null || string.IsNullOrWhiteSpace(test.ToString()))
                { isNotErr = false; errTitle = "错误"; errContent = "项目名称为空"; }
                else test = editingRow.Cells[1].Value;
            }
            if (isNotErr)
            {
                if (test == null || string.IsNullOrWhiteSpace(test.ToString()))
                { isNotErr = false; errTitle = "错误"; errContent = "项目定义为空"; }
                else test = editingRow.Cells[3].Value;
            }
            if (isNotErr)
            {
                if (test == null || string.IsNullOrWhiteSpace(test.ToString()))
                { isNotErr = false; errTitle = "错误"; errContent = "采购内容为空"; }
                else test = editingRow.Cells[4].Value;
            }
            if (isNotErr)
            {
                if (test == null || string.IsNullOrWhiteSpace(test.ToString()))
                { isNotErr = false; errTitle = "错误"; errContent = "采购数量为空"; }
            }
            if (isNotErr)
            {
                if (SimpleValueHelper.TryGetDecimal(test) < 0)
                { isNotErr = false; errTitle = "错误"; errContent = "数量不是数字"; }
                else test = editingRow.Cells[5].Value;
            }
            if (isNotErr)
            {
                if (test == null || string.IsNullOrWhiteSpace(test.ToString()))
                { isNotErr = false; errTitle = "错误"; errContent = "供应商名称为空"; }
                else test = editingRow.Cells[6].Value;
            }
            if (isNotErr)
            {
                if (test == null || string.IsNullOrWhiteSpace(test.ToString()))
                { isNotErr = false; errTitle = "错误"; errContent = "交货日期为空"; }
            }
            if (isNotErr)
            {
                if (SimpleValueHelper.TryGetDate(test) == DateTime.MinValue)
                { isNotErr = false; errTitle = "错误"; errContent = "交货日期不是有效日期"; }
            }
            if (!isNotErr)
            {
                MessageBox.Show(this, errContent, errTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            bool isInsert = false;
            if (editingRow.Tag == null)
            {
                isInsert = true;
                editingRow.Tag = new RowTagData()
                {
                    item = new DataTempletes.SupplyList.Item()
                    {
                        ID = Guid.NewGuid(),
                        Creator = core.LoginUser.ID,
                    },
                    modified = true,
                };
            }

            RowTagData tag = (RowTagData)editingRow.Tag;
            tag.item.ProjectName = editingRow.Cells[0].Value.ToString();
            tag.item.Definition = editingRow.Cells[1].Value.ToString();
            tag.item.Description = editingRow.Cells[3].Value.ToString();
            tag.item.Quantity = decimal.Parse(editingRow.Cells[4].Value.ToString());
            tag.item.Supplier = editingRow.Cells[5].Value.ToString();
            tag.item.DeliveryDate = DateTime.Parse(editingRow.Cells[6].Value.ToString());

            if (isInsert)
                core.SubmitSupply(tag.item, DataTempletes.RequestDataOperatTypes.Insert);
            else
                core.SubmitSupply(tag.item, DataTempletes.RequestDataOperatTypes.Update);
        }
        private void DeleteSupply()
        {
            if (dataGridView_list.SelectedRows.Count == 1)
            {
                DataGridViewRow selectDGVRow = dataGridView_list.SelectedRows[0];
                if (selectDGVRow.Tag is RowTagData)
                {
                    RowTagData tag = (RowTagData)selectDGVRow.Tag;
                    if (tag.item != null)
                    {
                        if (MessageBox.Show(
                            this, "即将删除物资，是否继续？", "警告",
                            MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2)
                            == DialogResult.Yes)
                            core.SubmitSupply(tag.item, DataTempletes.RequestDataOperatTypes.Delete);
                    }
                }
            }
        }

        private delegate void SetSubmitOKDelegate(Guid accessSupplyID, DataTempletes.RequestDataOperatTypes opType);
        internal void SetSubmitOK(Guid accessSupplyID, DataTempletes.RequestDataOperatTypes opType)
        {
            if (InvokeRequired)
            {
                SetSubmitOKDelegate callback = new SetSubmitOKDelegate(SetSubmitOK);
                Invoke(callback, accessSupplyID, opType);
            }
            else
            {
                isControlKeyPressing = false;
                needSave = false;
                editingRow = null;
                DataGridViewRow effectedDGVRow = null;
                RowTagData tag = null;
                foreach (DataGridViewRow dgvRow in dataGridView_list.Rows)
                {
                    if (dgvRow?.Tag is RowTagData)
                    {
                        tag = (RowTagData)dgvRow.Tag;
                        if (tag.item?.ID == accessSupplyID)
                        {
                            effectedDGVRow = dgvRow;
                            break;
                        }
                    }
                }
                if (effectedDGVRow == null)
                {
                    ShowNLogInfo($"成功删除了物资数据：{accessSupplyID}");
                    return;
                }

                switch (opType)
                {
                    case DataTempletes.RequestDataOperatTypes.Insert:
                        ShowNLogInfo($"成功插入物资数据：{accessSupplyID}");
                        break;
                    case DataTempletes.RequestDataOperatTypes.Update:
                        ShowNLogInfo($"成功更新物资数据：{accessSupplyID}");
                        break;
                    case DataTempletes.RequestDataOperatTypes.Delete:
                        dataGridView_list.Rows.Remove(effectedDGVRow);
                        ShowNLogInfo($"成功删除物资：{accessSupplyID}");
                        return;
                    default:
                        ShowNLogInfo($"成功执行了未知操作：{accessSupplyID}");
                        break;
                }
                tag.modified = false;
                foreach (DataGridViewCell c in effectedDGVRow.Cells)
                    c.Tag = null;

                // get alarm and proof info
                effectedDGVRow.Cells[7].Value = GetDeliveryAlarmText(tag.item.DeliveryDate);
                effectedDGVRow.Cells[11].Value = UIText_EnterSF;
                List<Guid> sList = new List<Guid>();
                sList.Add(accessSupplyID);
                core.GetFileCountList(sList);

                //dataGridView_list.Invalidate();
            }
        }

        private delegate void SetSubmitFailedDelegate(Guid accessSupplyID, Exception err);

        internal void SetSubmitFailed(Guid accessSupplyID, Exception err)
        {
            if (InvokeRequired)
            {
                SetSubmitFailedDelegate callback = new SetSubmitFailedDelegate(SetSubmitFailed);
                Invoke(callback, accessSupplyID, err);
            }
            else
            {
                isControlKeyPressing = false;
                _ShowNLogError("提交物资数据失败", err);
            }
        }

        #endregion


        #region file upload, download

        private Guid lookingFile_supplyID;


        private void dataGridView_list_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.ColumnIndex == 2
                || (e.ColumnIndex >= 8 && e.ColumnIndex <= 10))
            {
                if (!core.LoginUser.Authorities.DownloadFilesSupplies)
                {
                    ShowNLogInfo("您无权查看文件");
                    return;
                }
                DataGridViewRow lpRow = dataGridView_list.Rows[e.RowIndex];
                DataGridViewCell lpCell = lpRow.Cells[e.ColumnIndex];
                if (lpCell.Value == null)
                    return;
                if (SimpleValueHelper.TryGetInt(lpCell.Value) < 0)
                    return;

                RowTagData rTag = (RowTagData)lpRow.Tag;
                lookingFile_supplyID = rTag.item.ID;
                DataTempletes.SupplyList.FileTypes pt;
                if (e.ColumnIndex == 2)
                    pt = DataTempletes.SupplyList.FileTypes.Contract;
                else if (e.ColumnIndex == 8)
                    pt = DataTempletes.SupplyList.FileTypes.Delivery;
                else if (e.ColumnIndex == 9)
                    pt = DataTempletes.SupplyList.FileTypes.Acceptance;
                else //if (e.ColumnIndex == 10)
                    pt = DataTempletes.SupplyList.FileTypes.SignOff;

                core.Show_FileListForm(rTag.item, pt);
            }
            else if (e.ColumnIndex == 11)
            {
                if (!core.LoginUser.Authorities.QuerySignOff)
                {
                    ShowNLogInfo("您无权查看领用信息");
                    return;
                }
                DataGridViewRow lpRow = dataGridView_list.Rows[e.RowIndex];
                DataGridViewCell lpCell = lpRow.Cells[e.ColumnIndex];
                if (lpCell.Value == null)
                    return;

                RowTagData rTag = (RowTagData)lpRow.Tag;
                core.ShowDialog_SignOff(rTag.item);
            }
        }


        #endregion
    }
}
