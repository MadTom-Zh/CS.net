﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;

namespace MadTomDev.App.YPLQDJ
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            AssemblyProductAttribute attributes
                = (AssemblyProductAttribute)Attribute.GetCustomAttribute(Assembly.GetExecutingAssembly(), typeof(AssemblyProductAttribute), false);
            bool createdNew;
            string attributesProduct = attributes.Product;
            Mutex m = new Mutex(true, attributesProduct, out createdNew);

            if (!createdNew)
            {
                MessageBox.Show(
                    null,
                    "已经有一个登记客户端在运行了，" + Environment.NewLine
                        + attributesProduct + Environment.NewLine
                        + "，不能运行第二个同版本软件。"
                    , "终止", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FormSupplyList());
        }
    }
}
