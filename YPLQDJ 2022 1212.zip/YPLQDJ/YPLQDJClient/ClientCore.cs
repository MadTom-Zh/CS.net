﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using MadTomDev.CommonClasses;
using MadTomDev.Data;
using MadTomDev.Math;

using MadTomDev.Network;
using MadTomDev.UIs;
using MadTomDev.UIs.ExDialogs;

namespace MadTomDev.App.YPLQDJ
{
    public class ClientCore : IDisposable
    {
        public FormSupplyList formSupplyList;
        public FormFileList formFileList;
        public FormSignOff formSignOff;
        public FormSupplyOCR formSupplyOCR;
        public Logger logger;
        public PasswordProtector pp;
        public ClientSettings settings;
        public ClientFileIO fileIO;
        public SocketHelper.SocketTcpClient socketClient;

        public string Encryption_Password { private set; get; }
        public byte Encryption_ConfusionLength { private set; get; } = 13;

        public DataTempletes.User LoginUser { private set; get; } = new DataTempletes.User();

        public ClientCore(FormSupplyList mainForm)
        {
            formSupplyList = mainForm;
            formFileList = new FormFileList() { core = this, };
            formFileList.FormClosing += FormFileList_FormClosing;
            formSignOff = new FormSignOff() { core = this, };
            formSignOff.FormClosing += FormSignOff_FormClosing;
            formSupplyOCR = new FormSupplyOCR() { core = this, };
            formSupplyOCR.FormClosing += FormSupplyOCR_FormClosing;

            string startUpPath = Application.StartupPath;
            logger = new Logger()
            { BaseDir = Path.Combine(startUpPath, "Log"), };

            pp = PasswordProtector.GetInstance(
                Path.Combine(startUpPath, "Encry.cer"),
                "u$kjl!&wZv@%@qw*rNTh$DMBQ$t@D!rX*FOa");

            pp.Password = "this is a fixed password, do not change it.";
            Encryption_Password = pp.Password_forCipher;

            settings = new ClientSettings(this);
            fileIO = new ClientFileIO(this);

            socketClient = new SocketHelper.SocketTcpClient();
            socketClient.ServerConnected += SocketClient_ServerConnected;
            socketClient.ServerDataReceived += SocketClient_ServerDataReceived;
            socketClient.ServerReceiveError += SocketClient_ServerReceiveError;
            socketClient.ServerReceiveTimeout += SocketClient_ServerReceiveTimeout;
        }


        private void SendRequest(DataClientRequest request)
        {
            socketClient.socket.Send(
                EncryptedGZip.EncryptGZip(
                    request.Data, Encryption_Password, Encryption_ConfusionLength));
        }
        private void SocketClient_ServerConnected(SocketHelper.SocketTcpClient sender)
        {
            logger.Log("Server connection established.");
        }
        private void SocketClient_ServerReceiveTimeout(SocketHelper.SocketTcpClient sender)
        {
            logger.Log("Server connection timeout.");
            MessageBoxAlone.Show("服务器连接超时，长时间得不到响应", "错误", MessageBoxButtons.OK, MessageBoxIcon.Hand);
        }
        private void SocketClient_ServerReceiveError(SocketHelper.SocketTcpClient sender, Exception err)
        {
            logger.Log(err);
            MessageBoxAlone.Show(err.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void SocketClient_ServerDataReceived(SocketHelper.SocketTcpClient sender, byte[] data)
        {
            logger.Log($"Receive data from server, [{data.Length}] bytes.");
            data = EncryptedGZip.UnGZipDecrypt(data, Encryption_Password, Encryption_ConfusionLength);

            Flags.Types[] outTypes;
            object[] dataArray = DataReceiver.GetDataInstances(data, out outTypes);
            object dataObj;
            DataServerResponse dsResponse;
            for (int i = 0, iv = outTypes.Length; i < iv; i++)
            {
                dataObj = dataArray[i];
                switch (outTypes[i])
                {
                    default:
                    case Flags.Types.Unknow:
                        {
                            logger.Log("Unknow data: " + SimpleStringHelper.ToHexString(data));
                            MessageBoxAlone.Show(
                                $"收到未知数据，[{data.Length}] bytes，请查看日志文件。",
                                "不明", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            break;
                        }
                    case Flags.Types.Message:
                        {
                            DataMessage dm = (DataMessage)dataObj;
                            logger.Log("Server message: " + dm.Message);
                            MessageBoxAlone.Show(
                                $"来自服务器的消息：{Environment.NewLine + dm.Message}",
                                "消息", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                            break;
                        }
                    case Flags.Types.ResponseLogin:
                        {
                            dsResponse = (DataServerResponse)dataObj;
                            if (dsResponse.Login_Result == true)
                            {
                                bool loginOk = false;
                                logger.Log("Login success.");
                                LoginUser = dsResponse.Login_UserData;
                                if (dsResponse.Login_NeedSetPassword == true
                                    || formLogin.toResetPassword)
                                {
                                    logger.Log("Password reset required.");
                                    formLogin.toResetPassword = false;
                                    ShowDialog_Login_ResetPassword_orQuit();
                                }
                                else if (dsResponse.Login_HaveSession == true)
                                {
                                    logger.Log("User already logged-in on other device.");
                                    if (MessageBox.Show(null, $"强行登陆会踢掉其他终端上的连接，{Environment.NewLine + Environment.NewLine}要继续吗？",
                                        "已经在别处登陆", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
                                        == DialogResult.Yes)
                                    {
                                        DataClientRequest loginRequest = new DataClientRequest(Flags.Types.RequestLogin)
                                        { Login_ForceEnter = true, Login_User = LoginUser.ID, Login_Password = formLogin.UserPassword, };
                                        socketClient.socket.Send(
                                            EncryptedGZip.EncryptGZip(
                                                loginRequest.Data, Encryption_Password, Encryption_ConfusionLength));
                                        logger.Log("Current user kicked old-login connection.");
                                    }
                                    else
                                        loginOk = true;
                                }
                                else
                                    loginOk = true;

                                if (loginOk)
                                {
                                    if (!LoginUser.Authorities.QuerySupplies)
                                    {
                                        logger.Log("Login success, but don't have Authorities.QuerySupplies.");
                                        formLogin.Info = "您已登陆，但无权查询物资";
                                        LoginUser = new DataTempletes.User();
                                    }
                                    else if (!LoginUser.Authorities.Login)
                                    {
                                        logger.Log("Login success, but don't have Authorities.Login.");
                                        formLogin.Info = "您无权登陆";
                                        LoginUser = new DataTempletes.User();
                                    }
                                    else
                                    {

                                        formLogin.DialogResult = DialogResult.OK;  // auto close!
                                                                                   //if (!formLogin.IsDisposed)
                                                                                   //    formLogin.Close();
                                        formSupplyList.LoginUserText = $"登陆用户：{LoginUser.ID}";

                                        // request user delivery warnings
                                        DataClientRequest warningRequest = new DataClientRequest(Flags.Types.RequestDeliveryWarning)
                                        { DeliveryWarning_UserID = LoginUser.ID, DeliveryWarning_ReserveDays = 7, };
                                        formFileList.ShowInfoNLog("登陆成功，正在检查交货时间", true);
                                        SendRequest(warningRequest);
                                    }
                                }
                            }
                            else
                            {
                                logger.Log("Login failed.");
                                formLogin.Info = "登陆失败，账号/密码不正确";
                                LoginUser = new DataTempletes.User();
                            }

                            if (!formLogin.IsDisposed)
                                formLogin.SetButtonsEnable(true);
                            break;
                        }
                    case Flags.Types.ResponseResetPwd:
                        {
                            dsResponse = (DataServerResponse)dataObj;
                            if (dsResponse.ResetPwd_Result == true)
                            {
                                logger.Log("Reset new password success.");
                                formLogin.DialogResult = DialogResult.OK;// auto close!
                                formSupplyList.LoginUserText = $"登陆用户：{LoginUser.ID}";
                                formSupplyList.Start();
                            }
                            else
                            {
                                logger.Log("Reset new password failed.");
                                MessageBoxAlone.Show("未能成功设置新密码", "失败", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                ShowDialog_Login_ResetPassword_orQuit();
                            }
                            break;
                        }
                    case Flags.Types.ResponseSupplyList:
                        {
                            dsResponse = (DataServerResponse)dataObj;
                            formSupplyList.SetSearchResult(
                                dsResponse.SupplyList_TotalPages,
                                dsResponse.SupplyList_CurPage,
                                dsResponse.SupplyList_Data);
                            break;
                        }
                    case Flags.Types.ResponseSupplyFileCounts:
                        {
                            dsResponse = (DataServerResponse)dataObj;
                            formSupplyList.SetFiles(dsResponse.SupplyFileCounts_List);
                            break;
                        }
                    case Flags.Types.ResponseAccessSupply:
                        {
                            dsResponse = (DataServerResponse)dataObj;
                            if (dsResponse.AccessSupply_Result)
                            {
                                formSupplyList.SetSubmitOK(dsResponse.AccessSupply_ID, dsResponse.AccessSupply_OpType);
                            }
                            else
                            {
                                formSupplyList.SetSubmitFailed(
                                    dsResponse.AccessSupply_ID, dsResponse.AccessSupply_Error);
                            }
                            break;
                        }
                    case Flags.Types.ResponseFileQuery:
                        {
                            dsResponse = (DataServerResponse)dataObj;
                            formFileList.SetFiles(dsResponse.FileQuery_ID, dsResponse.FileQuery_NameList);
                            break;
                        }
                    case Flags.Types.ResponseFileUpload:
                        {
                            uploadingResponse = (DataServerResponse)dataObj;
                            // processing in waiting loop @ UploadFile()
                            break;
                        }
                    case Flags.Types.ResponseFileDownload:
                        {
                            downloadFileResponse = (DataServerResponse)dataObj;
                            // like upload, processing in loop
                            // do nothing, receive data inside stream instance;
                            break;
                        }
                    case Flags.Types.ResponseFileDelete:
                        {
                            dsResponse = (DataServerResponse)dataObj;
                            if (dsResponse.FileDelete_Result == true)
                                formFileList.RemoveFile(dsResponse.FileDelete_ID, dsResponse.FileDelete_No);
                            else if (dsResponse.FileDelete_Error != null)
                                formFileList.ShowErrorNLog(dsResponse.FileDelete_Error, "文件删除失败");
                            else
                                formFileList.ShowInfoNLog("文件删除失败，且没有返回错误");
                            break;
                        }
                    case Flags.Types.ResponseDeliveryWarning:
                        {
                            dsResponse = (DataServerResponse)dataObj;
                            if (dsResponse.DeliveryWarning_HaveWarning == true
                                && !string.IsNullOrWhiteSpace(dsResponse.DeliveryWarning_WarningMessage))
                            {
                                formSupplyList.ShowDeliveryWarming(dsResponse.DeliveryWarning_WarningMessage);
                            }
                            break;
                        }
                    case Flags.Types.ResponseSupplyStatus:
                        {
                            dsResponse = (DataServerResponse)dataObj;
                            SupplyStatus_CT = dsResponse.SupplyStatus_Dictionary;
                            SupplyStatus_TC.Clear();
                            foreach (KeyValuePair<int, string> kv in SupplyStatus_CT)
                            {
                                if (!SupplyStatus_TC.ContainsKey(kv.Value))
                                    SupplyStatus_TC.Add(kv.Value, kv.Key);
                            }
                            formSignOff.RefreshSignOffList();
                            break;
                        }
                    case Flags.Types.ResponseSignOffList:
                        {
                            dsResponse = (DataServerResponse)dataObj;
                            formSignOff.SetSignOffList(
                                dsResponse.SignOffList_SupplyID,
                                dsResponse.SignOffList_Data);
                            break;
                        }
                    case Flags.Types.ResponseSignOffCount:
                        {
                            dsResponse = (DataServerResponse)dataObj;
                            formSignOff.SetSignOffCount(
                                dsResponse.SignOffCount_SupplyID,
                                dsResponse.SignOffCount_Count);
                            break;
                        }
                    case Flags.Types.ResponseAccessSignOff:
                        {
                            dsResponse = (DataServerResponse)dataObj;
                            formSignOff.SetSignOffAccessResult(
                                dsResponse.AccessSignOff_Result,
                                dsResponse.AccessSignOff_ID,
                                dsResponse.AccessSignOff_OpType,
                                dsResponse.AccessSignOff_Error);
                            break;
                        }
                }
            }
        }




        internal DialogResult ShowDialog_Config()
        {
            FormConfig formConfig = new FormConfig()
            {
                IPv4 = settings.ServerIPV4,
                IPv6 = settings.ServerIPV6,
                SelectedIPV4orIPV6 = settings.SelectedServerIPV4orIPV6,
                Port = settings.ServerPort == null ? 0 : (int)settings.ServerPort,
            };
            DialogResult result = formConfig.ShowDialog();
            if (result == DialogResult.OK)
            {
                settings.ServerIPV4 = formConfig.IPv4;
                settings.ServerIPV6 = formConfig.IPv6;
                settings.SelectedServerIPV4orIPV6 = formConfig.SelectedIPV4orIPV6;
                settings.ServerPort = formConfig.Port;
                settings.Save();
            }
            return result;
        }

        #region login

        FormLogin formLogin;
        internal DialogResult ShowDialog_Login()
        {
            formLogin = new FormLogin() { core = this, };
            return formLogin.ShowDialog();
        }
        internal void ShowDialog_Login_ResetPassword_orQuit()
        {
            PasswordInputBox pwdBox = new PasswordInputBox()
            { Text = "重置密码", Info = "初始密码必须重置，请设置新密码：", IsSetNewPassword = true, };
            if (pwdBox.ShowDialog() == DialogResult.OK)
            {
                DataClientRequest newRequest = new DataClientRequest(Flags.Types.RequestResetPwd)
                { ResetPwd_User = LoginUser.ID, ResetPwd_NewPassword = pwdBox.Password, };
                SendRequest(newRequest);

                formLogin.Info = "正在设定新密码……";
            }
            else formSupplyList.Close();
        }

        public bool ConnectServer()
        {
            Exception err;
            bool result;
            if (settings.SelectedServerIPV4orIPV6)
                result = socketClient.Connect(
                    settings.ServerIPV4, (int)settings.ServerPort, out err);
            else
                result = socketClient.Connect(
                    settings.ServerIPV6, (int)settings.ServerPort, out err);
            if (err != null)
                logger.Log(err);
            return result;
        }
        internal void Login(string user, string pwd, bool forceEnter = false)
        {
            DataClientRequest request = new DataClientRequest(Flags.Types.RequestLogin)
            { Login_ForceEnter = false, Login_User = user, Login_Password = pwd, };
            SendRequest(request);
        }

        #endregion

        #region search supplies

        internal void SearchSupplies(string searchPattern, int requestPage = 0)
        {
            DataClientRequest request = new DataClientRequest(Flags.Types.RequestSupplyList)
            { SupplyList_Page = requestPage, SupplyList_SearchPattern = searchPattern, };
            SendRequest(request);
        }


        internal void GetFileCountList(List<Guid> supplyIDlist)
        {
            DataClientRequest request = new DataClientRequest(Flags.Types.RequestSupplyFileCounts)
            { SupplyFileCounts_SupplyIDList = supplyIDlist };
            SendRequest(request);
        }

        public Dictionary<int, string> SupplyStatus_CT;
        private Dictionary<string, int> SupplyStatus_TC = new Dictionary<string, int>();
        internal int GetSupplyStatusCode(string statusString)
        {
            if (SupplyStatus_TC.ContainsKey(statusString))
                return SupplyStatus_TC[statusString];
            else
                return -1;
        }

        #endregion

        #region OCR
        private bool OCRInputComplete = false;
        public void ShowDialog_OCRInput()
        {
            formSupplyList.Enabled = false;
            OCRInputComplete = false;
            formSupplyOCR.Reset();
            formSupplyOCR.ShowDialog();
        }
        private void FormSupplyOCR_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (formSupplyOCR.Result && !OCRInputComplete)
            {
                List<object> ocrResult = formSupplyOCR.OCRResult;
                if (ocrResult != null)
                {
                    formSupplyList.InputSupply_OCR(ocrResult);
                    OCRInputComplete = true;
                }
            }

            formSupplyList.Enabled = true;
            formSupplyList.Invalidate();
            formSupplyList.ShowNLogInfo("OCR结束");
        }
        #endregion

        #region submit supply
        internal void SubmitSupply(DataTempletes.SupplyList.Item item, DataTempletes.RequestDataOperatTypes operateType)
        {
            DataClientRequest request = new DataClientRequest(Flags.Types.RequestAccessSupply)
            {
                AccessSupply_ID = item.ID,
                AccessSupply_OpType = operateType,
                AccessSupply_Data = item,
            };
            SendRequest(request);
        }

        #endregion

        #region file access

        #region file upload
        internal void Show_FileListForm(DataTempletes.SupplyList.Item supply, DataTempletes.SupplyList.FileTypes proofType)
        {
            formFileList.Init(supply, proofType);
            formFileList.Show();
            switch (proofType)
            {
                default:
                    formFileList.ShowInfoNLog("凭证信息无效");
                    break;
                case DataTempletes.SupplyList.FileTypes.Contract:
                    formFileList.ShowInfoNLog("正在请求 合同文件", true);
                    DataClientRequest request = new DataClientRequest(Flags.Types.RequestFileQuery)
                    { FileQuery_ID = supply.ContractID, };
                    SendRequest(request);
                    break;
                case DataTempletes.SupplyList.FileTypes.Delivery:
                    formFileList.ShowInfoNLog("正在请求 交货凭证", true);
                    request = new DataClientRequest(Flags.Types.RequestFileQuery)
                    { FileQuery_ID = supply.ProofDeliveryID, };
                    SendRequest(request);
                    break;
                case DataTempletes.SupplyList.FileTypes.Acceptance:
                    formFileList.ShowInfoNLog("正在请求 验收凭证", true);
                    request = new DataClientRequest(Flags.Types.RequestFileQuery)
                    { FileQuery_ID = supply.ProofAcceptanceID, };
                    SendRequest(request);
                    break;
                case DataTempletes.SupplyList.FileTypes.SignOff:
                    formFileList.ShowInfoNLog("正在请求 领用凭证", true);
                    request = new DataClientRequest(Flags.Types.RequestFileQuery)
                    { FileQuery_ID = supply.ProofSignOffID, };
                    SendRequest(request);
                    break;
            }
        }
        internal void Show_ExcelTemplateForm()
        {
            formFileList.Init(
                "请(只)保留一个模板，必须是xlsx格式文件；" + Environment.NewLine
                + "* 先删除已有模板，然后再上传新模板；" + Environment.NewLine
                + "模板A20位置写入定位信息，格式为：" + Environment.NewLine
                + "    {列索引0}-{起始单元格位置0},{列索引1}-{起始单元格位置1}..."
                , DataTempletes.SupplyList.FileTypes.ExcelTemplate);
            formFileList.Show();
            formFileList.ShowInfoNLog("正在请求 模板文件列表", true);
            DataClientRequest request = new DataClientRequest(Flags.Types.RequestFileQuery)
            { FileQuery_ID = 0, };
            SendRequest(request);
        }
        private void FormFileList_FormClosing(object sender, FormClosingEventArgs e)
        {
            List<Guid> sIDList_reloadProofs = new List<Guid>();
            if (formFileList.FileType == DataTempletes.SupplyList.FileTypes.Contract
                || formFileList.FileType == DataTempletes.SupplyList.FileTypes.Acceptance
                || formFileList.FileType == DataTempletes.SupplyList.FileTypes.Delivery
                || formFileList.FileType == DataTempletes.SupplyList.FileTypes.SignOff)
            {
                sIDList_reloadProofs.Add(formFileList.Supply.ID);
                GetFileCountList(sIDList_reloadProofs);
            }
        }
        public bool IsUploading { private set; get; } = false;
        DataServerResponse uploadingResponse = null;
        internal void UploadFile_async(FormFileList sender, string localFile, long fileId, int readLength = 1024) // 1M-1048576 512K-524288
        {
            if (IsUploading)
                throw new InvalidOperationException("上传还在进行中，不能重复操作");

            ThreadPool.QueueUserWorkItem(new WaitCallback(s =>
            {
                using (FileStream fs = new FileStream(localFile, FileMode.Open, FileAccess.Read))
                {
                    IsUploading = true;
                    Guid taskID = Guid.NewGuid();
                    string fileName = Path.GetFileName(localFile);
                    int offset = 0;
                    byte[] buffer = new byte[readLength];
                    bool isStartPack = true, isLastPack = false;
                    int readedLength;
                    DataClientRequest req;
                    int stepTotal = (int)System.Math.Ceiling((float)fs.Length / readLength);
                    int stepCur = 1;
                    while (true)
                    {
                        sender.ShowInfoNLog($"正在上传文件，进度({stepCur++}/{stepTotal})");
                        readedLength = fs.Read(buffer, 0, readLength);
                        isLastPack = fs.Length == (offset + readedLength);
                        if (isLastPack)
                        {
                            // last pack
                            byte[] lastPack = new byte[readedLength];
                            Array.Copy(buffer, lastPack, readedLength);
                            buffer = lastPack;
                        };
                        req = new DataClientRequest(Flags.Types.RequestFileUpload)
                        {
                            FileUpload_ID = sender.FileID,
                            FileUpload_TaskID = taskID,
                            FileUpload_FileName = fileName,
                            FileUpload_Position = offset,
                            FileUpload_FileData = buffer,
                            FileUpload_IsStartPack = isStartPack,
                            FileUpload_IsEndPack = isLastPack,
                        };
                        isStartPack = false;
                        uploadingResponse = null;
                        SendRequest(req);
                        try
                        {
                            UploadFile_WaitForResponseNCheck(sender, taskID, offset, DateTime.MinValue);
                        }
                        catch (Exception err)
                        {
                            sender.ShowErrorNLog(err, "文件上传失败");
                            break;
                        }

                        if (isLastPack)
                        {
                            sender.ShowInfoNLog("文件上传完成，正在刷新文件列表", true);
                            DataClientRequest request = new DataClientRequest(Flags.Types.RequestFileQuery)
                            { FileQuery_ID = sender.FileID, };
                            SendRequest(request);
                            break;
                        }
                        offset += readedLength;
                    }
                    IsUploading = false;
                }
            }));
        }

        private void UploadFile_WaitForResponseNCheck(
            FormFileList sender, Guid taskID, int offset, DateTime startTime_orMinValue)
        {
            DateTime startTimePoint
                = (startTime_orMinValue == DateTime.MinValue) ?
                    DateTime.Now : startTime_orMinValue;
            while (uploadingResponse == null)
            {
                Thread.Sleep(10);
                if ((DateTime.Now - startTimePoint).TotalSeconds > 30)
                    throw new TimeoutException("上传文件超时，已经超过30秒");
            }
            if (uploadingResponse.FileUpload_TaskID != taskID)
            {
                uploadingResponse = null;
                UploadFile_WaitForResponseNCheck(sender, taskID, offset, startTimePoint);
                return;
            }
            if (uploadingResponse.FileUpload_Error != null)
                throw uploadingResponse.FileUpload_Error;
            if (offset != uploadingResponse.FileUpload_Position)
                throw new ArgumentOutOfRangeException("文件上传错误，偏移不匹配");
        }

        private IconHelper iconHelper;
        public Icon GetIcon(string fileExtension)
        {
            if (iconHelper == null)
            {
                iconHelper = IconHelper.GetInstance();
            }
            string targetIconFile = Path.Combine(fileIO.TmpDir, "f" + fileExtension);
            if (!File.Exists(targetIconFile))
                File.WriteAllText(targetIconFile, "");
            return iconHelper.IconFromExistIOPath(targetIconFile);
        }

        #endregion

        #region file download

        public DataServerResponse downloadFileResponse;

        public class StreamOutFromServer : Stream
        {
            private ClientCore clientCore;
            private DataTempletes.FileInfo serverFileInfo;
            public StreamOutFromServer(ClientCore clientCore, DataTempletes.FileInfo serverFileInfo)
            {

                this.clientCore = clientCore;
                this.clientCore.LoginUser.ID = clientCore.LoginUser.ID;

                this.serverFileInfo = serverFileInfo.Clone();
                taskID = Guid.NewGuid();

            }


            public override bool CanRead => true;

            public override bool CanSeek => false;

            public override bool CanWrite => false;

            public override long Length
            { get => serverFileInfo.Size; }

            public override long Position { get; set; }

            public Guid taskID { private set; get; }
            private DataClientRequest cRequest;
            private long downloadedOffset = 0;
            private List<byte> downloadedData = new List<byte>();
            private bool downloadedEnd = false;
            public override int Read(byte[] buffer, int offset, int count)
            {
                if (offset < 0)
                    throw new IndexOutOfRangeException("仅支持顺序读取，无法回溯");

                if (downloadedData.Count < count && !downloadedEnd)
                    DownloadNextDataPack(offset + count);

                int downloadedDataCount = downloadedData.Count;

                if (offset <= downloadedDataCount)
                    downloadedData.RemoveRange(0, offset);
                else
                    downloadedData.Clear();

                if (count > downloadedData.Count)
                    count = downloadedData.Count;

                Array.Copy(downloadedData.GetRange(0, count).ToArray(), buffer, count);
                downloadedData.RemoveRange(0, count);

                Position += count;
                return count;
            }
            private void DownloadNextDataPack(int minCount)
            {
                clientCore.downloadFileResponse = null;
                cRequest = new DataClientRequest(Flags.Types.RequestFileDownload)
                {
                    FileDownload_TaskID = taskID,
                    FileDownload_ID = serverFileInfo.ID,
                    FileDownload_No = serverFileInfo.No,
                    FileDownload_Name = serverFileInfo.Name,
                    FileDownload_Position = downloadedOffset,
                    FileDownload_Length = 524288, // 512K-524288
                };
                clientCore.SendRequest(cRequest);

                int getCount = 0;
                CaptureFileDataNCheck(ref getCount, DateTime.Now);
                if (getCount < minCount && !downloadedEnd)
                    DownloadNextDataPack(minCount - getCount);
            }
            private void CaptureFileDataNCheck(ref int getCount, DateTime startTime)
            {
                while (clientCore.downloadFileResponse == null)
                {
                    Thread.Sleep(10);
                    if ((DateTime.Now - startTime).TotalSeconds > 30)
                        throw new TimeoutException("下载文件超时，已经超过30秒");
                }
                if (clientCore.downloadFileResponse.FileDownload_TaskID != taskID)
                {
                    clientCore.downloadFileResponse = null;
                    CaptureFileDataNCheck(ref getCount, startTime);
                    return;
                }
                if (clientCore.downloadFileResponse.FileDownload_Result != true)
                {
                    if (clientCore.downloadFileResponse.FileDownload_Error != null)
                        throw clientCore.downloadFileResponse.FileDownload_Error;
                    else
                        throw new Exception("文件下载失败，且没有报错数据");
                }
                if (clientCore.downloadFileResponse.FileDownload_Position != downloadedOffset)
                    throw new ArgumentOutOfRangeException("文件下载错误，偏移不匹配");

                downloadedEnd = clientCore.downloadFileResponse.FileDownload_IsEndPack == true;
                downloadedData.AddRange(clientCore.downloadFileResponse.FileDownload_FileData);
                getCount = clientCore.downloadFileResponse.FileDownload_FileData.Length;
                downloadedOffset += getCount;
            }

            public override long Seek(long offset, SeekOrigin origin)
            { throw new NotSupportedException(); }
            public override void SetLength(long value)
            { throw new NotSupportedException(); }
            public override void Write(byte[] buffer, int offset, int count)
            { throw new NotSupportedException(); }
            public override void Flush()
            { throw new NotSupportedException(); }



        }

        internal void DownloadFileNOpen(FormFileList receiver, DataTempletes.FileInfo fileInfo)
        {
            ThreadPool.QueueUserWorkItem(new WaitCallback((s) =>
            {
                receiver.ShowInfoNLog("正在下载文件……", true);
                string tmpFile = DataTempletes.FileList.Item.GetPhysicalFileProfix(fileInfo.ID, fileInfo.No);
                string tmpFileSuf = Path.GetExtension(fileInfo.Name);
                if (tmpFileSuf.Length > 0) tmpFileSuf = tmpFileSuf.Substring(1);
                tmpFile += tmpFileSuf;


                StreamOutFromServer streamOutFromServer = new StreamOutFromServer(this, fileInfo);
                //FileDownloader streamOutFromServer = new FileDownloader(this, fileInfo);
                int bufferLength = 524288;// 0.5M-524288
                byte[] buffer = new byte[bufferLength];
                tmpFile = Path.Combine(fileIO.TmpDir, tmpFile);
                if (File.Exists(tmpFile))
                    File.Delete(tmpFile);
                using (FileStream fs = new FileStream(tmpFile, FileMode.CreateNew))
                {
                    int readLength;
                    int totalStep = (int)System.Math.Ceiling((double)fileInfo.Size / bufferLength);
                    int curStep = 1;
                    while (true)
                    {
                        receiver.ShowInfoNLog($"正在下载文件……({curStep++}/{totalStep})", true);
                        readLength = streamOutFromServer.Read(buffer, 0, bufferLength);
                        if (readLength == 0)
                            break;
                        fs.Write(buffer, 0, readLength);
                    }
                    fs.Flush();
                }
                streamOutFromServer.Close();
                streamOutFromServer.Dispose();


                ThreadPool.QueueUserWorkItem(new WaitCallback((s1) =>
                { Process.Start(tmpFile); }));

                receiver.ShowInfoNLog("已下载文件到临时目录，并打开");
            }));
        }

        internal void DownloadXlsFileNFillData(FormSignOff receiver, DataTempletes.SignOffList.Item signOffData)
        {
            ThreadPool.QueueUserWorkItem(new WaitCallback((s) =>
            {
                receiver.ShowNLogInfo("正在下载模板……", true);
                string tmpFile = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                tmpFile = Path.Combine(tmpFile, $"国网物资领用表-{LoginUser.ID} 填表 {DateTime.Now.ToString("yyyy MMdd")}.xlsx");

                using (StreamOutFromServer streamOutFromServer
                    = new StreamOutFromServer(this, new DataTempletes.FileInfo()
                    { ID = 0, No = 1, }))
                {
                    int bufferLength = 524288;// 0.5M-524288
                    byte[] buffer = new byte[bufferLength];
                    tmpFile = Path.Combine(fileIO.TmpDir, tmpFile);
                    if (File.Exists(tmpFile))
                        File.Delete(tmpFile);
                    using (FileStream fs = new FileStream(tmpFile, FileMode.CreateNew))
                    {
                        int readLength;
                        int downedBytes = 0;
                        while (true)
                        {
                            receiver.ShowNLogInfo($"正在下载模板……({SimpleStringHelper.UnitsOfMeasure.GetShortString(downedBytes, "B", 1024)}", true);
                            readLength = streamOutFromServer.Read(buffer, 0, bufferLength);
                            if (readLength == 0)
                                break;
                            fs.Write(buffer, 0, readLength);
                        }
                        fs.Flush();
                    }
                }

                receiver.ShowNLogInfo("正在启动Excel...", true);
                try
                {
                    ExcelHelper excel = new ExcelHelper();
                    excel.Show_Window();
                    excel.Open_ExcelFile(tmpFile, false);
                    ExcelHelper.Book.Sheet workingSheet = excel.Books[0].Sheets[0];

                    // flags in A20
                    //Usage-B5,Model-B3,Manufacturer-F4,
                    //Quantity-B4,QuantityUnit-D4,ERP_PID-F3,
                    //Status-B6,UserID-D2,DateNow-F2,   <--- 
                    //DateOperated-D6,DateRetirement-F6,PlacementLocation-F5,Remark-B7,

                    receiver.ShowNLogInfo("正在获取填充坐标...", true);
                    Dictionary<string, string> flags = new Dictionary<string, string>();
                    #region load flags
                    string[] flagPairs
                        = workingSheet.Get_CellValue(0, 19, false)
                            .Split(new string[] { ",", " " }, StringSplitOptions.RemoveEmptyEntries);
                    string[] pairParts;
                    foreach (string pair in flagPairs)
                    {
                        pairParts = pair.Split('-');
                        if (pairParts.Length == 2)
                        {
                            if (!flags.ContainsKey(pairParts[0]))
                                flags.Add(pairParts[0], pairParts[1]);
                        }
                    }
                    #endregion

                    receiver.ShowNLogInfo("正在填充数据...", true);
                    // fill data
                    foreach (KeyValuePair<string, string> kvPair in flags)
                    {
                        switch (kvPair.Key)
                        {
                            case "UserID":
                                workingSheet.Set_CellValue(kvPair.Value, signOffData.UserID); break;
                            case "Consumers":
                                workingSheet.Set_CellValue(kvPair.Value, signOffData.Consumers); break;
                            case "Usage":
                                workingSheet.Set_CellValue(kvPair.Value, signOffData.Usage); break;
                            case "Model":
                                workingSheet.Set_CellValue(kvPair.Value, signOffData.Model); break;
                            case "Manufacturer":
                                workingSheet.Set_CellValue(kvPair.Value, signOffData.Manufacturer); break;
                            case "Quantity":
                                workingSheet.Set_CellValue(kvPair.Value, signOffData.Quantity.ToString("G")); break;
                            case "QuantityUnit":
                                workingSheet.Set_CellValue(kvPair.Value, signOffData.QuantityUnit); break;
                            case "ERP_PID":
                                workingSheet.Set_CellValue(kvPair.Value, signOffData.ERP_PID); break;

                            case "Status":
                                workingSheet.Set_CellValue(kvPair.Value, SupplyStatus_CT[signOffData.StatusID]); break;
                            case "DateNow":
                                workingSheet.Set_CellValue(kvPair.Value, DateTime.Now.ToString("yyyy-MM-dd")); break;

                            case "DateOperated":
                                workingSheet.Set_CellValue(kvPair.Value, signOffData.DateOperated.ToString("yyyy-MM-dd")); break;
                            case "DateRetirement":
                                workingSheet.Set_CellValue(kvPair.Value, signOffData.DateRetirement.ToString("yyyy-MM-dd")); break;
                            case "PlacementLocation":
                                workingSheet.Set_CellValue(kvPair.Value, signOffData.PlacementLocation); break;
                            case "Remark":
                                workingSheet.Set_CellValue(kvPair.Value, signOffData.Remark); break;
                        }
                    }
                    workingSheet.Set_CellValue("A20", "");
                    excel.Books[0].Save();
                    receiver.ShowNLogInfo("模板填写完毕。");
                }
                catch (Exception err)
                {
                    receiver.ShowNLogError("填表失败", err);
                }
            }));
        }

        #region do not use
        // use a new socket connection to download file data
        // abandoned for security reasons
        public class FileDownloader : Stream
        {
            public Guid taskID { private set; get; }
            private DataTempletes.FileInfo serverFileInfo;
            private DataClientRequest cRequest;
            private long downloadedOffset = 0;
            private List<byte> downloadedData = new List<byte>();
            private bool downloadedEnd = false;

            public Logger logger;
            public PasswordProtector pp;
            public SocketHelper.SocketTcpClient socketClient;
            public IPAddress serverIP;
            public int serverPort;
            public string Encryption_Password { private set; get; }
            public byte Encryption_ConfusionLength { private set; get; } = 13;
            public FileDownloader(ClientCore core, DataTempletes.FileInfo fileInfo)
            {
                if (core.settings.SelectedServerIPV4orIPV6)
                    serverIP = core.settings.ServerIPV4;
                else
                    serverIP = core.settings.ServerIPV6;
                serverPort = (int)core.settings.ServerPort;

                taskID = Guid.NewGuid();
                serverFileInfo = fileInfo.Clone();
                string startUpPath = Application.StartupPath;
                logger = new Logger()
                { BaseDir = Path.Combine(startUpPath, "Log"), };

                pp = PasswordProtector.GetInstance(
                    Path.Combine(startUpPath, "Encry.cer"),
                    "u$kjl!&wZv@%@qw*rNTh$DMBQ$t@D!rX*FOa");
                pp.Password = core.pp.Password;
                Encryption_Password = pp.Password_forCipher;
                Encryption_ConfusionLength = core.Encryption_ConfusionLength;

                socketClient = new SocketHelper.SocketTcpClient();
                socketClient.ServerConnected += SocketClient_ServerConnected;
                socketClient.ServerDataReceived += SocketClient_ServerDataReceived;
                socketClient.ServerReceiveError += SocketClient_ServerReceiveError;
                socketClient.ServerReceiveTimeout += SocketClient_ServerReceiveTimeout;

                ConnectServer();
            }

            public bool ConnectServer()
            {
                Exception err;
                bool result = socketClient.Connect(
                    serverIP, serverPort, out err);
                if (err != null)
                    logger.Log(err);
                return result;
            }
            private void SendRequest(DataClientRequest request)
            {
                socketClient.socket.Send(
                    EncryptedGZip.EncryptGZip(
                        request.Data, Encryption_Password, Encryption_ConfusionLength));
            }
            private void SocketClient_ServerConnected(SocketHelper.SocketTcpClient sender)
            {
                logger.Log("File downloading, server connection established.");
            }
            private void SocketClient_ServerReceiveTimeout(SocketHelper.SocketTcpClient sender)
            {
                logger.Log("File downloading, server connection timeout.");
                MessageBoxAlone.Show("服务器连接超时，长时间得不到响应", "错误", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            private void SocketClient_ServerReceiveError(SocketHelper.SocketTcpClient sender, Exception err)
            {
                logger.Log(err);
                MessageBoxAlone.Show(err.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            private void SocketClient_ServerDataReceived(SocketHelper.SocketTcpClient sender, byte[] data)
            {
                logger.Log($"File downloading, receive data from server, [{data.Length}] bytes.");
                data = EncryptedGZip.UnGZipDecrypt(data, Encryption_Password, Encryption_ConfusionLength);

                Flags.Types[] outTypes;
                object[] dataArray = DataReceiver.GetDataInstances(data, out outTypes);
                object dataObj;
                for (int i = 0, iv = outTypes.Length; i < iv; i++)
                {
                    dataObj = dataArray[i];
                    switch (outTypes[i])
                    {
                        default:
                            {
                                logger.Log("File downloading, un-related data for downloading file: " + SimpleStringHelper.ToHexString(data));
                                MessageBoxAlone.Show(
                                    $"收到文件下载无关数据，[{data.Length}] bytes，请查看日志文件。",
                                    "无关数据", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                break;
                            }
                        case Flags.Types.ResponseFileDownload:
                            {
                                downloadFileResponse = (DataServerResponse)dataObj;
                                // like upload, processing in loop
                                // do nothing, receive data inside stream instance;
                                break;
                            }
                    }
                }
            }
            DataServerResponse downloadFileResponse = null;
            public override int Read(byte[] buffer, int offset, int count)
            {
                if (offset < 0)
                    throw new IndexOutOfRangeException("仅支持顺序读取，无法回溯");

                if (downloadedData.Count < count && !downloadedEnd)
                    DownloadNextDataPack(offset + count);

                int downloadedDataCount = downloadedData.Count;

                if (offset <= downloadedDataCount)
                    downloadedData.RemoveRange(0, offset);
                else
                    downloadedData.Clear();

                if (count > downloadedData.Count)
                    count = downloadedData.Count;

                Array.Copy(downloadedData.GetRange(0, count).ToArray(), buffer, count);
                downloadedData.RemoveRange(0, count);

                Position += count;
                return count;
            }
            private void DownloadNextDataPack(int minCount)
            {
                downloadFileResponse = null;
                cRequest = new DataClientRequest(Flags.Types.RequestFileDownload)
                {
                    FileDownload_TaskID = taskID,
                    FileDownload_ID = serverFileInfo.ID,
                    FileDownload_No = serverFileInfo.No,
                    FileDownload_Name = serverFileInfo.Name,
                    FileDownload_Position = downloadedOffset,
                    FileDownload_Length = 524288, // 512K-524288
                };
                SendRequest(cRequest);

                int getCount = 0;
                CaptureFileDataNCheck(ref getCount, DateTime.Now);
                if (getCount < minCount && !downloadedEnd)
                    DownloadNextDataPack(minCount - getCount);
            }
            private void CaptureFileDataNCheck(ref int getCount, DateTime startTime)
            {
                while (downloadFileResponse == null)
                {
                    Thread.Sleep(10);
                    if ((DateTime.Now - startTime).TotalSeconds > 30)
                        throw new TimeoutException("下载文件超时，已经超过30秒");
                }
                if (downloadFileResponse.FileDownload_TaskID != taskID)
                {
                    downloadFileResponse = null;
                    CaptureFileDataNCheck(ref getCount, startTime);
                    return;
                }
                if (downloadFileResponse.FileDownload_Result != true)
                {
                    if (downloadFileResponse.FileDownload_Error != null)
                        throw downloadFileResponse.FileDownload_Error;
                    else
                        throw new Exception("文件下载失败，且没有报错数据");
                }
                if (downloadFileResponse.FileDownload_Position != downloadedOffset)
                    throw new ArgumentOutOfRangeException("文件下载错误，偏移不匹配");

                downloadedEnd = downloadFileResponse.FileDownload_IsEndPack == true;
                downloadedData.AddRange(downloadFileResponse.FileDownload_FileData);
                getCount = downloadFileResponse.FileDownload_FileData.Length;
                downloadedOffset += getCount;
            }

            public override long Seek(long offset, SeekOrigin origin)
            { throw new NotSupportedException(); }
            public override void SetLength(long value)
            { throw new NotSupportedException(); }
            public override void Write(byte[] buffer, int offset, int count)
            { throw new NotSupportedException(); }
            public override void Flush()
            { throw new NotSupportedException(); }

            public override bool CanRead => true;

            public override bool CanSeek => false;

            public override bool CanWrite => false;

            public override long Length
            { get => serverFileInfo.Size; }

            public override long Position { get; set; }
        }
        #endregion

        #endregion

        internal void DeleteFile(DataTempletes.FileInfo fileInfo)
        {
            DataClientRequest request = new DataClientRequest(Flags.Types.RequestFileDelete)
            { FileDelete_ID = fileInfo.ID, FileDelete_No = fileInfo.No, };
            SendRequest(request);
        }
        #endregion

        #region sign off

        internal void ShowDialog_SignOff(DataTempletes.SupplyList.Item supplyInfo)
        {
            formSignOff.Init(supplyInfo);
            formSignOff.ShowDialog();
        }

        private void FormSignOff_FormClosing(object sender, FormClosingEventArgs e)
        {
            // do nothing
        }

        internal void QuerySupplyStatus()
        {
            DataClientRequest request = new DataClientRequest(Flags.Types.RequestSupplyStatus)
            { };
            SendRequest(request);
        }

        internal void QuerySignOffs(string userID, Guid supplyID)
        {
            DataClientRequest request = new DataClientRequest(Flags.Types.RequestSignOffList)
            { SignOffList_SupplyID = supplyID, SignOffList_UserID = userID, };
            SendRequest(request);
        }

        internal void QuerySignOffCount(Guid supplyID)
        {
            DataClientRequest request = new DataClientRequest(Flags.Types.RequestSignOffCount)
            { SignOffCount_SupplyID = supplyID, };
            SendRequest(request);
        }
        internal void AccessSignOff(DataTempletes.SignOffList.Item item, DataTempletes.RequestDataOperatTypes operatType)
        {
            DataClientRequest request;
            switch (operatType)
            {
                case DataTempletes.RequestDataOperatTypes.Insert:
                case DataTempletes.RequestDataOperatTypes.Update:
                    {
                        request = new DataClientRequest(Flags.Types.RequestAccessSignOff)
                        {
                            AccessSignOff_ID = item.ID,
                            AccessSignOff_OpType = operatType,
                            AccessSignOff_Data = item,
                        };
                        SendRequest(request);
                        break;
                    }
                case DataTempletes.RequestDataOperatTypes.Delete:
                    {
                        request = new DataClientRequest(Flags.Types.RequestAccessSignOff)
                        {
                            AccessSignOff_ID = item.ID,
                            AccessSignOff_OpType = operatType,
                            //AccessSignOff_Data = item,
                        };
                        SendRequest(request);
                        break;
                    }
                default:
                case DataTempletes.RequestDataOperatTypes.Select:
                    {
                        formSignOff.ShowNLogInfo("未知操作，或暂不支持使用通用方法读取列表");
                        break;
                    }
            }
        }

        #endregion

        public void Dispose()
        {
            socketClient.ServerReceiveError -= SocketClient_ServerReceiveError;
            socketClient?.Dispose();

        }

    }
}
