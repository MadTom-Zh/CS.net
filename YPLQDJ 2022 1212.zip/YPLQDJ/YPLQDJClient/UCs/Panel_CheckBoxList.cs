﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace MadTomDev.App.YPLQDJ.UCs
{
    public partial class Panel_CheckBoxList : UserControl
    {
        public Panel_CheckBoxList()
        {
            InitializeComponent();
        }
    }
}
