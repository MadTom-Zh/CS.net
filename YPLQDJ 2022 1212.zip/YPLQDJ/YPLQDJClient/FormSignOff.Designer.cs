﻿namespace MadTomDev.App.YPLQDJ
{
    partial class FormSignOff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.button_save = new System.Windows.Forms.Button();
            this.dataGridView_list = new System.Windows.Forms.DataGridView();
            this.textBox_description = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_supplier = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_projFullName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel_info = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel_spring = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar_info = new System.Windows.Forms.ToolStripProgressBar();
            this.textBox_RemainingQuantity = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button_downloadTpl_FillNOpen = new System.Windows.Forms.Button();
            this.button_downloadTpl = new System.Windows.Forms.Button();
            this.button_uploadTpl = new System.Windows.Forms.Button();
            this.button_refreshSignOffList = new System.Windows.Forms.Button();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.betterFolderBrowser = new WK.Libraries.BetterFolderBrowserNS.BetterFolderBrowser(this.components);
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Consumers = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_list)).BeginInit();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_save
            // 
            this.button_save.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_save.Location = new System.Drawing.Point(1200, 505);
            this.button_save.Name = "button_save";
            this.button_save.Size = new System.Drawing.Size(91, 25);
            this.button_save.TabIndex = 23;
            this.button_save.Text = "保存";
            this.button_save.UseVisualStyleBackColor = true;
            this.button_save.Click += new System.EventHandler(this.button_save_Click);
            // 
            // dataGridView_list
            // 
            this.dataGridView_list.AllowUserToOrderColumns = true;
            this.dataGridView_list.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_list.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_list.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Consumers,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column6,
            this.Column7,
            this.Column11,
            this.Column12});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_list.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView_list.Location = new System.Drawing.Point(20, 64);
            this.dataGridView_list.Name = "dataGridView_list";
            this.dataGridView_list.Size = new System.Drawing.Size(1271, 438);
            this.dataGridView_list.TabIndex = 20;
            this.dataGridView_list.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dataGridView_list_CellBeginEdit);
            this.dataGridView_list.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_list_CellClick);
            this.dataGridView_list.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_list_CellContentClick);
            this.dataGridView_list.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_list_CellEndEdit);
            this.dataGridView_list.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dataGridView_list_CellPainting);
            this.dataGridView_list.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_list_CellValueChanged);
            this.dataGridView_list.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dataGridView_list_KeyDown);
            // 
            // textBox_description
            // 
            this.textBox_description.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_description.Location = new System.Drawing.Point(92, 38);
            this.textBox_description.Name = "textBox_description";
            this.textBox_description.ReadOnly = true;
            this.textBox_description.Size = new System.Drawing.Size(911, 20);
            this.textBox_description.TabIndex = 19;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 18;
            this.label3.Text = "采购内容";
            // 
            // textBox_supplier
            // 
            this.textBox_supplier.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_supplier.Location = new System.Drawing.Point(1106, 12);
            this.textBox_supplier.Name = "textBox_supplier";
            this.textBox_supplier.ReadOnly = true;
            this.textBox_supplier.Size = new System.Drawing.Size(185, 20);
            this.textBox_supplier.TabIndex = 17;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1019, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "供应商";
            // 
            // textBox_projFullName
            // 
            this.textBox_projFullName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_projFullName.Location = new System.Drawing.Point(92, 12);
            this.textBox_projFullName.Name = "textBox_projFullName";
            this.textBox_projFullName.ReadOnly = true;
            this.textBox_projFullName.Size = new System.Drawing.Size(911, 20);
            this.textBox_projFullName.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "项目名称";
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel_info,
            this.toolStripStatusLabel_spring,
            this.toolStripProgressBar_info});
            this.statusStrip.Location = new System.Drawing.Point(0, 531);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(1307, 22);
            this.statusStrip.TabIndex = 26;
            this.statusStrip.Text = "statusStrip_info";
            // 
            // toolStripStatusLabel_info
            // 
            this.toolStripStatusLabel_info.Name = "toolStripStatusLabel_info";
            this.toolStripStatusLabel_info.Size = new System.Drawing.Size(59, 17);
            this.toolStripStatusLabel_info.Text = "Loading...";
            // 
            // toolStripStatusLabel_spring
            // 
            this.toolStripStatusLabel_spring.Name = "toolStripStatusLabel_spring";
            this.toolStripStatusLabel_spring.Size = new System.Drawing.Size(1131, 17);
            this.toolStripStatusLabel_spring.Spring = true;
            // 
            // toolStripProgressBar_info
            // 
            this.toolStripProgressBar_info.Name = "toolStripProgressBar_info";
            this.toolStripProgressBar_info.Size = new System.Drawing.Size(100, 16);
            // 
            // textBox_RemainingQuantity
            // 
            this.textBox_RemainingQuantity.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_RemainingQuantity.Location = new System.Drawing.Point(1106, 38);
            this.textBox_RemainingQuantity.Name = "textBox_RemainingQuantity";
            this.textBox_RemainingQuantity.ReadOnly = true;
            this.textBox_RemainingQuantity.Size = new System.Drawing.Size(185, 20);
            this.textBox_RemainingQuantity.TabIndex = 28;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1019, 41);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 13);
            this.label4.TabIndex = 27;
            this.label4.Text = "已领取/总数";
            // 
            // button_downloadTpl_FillNOpen
            // 
            this.button_downloadTpl_FillNOpen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_downloadTpl_FillNOpen.Location = new System.Drawing.Point(1066, 505);
            this.button_downloadTpl_FillNOpen.Name = "button_downloadTpl_FillNOpen";
            this.button_downloadTpl_FillNOpen.Size = new System.Drawing.Size(131, 25);
            this.button_downloadTpl_FillNOpen.TabIndex = 29;
            this.button_downloadTpl_FillNOpen.Text = "填充模板并打开";
            this.button_downloadTpl_FillNOpen.UseVisualStyleBackColor = true;
            this.button_downloadTpl_FillNOpen.Click += new System.EventHandler(this.button_downloadTpl_FillNOpen_Click);
            // 
            // button_downloadTpl
            // 
            this.button_downloadTpl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_downloadTpl.Location = new System.Drawing.Point(969, 505);
            this.button_downloadTpl.Name = "button_downloadTpl";
            this.button_downloadTpl.Size = new System.Drawing.Size(91, 25);
            this.button_downloadTpl.TabIndex = 30;
            this.button_downloadTpl.Text = "下载模板...";
            this.button_downloadTpl.UseVisualStyleBackColor = true;
            this.button_downloadTpl.Click += new System.EventHandler(this.button_downloadTpl_Click);
            // 
            // button_uploadTpl
            // 
            this.button_uploadTpl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_uploadTpl.Location = new System.Drawing.Point(872, 505);
            this.button_uploadTpl.Name = "button_uploadTpl";
            this.button_uploadTpl.Size = new System.Drawing.Size(91, 25);
            this.button_uploadTpl.TabIndex = 31;
            this.button_uploadTpl.Text = "上传模板...";
            this.button_uploadTpl.UseVisualStyleBackColor = true;
            this.button_uploadTpl.Click += new System.EventHandler(this.button_uploadTpl_Click);
            // 
            // button_refreshSignOffList
            // 
            this.button_refreshSignOffList.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button_refreshSignOffList.Location = new System.Drawing.Point(20, 503);
            this.button_refreshSignOffList.Name = "button_refreshSignOffList";
            this.button_refreshSignOffList.Size = new System.Drawing.Size(91, 25);
            this.button_refreshSignOffList.TabIndex = 32;
            this.button_refreshSignOffList.Text = "刷新";
            this.button_refreshSignOffList.UseVisualStyleBackColor = true;
            this.button_refreshSignOffList.Click += new System.EventHandler(this.button_refreshSignOffList_Click);
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker.Location = new System.Drawing.Point(251, 147);
            this.dateTimePicker.MinDate = new System.DateTime(2017, 9, 5, 0, 0, 0, 0);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(98, 20);
            this.dateTimePicker.TabIndex = 33;
            this.dateTimePicker.Value = new System.DateTime(2020, 8, 1, 0, 0, 0, 0);
            this.dateTimePicker.Visible = false;
            this.dateTimePicker.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dateTimePicker_KeyDown);
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(117, 511);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(690, 13);
            this.label5.TabIndex = 34;
            this.label5.Text = "* 在最下面的空行新增条目；选中整行后，按Del删除；上传的模板必须符合填充标记要求；选中需要填充的整行，点击填充模板；";
            // 
            // betterFolderBrowser
            // 
            this.betterFolderBrowser.Multiselect = false;
            this.betterFolderBrowser.RootFolder = "C:\\Personal\\Desktop";
            this.betterFolderBrowser.Title = "请选择模板的下载位置...";
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column1.Frozen = true;
            this.Column1.HeaderText = "序号";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 56;
            // 
            // Consumers
            // 
            this.Consumers.HeaderText = "领用人";
            this.Consumers.Name = "Consumers";
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Column2.DefaultCellStyle = dataGridViewCellStyle1;
            this.Column2.HeaderText = "用途";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "规格型号";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column4.HeaderText = "制造商";
            this.Column4.Name = "Column4";
            this.Column4.Width = 68;
            // 
            // Column5
            // 
            this.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column5.HeaderText = "数量";
            this.Column5.Name = "Column5";
            this.Column5.Width = 56;
            // 
            // Column8
            // 
            this.Column8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column8.HeaderText = "数量单位";
            this.Column8.Name = "Column8";
            this.Column8.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column8.Width = 80;
            // 
            // Column9
            // 
            this.Column9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column9.HeaderText = "ERP资产编码";
            this.Column9.Name = "Column9";
            this.Column9.Width = 102;
            // 
            // Column10
            // 
            this.Column10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column10.HeaderText = "物资状态";
            this.Column10.Name = "Column10";
            this.Column10.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column10.Width = 80;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "投运日期";
            this.Column6.Name = "Column6";
            this.Column6.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "退役日期";
            this.Column7.Name = "Column7";
            this.Column7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // Column11
            // 
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Column11.DefaultCellStyle = dataGridViewCellStyle2;
            this.Column11.HeaderText = "放置位置";
            this.Column11.Name = "Column11";
            this.Column11.Width = 150;
            // 
            // Column12
            // 
            this.Column12.HeaderText = "备注";
            this.Column12.Name = "Column12";
            // 
            // FormSignOff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1307, 553);
            this.Controls.Add(this.button_save);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dateTimePicker);
            this.Controls.Add(this.button_refreshSignOffList);
            this.Controls.Add(this.button_uploadTpl);
            this.Controls.Add(this.button_downloadTpl);
            this.Controls.Add(this.button_downloadTpl_FillNOpen);
            this.Controls.Add(this.textBox_RemainingQuantity);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.dataGridView_list);
            this.Controls.Add(this.textBox_description);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox_supplier);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox_projFullName);
            this.Controls.Add(this.label1);
            this.Name = "FormSignOff";
            this.Text = "物资领取信息";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormSignOff_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_list)).EndInit();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button_save;
        private System.Windows.Forms.DataGridView dataGridView_list;
        private System.Windows.Forms.TextBox textBox_description;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_supplier;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_projFullName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel_info;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel_spring;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar_info;
        private System.Windows.Forms.TextBox textBox_RemainingQuantity;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button_downloadTpl_FillNOpen;
        private System.Windows.Forms.Button button_downloadTpl;
        private System.Windows.Forms.Button button_uploadTpl;
        private System.Windows.Forms.Button button_refreshSignOffList;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.Label label5;
        private WK.Libraries.BetterFolderBrowserNS.BetterFolderBrowser betterFolderBrowser;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Consumers;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewComboBoxColumn Column10;
        private System.Windows.Forms.DataGridViewLinkColumn Column6;
        private System.Windows.Forms.DataGridViewLinkColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
    }
}