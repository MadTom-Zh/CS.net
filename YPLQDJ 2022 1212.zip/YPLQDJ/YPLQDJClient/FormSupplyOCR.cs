﻿using MadTomDev.Data;
using MadTomDev.UIs;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Gma.UserActivityMonitor;

namespace MadTomDev.App.YPLQDJ
{
    public partial class FormSupplyOCR : Form
    {
        public FormSupplyOCR()
        {
            InitializeComponent();
            InitDataGridRows();
        }
        private void InitDataGridRows()
        {
            dataGridView_OCRResult.Rows.Add(1, "项目名称", null);
            dataGridView_OCRResult.Rows.Add(2, "项目定义", null);
            dataGridView_OCRResult.Rows.Add(3, "采购内容", null);
            dataGridView_OCRResult.Rows.Add(4, "数量", null);
            dataGridView_OCRResult.Rows.Add(5, "供应商", null);
            dataGridView_OCRResult.Rows.Add(6, "交货日期", null);
        }

        public ClientCore core;
        private OCRInGrids ocr;
        private ScreenSelectorCore ssCore;
        private void FormSupplyOCR_Load(object sender, EventArgs e)
        {
            ocr = new OCRInGrids();
            ocr.OCRError += Ocr_OCRError;
            ocr.OCRComplete += Ocr_OCRComplete;
            ssCore = new ScreenSelectorCore()
            { HotKeyEnabled = false, };
            ssCore.SelectEnd += SsCore_SelectEnd;
        }


        private void FormSupplyOCR_FormClosing(object sender, FormClosingEventArgs e)
        { StopOCR(); e.Cancel = true; this.Hide(); }
        private delegate void ShowInfoDelegate(string text);
        private void ShowInfo(string text)
        {
            if (InvokeRequired)
            {
                ShowInfoDelegate callback = new ShowInfoDelegate(ShowInfo);
                Invoke(callback, text);
            }
            else
            {
                label_info.Text = text;
                Update();
            }
        }


        public bool Result = false;
        public List<object> OCRResult
        {
            get
            {
                if (!CheckValues())
                    return null;
                List<object> result = new List<object>();
                object test = dataGridView_OCRResult.Rows[0].Cells[2].Value;
                result.Add(test == null ? null : test.ToString());
                test = dataGridView_OCRResult.Rows[1].Cells[2].Value;
                result.Add(test == null ? null : test.ToString());
                test = dataGridView_OCRResult.Rows[2].Cells[2].Value;
                result.Add(test == null ? null : test.ToString());
                test = dataGridView_OCRResult.Rows[3].Cells[2].Value;
                result.Add(decimal.Parse(test.ToString()));
                test = dataGridView_OCRResult.Rows[4].Cells[2].Value;
                result.Add(test == null ? null : test.ToString());
                test = dataGridView_OCRResult.Rows[5].Cells[2].Value;
                result.Add(DateTime.Parse(test.ToString()));
                return result;
            }
        }
        internal void Reset()
        {
            Result = false;
            foreach (DataGridViewRow dgvr in dataGridView_OCRResult.Rows)
                dgvr.Cells[2].Value = null;
            StartOCR();
            label_info.Text = "就绪";
        }

        private void button_ok_Click(object sender, EventArgs e)
        {
            if (!CheckValues())
            {
                MessageBox.Show(this, "数量 或 日期 格式不正确。", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Result = true;
            this.Close();
        }
        private bool CheckValues()
        {
            try
            {                
                object test = dataGridView_OCRResult.Rows[3].Cells[2].Value;
                if (test == null)
                    return false;
                test = decimal.Parse(test.ToString());
                test = dataGridView_OCRResult.Rows[5].Cells[2].Value;
                if (test == null)
                    return false;
                test = DateTime.Parse(test.ToString());
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        private void button_cancel_Click(object sender, EventArgs e)
        { this.Close(); }


        public void StartOCR()
        {
            StopOCR();
            HookManager.KeyDown += HookManager_KeyDown;
            ShowInfo("OCR就绪，使用快捷键启动，也可以手动输入。");
        }
        public void StopOCR()
        {
            HookManager.KeyDown -= HookManager_KeyDown;
            ShowInfo("OCR已经关闭");
        }


        /// <summary>
        /// 0-projName, 1-Definition, 2-supply, 3-quantity, 4-supplier, 5-deliDate;
        /// 10-alt+1-table(1,3->2,3)
        /// </summary>
        private int ocrType = -1;
        private void HookManager_KeyDown(object sender, KeyEventArgs e)
        {
            if (dataGridView_OCRResult.SelectedCells.Count == 1
                && dataGridView_OCRResult.SelectedCells[0].ColumnIndex == 2
                )
                return;

            bool startSS = false;
            if (e.Alt)
            {
                switch (e.KeyCode)
                {
                    case Keys.D1:
                        ocrType = 10;
                        startSS = true;
                        break;
                }
            }
            else if (e.Shift)
            {
            }
            else if (e.Control)
            {
            }
            else
            {
                switch (e.KeyCode)
                {
                    case Keys.D1:
                        ocrType = 0;
                        startSS = true;
                        break;
                    case Keys.D2:
                        ocrType = 1;
                        startSS = true;
                        break;
                    case Keys.D3:
                        ocrType = 2;
                        startSS = true;
                        break;
                    case Keys.D4:
                        ocrType = 3;
                        startSS = true;
                        break;
                    case Keys.D5:
                        ocrType = 4;
                        startSS = true;
                        break;
                    case Keys.D6:
                        ocrType = 5;
                        startSS = true;
                        break;
                }
            }
            if (startSS)
            {
                ShowInfo("开始截图...");
                ssCore.StartSelect();
            }
        }
        private void SsCore_SelectEnd(object sender, bool isCanceled, Bitmap selectedImg)
        {
            if (isCanceled)
            {
                ShowInfo("截图已取消。");
                return;
            }

            ShowInfo("截图完成，正在OCR...");
            ocr.OCR_async(selectedImg, 500);
        }
        private void Ocr_OCRError(OCRInGrids sender, Exception err)
        {
            ShowInfo($"OCR遇到错误：{err.Message}");
        }
        private void Ocr_OCRComplete(OCRInGrids sender, List<OCRInGrids.ParagraphData> result)
        {
            ShowInfo("OCR识别完成");
            if (result.Count == 0)
            {
                ShowInfo("OCR未识别到文字");
                return;
            }
            switch (ocrType)
            {
                case 0:
                    {
                        if (CheckTextNShowInfo(result[0].Text))
                            dataGridView_OCRResult.Rows[0].Cells[2].Value = result[0].Text;
                        break;
                    }
                case 1:
                    {
                        if (CheckTextNShowInfo(result[0].Text))
                            dataGridView_OCRResult.Rows[1].Cells[2].Value = result[0].Text;
                        break;
                    }
                case 2:
                    {
                        if (CheckTextNShowInfo(result[0].Text))
                            dataGridView_OCRResult.Rows[2].Cells[2].Value = result[0].Text;
                        break;
                    }
                case 3:
                    {
                        if (CheckTextNShowInfo(result[0].Text))
                            dataGridView_OCRResult.Rows[3].Cells[2].Value = result[0].Text;
                        break;
                    }
                case 4:
                    {
                        if (CheckTextNShowInfo(result[0].Text))
                            dataGridView_OCRResult.Rows[4].Cells[2].Value = result[0].Text;
                        break;
                    }
                case 5:
                    {
                        if (CheckTextNShowInfo(result[0].Text))
                            dataGridView_OCRResult.Rows[5].Cells[2].Value = result[0].Text;
                        break;
                    }


                case 10:
                    {
                        if (result[0].table == null)
                        {
                            ShowInfo("未识别到表格");
                            break;
                        }
                        if (result[0].table.collomnCount < 4)
                        {
                            ShowInfo($"表格列数不足，只有{result[0].table.collomnCount}列");
                            break;
                        }
                        string test1 = result[0].GetCellValue(1, 0);
                        string test2 = result[0].GetCellValue(3, 0);
                        if (string.IsNullOrWhiteSpace(test1)
                            && string.IsNullOrWhiteSpace(test1))
                        {
                            ShowInfo("未识别到 物品名称 和 物品数量");
                        }
                        else
                        {
                            if (!string.IsNullOrWhiteSpace(test1))
                                dataGridView_OCRResult.Rows[2].Cells[2].Value = test1;
                            else
                                ShowInfo("未识别到 物品名称");
                            if (!string.IsNullOrWhiteSpace(test2))
                                dataGridView_OCRResult.Rows[3].Cells[2].Value = test2;
                            else
                                ShowInfo("未识别到 物品数量");
                        }
                        break;
                    }
            }
        }
        private bool CheckTextNShowInfo(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                ShowInfo("文字内容为空");
                return false;
            }
            return true;
        }


        private void button_a1_Click(object sender, EventArgs e)
        {
            ocrType = 10;
            ShowInfo("开始截图...");
            ssCore.StartSelect();
        }

    }
}
