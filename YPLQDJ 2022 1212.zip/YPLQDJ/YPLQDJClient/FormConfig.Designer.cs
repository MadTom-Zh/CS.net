﻿namespace MadTomDev.App.YPLQDJ
{
    partial class FormConfig
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage_server = new System.Windows.Forms.TabPage();
            this.textBox_serverPort = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_serverIPv4 = new System.Windows.Forms.TextBox();
            this.button_ok = new System.Windows.Forms.Button();
            this.button_cancel = new System.Windows.Forms.Button();
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.radioButton_addrIPV4 = new System.Windows.Forms.RadioButton();
            this.radioButton_addrIPV6 = new System.Windows.Forms.RadioButton();
            this.textBox_serverIPv6 = new System.Windows.Forms.TextBox();
            this.tabControl.SuspendLayout();
            this.tabPage_server.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl.Controls.Add(this.tabPage_server);
            this.tabControl.Location = new System.Drawing.Point(12, 12);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(386, 374);
            this.tabControl.TabIndex = 0;
            // 
            // tabPage_server
            // 
            this.tabPage_server.Controls.Add(this.radioButton_addrIPV6);
            this.tabPage_server.Controls.Add(this.radioButton_addrIPV4);
            this.tabPage_server.Controls.Add(this.textBox_serverPort);
            this.tabPage_server.Controls.Add(this.label2);
            this.tabPage_server.Controls.Add(this.textBox_serverIPv6);
            this.tabPage_server.Controls.Add(this.textBox_serverIPv4);
            this.tabPage_server.Location = new System.Drawing.Point(4, 22);
            this.tabPage_server.Name = "tabPage_server";
            this.tabPage_server.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_server.Size = new System.Drawing.Size(378, 348);
            this.tabPage_server.TabIndex = 0;
            this.tabPage_server.Text = "服务器";
            this.tabPage_server.UseVisualStyleBackColor = true;
            // 
            // textBox_serverPort
            // 
            this.textBox_serverPort.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_serverPort.Location = new System.Drawing.Point(280, 45);
            this.textBox_serverPort.Name = "textBox_serverPort";
            this.textBox_serverPort.Size = new System.Drawing.Size(75, 20);
            this.textBox_serverPort.TabIndex = 3;
            this.textBox_serverPort.Validating += new System.ComponentModel.CancelEventHandler(this.textBox_serverPort_Validating);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(277, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "端口号";
            // 
            // textBox_serverIPv4
            // 
            this.textBox_serverIPv4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_serverIPv4.Location = new System.Drawing.Point(84, 19);
            this.textBox_serverIPv4.Name = "textBox_serverIPv4";
            this.textBox_serverIPv4.Size = new System.Drawing.Size(170, 20);
            this.textBox_serverIPv4.TabIndex = 1;
            this.textBox_serverIPv4.Validating += new System.ComponentModel.CancelEventHandler(this.textBox_serverIPv4_Validating);
            // 
            // button_ok
            // 
            this.button_ok.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ok.Location = new System.Drawing.Point(238, 392);
            this.button_ok.Name = "button_ok";
            this.button_ok.Size = new System.Drawing.Size(75, 23);
            this.button_ok.TabIndex = 1;
            this.button_ok.Text = "确定";
            this.button_ok.UseVisualStyleBackColor = true;
            this.button_ok.Click += new System.EventHandler(this.button_ok_Click);
            // 
            // button_cancel
            // 
            this.button_cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_cancel.Location = new System.Drawing.Point(319, 392);
            this.button_cancel.Name = "button_cancel";
            this.button_cancel.Size = new System.Drawing.Size(75, 23);
            this.button_cancel.TabIndex = 1;
            this.button_cancel.Text = "取消";
            this.button_cancel.UseVisualStyleBackColor = true;
            this.button_cancel.Click += new System.EventHandler(this.button_cancel_Click);
            // 
            // errorProvider
            // 
            this.errorProvider.ContainerControl = this;
            // 
            // radioButton_addrIPV4
            // 
            this.radioButton_addrIPV4.AutoSize = true;
            this.radioButton_addrIPV4.Location = new System.Drawing.Point(6, 20);
            this.radioButton_addrIPV4.Name = "radioButton_addrIPV4";
            this.radioButton_addrIPV4.Size = new System.Drawing.Size(72, 17);
            this.radioButton_addrIPV4.TabIndex = 4;
            this.radioButton_addrIPV4.TabStop = true;
            this.radioButton_addrIPV4.Text = "IPV4地址";
            this.radioButton_addrIPV4.UseVisualStyleBackColor = true;
            this.radioButton_addrIPV4.CheckedChanged += new System.EventHandler(this.radioButton_addrIPV4_CheckedChanged);
            // 
            // radioButton_addrIPV6
            // 
            this.radioButton_addrIPV6.AutoSize = true;
            this.radioButton_addrIPV6.Location = new System.Drawing.Point(6, 46);
            this.radioButton_addrIPV6.Name = "radioButton_addrIPV6";
            this.radioButton_addrIPV6.Size = new System.Drawing.Size(72, 17);
            this.radioButton_addrIPV6.TabIndex = 4;
            this.radioButton_addrIPV6.TabStop = true;
            this.radioButton_addrIPV6.Text = "IPV6地址";
            this.radioButton_addrIPV6.UseVisualStyleBackColor = true;
            this.radioButton_addrIPV6.CheckedChanged += new System.EventHandler(this.radioButton_addrIPV6_CheckedChanged);
            // 
            // textBox_serverIPv6
            // 
            this.textBox_serverIPv6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_serverIPv6.Enabled = false;
            this.textBox_serverIPv6.Location = new System.Drawing.Point(84, 45);
            this.textBox_serverIPv6.Name = "textBox_serverIPv6";
            this.textBox_serverIPv6.Size = new System.Drawing.Size(170, 20);
            this.textBox_serverIPv6.TabIndex = 1;
            this.textBox_serverIPv6.Validating += new System.ComponentModel.CancelEventHandler(this.textBox_serverIPv6_Validating);
            // 
            // FormConfig
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(410, 427);
            this.Controls.Add(this.button_cancel);
            this.Controls.Add(this.button_ok);
            this.Controls.Add(this.tabControl);
            this.Name = "FormConfig";
            this.Text = "配置";
            this.Shown += new System.EventHandler(this.FormConfig_Shown);
            this.tabControl.ResumeLayout(false);
            this.tabPage_server.ResumeLayout(false);
            this.tabPage_server.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPage_server;
        private System.Windows.Forms.Button button_ok;
        private System.Windows.Forms.Button button_cancel;
        private System.Windows.Forms.TextBox textBox_serverPort;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_serverIPv4;
        private System.Windows.Forms.ErrorProvider errorProvider;
        private System.Windows.Forms.RadioButton radioButton_addrIPV6;
        private System.Windows.Forms.RadioButton radioButton_addrIPV4;
        private System.Windows.Forms.TextBox textBox_serverIPv6;
    }
}