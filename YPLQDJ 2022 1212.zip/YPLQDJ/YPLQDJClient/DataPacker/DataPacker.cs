﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace MadTomDev.App.YPLQDJ
{

    public class DataReceiver
    {
        public static object[] GetDataInstances(byte[] data, out Flags.Types[] dataTypeArray)
        {
            dataTypeArray = null;
            List<Flags.Types> dataTypeList = new List<Flags.Types>();
            List<object> resultList = new List<object>();


            using (MemoryStream ms = new MemoryStream(data))
            {
                BinaryFormatter bf = new BinaryFormatter();
                Dictionary<string, object> dataDict;
                Flags.Types dataType;
                while (ms.Position < data.Length)
                {
                    dataDict = (Dictionary<string, object>)bf.Deserialize(ms);
                    dataType = (Flags.Types)dataDict[Flags.FlagName_Type];
                    dataTypeList.Add(dataType);
                    switch (dataType)
                    {
                        default:
                        case Flags.Types.Unknow:
                            {
                                resultList.Add(new DataPacker() { dataDict = dataDict });
                                break;
                            }
                        case Flags.Types.Message:
                            {
                                resultList.Add(new DataMessage() { dataDict = dataDict });
                                break;
                            }


                        case Flags.Types.RequestLogin:
                        case Flags.Types.RequestResetPwd:
                        case Flags.Types.RequestSupplyList:
                        case Flags.Types.RequestSupplyFileCounts:
                        case Flags.Types.RequestAccessSupply:
                        case Flags.Types.RequestSupplyStatus:
                        case Flags.Types.RequestSignOffList:
                        case Flags.Types.RequestSignOffCount:
                        case Flags.Types.RequestAccessSignOff:
                        case Flags.Types.RequestFileQuery:
                        case Flags.Types.RequestFileDownload:
                        case Flags.Types.RequestFileUpload:
                        case Flags.Types.RequestFileDelete:
                        case Flags.Types.RequestDeliveryWarning:

                        case Flags.Types.RequestUniversalDir:
                        case Flags.Types.RequestUniversalCreateDir:
                        case Flags.Types.RequestUniversalDelete:
                        case Flags.Types.RequestUniversalMove:
                        case Flags.Types.RequestUniversalDownload:
                        case Flags.Types.RequestUniversalUpload:

                        case Flags.Types.ConsoleIn:
                            {
                                resultList.Add(new DataClientRequest() { dataDict = dataDict });
                                break;
                            }
                        case Flags.Types.ResponseLogin:
                        case Flags.Types.ResponseResetPwd:
                        case Flags.Types.ResponseSupplyList:
                        case Flags.Types.ResponseSupplyFileCounts:
                        case Flags.Types.ResponseAccessSupply:
                        case Flags.Types.ResponseSupplyStatus:
                        case Flags.Types.ResponseSignOffList:
                        case Flags.Types.ResponseSignOffCount:
                        case Flags.Types.ResponseAccessSignOff:
                        case Flags.Types.ResponseFileQuery:
                        case Flags.Types.ResponseFileDownload:
                        case Flags.Types.ResponseFileUpload:
                        case Flags.Types.ResponseFileDelete:
                        case Flags.Types.ResponseDeliveryWarning:

                        case Flags.Types.ResponseUniversalDir:
                        case Flags.Types.ResponseUniversalCreateDir:
                        case Flags.Types.ResponseUniversalDelete:
                        case Flags.Types.ResponseUniversalMove:
                        case Flags.Types.ResponseUniversalDownload:
                        case Flags.Types.ResponseUniversalUpload:

                        case Flags.Types.ConsoleOut:
                            {
                                resultList.Add(new DataServerResponse() { dataDict = dataDict });
                                break;
                            }
                    }
                }
            }
            if (dataTypeList.Count > 0)
            {
                dataTypeArray = dataTypeList.ToArray();
                return resultList.ToArray();
            }
            return null;
        }
    }
    public class Flags
    {
        public const string FlagName_Type = "Type";
        public enum Types
        {
            Unknow,
            RequestLogin, ResponseLogin,
            RequestResetPwd, ResponseResetPwd,

            RequestSupplyList, RequestSupplyFileCounts, RequestAccessSupply,
            ResponseSupplyList, ResponseSupplyFileCounts, ResponseAccessSupply,

            RequestSupplyStatus, RequestSignOffList, RequestSignOffCount, RequestAccessSignOff,
            ResponseSupplyStatus, ResponseSignOffList, ResponseSignOffCount, ResponseAccessSignOff,

            RequestFileQuery, RequestFileUpload, RequestFileDownload, RequestFileDelete,
            ResponseFileQuery, ResponseFileUpload, ResponseFileDownload, ResponseFileDelete,
            Message, ConsoleIn, ConsoleOut,

            RequestDeliveryWarning,
            ResponseDeliveryWarning,

            RequestUniversalDir, ResponseUniversalDir,
            RequestUniversalUpload, ResponseUniversalUpload,
            RequestUniversalDownload, ResponseUniversalDownload,
            RequestUniversalDelete, ResponseUniversalDelete,
            RequestUniversalCreateDir, ResponseUniversalCreateDir,
            RequestUniversalMove, ResponseUniversalMove,
            //Request, Response,
        }

        public const string FlagName_Message = "Message";
    }

    public class DataClientRequest : DataPacker
    {
        public Flags.Types DataType
        {
            private set
            {
                if (dataDict.ContainsKey(Flags.FlagName_Type))
                    dataDict[Flags.FlagName_Type] = value;
                else
                    dataDict.Add(Flags.FlagName_Type, value);
            }
            get
            {
                if (dataDict.ContainsKey(Flags.FlagName_Type))
                    return (Flags.Types)dataDict[Flags.FlagName_Type];
                else
                    return Flags.Types.Unknow;
            }
        }

        public DataClientRequest() { }
        public DataClientRequest(Flags.Types dataType)
        { DataType = dataType; }

        #region login
        public string Login_User
        {
            get
            {
                if (DataType != Flags.Types.RequestLogin)
                    return null;
                else
                    return (string)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.RequestLogin)
                    SetValue("0", value);
            }
        }
        public string Login_Password
        {
            get
            {
                if (DataType != Flags.Types.RequestLogin)
                    return null;
                else
                    return (string)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.RequestLogin)
                    SetValue("1", value);
            }
        }
        public bool Login_ForceEnter
        {
            get
            {
                if (DataType != Flags.Types.RequestLogin)
                    return false;
                else
                    return (bool)GetValue("2");
            }
            set
            {
                if (DataType == Flags.Types.RequestLogin)
                    SetValue("2", value);
            }
        }
        #endregion

        #region reset password
        public string ResetPwd_User
        {
            get
            {
                if (DataType != Flags.Types.RequestResetPwd)
                    return null;
                else
                    return (string)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.RequestResetPwd)
                    SetValue("0", value);
            }
        }
        public string ResetPwd_NewPassword
        {
            get
            {
                if (DataType != Flags.Types.RequestResetPwd)
                    return null;
                else
                    return (string)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.RequestResetPwd)
                    SetValue("1", value);
            }
        }

        #endregion

        #region supply list
        public string SupplyList_SearchPattern
        {
            get
            {
                if (DataType != Flags.Types.RequestSupplyList)
                    return null;
                else
                    return (string)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.RequestSupplyList)
                    SetValue("0", value);
            }
        }
        public int? SupplyList_Page
        {
            get
            {
                if (DataType != Flags.Types.RequestSupplyList)
                    return null;
                else
                    return (int)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.RequestSupplyList)
                    SetValue("1", value);
            }
        }

        #endregion

        #region Supply Proof Counts

        public List<Guid> SupplyFileCounts_SupplyIDList
        {
            get
            {
                if (DataType != Flags.Types.RequestSupplyFileCounts)
                    return null;
                else
                    return (List<Guid>)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.RequestSupplyFileCounts)
                    SetValue("0", value);
            }
        }

        #endregion

        #region supply list access
        public DataTempletes.RequestDataOperatTypes AccessSupply_OpType
        {
            get
            {
                if (DataType != Flags.Types.RequestAccessSupply)
                    return DataTempletes.RequestDataOperatTypes.None;
                else
                    return (DataTempletes.RequestDataOperatTypes)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.RequestAccessSupply)
                    SetValue("0", value);
            }
        }
        public Guid AccessSupply_ID
        {
            get
            {
                if (DataType != Flags.Types.RequestAccessSupply)
                    return Guid.Empty;
                else
                    return (Guid)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.RequestAccessSupply)
                    SetValue("1", value);
            }
        }
        public DataTempletes.SupplyList.Item AccessSupply_Data
        {
            get
            {
                if (DataType != Flags.Types.RequestAccessSupply)
                    return null;
                else
                    return (DataTempletes.SupplyList.Item)GetValue("2");
            }
            set
            {
                if (DataType == Flags.Types.RequestAccessSupply)
                    SetValue("2", value);
            }
        }

        #endregion

        #region supply status(nothing)


        #endregion

        #region sign-off list
        public Guid SignOffList_SupplyID
        {
            get
            {
                if (DataType != Flags.Types.RequestSignOffList)
                    return Guid.Empty;
                else
                    return (Guid)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.RequestSignOffList)
                    SetValue("0", value);
            }
        }
        public string SignOffList_UserID
        {
            get
            {
                if (DataType != Flags.Types.RequestSignOffList)
                    return null;
                else
                    return GetValue("1")?.ToString();
            }
            set
            {
                if (DataType == Flags.Types.RequestSignOffList)
                    SetValue("1", value);
            }
        }

        #endregion

        #region sign-off count
        public Guid SignOffCount_SupplyID
        {
            get
            {
                if (DataType != Flags.Types.RequestSignOffCount)
                    return Guid.Empty;
                else
                    return (Guid)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.RequestSignOffCount)
                    SetValue("0", value);
            }
        }

        #endregion

        #region sign-off list access
        public DataTempletes.RequestDataOperatTypes AccessSignOff_OpType
        {
            get
            {
                if (DataType != Flags.Types.RequestAccessSignOff)
                    return DataTempletes.RequestDataOperatTypes.None;
                else
                    return (DataTempletes.RequestDataOperatTypes)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.RequestAccessSignOff)
                    SetValue("0", value);
            }
        }
        public Guid AccessSignOff_ID
        {
            get
            {
                if (DataType != Flags.Types.RequestAccessSignOff)
                    return Guid.Empty;
                else
                    return (Guid)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.RequestAccessSignOff)
                    SetValue("1", value);
            }
        }
        public DataTempletes.SignOffList.Item AccessSignOff_Data
        {
            get
            {
                if (DataType != Flags.Types.RequestAccessSignOff)
                    return null;
                else
                    return (DataTempletes.SignOffList.Item)GetValue("2");
            }
            set
            {
                if (DataType == Flags.Types.RequestAccessSignOff)
                    SetValue("2", value);
            }
        }

        #endregion

        #region file query
        public long? FileQuery_ID
        {
            get
            {
                if (DataType != Flags.Types.RequestFileQuery)
                    return -1;
                else
                    return (long)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.RequestFileQuery)
                    SetValue("0", value);
            }
        }
        #endregion

        #region FileUpload
        public long? FileUpload_ID
        {
            get
            {
                if (DataType != Flags.Types.RequestFileUpload)
                    return null;
                else
                    return (long)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.RequestFileUpload)
                    SetValue("0", value);
            }
        }
        public Guid FileUpload_TaskID
        {
            get
            {
                if (DataType != Flags.Types.RequestFileUpload)
                    return Guid.Empty;
                else
                    return (Guid)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.RequestFileUpload)
                    SetValue("1", value);
            }
        }
        public string FileUpload_FileName
        {
            get
            {
                if (DataType != Flags.Types.RequestFileUpload)
                    return null;
                else
                    return (string)GetValue("2");
            }
            set
            {
                if (DataType == Flags.Types.RequestFileUpload)
                    SetValue("2", value);
            }
        }
        public long? FileUpload_Position
        {
            get
            {
                if (DataType != Flags.Types.RequestFileUpload)
                    return null;
                else
                    return (long)GetValue("3");
            }
            set
            {
                if (DataType == Flags.Types.RequestFileUpload)
                    SetValue("3", value);
            }
        }
        public byte[] FileUpload_FileData
        {
            get
            {
                if (DataType != Flags.Types.RequestFileUpload)
                    return null;
                else
                    return (byte[])GetValue("4");
            }
            set
            {
                if (DataType == Flags.Types.RequestFileUpload)
                    SetValue("4", value);
            }
        }
        public bool? FileUpload_IsStartPack
        {
            get
            {
                if (DataType != Flags.Types.RequestFileUpload)
                    return null;
                else
                    return (bool)GetValue("5");
            }
            set
            {
                if (DataType == Flags.Types.RequestFileUpload)
                    SetValue("5", value);
            }
        }
        public bool? FileUpload_IsEndPack
        {
            get
            {
                if (DataType != Flags.Types.RequestFileUpload)
                    return null;
                else
                    return (bool)GetValue("6");
            }
            set
            {
                if (DataType == Flags.Types.RequestFileUpload)
                    SetValue("6", value);
            }
        }

        #endregion

        #region FileDownload

        public Guid FileDownload_TaskID
        {
            get
            {
                if (DataType != Flags.Types.RequestFileDownload)
                    return Guid.Empty;
                else
                    return (Guid)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.RequestFileDownload)
                    SetValue("0", value);
            }
        }
        public long? FileDownload_ID
        {
            get
            {
                if (DataType != Flags.Types.RequestFileDownload)
                    return null;
                else
                    return (long)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.RequestFileDownload)
                    SetValue("1", value);
            }
        }
        public long? FileDownload_No
        {
            get
            {
                if (DataType != Flags.Types.RequestFileDownload)
                    return null;
                else
                    return (long)GetValue("2");
            }
            set
            {
                if (DataType == Flags.Types.RequestFileDownload)
                    SetValue("2", value);
            }
        }
        public string FileDownload_Name
        {
            get
            {
                if (DataType != Flags.Types.RequestFileDownload)
                    return null;
                else
                    return (string)GetValue("3");
            }
            set
            {
                if (DataType == Flags.Types.RequestFileDownload)
                    SetValue("3", value);
            }
        }
        public long? FileDownload_Position
        {
            get
            {
                if (DataType != Flags.Types.RequestFileDownload)
                    return null;
                else
                    return (long)GetValue("4");
            }
            set
            {
                if (DataType == Flags.Types.RequestFileDownload)
                    SetValue("4", value);
            }
        }
        public long? FileDownload_Length
        {
            get
            {
                if (DataType != Flags.Types.RequestFileDownload)
                    return null;
                else
                    return (long)GetValue("5");
            }
            set
            {
                if (DataType == Flags.Types.RequestFileDownload)
                    SetValue("5", value);
            }
        }

        #endregion

        #region FileDelete

        public long? FileDelete_ID
        {
            get
            {
                if (DataType != Flags.Types.RequestFileDelete)
                    return null;
                else
                    return (long)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.RequestFileDelete)
                    SetValue("0", value);
            }
        }
        public long? FileDelete_No
        {
            get
            {
                if (DataType != Flags.Types.RequestFileDelete)
                    return null;
                else
                    return (long)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.RequestFileDelete)
                    SetValue("1", value);
            }
        }

        #endregion

        #region DeliveryWarning

        public string DeliveryWarning_UserID
        {
            get
            {
                if (DataType != Flags.Types.RequestDeliveryWarning)
                    return null;
                else
                    return GetValue("0")?.ToString();
            }
            set
            {
                if (DataType == Flags.Types.RequestDeliveryWarning)
                    SetValue("0", value);
            }
        }
        public double? DeliveryWarning_ReserveDays
        {
            get
            {
                if (DataType != Flags.Types.RequestDeliveryWarning)
                    return null;
                else
                    return (double)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.RequestDeliveryWarning)
                    SetValue("1", value);
            }
        }

        #endregion

        #region Universal File Transfer
        public string UniversalDir_BaseDir
        {
            get
            {
                if (DataType != Flags.Types.RequestUniversalDir)
                    return null;
                else
                    return GetValue("0")?.ToString();
            }
            set
            {
                if (DataType == Flags.Types.RequestUniversalDir)
                    SetValue("0", value);
            }
        }

        #region UniversalUpload
        public string UniversalUpload_FileFullName
        {
            get
            {
                if (DataType != Flags.Types.RequestUniversalUpload)
                    return null;
                else
                    return GetValue("0")?.ToString();
            }
            set
            {
                if (DataType == Flags.Types.RequestUniversalUpload)
                    SetValue("0", value);
            }
        }
        public long? UniversalUpload_Position
        {
            get
            {
                if (DataType != Flags.Types.RequestUniversalUpload)
                    return null;
                else
                    return (long)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.RequestUniversalUpload)
                    SetValue("1", value);
            }
        }
        public byte[] UniversalUpload_Data
        {
            get
            {
                if (DataType != Flags.Types.RequestUniversalUpload)
                    return null;
                else
                    return (byte[])GetValue("2");
            }
            set
            {
                if (DataType == Flags.Types.RequestUniversalUpload)
                    SetValue("2", value);
            }
        }
        public bool? UniversalUpload_IsEndPack
        {
            get
            {
                if (DataType != Flags.Types.RequestUniversalUpload)
                    return null;
                else
                    return (bool)GetValue("3");
            }
            set
            {
                if (DataType == Flags.Types.RequestUniversalUpload)
                    SetValue("3", value);
            }
        }



        #endregion

        #region UniversalDownload
        public string UniversalDownload_FileFullName
        {
            get
            {
                if (DataType != Flags.Types.RequestUniversalDownload)
                    return null;
                else
                    return GetValue("0")?.ToString();
            }
            set
            {
                if (DataType == Flags.Types.RequestUniversalDownload)
                    SetValue("0", value);
            }
        }
        public long? UniversalDownload_Position
        {
            get
            {
                if (DataType != Flags.Types.RequestUniversalDownload)
                    return null;
                else
                    return (long)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.RequestUniversalDownload)
                    SetValue("1", value);
            }
        }
        #endregion

        public List<DataTempletes.UniversalFileSystemInfo> UniversalDelete_FileList
        {
            get
            {
                if (DataType != Flags.Types.RequestUniversalDelete)
                    return null;
                else
                    return (List<DataTempletes.UniversalFileSystemInfo>)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.RequestUniversalDelete)
                    SetValue("0", value);
            }
        }

        public string UniversalCreateDir_DirFullName
        {
            get
            {
                if (DataType != Flags.Types.RequestUniversalCreateDir)
                    return null;
                else
                    return GetValue("0")?.ToString();
            }
            set
            {
                if (DataType == Flags.Types.RequestUniversalCreateDir)
                    SetValue("0", value);
            }
        }

        #region UniversalMove
        public string UniversalMove_OriFullName
        {
            get
            {
                if (DataType != Flags.Types.RequestUniversalMove)
                    return null;
                else
                    return GetValue("0")?.ToString();
            }
            set
            {
                if (DataType == Flags.Types.RequestUniversalMove)
                    SetValue("0", value);
            }
        }
        public string UniversalMove_NewFullName
        {
            get
            {
                if (DataType != Flags.Types.RequestUniversalMove)
                    return null;
                else
                    return GetValue("1")?.ToString();
            }
            set
            {
                if (DataType == Flags.Types.RequestUniversalMove)
                    SetValue("1", value);
            }
        }

        #endregion

        #endregion

        #region Console
        public string Console_CmdIn
        {
            get
            {
                if (DataType != Flags.Types.ConsoleIn)
                    return null;
                else
                    return (string)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.ConsoleIn)
                    SetValue("0", value);
            }
        }


        #endregion
    }
    public class DataServerResponse : DataPacker
    {
        public Flags.Types DataType
        {
            private set
            {
                if (dataDict.ContainsKey(Flags.FlagName_Type))
                    dataDict[Flags.FlagName_Type] = value;
                else
                    dataDict.Add(Flags.FlagName_Type, value);
            }
            get
            {
                if (dataDict.ContainsKey(Flags.FlagName_Type))
                    return (Flags.Types)dataDict[Flags.FlagName_Type];
                else
                    return Flags.Types.Unknow;
            }
        }

        public DataServerResponse() { }
        public DataServerResponse(Flags.Types dataType)
        { DataType = dataType; }

        #region Login
        public bool? Login_Result
        {
            get
            {
                if (DataType != Flags.Types.ResponseLogin)
                    return null;
                else
                    return (bool)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.ResponseLogin)
                    SetValue("0", value);
            }
        }
        public bool? Login_NeedSetPassword
        {
            get
            {
                if (DataType != Flags.Types.ResponseLogin)
                    return null;
                else
                    return (bool)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.ResponseLogin)
                    SetValue("1", value);
            }
        }
        public bool? Login_HaveSession
        {
            get
            {
                if (DataType != Flags.Types.ResponseLogin)
                    return null;
                else
                    return (bool)GetValue("2");
            }
            set
            {
                if (DataType == Flags.Types.ResponseLogin)
                    SetValue("2", value);
            }
        }
        public DataTempletes.User Login_UserData
        {
            get
            {
                if (DataType != Flags.Types.ResponseLogin)
                    return null;
                else
                    return (DataTempletes.User)GetValue("3");
            }
            set
            {
                if (DataType == Flags.Types.ResponseLogin)
                    SetValue("3", value);
            }
        }
        #endregion

        #region reset password
        public bool? ResetPwd_Result
        {
            get
            {
                if (DataType != Flags.Types.ResponseResetPwd)
                    return null;
                else
                    return (bool)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.ResponseResetPwd)
                    SetValue("0", value);
            }
        }
        #endregion

        #region supply list
        public int? SupplyList_CurPage
        {
            get
            {
                if (DataType != Flags.Types.ResponseSupplyList)
                    return null;
                else
                    return (int)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.ResponseSupplyList)
                    SetValue("0", value);
            }
        }
        public int? SupplyList_TotalPages
        {
            get
            {
                if (DataType != Flags.Types.ResponseSupplyList)
                    return null;
                else
                    return (int)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.ResponseSupplyList)
                    SetValue("1", value);
            }
        }
        public DataTempletes.SupplyList SupplyList_Data
        {
            get
            {
                if (DataType != Flags.Types.ResponseSupplyList)
                    return null;
                else
                    return (DataTempletes.SupplyList)GetValue("2");
            }
            set
            {
                if (DataType == Flags.Types.ResponseSupplyList)
                    SetValue("2", value);
            }
        }
        #endregion

        #region Supply Proof Counts

        public List<DataTempletes.SupplyList.FileCountInfo> SupplyFileCounts_List
        {
            get
            {
                if (DataType != Flags.Types.ResponseSupplyFileCounts)
                    return null;
                else
                    return (List<DataTempletes.SupplyList.FileCountInfo>)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.ResponseSupplyFileCounts)
                    SetValue("0", value);
            }
        }

        #endregion

        #region supply list access
        public DataTempletes.RequestDataOperatTypes AccessSupply_OpType
        {
            get
            {
                if (DataType != Flags.Types.ResponseAccessSupply)
                    return DataTempletes.RequestDataOperatTypes.None;
                else
                    return (DataTempletes.RequestDataOperatTypes)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.ResponseAccessSupply)
                    SetValue("0", value);
            }
        }
        public Guid AccessSupply_ID
        {
            get
            {
                if (DataType != Flags.Types.ResponseAccessSupply)
                    return Guid.Empty;
                else
                    return (Guid)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.ResponseAccessSupply)
                    SetValue("1", value);
            }
        }
        public bool AccessSupply_Result
        {
            get
            {
                if (DataType != Flags.Types.ResponseAccessSupply)
                    return false;
                else
                    return (bool)GetValue("2");
            }
            set
            {
                if (DataType == Flags.Types.ResponseAccessSupply)
                    SetValue("2", value);
            }
        }
        public Exception AccessSupply_Error
        {
            get
            {
                if (DataType != Flags.Types.ResponseAccessSupply)
                    return null;
                else
                    return (Exception)GetValue("3");
            }
            set
            {
                if (DataType == Flags.Types.ResponseAccessSupply)
                    SetValue("3", value);
            }
        }

        #endregion

        #region sign-off list
        public Guid SignOffList_SupplyID
        {
            get
            {
                if (DataType != Flags.Types.ResponseSignOffList)
                    return Guid.Empty;
                else
                    return (Guid)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.ResponseSignOffList)
                    SetValue("0", value);
            }
        }
        public string SignOffList_UserID
        {
            get
            {
                if (DataType != Flags.Types.ResponseSignOffList)
                    return null;
                else
                    return GetValue("1")?.ToString();
            }
            set
            {
                if (DataType == Flags.Types.ResponseSignOffList)
                    SetValue("1", value);
            }
        }
        public DataTempletes.SignOffList SignOffList_Data
        {
            get
            {
                if (DataType != Flags.Types.ResponseSignOffList)
                    return null;
                else
                    return (DataTempletes.SignOffList)GetValue("2");
            }
            set
            {
                if (DataType == Flags.Types.ResponseSignOffList)
                    SetValue("2", value);
            }
        }
        #endregion

        #region supply status

        public Dictionary<int, string> SupplyStatus_Dictionary
        {
            get
            {
                if (DataType != Flags.Types.ResponseSupplyStatus)
                    return null;
                else
                    return (Dictionary<int, string>)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.ResponseSupplyStatus)
                    SetValue("0", value);
            }
        }

        #endregion

        #region sign-off count
        public Guid SignOffCount_SupplyID
        {
            get
            {
                if (DataType != Flags.Types.ResponseSignOffCount)
                    return Guid.Empty;
                else
                    return (Guid)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.ResponseSignOffCount)
                    SetValue("0", value);
            }
        }
        public decimal? SignOffCount_Count
        {
            get
            {
                if (DataType != Flags.Types.ResponseSignOffCount)
                    return null;
                else
                    return (decimal)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.ResponseSignOffCount)
                    SetValue("1", value);
            }
        }
        #endregion

        #region sign-off list access
        public DataTempletes.RequestDataOperatTypes AccessSignOff_OpType
        {
            get
            {
                if (DataType != Flags.Types.ResponseAccessSignOff)
                    return DataTempletes.RequestDataOperatTypes.None;
                else
                    return (DataTempletes.RequestDataOperatTypes)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.ResponseAccessSignOff)
                    SetValue("0", value);
            }
        }
        public Guid AccessSignOff_ID
        {
            get
            {
                if (DataType != Flags.Types.ResponseAccessSignOff)
                    return Guid.Empty;
                else
                    return (Guid)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.ResponseAccessSignOff)
                    SetValue("1", value);
            }
        }
        public bool? AccessSignOff_Result
        {
            get
            {
                if (DataType != Flags.Types.ResponseAccessSignOff)
                    return null;
                else
                    return (bool)GetValue("2");
            }
            set
            {
                if (DataType == Flags.Types.ResponseAccessSignOff)
                    SetValue("2", value);
            }
        }
        public Exception AccessSignOff_Error
        {
            get
            {
                if (DataType != Flags.Types.ResponseAccessSignOff)
                    return null;
                else
                    return (Exception)GetValue("3");
            }
            set
            {
                if (DataType == Flags.Types.ResponseAccessSignOff)
                    SetValue("3", value);
            }
        }
        #endregion

        #region file query
        public long? FileQuery_ID
        {
            get
            {
                if (DataType != Flags.Types.ResponseFileQuery)
                    return -1;
                else
                    return (long)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.ResponseFileQuery)
                    SetValue("0", value);
            }
        }
        public List<DataTempletes.FileInfo> FileQuery_NameList
        {
            get
            {
                if (DataType != Flags.Types.ResponseFileQuery)
                    return null;
                else
                    return (List<DataTempletes.FileInfo>)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.ResponseFileQuery)
                    SetValue("1", value);
            }
        }
        #endregion

        #region file upload

        public long? FileUpload_ID
        {
            get
            {
                if (DataType != Flags.Types.ResponseFileUpload)
                    return null;
                else
                    return (long)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.ResponseFileUpload)
                    SetValue("0", value);
            }
        }
        public Guid FileUpload_TaskID
        {
            get
            {
                if (DataType != Flags.Types.ResponseFileUpload)
                    return Guid.Empty;
                else
                    return (Guid)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.ResponseFileUpload)
                    SetValue("1", value);
            }
        }
        public long? FileUpload_Position
        {
            get
            {
                if (DataType != Flags.Types.ResponseFileUpload)
                    return null;
                else
                    return (long)GetValue("2");
            }
            set
            {
                if (DataType == Flags.Types.ResponseFileUpload)
                    SetValue("2", value);
            }
        }
        public long? FileUpload_Length
        {
            get
            {
                if (DataType != Flags.Types.ResponseFileUpload)
                    return null;
                else
                    return (long)GetValue("3");
            }
            set
            {
                if (DataType == Flags.Types.ResponseFileUpload)
                    SetValue("3", value);
            }
        }
        public bool? FileUpload_Result
        {
            get
            {
                if (DataType != Flags.Types.ResponseFileUpload)
                    return null;
                else
                    return (bool)GetValue("4");
            }
            set
            {
                if (DataType == Flags.Types.ResponseFileUpload)
                    SetValue("4", value);
            }
        }
        public long? FileUpload_No
        {
            get
            {
                if (DataType != Flags.Types.ResponseFileUpload)
                    return null;
                else
                    return (long)GetValue("5");
            }
            set
            {
                if (DataType == Flags.Types.ResponseFileUpload)
                    SetValue("5", value);
            }
        }
        public Exception FileUpload_Error
        {
            get
            {
                if (DataType != Flags.Types.ResponseFileUpload)
                    return null;
                else
                    return (Exception)GetValue("6");
            }
            set
            {
                if (DataType == Flags.Types.ResponseFileUpload)
                    SetValue("6", value);
            }
        }

        #endregion

        #region file download

        public Guid FileDownload_TaskID
        {
            get
            {
                if (DataType != Flags.Types.ResponseFileDownload)
                    return Guid.Empty;
                else
                    return (Guid)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.ResponseFileDownload)
                    SetValue("0", value);
            }
        }
        public long? FileDownload_ID
        {
            get
            {
                if (DataType != Flags.Types.ResponseFileDownload)
                    return null;
                else
                    return (long)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.ResponseFileDownload)
                    SetValue("1", value);
            }
        }
        public long? FileDownload_No
        {
            get
            {
                if (DataType != Flags.Types.ResponseFileDownload)
                    return null;
                else
                    return (long)GetValue("2");
            }
            set
            {
                if (DataType == Flags.Types.ResponseFileDownload)
                    SetValue("2", value);
            }
        }
        public bool? FileDownload_Result
        {
            get
            {
                if (DataType != Flags.Types.ResponseFileDownload)
                    return null;
                else
                    return (bool)GetValue("3");
            }
            set
            {
                if (DataType == Flags.Types.ResponseFileDownload)
                    SetValue("3", value);
            }
        }
        public string FileDownload_FileName
        {
            get
            {
                if (DataType != Flags.Types.ResponseFileDownload)
                    return null;
                else
                    return (string)GetValue("4");
            }
            set
            {
                if (DataType == Flags.Types.ResponseFileDownload)
                    SetValue("4", value);
            }
        }
        public long? FileDownload_Position
        {
            get
            {
                if (DataType != Flags.Types.ResponseFileDownload)
                    return null;
                else
                    return (long)GetValue("5");
            }
            set
            {
                if (DataType == Flags.Types.ResponseFileDownload)
                    SetValue("5", value);
            }
        }
        public byte[] FileDownload_FileData
        {
            get
            {
                if (DataType != Flags.Types.ResponseFileDownload)
                    return null;
                else
                    return (byte[])GetValue("6");
            }
            set
            {
                if (DataType == Flags.Types.ResponseFileDownload)
                    SetValue("6", value);
            }
        }
        public bool? FileDownload_IsEndPack
        {
            get
            {
                if (DataType != Flags.Types.ResponseFileDownload)
                    return null;
                else
                    return (bool)GetValue("7");
            }
            set
            {
                if (DataType == Flags.Types.ResponseFileDownload)
                    SetValue("7", value);
            }
        }
        public Exception FileDownload_Error
        {
            get
            {
                if (DataType != Flags.Types.ResponseFileDownload)
                    return null;
                else
                    return (Exception)GetValue("8");
            }
            set
            {
                if (DataType == Flags.Types.ResponseFileDownload)
                    SetValue("8", value);
            }
        }

        #endregion

        #region file delete

        public long? FileDelete_ID
        {
            get
            {
                if (DataType != Flags.Types.ResponseFileDelete)
                    return null;
                else
                    return (long)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.ResponseFileDelete)
                    SetValue("0", value);
            }
        }
        public long? FileDelete_No
        {
            get
            {
                if (DataType != Flags.Types.ResponseFileDelete)
                    return null;
                else
                    return (long)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.ResponseFileDelete)
                    SetValue("1", value);
            }
        }
        public bool? FileDelete_Result
        {
            get
            {
                if (DataType != Flags.Types.ResponseFileDelete)
                    return null;
                else
                    return (bool)GetValue("2");
            }
            set
            {
                if (DataType == Flags.Types.ResponseFileDelete)
                    SetValue("2", value);
            }
        }
        public Exception FileDelete_Error
        {
            get
            {
                if (DataType != Flags.Types.ResponseFileDelete)
                    return null;
                else
                    return (Exception)GetValue("3");
            }
            set
            {
                if (DataType == Flags.Types.ResponseFileDelete)
                    SetValue("3", value);
            }
        }
        #endregion

        #region Delivery Warning

        public string DeliveryWarning_UserID
        {
            get
            {
                if (DataType != Flags.Types.ResponseDeliveryWarning)
                    return null;
                else
                    return GetValue("0")?.ToString();
            }
            set
            {
                if (DataType == Flags.Types.ResponseDeliveryWarning)
                    SetValue("0", value);
            }
        }
        public bool? DeliveryWarning_HaveWarning
        {
            get
            {
                if (DataType != Flags.Types.ResponseDeliveryWarning)
                    return null;
                else
                    return (bool)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.ResponseDeliveryWarning)
                    SetValue("1", value);
            }
        }
        public string DeliveryWarning_WarningMessage
        {
            get
            {
                if (DataType != Flags.Types.ResponseDeliveryWarning)
                    return null;
                else
                    return GetValue("2")?.ToString();
            }
            set
            {
                if (DataType == Flags.Types.ResponseDeliveryWarning)
                    SetValue("2", value);
            }
        }

        #endregion

        #region Universal File Transfer
        #region UniversalDir
        public string UniversalDir_BaseDir
        {
            get
            {
                if (DataType != Flags.Types.ResponseUniversalDir)
                    return null;
                else
                    return GetValue("0")?.ToString();
            }
            set
            {
                if (DataType == Flags.Types.ResponseUniversalDir)
                    SetValue("0", value);
            }
        }
        public List<DataTempletes.UniversalFileSystemInfo> UniversalDir_FSList
        {
            get
            {
                if (DataType != Flags.Types.ResponseUniversalDir)
                    return null;
                else
                    return (List<DataTempletes.UniversalFileSystemInfo>)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.ResponseUniversalDir)
                    SetValue("1", value);
            }
        }
        public Exception UniversalDir_Error
        {
            get
            {
                if (DataType != Flags.Types.ResponseUniversalDir)
                    return null;
                else
                    return (Exception)GetValue("2");
            }
            set
            {
                if (DataType == Flags.Types.ResponseUniversalDir)
                    SetValue("2", value);
            }
        }
        #endregion

        #region UniversalUpload
        public string UniversalUpload_FileFullName
        {
            get
            {
                if (DataType != Flags.Types.ResponseUniversalUpload)
                    return null;
                else
                    return GetValue("0")?.ToString();
            }
            set
            {
                if (DataType == Flags.Types.ResponseUniversalUpload)
                    SetValue("0", value);
            }
        }
        public long? UniversalUpload_Position
        {
            get
            {
                if (DataType != Flags.Types.ResponseUniversalUpload)
                    return null;
                else
                    return (long)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.ResponseUniversalUpload)
                    SetValue("1", value);
            }
        }
        public int? UniversalUpload_DataLength
        {
            get
            {
                if (DataType != Flags.Types.ResponseUniversalUpload)
                    return null;
                else
                    return (int)GetValue("2");
            }
            set
            {
                if (DataType == Flags.Types.ResponseUniversalUpload)
                    SetValue("2", value);
            }
        }
        public bool? UniversalUpload_Result
        {
            get
            {
                if (DataType != Flags.Types.ResponseUniversalUpload)
                    return null;
                else
                    return (bool)GetValue("3");
            }
            set
            {
                if (DataType == Flags.Types.ResponseUniversalUpload)
                    SetValue("3", value);
            }
        }
        public Exception UniversalUpload_Error
        {
            get
            {
                if (DataType != Flags.Types.ResponseUniversalUpload)
                    return null;
                else
                    return (Exception)GetValue("4");
            }
            set
            {
                if (DataType == Flags.Types.ResponseUniversalUpload)
                    SetValue("4", value);
            }
        }
        #endregion

        #region UniversalDownload
        public string UniversalDownload_FileFullName
        {
            get
            {
                if (DataType != Flags.Types.ResponseUniversalDownload)
                    return null;
                else
                    return GetValue("0")?.ToString();
            }
            set
            {
                if (DataType == Flags.Types.ResponseUniversalDownload)
                    SetValue("0", value);
            }
        }
        public long? UniversalDownload_FileLength
        {
            get
            {
                if (DataType != Flags.Types.ResponseUniversalDownload)
                    return null;
                else
                {
                    object test = GetValue("1");
                    if (test == null)
                        return null;
                    else
                        return (long)test;
                }
            }
            set
            {
                if (DataType == Flags.Types.ResponseUniversalDownload)
                    SetValue("1", value);
            }
        }
        public long? UniversalDownload_Position
        {
            get
            {
                if (DataType != Flags.Types.ResponseUniversalDownload)
                    return null;
                else
                {
                    object test = GetValue("2");
                    if (test == null)
                        return null;
                    else
                        return (long)test;
                }
            }
            set
            {
                if (DataType == Flags.Types.ResponseUniversalDownload)
                    SetValue("2", value);
            }
        }
        public byte[] UniversalDownload_Data
        {
            get
            {
                if (DataType != Flags.Types.ResponseUniversalDownload)
                    return null;
                else
                    return (byte[])GetValue("3");
            }
            set
            {
                if (DataType == Flags.Types.ResponseUniversalDownload)
                    SetValue("3", value);
            }
        }
        public Exception UniversalDownload_Error
        {
            get
            {
                if (DataType != Flags.Types.ResponseUniversalDownload)
                    return null;
                else
                    return (Exception)GetValue("4");
            }
            set
            {
                if (DataType == Flags.Types.ResponseUniversalDownload)
                    SetValue("4", value);
            }
        }
        #endregion

        #region UniversalDelete
        public List<DataTempletes.UniversalFileSystemInfo> UniversalDelete_FileList
        {
            get
            {
                if (DataType != Flags.Types.ResponseUniversalDelete)
                    return null;
                else
                    return (List<DataTempletes.UniversalFileSystemInfo>)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.ResponseUniversalDelete)
                    SetValue("0", value);
            }
        }
        public List<bool> UniversalDelete_ResultList
        {
            get
            {
                if (DataType != Flags.Types.ResponseUniversalDelete)
                    return null;
                else
                    return (List<bool>)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.ResponseUniversalDelete)
                    SetValue("1", value);
            }
        }
        public Exception UniversalDelete_Error
        {
            get
            {
                if (DataType != Flags.Types.ResponseUniversalDelete)
                    return null;
                else
                    return (Exception)GetValue("2");
            }
            set
            {
                if (DataType == Flags.Types.ResponseUniversalDelete)
                    SetValue("2", value);
            }
        }
        #endregion

        #region UniversalMove
        public string UniversalMove_NewFullName
        {
            get
            {
                if (DataType != Flags.Types.ResponseUniversalMove)
                    return null;
                else
                    return GetValue("0")?.ToString();
            }
            set
            {
                if (DataType == Flags.Types.ResponseUniversalMove)
                    SetValue("0", value);
            }
        }
        public bool? UniversalMove_Result
        {
            get
            {
                if (DataType != Flags.Types.ResponseUniversalMove)
                    return null;
                else
                    return (bool)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.ResponseUniversalMove)
                    SetValue("1", value);
            }
        }
        public Exception UniversalMove_Error
        {
            get
            {
                if (DataType != Flags.Types.ResponseUniversalMove)
                    return null;
                else
                    return (Exception)GetValue("2");
            }
            set
            {
                if (DataType == Flags.Types.ResponseUniversalMove)
                    SetValue("2", value);
            }
        }
        #endregion

        #region UniversalCreateDir
        public string UniversalCreateDir_DirFullName
        {
            get
            {
                if (DataType != Flags.Types.ResponseUniversalCreateDir)
                    return null;
                else
                    return GetValue("0")?.ToString();
            }
            set
            {
                if (DataType == Flags.Types.ResponseUniversalCreateDir)
                    SetValue("0", value);
            }
        }
        public bool? UniversalCreateDir_Result
        {
            get
            {
                if (DataType != Flags.Types.ResponseUniversalCreateDir)
                    return null;
                else
                    return (bool)GetValue("1");
            }
            set
            {
                if (DataType == Flags.Types.ResponseUniversalCreateDir)
                    SetValue("1", value);
            }
        }
        public Exception UniversalCreateDir_Error
        {
            get
            {
                if (DataType != Flags.Types.ResponseUniversalCreateDir)
                    return null;
                else
                    return (Exception)GetValue("2");
            }
            set
            {
                if (DataType == Flags.Types.ResponseUniversalCreateDir)
                    SetValue("2", value);
            }
        }
        #endregion



        #endregion

        #region Console
        public string Console_ResultOut
        {
            get
            {
                if (DataType != Flags.Types.ConsoleOut)
                    return null;
                else
                    return (string)GetValue("0");
            }
            set
            {
                if (DataType == Flags.Types.ConsoleOut)
                    SetValue("0", value);
            }
        }


        #endregion
    }
    public class DataMessage : DataPacker
    {
        public DataMessage()
        {
            dataDict.Add(Flags.FlagName_Type, Flags.Types.Message);
        }
        public string Message
        {
            get => (string)GetValue(Flags.FlagName_Message);
            set => SetValue(Flags.FlagName_Message, value);
        }
    }

    public class DataPacker
    {
        private BinaryFormatter binFormatter = new BinaryFormatter();
        public Dictionary<string, object> dataDict = new Dictionary<string, object>();

        public byte[] Data
        {
            get
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    binFormatter.Serialize(ms, dataDict);
                    ms.Flush();
                    return ms.ToArray();
                }
            }
            set
            {
                using (MemoryStream ms = new MemoryStream(value))
                {
                    ms.Position = 0;
                    dataDict = (Dictionary<string, object>)binFormatter.Deserialize(ms);
                    ms.Flush();
                }
            }
        }
        public object GetValue(string key)
        {
            if (dataDict.ContainsKey(key))
                return dataDict[key];
            else
                return null;
        }
        public void SetValue(string key, object value)
        {
            if (dataDict.ContainsKey(key))
                dataDict[key] = value;
            else
                dataDict.Add(key, value);
        }
    }
}
