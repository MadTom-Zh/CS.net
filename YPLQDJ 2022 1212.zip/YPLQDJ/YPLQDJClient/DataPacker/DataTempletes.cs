﻿using MadTomDev.CommonClasses;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace MadTomDev.App.YPLQDJ
{
    public class DataTempletes
    {
        [Serializable]
        public class User
        {
            public User() { }
            public User(DataRow dr)
            {
                ID = dr[DataTempletes.DBFieldNames.User.ID].ToString();
                Name = dr[DataTempletes.DBFieldNames.User.Name].ToString();
                SexID = (long)dr[DataTempletes.DBFieldNames.User.SexID];
                UnitID = (long)dr[DataTempletes.DBFieldNames.User.UnitID];
                CPhoneNoMesh = dr[DataTempletes.DBFieldNames.User.CPhoneNoMesh].ToString();
                LoginPwdMesh = dr[DataTempletes.DBFieldNames.User.LoginPwdMesh].ToString();
                LoginPwdInited = (bool?)dr[DataTempletes.DBFieldNames.User.LoginPwdInited];
                Authorities = new AuthoritiesData(dr[DataTempletes.DBFieldNames.User.Authorities].ToString());
            }
            public string ID = null;
            public string Name = null;
            public long SexID = -1;
            public long UnitID = -1;
            public string CPhoneNoMesh = null;
            public string LoginPwdMesh = null;
            public bool? LoginPwdInited = null;
            public AuthoritiesData Authorities = null;

            [Serializable]
            public class AuthoritiesData
            {
                public AuthoritiesData(string value)
                {
                    TextValue = value;
                }

                public bool Login;
                public bool QuerySupplies;
                public bool DownloadFilesSupplies;
                public bool MaintainSupplies;
                public bool UploadFilesSupplies;
                public bool DeleteFilesSupplies;
                public bool QuerySignOff;
                public bool MaintainSignOff;
                public bool Console;
                public bool ReUploadSignOffTempleteXlsx;
                public bool DownloadFileTemplateXlsx;
                public bool ConsoleUFT;
                public bool DBExportImport;
                public string TextValue
                {
                    get
                    {
                        StringBuilder strBdr = new StringBuilder();
                        // add @ 2020-07-20
                        strBdr.Append(Login ? "1" : "-");
                        strBdr.Append(QuerySupplies ? "1" : "-");
                        strBdr.Append(DownloadFilesSupplies ? "1" : "-");
                        strBdr.Append(MaintainSupplies ? "1" : "-");
                        strBdr.Append(UploadFilesSupplies ? "1" : "-");
                        strBdr.Append(DeleteFilesSupplies ? "1" : "-");
                        strBdr.Append(QuerySignOff ? "1" : "-");
                        strBdr.Append(MaintainSignOff ? "1" : "-");
                        strBdr.Append(Console ? "1" : "-"); // index @ 8
                        strBdr.Append(ReUploadSignOffTempleteXlsx ? "1" : "-"); // index @ 9
                        strBdr.Append(DownloadFileTemplateXlsx ? "1" : "-"); // index @ 10

                        strBdr.Append(ConsoleUFT ? "1" : "-"); // index @ 10
                        strBdr.Append(DBExportImport ? "1" : "-"); // index @ 10

                        return strBdr.ToString();
                    }
                    set
                    {
                        for (int i = 0, iv = value.Length; i < iv; i++)
                        {
                            switch (i)
                            {
                                case 0: Login = value[i] == '1'; break;
                                case 1: QuerySupplies = value[i] == '1'; break;
                                case 2: DownloadFilesSupplies = value[i] == '1'; break;
                                case 3: MaintainSupplies = value[i] == '1'; break;
                                case 4: UploadFilesSupplies = value[i] == '1'; break;
                                case 5: DeleteFilesSupplies = value[i] == '1'; break;
                                case 6: QuerySignOff = value[i] == '1'; break;
                                case 7: MaintainSignOff = value[i] == '1'; break;
                                case 8: Console = value[i] == '1'; break;
                                case 9: ReUploadSignOffTempleteXlsx = value[i] == '1'; break;
                                case 10: DownloadFileTemplateXlsx = value[i] == '1'; break;

                                case 11: ConsoleUFT = value[i] == '1'; break;
                                case 12: DBExportImport = value[i] == '1'; break;
                            }
                        }
                    }
                }
            }
        }
        [Serializable]
        public class SupplyList
        {
            public SupplyList(DataTable dt)
            {
                Content = new List<Item>();
                foreach (DataRow dr in dt.Rows)
                    Content.Add(new Item(dr));
            }
            [Serializable]
            public class Item
            {
                public Item() { }
                public Item(DataRow dr)
                {
                    ID = (Guid)dr[DBFieldNames.Supplies.ID];
                    ProjectName = dr[DBFieldNames.Supplies.ProjectName].ToString();
                    Definition = dr[DBFieldNames.Supplies.Definition].ToString();
                    ContractID = (long)dr[DBFieldNames.Supplies.ContractID];
                    Description = dr[DBFieldNames.Supplies.Description].ToString();
                    Quantity = (decimal)dr[DBFieldNames.Supplies.Quantity];
                    Supplier = dr[DBFieldNames.Supplies.Supplier].ToString();
                    DeliveryDate = (DateTime)dr[DBFieldNames.Supplies.DeliveryDate];
                    ProofDeliveryID = (long)dr[DBFieldNames.Supplies.ProofDeliveryID];
                    ProofAcceptanceID = (long)dr[DBFieldNames.Supplies.ProofAcceptanceID];
                    ProofSignOffID = (long)dr[DBFieldNames.Supplies.ProofSignOffID];
                    Remark = dr[DBFieldNames.Supplies.Remark].ToString();
                    Creator = dr[DBFieldNames.Supplies.Creator].ToString();
                }

                public Guid ID = Guid.Empty;
                public string ProjectName = null;
                public string Description = null;
                public string Definition = null;
                public long ContractID = -1;
                public decimal Quantity = -1;
                public string Supplier = null;
                public DateTime DeliveryDate = DateTime.MinValue;
                public long ProofDeliveryID = -1;
                public long ProofAcceptanceID = -1;
                public long ProofSignOffID = -1;
                public string Remark = null;
                public string Creator = null;
            }
            public List<Item> Content = null;

            public List<Guid> GetIDList()
            { return Content.Select(a => a.ID).ToList(); }

            [Serializable]
            public class FileCountInfo
            {
                public Guid SupplyID = Guid.Empty;
                public int Contract = -1;
                public int ProofDelivery = -1;
                public int ProofAcceptance = -1;
                public int ProofSignOff = -1;

                public long ContractID = -1;
                public long ProofDeliveryID = -1;
                public long ProofAcceptanceID = -1;
                public long ProofSignOffID = -1;
            }

            public enum FileTypes
            {
                None,
                Contract,
                Delivery, Acceptance, SignOff,
                ExcelTemplate,
            }
        }

        [Serializable]
        public class FileInfo
        {
            public long ID;
            public long No;
            public string Name;
            public long Size;
            public DateTime ModifyTime;
            public string Uploader;
            public DateTime UploadTime;
            public FileInfo Clone()
            {
                return new FileInfo()
                {
                    ID = ID,
                    No = No,
                    Name = Name,
                    Size = Size,
                    ModifyTime = ModifyTime,
                    Uploader = Uploader,
                    UploadTime = UploadTime,
                };
            }
        }
        [Serializable]
        public class FileList
        {
            public FileList(DataTable dt)
            {
                Content = new List<Item>();
                foreach (DataRow dr in dt.Rows)
                    Content.Add(new Item(dr));
            }
            [Serializable]
            public class Item
            {
                public Item(DataRow dr)
                {
                    ID = (long)dr[DBFieldNames.FileList.ID];
                    No = (long)dr[DBFieldNames.FileList.No];
                    Name = (string)dr[DBFieldNames.FileList.Name];
                    Uploader = (string)dr[DBFieldNames.FileList.Uploader];
                    UploadTime = (DateTime)dr[DBFieldNames.FileList.UploadTime];
                }
                /// <summary>
                /// if file name is "identify.no.jpg", then return "identify.no." ;
                /// </summary>
                /// <returns></returns>
                public string GetPhysicalFileProfix()
                {
                    return GetPhysicalFileProfix(ID, No);
                }
                public static string GetPhysicalFileProfix(long id, long no)
                {
                    StringBuilder strBdr = new StringBuilder();
                    strBdr.Append(SimpleStringHelper.ToHexString(id));
                    strBdr.Append(".");
                    strBdr.Append(no);
                    return strBdr.ToString();
                }


                public long ID = -1;
                public long No = -1;
                public string Name = null;
                public string NameSuffix
                {
                    get
                    {
                        if (Name != null && Name.Contains('.'))
                            return Name.Substring(Name.LastIndexOf('.'));
                        else
                            return Name;
                    }
                }
                public string Uploader = null;
                public DateTime UploadTime = DateTime.MinValue;
            }
            public List<Item> Content = null;
        }
        [Serializable]
        public class SignOffList
        {
            public SignOffList(DataTable dt)
            {
                Content = new List<Item>();
                foreach (DataRow dr in dt.Rows)
                    Content.Add(new Item(dr));
            }
            [Serializable]
            public class Item
            {
                public Item() { }
                public Item(DataRow dr)
                {
                    ID = (Guid)dr[DataTempletes.DBFieldNames.SignOff.ID];
                    SupplyID = (Guid)dr[DataTempletes.DBFieldNames.SignOff.SupplyID];
                    UserID = dr[DataTempletes.DBFieldNames.SignOff.UserID].ToString();
                    Consumers = dr[DataTempletes.DBFieldNames.SignOff.Consumers].ToString();
                    Usage = dr[DataTempletes.DBFieldNames.SignOff.Usage].ToString();
                    Model = dr[DataTempletes.DBFieldNames.SignOff.Model].ToString();
                    Manufacturer = dr[DataTempletes.DBFieldNames.SignOff.Manufacturer].ToString();
                    Quantity = (decimal)dr[DataTempletes.DBFieldNames.SignOff.Quantity];
                    QuantityUnit = dr[DataTempletes.DBFieldNames.SignOff.QuantityUnit].ToString();
                    ERP_PID = dr[DataTempletes.DBFieldNames.SignOff.ERP_PID].ToString();
                    StatusID = (int)dr[DataTempletes.DBFieldNames.SignOff.StatusID];
                    DateOperated = (DateTime)dr[DataTempletes.DBFieldNames.SignOff.DateOperated];
                    DateRetirement = (DateTime)dr[DataTempletes.DBFieldNames.SignOff.DateRetirement];
                    PlacementLocation = dr[DataTempletes.DBFieldNames.SignOff.PlacementLocation].ToString();
                    Remark = dr[DataTempletes.DBFieldNames.SignOff.Remark].ToString();
                }

                public Guid ID = Guid.Empty;
                public Guid SupplyID = Guid.Empty;
                public string UserID = null;
                public string Consumers = null;
                public string Usage = null;
                public string Model = null;
                public string Manufacturer = null;
                public decimal Quantity = -1;
                public string QuantityUnit = null;
                public string ERP_PID = null;
                public int StatusID = -1;
                public DateTime DateOperated = DateTime.MinValue;
                public DateTime DateRetirement = DateTime.MinValue;
                public string PlacementLocation = null;
                public string Remark = null;
            }
            public List<Item> Content = null;
            //public Dictionary<int, string> StatusDict;
        }
        public enum RequestDataOperatTypes
        {
            None = 0,
            Select = 1,
            Insert = 2,
            Delete = 4,
            Update = 8
        }
        public static class DBFieldNames
        {
            public static class User
            {
                public const string TableName = "User";
                public const string ID = "ID";
                public const string Name = "Name";
                public const string SexID = "SexID";
                public const string UnitID = "UnitID";
                public const string CPhoneNoMesh = "CPhoneNoMesh";
                public const string LoginPwdMesh = "LoginPwdMesh";
                public const string LoginPwdInited = "LoginPwdInited";
                public const string Authorities = "Authorities";
            }
            public static class Unit
            {
                public const string TableName = "Unit";
                public const string ID = "ID";
                public const string PUnitID = "PUnitID";
                public const string Name = "Name";
                public const string Remark = "Remark";
            }
            public static class Supplies
            {
                public const string TableName = "Supplies";
                public const string ID = "ID";
                public const string ProjectName = "ProjectName";
                public const string Definition = "Definition";
                public const string ContractID = "ContractID";
                public const string Description = "Description";
                public const string Quantity = "Quantity";
                public const string Supplier = "Supplier";
                public const string DeliveryDate = "DeliveryDate";
                public const string ProofDeliveryID = "ProofDeliveryID";
                public const string ProofAcceptanceID = "ProofAcceptanceID";
                public const string ProofSignOffID = "ProofSignOffID";
                public const string Remark = "Remark";
                public const string Creator = "Creator";
            }
            public static class SupplyStatus
            {
                public const string TableName = "SupplyStatus";
                public const string ID = "ID";
                public const string Name = "Name";
            }
            public static class SignOff
            {
                public const string TableName = "SignOff";
                public const string ID = "ID";
                public const string SupplyID = "SupplyID";
                public const string UserID = "UserID";
                public const string Consumers = "Consumers";
                public const string Usage = "Usage";
                public const string Model = "Model";
                public const string Manufacturer = "Manufacturer";
                public const string Quantity = "Quantity";
                public const string QuantityUnit = "QuantityUnit";
                public const string ERP_PID = "ERP_PID";
                public const string StatusID = "StatusID";
                public const string DateOperated = "DateOperated";
                public const string DateRetirement = "DateRetirement";
                public const string PlacementLocation = "PlacementLocation";
                public const string Remark = "Remark";
            }
            public static class Sex
            {
                public const string TableName = "Sex";
                public const string ID = "ID";
                public const string Name = "Name";
            }
            public static class FileList
            {
                public const string TableName = "FileList";
                public const string ID = "ID";
                public const string No = "No";
                public const string Name = "Name";
                public const string Uploader = "Uploader";
                public const string UploadTime = "UploadTime";

            }
        }

        [Serializable]
        public class UniversalFileSystemInfo
        {
            public UniversalFileSystemInfo()
            { }
            public char DirectorySeparatorChar;
            //[NonSerialized]
            //private string _FullName;
            // [Serializable] or [NonSerialized] only works on fields, not properties.


            public string FullName;
            public string Name
            {
                get
                {
                    if (FullName.Length > 1
                        && FullName.Contains(DirectorySeparatorChar))
                        return FullName.Substring(FullName.LastIndexOf(DirectorySeparatorChar) + 1);
                    else
                        return FullName;
                }
            }
            public string DirPath
            {
                get
                {
                    if (FullName.Length > 1
                        && FullName.Contains(DirectorySeparatorChar))
                        return FullName.Substring(0, FullName.LastIndexOf(DirectorySeparatorChar));
                    else
                        return FullName;
                }
            }
            public string Extension
            {
                get
                {
                    if (Attributes.HasFlag(FileAttributes.Directory))
                        return "";

                    if (Name.Contains("."))
                        return Name.Substring(Name.LastIndexOf("."));
                    else
                        return "";
                }
            }

            public long Size;
            public string AttributesCode;
            public FileAttributes Attributes
            {
                set
                {
                    StringBuilder code = new StringBuilder();
                    if (value.HasFlag(FileAttributes.Archive)) code.Append("A");
                    if (value.HasFlag(FileAttributes.Compressed)) code.Append("C");
                    if (value.HasFlag(FileAttributes.Device)) code.Append("Dev");
                    if (value.HasFlag(FileAttributes.Directory)) code.Append("Dir");
                    if (value.HasFlag(FileAttributes.Encrypted)) code.Append("E");
                    if (value.HasFlag(FileAttributes.Hidden)) code.Append("H");
                    if (value.HasFlag(FileAttributes.IntegrityStream)) code.Append("I");
                    if (value.HasFlag(FileAttributes.Normal)) code.Append("Nor");
                    if (value.HasFlag(FileAttributes.NoScrubData)) code.Append("Nsd");
                    if (value.HasFlag(FileAttributes.NotContentIndexed)) code.Append("Nci");
                    if (value.HasFlag(FileAttributes.Offline)) code.Append("O");
                    if (value.HasFlag(FileAttributes.ReadOnly)) code.Append("Ro");
                    if (value.HasFlag(FileAttributes.ReparsePoint)) code.Append("Rp");
                    if (value.HasFlag(FileAttributes.SparseFile)) code.Append("Sf");
                    if (value.HasFlag(FileAttributes.System)) code.Append("Sy");
                    if (value.HasFlag(FileAttributes.Temporary)) code.Append("T");
                    AttributesCode = code.ToString();
                }
                get
                {
                    FileAttributes result = 0;
                    if (AttributesCode.Contains("A")) result |= FileAttributes.Archive;
                    if (AttributesCode.Contains("C")) result |= FileAttributes.Compressed;
                    if (AttributesCode.Contains("Dev")) result |= FileAttributes.Device;
                    if (AttributesCode.Contains("Dir")) result |= FileAttributes.Directory;
                    if (AttributesCode.Contains("E")) result |= FileAttributes.Encrypted;
                    if (AttributesCode.Contains("H")) result |= FileAttributes.Hidden;
                    if (AttributesCode.Contains("I")) result |= FileAttributes.IntegrityStream;
                    if (AttributesCode.Contains("Nor")) result |= FileAttributes.Normal;
                    if (AttributesCode.Contains("Nsd")) result |= FileAttributes.NoScrubData;
                    if (AttributesCode.Contains("Nci")) result |= FileAttributes.NotContentIndexed;
                    if (AttributesCode.Contains("O")) result |= FileAttributes.Offline;
                    if (AttributesCode.Contains("Ro")) result |= FileAttributes.ReadOnly;
                    if (AttributesCode.Contains("Rp")) result |= FileAttributes.ReparsePoint;
                    if (AttributesCode.Contains("Sf")) result |= FileAttributes.SparseFile;
                    if (AttributesCode.Contains("Sy")) result |= FileAttributes.System;
                    if (AttributesCode.Contains("T")) result |= FileAttributes.Temporary;
                    return result;
                }
            }
            public bool IsDir
            {
                get => Attributes.HasFlag(FileAttributes.Directory);
            }
            public DateTime CreationTime;
            public DateTime LastWriteTime;
            public UniversalFileSystemInfo Clone()
            {
                return new UniversalFileSystemInfo()
                {
                    DirectorySeparatorChar = DirectorySeparatorChar,
                    FullName = FullName,
                    Attributes = Attributes,
                    CreationTime = CreationTime,
                    LastWriteTime = LastWriteTime,
                };
            }
        }
    }
}
