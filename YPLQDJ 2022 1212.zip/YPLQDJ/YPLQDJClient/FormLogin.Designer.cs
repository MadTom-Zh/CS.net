﻿namespace MadTomDev.App.YPLQDJ
{
    partial class FormLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button_resetPwd = new System.Windows.Forms.Button();
            this.button_login = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.maskedTextBox_password = new System.Windows.Forms.MaskedTextBox();
            this.textBox_userId = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.label_info = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // button_resetPwd
            // 
            this.button_resetPwd.Location = new System.Drawing.Point(89, 98);
            this.button_resetPwd.Name = "button_resetPwd";
            this.button_resetPwd.Size = new System.Drawing.Size(75, 27);
            this.button_resetPwd.TabIndex = 11;
            this.button_resetPwd.Text = "重置密码";
            this.button_resetPwd.UseVisualStyleBackColor = true;
            this.button_resetPwd.Click += new System.EventHandler(this.button_resetPwd_Click);
            // 
            // button_login
            // 
            this.button_login.Location = new System.Drawing.Point(173, 98);
            this.button_login.Name = "button_login";
            this.button_login.Size = new System.Drawing.Size(75, 27);
            this.button_login.TabIndex = 10;
            this.button_login.Text = "登陆";
            this.button_login.UseVisualStyleBackColor = true;
            this.button_login.Click += new System.EventHandler(this.button_login_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "密码";
            // 
            // maskedTextBox_password
            // 
            this.maskedTextBox_password.Location = new System.Drawing.Point(89, 58);
            this.maskedTextBox_password.Name = "maskedTextBox_password";
            this.maskedTextBox_password.PasswordChar = '#';
            this.maskedTextBox_password.Size = new System.Drawing.Size(159, 20);
            this.maskedTextBox_password.TabIndex = 8;
            this.maskedTextBox_password.Validating += new System.ComponentModel.CancelEventHandler(this.maskedTextBox_password_Validating);
            // 
            // textBox_userId
            // 
            this.textBox_userId.Location = new System.Drawing.Point(89, 25);
            this.textBox_userId.Name = "textBox_userId";
            this.textBox_userId.Size = new System.Drawing.Size(159, 20);
            this.textBox_userId.TabIndex = 7;
            this.textBox_userId.Validating += new System.ComponentModel.CancelEventHandler(this.textBox_userId_Validating);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "工号";
            // 
            // errorProvider
            // 
            this.errorProvider.ContainerControl = this;
            // 
            // label_info
            // 
            this.label_info.AutoSize = true;
            this.label_info.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_info.ForeColor = System.Drawing.Color.DarkRed;
            this.label_info.Location = new System.Drawing.Point(27, 136);
            this.label_info.Name = "label_info";
            this.label_info.Size = new System.Drawing.Size(0, 18);
            this.label_info.TabIndex = 12;
            // 
            // FormLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(286, 161);
            this.Controls.Add(this.label_info);
            this.Controls.Add(this.button_resetPwd);
            this.Controls.Add(this.button_login);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.maskedTextBox_password);
            this.Controls.Add(this.textBox_userId);
            this.Controls.Add(this.label1);
            this.KeyPreview = true;
            this.Name = "FormLogin";
            this.Text = "登陆";
            this.Load += new System.EventHandler(this.FormLogin_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FormLogin_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_resetPwd;
        private System.Windows.Forms.Button button_login;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_password;
        private System.Windows.Forms.TextBox textBox_userId;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ErrorProvider errorProvider;
        private System.Windows.Forms.Label label_info;
    }
}

