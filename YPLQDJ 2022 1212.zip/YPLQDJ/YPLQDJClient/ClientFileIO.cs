﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadTomDev.App.YPLQDJ
{
    public class ClientFileIO
    {
        private ClientCore core;
        public ClientFileIO(ClientCore core)
        {
            this.core = core;
            string baseDir = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            IconDir = Path.Combine(baseDir, Application.ProductName + "_Icons");
            if (!Directory.Exists(IconDir))
                Directory.CreateDirectory(IconDir);

            TmpDir = Path.Combine(baseDir, Application.ProductName + "_Tmp");
            if (!Directory.Exists(TmpDir))
                Directory.CreateDirectory(TmpDir);

        }

        public string TmpDir { private set; get; }
        public string IconDir { private set; get; }

        public byte[] ReadFile(string file, int offset, int length, out bool isEndPack)
        {
            isEndPack = false;
            if (!File.Exists(file))
                return null;

            byte[] result = new byte[length];
            int readLength;
            using (FileStream fs = new FileStream(file, FileMode.Open, FileAccess.Read))
            {
                if (offset >= fs.Length)
                {
                    isEndPack = true;
                    return null;
                }
                readLength = fs.Read(result, offset, length);
                isEndPack = fs.Length == (offset + readLength);
                if (readLength < length)
                {
                    byte[] newArr = new byte[readLength];
                    result.CopyTo(newArr, 0);
                    return newArr;
                }
                else return result;
            }
        }
        public void WriteFile(string file, int offset, byte[] data)
        {
            using (Stream fileStream = new FileStream(file, FileMode.OpenOrCreate, FileAccess.Write))
                fileStream.Write(data, offset, data.Length);
        }
    }
}
