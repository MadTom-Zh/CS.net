﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Media;
using System.Net;
using System.Text;
using System.Windows.Forms;

using MadTomDev.UIs.ExDialogs;

namespace MadTomDev.App.YPLQDJ
{
    public partial class FormConfig : Form
    {
        public FormConfig()
        {
            InitializeComponent();
        }

        public bool SelectedIPV4orIPV6
        {
            get => radioButton_addrIPV4.Checked;
            set
            {
                radioButton_addrIPV4.Checked = value;
                radioButton_addrIPV6.Checked = !value;
            }
        }
        private void radioButton_addrIPV4_CheckedChanged(object sender, EventArgs e)
        { textBox_serverIPv4.Enabled = ((RadioButton)sender).Checked; }
        private void radioButton_addrIPV6_CheckedChanged(object sender, EventArgs e)
        { textBox_serverIPv6.Enabled = ((RadioButton)sender).Checked; }


        public IPAddress IPv4
        {
            get
            {
                try
                { return IPAddress.Parse(textBox_serverIPv4.Text); }
                catch (Exception)
                { return IPAddress.Any; }
            }
            set
            {
                if (value != null)
                    textBox_serverIPv4.Text = value.ToString();
            }
        }
        public IPAddress IPv6
        {
            get
            {
                try
                { return IPAddress.Parse(textBox_serverIPv6.Text); }
                catch (Exception)
                { return IPAddress.IPv6Any; }
            }
            set
            {
                if (value != null)
                    textBox_serverIPv6.Text = value.ToString();
            }
        }
        public int Port
        {
            get => int.Parse(textBox_serverPort.Text);
            set
            {
                if (value > 0)
                    textBox_serverPort.Text = value.ToString();
                else
                    textBox_serverPort.Text = "25571";
            }
        }

        private void FormConfig_Shown(object sender, EventArgs e)
        {

        }

        private void textBox_serverIPv4_Validating(object sender, CancelEventArgs e)
        {
            if (!radioButton_addrIPV4.Checked)
            {
                return;
            }
            try
            {
                IPAddress test = IPAddress.Parse(textBox_serverIPv4.Text);
                if (test.AddressFamily != System.Net.Sockets.AddressFamily.InterNetwork)
                    throw new ArgumentException("输入的不是IPV4地址");
                errorProvider.SetError(textBox_serverIPv4, null);
            }
            catch (Exception err)
            {
                errorProvider.SetError(textBox_serverIPv4, err.Message);
                e.Cancel = true;
            }
        }
        private void textBox_serverIPv6_Validating(object sender, CancelEventArgs e)
        {
            if (!radioButton_addrIPV6.Checked)
            {
                return;
            }
            try
            {
                IPAddress test = IPAddress.Parse(textBox_serverIPv6.Text);
                if (test.AddressFamily != System.Net.Sockets.AddressFamily.InterNetworkV6)
                    throw new ArgumentException("输入的不是IPV6地址");
                errorProvider.SetError(textBox_serverIPv6, null);
            }
            catch (Exception err)
            {
                errorProvider.SetError(textBox_serverIPv6, err.Message);
                e.Cancel = true;
            }
        }

        private void textBox_serverPort_Validating(object sender, CancelEventArgs e)
        {
            try
            {
                int test = int.Parse(textBox_serverPort.Text);
                errorProvider.SetError(textBox_serverPort, null);
            }
            catch (Exception err)
            {
                errorProvider.SetError(textBox_serverPort, err.Message);
            }
        }

        private void button_ok_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(errorProvider.GetError(textBox_serverIPv4))
                && string.IsNullOrWhiteSpace(errorProvider.GetError(textBox_serverPort)))
            {
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                ExCtrlMethords.ErrorProvider_ReBlink(errorProvider);
                SystemSounds.Beep.Play();
            }
        }

        private void button_cancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }



        //private delegate void CloseDelegate();
        //public new void Close()
        //{
        //    if (InvokeRequired)
        //    {
        //        CloseDelegate callback = new CloseDelegate(Close);
        //        Invoke(callback);
        //    }
        //    else
        //    {
        //        base.Close();
        //    }
        //}
    }
}
