﻿using MadTomDev.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Media;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Windows.Forms;

using MadTomDev.UIs.ExDialogs;

namespace MadTomDev.App.YPLQDJ
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        public ClientCore core;
        private void FormLogin_Load(object sender, EventArgs e)
        {
        }

        public string UserId
        { get => textBox_userId.Text; }
        public string UserPassword
        { get => maskedTextBox_password.Text; }

        private delegate void SetInfoDelegate(string v);
        private void _SetInfo(string v)
        {
            label_info.Text = v;
        }
        public string Info
        {
            set
            {
                if (InvokeRequired)
                {
                    SetInfoDelegate callback = new SetInfoDelegate(_SetInfo);
                    Invoke(callback, value);
                }
                else
                    _SetInfo(value);
            }
        }

        private void textBox_userId_Validating(object sender, CancelEventArgs e)
        {
            string userId = textBox_userId.Text;
            if (string.IsNullOrWhiteSpace(userId))
                errorProvider.SetError(textBox_userId, "请输入工号");
            else if (userId.Contains(" ") || userId.Contains("=")
                || userId.Contains("\'") || userId.Contains("\""))
                errorProvider.SetError(textBox_userId, "存在非法字符");
            else
                errorProvider.SetError(textBox_userId, null);
        }

        private void maskedTextBox_password_Validating(object sender, CancelEventArgs e)
        {
            string userPwd = maskedTextBox_password.Text;
            if (string.IsNullOrWhiteSpace(userPwd))
                errorProvider.SetError(maskedTextBox_password, "请输入密码");
            else
                errorProvider.SetError(maskedTextBox_password, null);
        }

        public bool toResetPassword { set; get; } = false;
        private void button_resetPwd_Click(object sender, EventArgs e)
        {
            if (button_login.Enabled)
            {
                button_resetPwd.Enabled = false;
                toResetPassword = true;
                button_login_Click(sender, e);
            }
            else
                SystemSounds.Beep.Play();
        }

        private void button_login_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(errorProvider.GetError(textBox_userId))
                && string.IsNullOrWhiteSpace(errorProvider.GetError(maskedTextBox_password)))
            {
                if (!core.socketClient.socket.Connected)
                {
                    MessageBox.Show(
                        this,
                        "服务器端已经拒绝连接，可能的原因：" + Environment.NewLine
                        + ("· 您在短时间内多次错误登陆；" + Environment.NewLine)
                        + ("· 您在短时间内频繁重启客户端；" + Environment.NewLine)
                        + ("· 终端上其他应用正尝试攻击服务器。" + Environment.NewLine + Environment.NewLine)
                        + ("您可以：" + Environment.NewLine)
                        + ("· (从连接拒绝开始)等待至少一小时；" + Environment.NewLine)
                        + ("· 换一台终端；" + Environment.NewLine)
                        + ("· 联系服务器管理员解除锁定。" + Environment.NewLine),
                        "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                label_info.Text = "正在登陆……";
                button_login.Enabled = false;

                core.Login(UserId, UserPassword);
            }
            else
            {
                ExCtrlMethords.ErrorProvider_ReBlink(errorProvider);
                SystemSounds.Beep.Play();
            }
        }

        private delegate void SetButtonsEnableDelegate(bool enable);
        internal void SetButtonsEnable(bool enable)
        {
            if (InvokeRequired)
            {
                SetButtonsEnableDelegate callback
                    = new SetButtonsEnableDelegate(SetButtonsEnable);
                this.Invoke(callback, enable);
            }
            else
            {
                button_login.Enabled = enable;
                button_resetPwd.Enabled = enable;
            }
        }

        private delegate void CloseDelegate();
        public new void Close()
        {
            if (InvokeRequired)
            {
                CloseDelegate callback = new CloseDelegate(Close);
                Invoke(callback);
            }
            else
            {
                base.Close();
            }
        }

        private void FormLogin_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                if (button_login.Enabled)
                    button_login_Click(sender, null);
        }
    }
}
