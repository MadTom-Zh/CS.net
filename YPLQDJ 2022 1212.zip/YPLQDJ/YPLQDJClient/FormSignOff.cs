﻿using MadTomDev.CommonClasses;
using MadTomDev.UIs.ExDialogs;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace MadTomDev.App.YPLQDJ
{
    public partial class FormSignOff : Form
    {
        public FormSignOff()
        {
            InitializeComponent();
        }

        public ClientCore core;
        private void FormSignOff_FormClosing(object sender, FormClosingEventArgs e)
        { e.Cancel = true; this.Hide(); }


        #region show info

        private delegate void _ShowNLogInfoDelegate(string info, bool showProgressBar);
        public void ShowNLogInfo(string info, bool showProgressBar = false)
        {
            if (InvokeRequired)
            {
                _ShowNLogInfoDelegate callback
                    = new _ShowNLogInfoDelegate(ShowNLogInfo);
                this.Invoke(callback, info, showProgressBar);
            }
            else
            {
                core.logger.Log(info);
                toolStripStatusLabel_info.Text = info;
                toolStripProgressBar_info.Visible = showProgressBar;
                EnableCtrls(!showProgressBar);
                this.Cursor = showProgressBar ? Cursors.AppStarting : Cursors.Default;
                Update();
            }
        }
        private void EnableCtrls(bool enable = true)
        {
            dataGridView_list.Enabled = enable;
            button_save.Enabled = enable;
            if (core.LoginUser.Authorities.ReUploadSignOffTempleteXlsx)
                button_uploadTpl.Enabled = enable;
            button_downloadTpl.Enabled = enable;
            button_downloadTpl_FillNOpen.Enabled = enable;
        }
        private delegate void _ShowNLogErrorDelegate(Exception err);
        public void ShowNLogError(Exception err)
        {
            if (InvokeRequired)
            {
                _ShowNLogErrorDelegate callback
                    = new _ShowNLogErrorDelegate(ShowNLogError);
                this.Invoke(callback, err);
            }
            else
            {
                core.logger.Log(err);
                toolStripStatusLabel_info.Text = err.Message;
                toolStripProgressBar_info.Visible = false;
                Update();
                MessageBoxAlone.Show(err.ToString(), "错误！", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private delegate void _ShowNLogErrorDelegate2(string preInfo, Exception err);
        public void ShowNLogError(string preInfo, Exception err)
        {
            if (InvokeRequired)
            {
                _ShowNLogErrorDelegate2 callback
                    = new _ShowNLogErrorDelegate2(ShowNLogError);
                this.Invoke(callback, preInfo, err);
            }
            else
            {
                core.logger.Log(preInfo);
                core.logger.Log(err);
                toolStripStatusLabel_info.Text = preInfo + " " + err.Message;
                toolStripProgressBar_info.Visible = false;
                Update();
                MessageBoxAlone.Show(
                    preInfo + Environment.NewLine + err.ToString(),
                    "错误！", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion

        #region list, sign-off
        public DataTempletes.SupplyList.Item selectedSupplyInfo;
        internal void Init(DataTempletes.SupplyList.Item supplyInfo)
        {
            this.selectedSupplyInfo = supplyInfo;
            textBox_projFullName.Text = supplyInfo.ProjectName;
            textBox_description.Text = supplyInfo.Description;
            textBox_supplier.Text = supplyInfo.Supplier;

            ShowNLogInfo("正在获取物资状态标识...", true);
            core.QuerySupplyStatus();
            // after status got, core will triger RefreshSignOffList()
        }
        private void button_refreshSignOffList_Click(object sender, EventArgs e)
        {
            RefreshSignOffList();
        }
        private delegate void RefreshSignOffListDelegate();
        private bool isRefreshingSignOffList = false;
        public void RefreshSignOffList()
        {
            if (InvokeRequired)
            {
                RefreshSignOffListDelegate callback
                    = new RefreshSignOffListDelegate(RefreshSignOffList);
                Invoke(callback);
            }
            else
            {
                isRefreshingSignOffList = true;
                textBox_RemainingQuantity.Text = $"获取中 / {selectedSupplyInfo.Quantity.ToString("G")}";
                dataGridView_list.Rows.Clear();
                dataGridView_list.ReadOnly = !core.LoginUser.Authorities.MaintainSignOff;

                // reload list
                ShowNLogInfo("正在载入列表...", true);
                core.QuerySignOffs(core.LoginUser.ID, selectedSupplyInfo.ID);
            }
        }

        private delegate void SetSignOffListDelegate(Guid supplyID, DataTempletes.SignOffList signOffList);
        internal void SetSignOffList(Guid supplyID, DataTempletes.SignOffList signOffList)
        {
            if (InvokeRequired)
            {
                SetSignOffListDelegate callback
                    = new SetSignOffListDelegate(SetSignOffList);
                Invoke(callback, supplyID, signOffList);
            }
            else
            {
                if (!core.LoginUser.Authorities.QuerySignOff)
                {
                    ShowNLogInfo("您无权查询领用信息");
                    EnableCtrls(false);
                    return;
                }


                if (supplyID != selectedSupplyInfo.ID)
                {
                    ShowNLogInfo("服务器返回的 领用清单 不属于当前选中的物资");
                    return;
                }

                DataGridViewComboBoxColumn cbCol = (DataGridViewComboBoxColumn)dataGridView_list.Columns[8];
                cbCol.Items.Clear();
                foreach (KeyValuePair<int, string> codeText in core.SupplyStatus_CT)
                    cbCol.Items.Add(codeText.Value);

                if (signOffList != null)
                {
                    DataGridViewRow newDgvRow;
                    int no = 1;
                    foreach (DataTempletes.SignOffList.Item item in signOffList.Content)
                    {
                        newDgvRow = dataGridView_list.Rows[dataGridView_list.Rows.Add()];
                        newDgvRow.Tag = new RowTagData() { item = item, };
                        SetSignOffData_SetRow(newDgvRow, item, no++);
                    }
                }
                isRefreshingSignOffList = false;

                // load remaining quantity
                ShowNLogInfo("正在询问剩余数量...", true);
                core.QuerySignOffCount(selectedSupplyInfo.ID);
            }
        }
        private void SetSignOffData_SetRow(DataGridViewRow dgvRow, DataTempletes.SignOffList.Item data, int rowNo = -1)
        {
            if (rowNo > 0)
                dgvRow.Cells[0].Value = rowNo;
            dgvRow.Cells[1].Value = data.Consumers;
            dgvRow.Cells[2].Value = data.Usage;
            dgvRow.Cells[3].Value = data.Model;
            dgvRow.Cells[4].Value = data.Manufacturer;
            dgvRow.Cells[5].Value = data.Quantity;
            dgvRow.Cells[6].Value = data.QuantityUnit;
            dgvRow.Cells[7].Value = data.ERP_PID;
            dgvRow.Cells[8].Value = core.SupplyStatus_CT[data.StatusID];
            dgvRow.Cells[9].Value = data.DateOperated.ToString("yyyy-MM-dd");
            dgvRow.Cells[10].Value = data.DateRetirement.ToString("yyyy-MM-dd");
            dgvRow.Cells[11].Value = data.PlacementLocation;
            dgvRow.Cells[12].Value = data.Remark;
        }


        private decimal signOffCount_total, signOffCount_byOthers;
        private delegate void SetSignOffCountDelegate(Guid supplyID, decimal? count);
        internal void SetSignOffCount(Guid supplyID, decimal? count)
        {
            if (InvokeRequired)
            {
                SetSignOffCountDelegate callback
                    = new SetSignOffCountDelegate(SetSignOffCount);
                Invoke(callback, supplyID, count);
            }
            else
            {
                if (supplyID != selectedSupplyInfo.ID)
                {
                    ShowNLogInfo("服务器返回的 领用数量 不属于当前选中的物资");
                    return;
                }
                if (count == null)
                {
                    ShowNLogInfo("服务器返回的 领用数量 不是数字");
                    return;
                }
                signOffCount_total = (decimal)count;
                signOffCount_byOthers = signOffCount_total - GetSignOffCount_withinList();
                textBox_RemainingQuantity.Text = $"{signOffCount_total.ToString("G")} / {selectedSupplyInfo.Quantity.ToString("G")}";
                ShowNLogInfo("领用信息加载完成");
            }
        }
        private decimal GetSignOffCount_withinList()
        {
            decimal count = 0, test;
            foreach (DataGridViewRow dgvRow in dataGridView_list.Rows)
            {
                test = SimpleValueHelper.TryGetDecimal(dgvRow.Cells[5].Value);
                if (test > 0)
                    count += test;
            }
            return count;
        }

        #endregion


        #region row edit, save, delete

        private bool CheckCanEdit()
        {
            if (!core.LoginUser.Authorities.MaintainSignOff)
            {
                ShowNLogInfo("您无权维护领用信息");
                return false;
            }
            return true;
        }
        private DataGridViewRow editingRow = null;
        private string editingRowOrgValue = null;
        private bool needSave = false;
        private void dataGridView_list_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (isRefreshingSignOffList)
                return;
            if (!CheckCanEdit())
                return;

            if (editingRow != null
                && dataGridView_list.Rows[e.RowIndex] != editingRow
                && CheckNeedSaveNShowMessage())
            {
                e.Cancel = true;
                return;
            }
            object test = dataGridView_list.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;
            if (test == null)
            {
                if (e.ColumnIndex == 1)
                {
                    editingRowOrgValue = core.LoginUser.Name;
                    dataGridView_list.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = editingRowOrgValue;
                }
                else
                    editingRowOrgValue = null;
            }
            else
                editingRowOrgValue = test.ToString();
        }
        private bool CheckNeedSaveNShowMessage()
        {
            if (needSave)
            {
                MessageBox.Show(this, "请先保存！", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            return needSave;
        }

        private void dataGridView_list_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (isRefreshingSignOffList)
                return;
            object test = dataGridView_list.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;
            string testStr = test == null ? null : test.ToString();
            if (editingRowOrgValue == testStr)
            {
                return;
            }

            // modified row(from DB), show yellow color
            editingRow = dataGridView_list.Rows[e.RowIndex];
            if (editingRow.Tag != null && editingRow.Tag is RowTagData)
            {
                RowTagData rTag = (RowTagData)editingRow.Tag;
                rTag.modified = true;
            }
            editingRow.Cells[e.ColumnIndex].Tag
                = new CellTagData() { modified = true, };

            needSave = true;
        }
        private void dataGridView_list_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (isRefreshingSignOffList)
                return;
            if (e.RowIndex < 0 || e.ColumnIndex < 0)
                return;

            if (e.ColumnIndex == 8)
            {
                if (editingRow != null
                    && dataGridView_list.Rows[e.RowIndex] != editingRow
                    && CheckNeedSaveNShowMessage())
                {
                    RowTagData rowTag
                        = dataGridView_list.Rows[e.RowIndex].Tag == null ?
                        null : (RowTagData)dataGridView_list.Rows[e.RowIndex].Tag;
                    if (rowTag != null)
                        SetSignOffData_SetRow(dataGridView_list.Rows[e.RowIndex], rowTag.item);
                    return;
                }

                editingRow = dataGridView_list.Rows[e.RowIndex];
                if (editingRow.Tag != null && editingRow.Tag is RowTagData)
                {
                    RowTagData rTag = (RowTagData)editingRow.Tag;
                    rTag.modified = true;
                }
                editingRow.Cells[e.ColumnIndex].Tag
                    = new CellTagData() { modified = true, };

                needSave = true;
            }
        }
        private DateTime DateOperated_Org, DateRetirement_Org, Date_pickerOrg;
        private int dataPicker_rowIdx, dataPicker_columnIdx;
        private void dataGridView_list_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {  /* do nothing */   }
        private void dataGridView_list_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 9 || e.ColumnIndex == 10)
            {
                // 9-DateOperated, 10-DateRetirement
                if (!CheckCanEdit())
                {
                    dateTimePicker.Hide();
                    return;
                }

                if (editingRow != null
                    && dataGridView_list.Rows[e.RowIndex] != editingRow
                    && CheckNeedSaveNShowMessage())
                {
                    dateTimePicker.Hide();
                    return;
                }
            }
            else
            {
                dateTimePicker.Hide();
                return;
            }

            dataPicker_rowIdx = e.RowIndex;
            dataPicker_columnIdx = e.ColumnIndex;
            DataGridViewRow clickingRow = dataGridView_list.Rows[dataPicker_rowIdx];
            if (e.ColumnIndex == 9)
            {
                DateOperated_Org
                    = (clickingRow.Tag == null) ?
                        DateTime.Now : ((RowTagData)clickingRow.Tag).item.DateOperated;
                if (DateOperated_Org < dateTimePicker.MinDate)
                    dateTimePicker.Value = dateTimePicker.MinDate;
                else if (DateOperated_Org > dateTimePicker.MaxDate)
                    dateTimePicker.Value = dateTimePicker.MaxDate;
                else
                    dateTimePicker.Value = DateOperated_Org;

                Rectangle clickingCellRectangle
                    = dataGridView_list.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, false);

                dateTimePicker.Top
                    = dataGridView_list.Top
                    + clickingCellRectangle.Top;
                dateTimePicker.Left
                    = dataGridView_list.Left
                    + clickingCellRectangle.Left;
                dateTimePicker.Width = clickingCellRectangle.Width;
                dateTimePicker.Height = clickingCellRectangle.Height;
                dateTimePicker.Show();
                dateTimePicker.Focus();
            }
            else
            if (e.ColumnIndex == 10)
            {
                DateRetirement_Org
                    = (clickingRow.Tag == null) ?
                        DateTime.MaxValue : ((RowTagData)clickingRow.Tag).item.DateOperated;
                if (DateRetirement_Org < dateTimePicker.MinDate)
                    dateTimePicker.Value = dateTimePicker.MinDate;
                else if (DateRetirement_Org > dateTimePicker.MaxDate)
                    dateTimePicker.Value = dateTimePicker.MaxDate;
                else
                    dateTimePicker.Value = DateRetirement_Org;

                Rectangle clickingCellRectangle
                    = dataGridView_list.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, false);

                dateTimePicker.Top
                    = dataGridView_list.Top
                    + clickingCellRectangle.Top;
                dateTimePicker.Left
                    = dataGridView_list.Left
                    + clickingCellRectangle.Left;
                dateTimePicker.Show();
                dateTimePicker.Focus();
            }
            Date_pickerOrg = dateTimePicker.Value;
        }
        private void dateTimePicker_KeyDown(object sender, KeyEventArgs e)
        {
            if (isRefreshingSignOffList)
            {
                dateTimePicker.Hide();
                return;
            }
            if (e.KeyCode == Keys.Enter)
            {
                if (dateTimePicker.Value != Date_pickerOrg)
                {
                    editingRow = dataGridView_list.Rows[dataPicker_rowIdx];
                    if (editingRow.Tag != null && editingRow.Tag is RowTagData)
                    {
                        RowTagData rTag = (RowTagData)editingRow.Tag;
                        rTag.modified = true;
                    }
                    editingRow.Cells[dataPicker_columnIdx].Tag
                        = new CellTagData() { modified = true, };

                    editingRow.Cells[dataPicker_columnIdx].Value = dateTimePicker.Value.ToString("yyyy-MM-dd");
                    needSave = true;
                }
                dateTimePicker.Hide();
            }
            else if (e.KeyCode == Keys.Escape)
            {
                dateTimePicker.Hide();
            }
        }


        private void button_save_Click(object sender, EventArgs e)
        {
            if (!needSave)
            {
                ShowNLogInfo("无需保存");
                return;
            }
            DialogResult dr = MessageBox.Show(
                this,
                "确定要提交内容吗？" + Environment.NewLine + Environment.NewLine
                + "是   - 提交内容" + Environment.NewLine
                + "否   - 放弃变动(重新载入)" + Environment.NewLine
                + "取消 - 返回(继续修改)",
                "即将保存",
                MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button3);
            switch (dr)
            {
                case DialogResult.Yes:
                    SubmitSignOff();
                    break;
                case DialogResult.No:
                    if (editingRow.Tag == null)
                        dataGridView_list.Rows.Remove(editingRow);
                    else
                        SetSignOffData_SetRow(editingRow, ((RowTagData)editingRow.Tag).item); // restore
                    needSave = false;
                    editingRow = null;
                    break;
                case DialogResult.Cancel:
                    return;
            }
        }
        private void SubmitSignOff()
        {
            #region check values
            object test = editingRow.Cells[1].Value;
            bool isNotErr = true;
            string errTitle = "未知", errContent = "未获得错误原因";
            if (isNotErr)
            {
                if (test == null || string.IsNullOrWhiteSpace(test.ToString()))
                { isNotErr = false; errTitle = "错误"; errContent = "l领用人为空"; }
                else test = editingRow.Cells[2].Value;
            }
            if (isNotErr)
            {
                if (test == null || string.IsNullOrWhiteSpace(test.ToString()))
                { isNotErr = false; errTitle = "错误"; errContent = "用途为空"; }
                else test = editingRow.Cells[3].Value;
            }
            if (isNotErr)
            {
                if (test == null || string.IsNullOrWhiteSpace(test.ToString()))
                { isNotErr = false; errTitle = "错误"; errContent = "规格型号为空"; }
                else test = editingRow.Cells[4].Value;
            }
            if (isNotErr)
            {
                if (test == null || string.IsNullOrWhiteSpace(test.ToString()))
                { isNotErr = false; errTitle = "错误"; errContent = "制造商为空"; }
                else test = editingRow.Cells[5].Value;
            }
            if (isNotErr)
            {
                if (test == null || string.IsNullOrWhiteSpace(test.ToString()))
                { isNotErr = false; errTitle = "错误"; errContent = "数量为空"; }
            }
            if (isNotErr)
            {
                if (SimpleValueHelper.TryGetDecimal(test) < 0)
                { isNotErr = false; errTitle = "错误"; errContent = "数量不是数字"; }
                else test = editingRow.Cells[6].Value;
            }
            if (isNotErr)
            {
                if (test == null || string.IsNullOrWhiteSpace(test.ToString()))
                { isNotErr = false; errTitle = "错误"; errContent = "数量单位为空"; }
                else test = editingRow.Cells[7].Value;
            }
            if (isNotErr)
            {
                if (test == null || string.IsNullOrWhiteSpace(test.ToString()))
                { isNotErr = false; errTitle = "错误"; errContent = "ERP编码资产为空"; }
                else test = editingRow.Cells[8].Value;
            }
            if (isNotErr)
            {
                if (test == null || string.IsNullOrWhiteSpace(test.ToString()))
                { isNotErr = false; errTitle = "错误"; errContent = "物资状态为空"; }
                else test = editingRow.Cells[9].Value;
            }
            if (isNotErr)
            {
                if (test == null || string.IsNullOrWhiteSpace(test.ToString()))
                { isNotErr = false; errTitle = "错误"; errContent = "投运日期为空"; }
            }
            if (isNotErr)
            {
                if (SimpleValueHelper.TryGetDate(test) == DateTime.MinValue)
                { isNotErr = false; errTitle = "错误"; errContent = "投运日期无效"; }
                else test = editingRow.Cells[10].Value;
            }
            if (isNotErr)
            {
                if (test == null || string.IsNullOrWhiteSpace(test.ToString()))
                { isNotErr = false; errTitle = "错误"; errContent = "退役日期为空"; }
            }
            if (isNotErr)
            {
                if (SimpleValueHelper.TryGetDate(test) == DateTime.MinValue)
                { isNotErr = false; errTitle = "错误"; errContent = "退役日期无效"; }
                else test = editingRow.Cells[11].Value;
            }
            if (isNotErr)
            {
                if (test == null || string.IsNullOrWhiteSpace(test.ToString()))
                { isNotErr = false; errTitle = "错误"; errContent = "放置位置为空"; }
            }
            if (isNotErr)
            {
                if (selectedSupplyInfo.Quantity < signOffCount_byOthers + GetSignOffCount_withinList())
                { isNotErr = false; errTitle = "错误"; errContent = "当前领取数量合计已经超过可领取总数"; }
            }
            if (!isNotErr)
            {
                MessageBox.Show(this, errContent, errTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            #endregion

            bool isInsert = false;
            if (editingRow.Tag == null)
            {
                isInsert = true;
                editingRow.Tag = new RowTagData()
                {
                    item = new DataTempletes.SignOffList.Item()
                    {
                        SupplyID = selectedSupplyInfo.ID,
                        ID = Guid.NewGuid(),
                        UserID = core.LoginUser.ID,
                    },
                    modified = true,
                };
            }

            RowTagData tag = (RowTagData)editingRow.Tag;
            tag.item.Consumers = editingRow.Cells[1].Value.ToString();
            tag.item.Usage = editingRow.Cells[2].Value.ToString();
            tag.item.Model = editingRow.Cells[3].Value.ToString();
            tag.item.Manufacturer = editingRow.Cells[4].Value.ToString();
            tag.item.Quantity = decimal.Parse(editingRow.Cells[5].Value.ToString());
            tag.item.QuantityUnit = editingRow.Cells[6].Value.ToString();
            tag.item.ERP_PID = editingRow.Cells[7].Value.ToString();
            tag.item.StatusID = core.GetSupplyStatusCode(editingRow.Cells[8].Value.ToString());
            tag.item.DateOperated = DateTime.Parse(editingRow.Cells[9].Value.ToString());
            tag.item.DateRetirement = DateTime.Parse(editingRow.Cells[10].Value.ToString());
            tag.item.PlacementLocation = editingRow.Cells[11].Value.ToString();
            test = editingRow.Cells[12].Value;
            tag.item.Remark = test == null ? null : test.ToString();

            if (isInsert)
                core.AccessSignOff(tag.item, DataTempletes.RequestDataOperatTypes.Insert);
            else
                core.AccessSignOff(tag.item, DataTempletes.RequestDataOperatTypes.Update);
        }


        private void dataGridView_list_KeyDown(object sender, KeyEventArgs e)
        {
            if (dataGridView_list.SelectedRows.Count == 1)
            {
                if (e.KeyCode == Keys.Delete)
                {
                    DataGridViewRow selectDGVRow = dataGridView_list.SelectedRows[0];
                    if (selectDGVRow.Tag is RowTagData)
                    {
                        RowTagData tag = (RowTagData)selectDGVRow.Tag;
                        if (tag.item != null)
                        {
                            if (MessageBox.Show(
                                this, "即将删除物资，是否继续？", "警告",
                                MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2)
                                == DialogResult.Yes)
                                core.AccessSignOff(tag.item, DataTempletes.RequestDataOperatTypes.Delete);
                        }
                    }
                }
            }
        }


        internal void SetSignOffAccessResult(bool? result, Guid signOffID,
            DataTempletes.RequestDataOperatTypes opType, Exception err)
        {
            if (result != true)
            {
                if (err != null)
                    ShowNLogError(err);
                else
                    ShowNLogInfo("操作失败，未返回失败原因。");
                return;
            }

            needSave = false;
            editingRow = null;

            bool isModOrDel = true;
            switch (opType)
            {
                case DataTempletes.RequestDataOperatTypes.Insert:
                    ShowNLogInfo($"成功添加记录[{signOffID}]");
                    break;
                case DataTempletes.RequestDataOperatTypes.Update:
                    ShowNLogInfo($"成功更新记录[{signOffID}]");
                    break;
                case DataTempletes.RequestDataOperatTypes.Delete:
                    ShowNLogInfo($"成功删除记录[{signOffID}]");
                    isModOrDel = false;
                    break;
                default:
                case DataTempletes.RequestDataOperatTypes.Select:
                    ShowNLogInfo($"成功执行(未知操作)，记录[{signOffID}]");
                    break;
            }

            DataGridViewRow effectedDGVRow = null;
            RowTagData tag = null;
            foreach (DataGridViewRow dgvRow in dataGridView_list.Rows)
            {
                if (dgvRow?.Tag is RowTagData)
                {
                    tag = (RowTagData)dgvRow.Tag;
                    if (tag.item?.ID == signOffID)
                    {
                        effectedDGVRow = dgvRow;
                        break;
                    }
                }
            }
            if (tag != null)
            {
                if (isModOrDel)
                {
                    tag.modified = false;
                    foreach (DataGridViewCell c in effectedDGVRow.Cells)
                        c.Tag = null;
                    if (SimpleValueHelper.TryGetInt(effectedDGVRow.Cells[0].Value) < 0)
                    {
                        effectedDGVRow.Cells[0].Value = GetMaxNo() + 1;
                    }
                    else
                    {
                        // refresh row
                        string tmp = effectedDGVRow.Cells[0].Value.ToString();
                        if (tmp.EndsWith(" "))
                            effectedDGVRow.Cells[0].Value = tmp.Substring(0, tmp.Length - 1);
                        else
                            effectedDGVRow.Cells[0].Value = tmp + " ";
                    }
                    dataGridView_list.Invalidate();
                }
                else
                {
                    //dataGridView_list.Rows.Remove(effectedDGVRow);
                    button_refreshSignOffList_Click(null, null);
                }
            }
        }
        private int GetMaxNo()
        {
            int result = 0, test;
            DataGridViewCell cell;

            foreach (DataGridViewRow dgvRow in dataGridView_list.Rows)
            {
                cell = dgvRow.Cells[0];
                test = SimpleValueHelper.TryGetInt(cell.Value);
                if (result < test)
                    result = test;
            }
            return result;
        }


        #endregion





        public class RowTagData
        {
            public DataTempletes.SignOffList.Item item = null;
            public bool modified = false;
        }
        public class CellTagData
        {
            public bool modified = false;
        }



        private void dataGridView_list_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0)
                return;

            DataGridViewRow paintingRow = dataGridView_list.Rows[e.RowIndex];
            DataGridViewCell curCell = paintingRow.Cells[e.ColumnIndex];
            if (dataGridView_list.SelectedCells.Contains(curCell))
                return;


            Rectangle cellBounds = e.CellBounds;
            cellBounds.Width--; cellBounds.Height--;
            Color bgColor = Color.Empty;
            if (paintingRow.Tag == null && paintingRow != dataGridView_list.Rows[dataGridView_list.Rows.Count - 1])
            {
                // new row
                if (e.ColumnIndex > 0)
                    bgColor = Color.AliceBlue;
                else
                    bgColor = Color.Gray;
            }
            else if (paintingRow.Tag is RowTagData)
            {
                RowTagData rTag = (RowTagData)paintingRow.Tag;
                if (rTag.modified)
                {
                    // modified row
                    if (e.ColumnIndex > 0)
                    {
                        if (curCell.Tag != null && curCell.Tag is CellTagData)
                        {
                            CellTagData cTag = (CellTagData)curCell.Tag;
                            if (cTag.modified)
                                bgColor = Color.Yellow;
                        }
                    }
                }
            }
            if (bgColor == Color.Empty)
                return;

            using (SolidBrush br = new SolidBrush(bgColor))
            {
                e.Graphics.FillRectangle(br, cellBounds);
                e.PaintContent(e.ClipBounds);
                e.Handled = true;
            }
        }





        #region transfer excel file, fill excel
        private void button_uploadTpl_Click(object sender, EventArgs e)
        {
            if (!core.LoginUser.Authorities.ReUploadSignOffTempleteXlsx)
            {
                MessageBox.Show(this, "您无权上传模板文件。", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult dr
                = MessageBox.Show(
                    this,
                "只能保留一个模板，要继续吗？",
                "警告",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning,
                MessageBoxDefaultButton.Button2);

            if (dr == DialogResult.Yes)
            {
                core.Show_ExcelTemplateForm();
            }
        }

        private void button_downloadTpl_Click(object sender, EventArgs e)
        {
            if (!core.LoginUser.Authorities.DownloadFileTemplateXlsx)
            {
                MessageBox.Show(this, "您无权下载传模板文件。", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (betterFolderBrowser.ShowDialog() == DialogResult.OK)
            {
                using (ClientCore.StreamOutFromServer netStream
                    = new ClientCore.StreamOutFromServer(core, new DataTempletes.FileInfo()
                    { ID = 0, No = 1, }))
                {
                    int bufferLength = 1048576, readLength;
                    byte[] buffer = new byte[bufferLength];
                    string fileName = $"国网信通公司物资领用表模板{DateTime.Now.ToString("yyyy-MM-dd")}.xlsx";
                    using (FileStream fs = new FileStream(
                        Path.Combine(betterFolderBrowser.SelectedFolder, fileName),
                        FileMode.Create
                        ))
                    {
                        long downedBytes = 0;
                        while (true)
                        {
                            ShowNLogInfo($"正在下载文件...({SimpleStringHelper.UnitsOfMeasure.GetShortString(downedBytes, "B", 1024)})", true);
                            readLength = netStream.Read(buffer, 0, bufferLength);
                            downedBytes += readLength;
                            fs.Write(buffer, 0, readLength);
                            if (readLength == 0)
                            {
                                break;
                            }
                        }
                        fs.Flush();
                        ShowNLogInfo($"模板下载完成。");
                        MessageBox.Show(this, $"已将文件 {fileName} 下载到指定位置。", "提示", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                }
            }
        }

        private void button_downloadTpl_FillNOpen_Click(object sender, EventArgs e)
        {
            if (!core.LoginUser.Authorities.DownloadFileTemplateXlsx)
            {
                MessageBox.Show(this, "您无权下载传模板文件。", "警告",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (needSave)
            {
                MessageBox.Show(this, "为防止数据错误，请保存后再使用自动填表。", "警告",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (dataGridView_list.SelectedRows.Count != 1)
            {
                MessageBox.Show(this, "请选中要填充的一行数据，然后再点击下载并填表。", "警告",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            DataGridViewRow dgvRow = dataGridView_list.SelectedRows[0];
            if (dgvRow.Tag == null)
            {
                MessageBox.Show(this, "当前选中行不是有效的数据行。", "警告",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            core.DownloadXlsFileNFillData(this, ((RowTagData)dgvRow.Tag).item);
        }

        #endregion
    }
}
