﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;

using MadTomDev.Data;

namespace MadTomDev.WWWs
{
    class ServerSettings : Data.SettingsTxt
    {
        private ServerCore core;
        public ServerSettings(ServerCore core)
        {
            this.core = core;
            string settingFileFullName
                = AppDomain.CurrentDomain.BaseDirectory + Path.DirectorySeparatorChar + "Server.cfg";
            base.SettingsFileFullName = settingFileFullName;
            if (File.Exists(settingFileFullName))
            {
                core.ShowInfoNLog("Loading server configs...");
                ReLoad();
            }
            else
            {
                // init
                core.ShowInfoNLog("No server config file found, initialing and writing...");

                // use null to listen all incoming addresses;
                ListeningAddressIPV4 = null; // Network.SocketHelper.GetLocalIPv4();
                ListeningAddressIPV6 = null; // Network.SocketHelper.GetLocalIPv6();

                ListeningPort = 25571;

                Save();
            }
        }

        public bool ListeningAddressIsIPV4orIPV6
        {
            set => base["ListeningAddressIsIPV4orIPV6"] = value.ToString();
            get
            {
                bool result;
                if (bool.TryParse(base["ListeningAddressIsIPV4orIPV6"], out result))
                    return result;

                base["ListeningAddressIsIPV4orIPV6"] = true.ToString();
                return true;
            }
        }
        public IPAddress ListeningAddressIPV4
        {
            set => base["ListeningAddressIPV4"] = value.ToString();
            get
            {
                string v = base["ListeningAddressIPV4"];
                if (!string.IsNullOrWhiteSpace(v))
                    return IPAddress.Parse(v);

                base["ListeningAddressIPV4"] = null;
                return null;
            }
        }
        public IPAddress ListeningAddressIPV6
        {
            set => base["ListeningAddressIPV6"] = value.ToString();
            get
            {
                string v = base["ListeningAddressIPV6"];
                if (!string.IsNullOrWhiteSpace(v))
                    return IPAddress.Parse(v);

                base["ListeningAddressIPV6"] = null;
                return null;
            }
        }
        public int ListeningPort
        {
            set => base["ListeningPort"] = value.ToString();
            get
            {
                int result;
                if (int.TryParse(base["ListeningPort"], out result))
                    return result;

                base["ListeningPort"] = "25571";
                return 25571;
            }
        }

        public int SessionMaxLoginFaildCount
        {
            set => base["SessionMaxLoginFaildCount"] = value.ToString();
            get
            {
                int result;
                if (int.TryParse(base["SessionMaxLoginFaildCount"], out result))
                    return result;

                base["ListeningPort"] = "5";
                return 5;
            }
        }
        public TimeSpan SessionMaxLoginFaildWithin
        {
            set => base["SessionMaxLoginFaildWithin"] = value.Ticks.ToString();
            get
            {
                long outLong;
                if (long.TryParse(base["SessionMaxLoginFaildWithin"], out outLong))
                    return TimeSpan.FromTicks(outLong);

                TimeSpan defaultValue = new TimeSpan(0, 1, 0); // one minute
                base["SessionMaxLoginFaildWithin"] = defaultValue.Ticks.ToString();
                return defaultValue;
            }
        }
        public TimeSpan SessionMaxRefuseTimeSpan
        {
            set => base["SessionMaxLoginFaildCount"] = value.Ticks.ToString();
            get
            {
                long outLong;
                if (long.TryParse(base["SessionMaxLoginFaildCount"], out outLong))
                    return TimeSpan.FromTicks(outLong);

                TimeSpan defaultValue = new TimeSpan(1, 0, 0); // one hour
                base["SessionMaxLoginFaildCount"] = defaultValue.Ticks.ToString();
                return defaultValue;
            }
        }

        public int MaxSuppliesPerPage
        {
            set => base["MaxSuppliesPerPage"] = value.ToString();
            get
            {
                int result;
                if (int.TryParse(base["MaxSuppliesPerPage"], out result))
                    return result;

                base["MaxSuppliesPerPage"] = "10";
                return 10;
            }
        }

        public int MaxConnQueue
        {
            set => base["MaxConnQueue"] = value.ToString();
            get
            {
                int result;
                if (int.TryParse(base["MaxConnQueue"], out result))
                    return result;

                base["MaxConnQueue"] = "8";
                return 8;
            }
        }

        public int ReceiveBufferLength
        {
            set => base["ReceiveBufferLength"] = value.ToString();
            get
            {
                int result;
                if (int.TryParse(base["ReceiveBufferLength"], out result))
                    return result;

                base["ReceiveBufferLength"] = "4194304";
                return 4194304;
            }
        }
        public int ReceiveTimeOutSec
        {
            set => base["ReceiveTimeOutSec"] = value.ToString();
            get
            {
                int result;
                if (int.TryParse(base["ReceiveTimeOutSec"], out result))
                    return result;

                base["ReceiveTimeOutSec"] = "60";
                return 60;
            }
        }
    }
}
