﻿using MadTomDev.Network;
using System;
using System.Collections.Generic;
using System.Text;

using System.Collections;
using MadTomDev.CommonClasses;

namespace MadTomDev.WWWs
{
    class UserSessions
    {
        private ServerCore core;
        public UserSessions(ServerCore core)
        {
            this.core = core;
        }

        public List<SessionData> list
            = new List<SessionData>();

        public int Count { get => list.Count; }

        public List<SessionData> this[string userId]
        {
            get
            {
                return list.FindAll(i => i.userID == userId);
            }
        }
        public class SessionData
        {
            public string userID;
            public SocketHelper.SocketTcpServer.ConnectedClient client;
            public DateTime loginTime;
        }


        public bool HaveSession(string userId)
        {
            bool next = false;
            do
            {
                SessionData found = list.Find(i => i.userID == userId);
                if (found != null)
                {
                    if (found.client.IsDisconnected)
                    {
                        list.Remove(found);
                        next = true;
                    }
                    else
                        return true;
                }
                else
                    return false;
            }
            while (next);
            return false;
        }
        public void AddSession(string userId, SocketHelper.SocketTcpServer.ConnectedClient client)
        {
            SessionData found = list.Find(i => i.client.RemoteEndPointString == client.RemoteEndPointString);
            if (found == null)
                list.Add(new SessionData()
                { userID = userId, loginTime = DateTime.Now, client = client, });
        }
        public void RemoveSession(SocketHelper.SocketTcpServer.ConnectedClient client)
        {
            SessionData found = list.Find(i => i.client.RemoteEndPointString == client.RemoteEndPointString);
            if (found != null)
            {
                list.Remove(found);
                found.client?.Dispose();
            }
        }
        public void RemoveSessionByUserID(string userId)
        {
            foreach (SessionData found in list.FindAll(i => i.userID == userId))
            {
                if (found != null)
                {
                    list.Remove(found);
                    found.client?.Dispose();
                }
            }
        }

        public string GetUserId(SocketHelper.SocketTcpServer.ConnectedClient client)
        {
            SessionData found = list.Find(i => i.client.RemoteEndPointString == client.RemoteEndPointString);
            if (found != null)
                return found.userID;
            else
                return null;
        }

        public string ToInfoString()
        {
            string result;
            if (list.Count > 0)
            {
                SimpleStringHelper.TableFormater tf = new SimpleStringHelper.TableFormater();
                tf.AddColumnHeader("User Id");
                tf.AddColumnHeader("IP Address");
                tf.AddColumnHeader("Login Time");
                tf.TableBorderLineStyle = SimpleStringHelper.TableFormater.TableBorderStyles.None;
                tf.TableHeaderLineStyle = SimpleStringHelper.TableFormater.TableBorderStyles.None;
                tf.TableDataRowLineStyle = SimpleStringHelper.TableFormater.TableBorderStyles.None;
                foreach (SessionData sd in list)
                {
                    tf.AddRow(new string[]
                    {
                        sd.userID,
                        sd.client.RemoteEndPointString,
                        sd.loginTime.ToString(),
                    });
                }
                tf.AutoSetColumnWidthes();
                result = Environment.NewLine + tf.ToFullString();
            }
            else
            {
                result = "[No result]";
            }
            return result;
        }

        internal void RemoveDeadSessions()
        {
            SessionData sd;
            for (int i = list.Count - 1; i >= 0; i--)
            {
                sd = list[i];
                if (sd.client.IsDisconnected)
                    list.RemoveAt(i);
            }
        }
    }
}
