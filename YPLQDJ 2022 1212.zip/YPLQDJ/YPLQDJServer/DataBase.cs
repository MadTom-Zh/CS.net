﻿using MadTomDev.App.YPLQDJ;
using MadTomDev.CommonClasses;
using MadTomDev.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SQLite;
using System.IO;
using System.Text;
using System.Threading;

namespace MadTomDev.WWWs
{
    class DataBase
    {
        private ServerCore core;
        private SQLiteHelper sqliteHelper;
        public DataBase(ServerCore core)
        {
            this.core = core;
            sqliteHelper = new SQLiteHelper(
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "AIO.db")
                );
        }

        #region private methods
        private bool _CheckUserId(string userId)
        {
            if (userId.Contains('=') || userId.Contains(' ')
                || userId.Contains('\'') || userId.Contains('\"'))
            {
                return false;
            }
            return true;
        }

        #endregion

        #region user

        public DataTempletes.User GetUser(string userId, string userPassword)
        {
            if (!_CheckUserId(userId))
                return null;

            core.pp.Password = userPassword;
            string pwdMesh = core.pp.Password_Mashed;
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append($"select * from {DataTempletes.DBFieldNames.User.TableName} ");
                cmdBdr.Append($"where {DataTempletes.DBFieldNames.User.ID}=@uid ");
                cmdBdr.Append($"and {DataTempletes.DBFieldNames.User.LoginPwdMesh}=@pwd;");
                cmd.CommandText = cmdBdr.ToString();
                cmd.Parameters.AddWithValue("@uid", userId);
                cmd.Parameters.AddWithValue("@pwd", pwdMesh);
                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(cmd))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    if (dt.Rows.Count > 0)
                        return new DataTempletes.User(dt.Rows[0]);
                    else
                        return null;
                }
            }
        }
        internal DataTempletes.User GetUser(string userId)
        {
            if (!_CheckUserId(userId))
                return null;

            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append($"select * from {DataTempletes.DBFieldNames.User.TableName} ");
                cmdBdr.Append($"where {DataTempletes.DBFieldNames.User.ID}=@uid;");
                cmd.CommandText = cmdBdr.ToString();
                cmd.Parameters.AddWithValue("@uid", userId);
                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(cmd))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    if (dt.Rows.Count > 0)
                        return new DataTempletes.User(dt.Rows[0]);
                    else
                        return null;
                }
            }
        }
        internal bool HaveUser(string userId)
        {
            if (!_CheckUserId(userId))
                return false;

            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append($"select count(*) from {DataTempletes.DBFieldNames.User.TableName} ");
                cmdBdr.Append($"where {DataTempletes.DBFieldNames.User.ID}=@uid;");
                cmd.CommandText = cmdBdr.ToString();
                cmd.Parameters.AddWithValue("@uid", userId);
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                        return reader.GetInt32(0) > 0;
                }
            }
            return false;
        }
        private bool HaveSexCode(string userSexCode)
        {
            if (string.IsNullOrWhiteSpace(userSexCode))
                return false;
            long sCode = MadTomDev.CommonClasses.SimpleValueHelper.TryGetLong(userSexCode);
            if (sCode < 0)
                return false;

            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append($"select count(*) from {DataTempletes.DBFieldNames.Sex.TableName} ");
                cmdBdr.Append($"where {DataTempletes.DBFieldNames.Sex.ID}=@ID;");
                cmd.CommandText = cmdBdr.ToString();
                cmd.Parameters.AddWithValue("@ID", sCode);
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                        return reader.GetInt32(0) > 0;
                }
            }
            return false;
        }
        private bool HaveUnitCode(string userUnitCode)
        {
            if (string.IsNullOrWhiteSpace(userUnitCode))
                return false;
            long uCode = MadTomDev.CommonClasses.SimpleValueHelper.TryGetLong(userUnitCode);
            if (uCode < 0)
                return false;

            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append($"select count(*) from {DataTempletes.DBFieldNames.Unit.TableName} ");
                cmdBdr.Append($"where {DataTempletes.DBFieldNames.Unit.ID}=@ID;");
                cmd.CommandText = cmdBdr.ToString();
                cmd.Parameters.AddWithValue("@ID", uCode);
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                        return reader.GetInt32(0) > 0;
                }
            }
            return false;
        }
        public bool SetUserPassword(string userId, string newPwd, bool isInitial = true)
        {
            if (!_CheckUserId(userId))
                return false;

            core.pp.Password = newPwd;
            string pwdMesh = core.pp.Password_Mashed;
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                string tableName = "User";
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append($"update {tableName} ");
                cmdBdr.Append($"set {DataTempletes.DBFieldNames.User.LoginPwdMesh}=@pwd, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.User.LoginPwdInited}=@init ");
                cmdBdr.Append($"where {DataTempletes.DBFieldNames.User.ID}=@uid;");
                cmd.CommandText = cmdBdr.ToString();
                cmd.Parameters.AddWithValue("@uid", userId);
                cmd.Parameters.AddWithValue("@pwd", pwdMesh);
                cmd.Parameters.AddWithValue("@init", isInitial);
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        internal bool CreateUser(string userId, string userName, string userSexCode, string userUnitCode, string initPassword, string userAuthes)
        {
            if (!_CheckUserId(userId))
                return false;

            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append($"insert into {DataTempletes.DBFieldNames.User.TableName}(");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.User.ID},");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.User.Name},");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.User.SexID},");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.User.UnitID},");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.User.LoginPwdMesh},");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.User.LoginPwdInited},");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.User.Authorities}");
                cmdBdr.Append($") values (@P1,@P2,@P3,@P4,@P5,@P6,@P7);");
                cmd.Parameters.AddWithValue("@P1", userId);
                cmd.Parameters.AddWithValue("@P2", userName);

                cmd.Parameters.AddWithValue("@P3", HaveSexCode(userSexCode) ? long.Parse(userSexCode) : 4);
                cmd.Parameters.AddWithValue("@P4", HaveUnitCode(userUnitCode) ? long.Parse(userUnitCode) : 0);
                core.pp.Password = initPassword;
                cmd.Parameters.AddWithValue("@P5", core.pp.Password_Mashed);
                cmd.Parameters.AddWithValue("@P6", true);
                cmd.Parameters.AddWithValue("@P7", userAuthes);

                cmd.CommandText = cmdBdr.ToString();
                return cmd.ExecuteNonQuery() > 0;
            }
        }
        internal int SetUserAuthes(string userId, string userAuthes)
        {
            if (!_CheckUserId(userId))
                return 0;

            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append($"update {DataTempletes.DBFieldNames.User.TableName} ");
                cmdBdr.Append($"set {DataTempletes.DBFieldNames.User.Authorities}=@A ");
                cmdBdr.Append($"where {DataTempletes.DBFieldNames.User.ID}=@U;");
                cmd.Parameters.AddWithValue("@A", userAuthes);
                cmd.Parameters.AddWithValue("@U", userId);
                cmd.CommandText = cmdBdr.ToString();
                return cmd.ExecuteNonQuery();
            }
        }





        #endregion


        #region supply list
        private int GetSupplyCount(string searchPattern)
        {
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder whereSeg = GetSupplies_GetSqlSP(searchPattern, cmd);
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append("select count(*) from ");
                cmdBdr.Append(DataTempletes.DBFieldNames.Supplies.TableName);
                cmdBdr.Append(" where ");
                cmdBdr.Append(whereSeg.ToString());
                cmdBdr.Append(";");
                cmd.CommandText = cmdBdr.ToString();
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                        return reader.GetInt32(0);
                }
            }
            return 0;
        }
        private DataTempletes.SupplyList.Item GetSupply(Guid supplyID)
        {
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append($"select * from {DataTempletes.DBFieldNames.Supplies.TableName} ");
                cmdBdr.Append($"where {DataTempletes.DBFieldNames.Supplies.ID}=@ID;");
                cmd.Parameters.AddWithValue("@ID", supplyID);
                cmd.CommandText = cmdBdr.ToString();
                using (DataTable dt = new DataTable())
                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(cmd))
                {
                    adapter.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        return new DataTempletes.SupplyList.Item(dt.Rows[0]);
                    }
                    else
                        return null;
                }
            }
        }
        public bool HaveSupply(Guid supplyID)
        {
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append($"select count(*) from {DataTempletes.DBFieldNames.Supplies.TableName} ");
                cmdBdr.Append($"where {DataTempletes.DBFieldNames.Supplies.ID}=@ID;");
                cmd.Parameters.AddWithValue("@ID", supplyID);
                cmd.CommandText = cmdBdr.ToString();
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                        return reader.GetInt32(0) > 0;
                }
            }
            return false;
        }
        internal DataTempletes.SupplyList GetSupplies(
            string searchPattern, int maxSuppliesPerPage, int? supplyList_Page,
            out int maxPage, out int curPage)
        {
            if (maxSuppliesPerPage < 1)
                maxSuppliesPerPage = 1;
            curPage = supplyList_Page == null ? 1 : (int)supplyList_Page;
            if (curPage < 1)
                curPage = 1;

            int allRecCount = GetSupplyCount(searchPattern);
            maxPage = allRecCount / maxSuppliesPerPage;
            if (allRecCount % maxSuppliesPerPage > 0)
                maxPage++;
            if (curPage > maxPage)
                curPage = maxPage;

            if (curPage <= 0)
                return null;

            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder whereSeg = GetSupplies_GetSqlSP(searchPattern, cmd);
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append("select * from ");
                cmdBdr.Append(DataTempletes.DBFieldNames.Supplies.TableName);
                cmdBdr.Append(" where ");
                cmdBdr.Append(whereSeg.ToString());
                cmdBdr.Append($" limit {maxSuppliesPerPage}");
                cmdBdr.Append($" offset {(curPage - 1) * maxSuppliesPerPage};");
                cmd.CommandText = cmdBdr.ToString();
                using (DataTable dt = new DataTable())
                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(cmd))
                {
                    adapter.Fill(dt);
                    return new DataTempletes.SupplyList(dt);
                }
            }
        }
        private StringBuilder GetSupplies_GetSqlSP(string searchPattern, SQLiteCommand cmdToAddPars)
        {
            StringBuilder sqlSPBdr = new StringBuilder();
            if (string.IsNullOrWhiteSpace(searchPattern))
            {
                sqlSPBdr.Append("'1'='1'");
                return sqlSPBdr;
            }
            searchPattern = searchPattern.Trim();
            while (searchPattern.Contains(" &")) searchPattern = searchPattern.Replace(" &", "&");
            while (searchPattern.Contains("& ")) searchPattern = searchPattern.Replace("& ", "&");
            while (searchPattern.Contains(" |")) searchPattern = searchPattern.Replace(" |", "|");
            while (searchPattern.Contains("| ")) searchPattern = searchPattern.Replace("| ", "|");
            while (searchPattern.Contains("  ")) searchPattern = searchPattern.Replace("  ", " ");
            searchPattern = searchPattern.Replace(' ', '&');
            List<string> sParts = new List<string>();
            int sIdx = 0, preSIdx = 0;
            bool first = true;
            string testS;
            while (sIdx >= 0)
            {
                sIdx = searchPattern.IndexOfAny(new char[] { '&', '|', '(', ')' }, sIdx);
                if (sIdx >= 0)
                {
                    if (first)
                    {
                        testS = searchPattern.Substring(0, sIdx);
                        GetSupplies_AddNorEmpty(ref sParts, ref testS);
                        first = false;
                    }
                    else
                    {
                        testS = searchPattern.Substring(preSIdx, sIdx);
                        GetSupplies_AddNorEmpty(ref sParts, ref testS);
                    }
                    sParts.Add(searchPattern[sIdx].ToString());
                    sIdx++;
                }
                else
                {
                    if (first)
                    {
                        GetSupplies_AddNorEmpty(ref sParts, ref searchPattern);
                    }
                    else
                    {
                        testS = searchPattern.Substring(preSIdx);
                        GetSupplies_AddNorEmpty(ref sParts, ref testS);
                    }
                }
                preSIdx = sIdx;
            }

            string likeP, pP;
            decimal pDecimal;
            int pIdx = 0;
            DateTime pDate;

            first = true;
            foreach (string p in sParts)
            {
                if (p == "&")
                {
                    if (!first) sqlSPBdr.Append(")");
                    sqlSPBdr.Append(" and ");
                    first = true;
                }
                else if (p == "|")
                {
                    if (!first) sqlSPBdr.Append(")");
                    sqlSPBdr.Append(" or ");
                    first = true;
                }
                else if (p == "(")
                {
                    if (!first) sqlSPBdr.Append(")");
                    sqlSPBdr.Append("(");
                    first = true;
                }
                else if (p == ")")
                {
                    if (!first) sqlSPBdr.Append(")");
                    sqlSPBdr.Append(")");
                    first = true;
                }
                else
                {
                    if (first) sqlSPBdr.Append("(");
                    else sqlSPBdr.Append(" or ");

                    likeP = "%" + p + "%";
                    pDecimal = GetSupplies_GetDecimal(p);
                    //pInt = GetSupplies_GetInt(p);
                    pDate = GetSupplies_GetDate(p);

                    pP = $"@P{pIdx}";
                    sqlSPBdr.Append($" {DataTempletes.DBFieldNames.Supplies.ProjectName} like {pP} or ");
                    sqlSPBdr.Append($" {DataTempletes.DBFieldNames.Supplies.Description} like {pP} or ");
                    sqlSPBdr.Append($" {DataTempletes.DBFieldNames.Supplies.Supplier} like {pP} or ");
                    sqlSPBdr.Append($" {DataTempletes.DBFieldNames.Supplies.Remark} like {pP} or ");
                    sqlSPBdr.Append($" {DataTempletes.DBFieldNames.Supplies.Creator} like {pP}");
                    cmdToAddPars.Parameters.AddWithValue(pP, likeP);
                    pIdx++;
                    if (pDecimal > 0)
                    {
                        pP = $"@P{pIdx}";
                        sqlSPBdr.Append($" or {DataTempletes.DBFieldNames.Supplies.Quantity}={pP}");
                        cmdToAddPars.Parameters.AddWithValue(pP, pDecimal);
                        pIdx++;
                    }
                    if (pDate > DateTime.MinValue)
                    {
                        pP = $"@P{pIdx}";
                        sqlSPBdr.Append($" or {DataTempletes.DBFieldNames.Supplies.DeliveryDate}={pP}");
                        cmdToAddPars.Parameters.AddWithValue(pP, pDate);
                        pIdx++;
                    }

                    first = false;
                }
            }
            if (!first) sqlSPBdr.Append(")");
            return sqlSPBdr;
        }
        private void GetSupplies_AddNorEmpty(ref List<string> sParts, ref string testS)
        {
            if (!string.IsNullOrWhiteSpace(testS))
                sParts.Add(testS);
        }
        private int GetSupplies_GetInt(string testV)
        {
            try
            { return int.Parse(testV); }
            catch (Exception)
            { return -1; }
        }
        private decimal GetSupplies_GetDecimal(string testV)
        {
            try
            { return decimal.Parse(testV); }
            catch (Exception)
            { return -1; }
        }
        private DateTime GetSupplies_GetDate(string testV)
        {
            try
            { return DateTime.Parse(testV); }
            catch (Exception)
            { return DateTime.MinValue; }
        }


        internal List<DataTempletes.SupplyList.FileCountInfo> GetSupplyFileIDs(List<Guid> supplyIDList)
        {
            if (supplyIDList == null || supplyIDList.Count == 0)
                return null;

            List<DataTempletes.SupplyList.FileCountInfo> result
                = new List<DataTempletes.SupplyList.FileCountInfo>();
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append($"select {DataTempletes.DBFieldNames.Supplies.ID}, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.Supplies.ContractID}, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.Supplies.ProofDeliveryID}, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.Supplies.ProofAcceptanceID}, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.Supplies.ProofSignOffID} ");
                cmdBdr.Append($"from {DataTempletes.DBFieldNames.Supplies.TableName} ");
                cmdBdr.Append($"where {DataTempletes.DBFieldNames.Supplies.ID} in (");
                int pIdx = 0;
                string pP;
                foreach (Guid sID in supplyIDList)
                {
                    pP = "@P" + pIdx.ToString();
                    cmdBdr.Append(pP + ", ");
                    cmd.Parameters.AddWithValue(pP, sID);
                    pIdx++;
                }
                cmdBdr.Remove(cmdBdr.Length - 2, 2);
                cmdBdr.Append(");");
                cmd.CommandText = cmdBdr.ToString();
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(new DataTempletes.SupplyList.FileCountInfo()
                        {
                            SupplyID = reader.GetGuid(0),
                            ContractID = reader.GetInt64(1),
                            ProofDeliveryID = reader.GetInt64(2),
                            ProofAcceptanceID = reader.GetInt64(3),
                            ProofSignOffID = reader.GetInt64(4),
                        });
                    }
                    return result;
                }
            }
        }

        #endregion

        #region access supply, insert, update, delete

        internal int InsertOrUpdateSupply(DataTempletes.SupplyList.Item supplyData, string user)
        {
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                bool isNew = !HaveSupply(supplyData.ID);
                StringBuilder cmdBdr = new StringBuilder();
                if (isNew)
                {
                    cmdBdr.Append($"insert into {DataTempletes.DBFieldNames.Supplies.TableName}(");
                    cmdBdr.Append($"{DataTempletes.DBFieldNames.Supplies.ID}, ");
                    cmdBdr.Append($"{DataTempletes.DBFieldNames.Supplies.Creator}, ");
                    cmdBdr.Append($"{DataTempletes.DBFieldNames.Supplies.ProjectName}, ");
                    cmdBdr.Append($"{DataTempletes.DBFieldNames.Supplies.Definition}, ");
                    cmdBdr.Append($"{DataTempletes.DBFieldNames.Supplies.ContractID}, ");
                    cmdBdr.Append($"{DataTempletes.DBFieldNames.Supplies.Description}, ");
                    cmdBdr.Append($"{DataTempletes.DBFieldNames.Supplies.Quantity}, ");
                    cmdBdr.Append($"{DataTempletes.DBFieldNames.Supplies.Supplier}, ");
                    cmdBdr.Append($"{DataTempletes.DBFieldNames.Supplies.DeliveryDate}, ");
                    cmdBdr.Append($"{DataTempletes.DBFieldNames.Supplies.ProofDeliveryID}, ");
                    cmdBdr.Append($"{DataTempletes.DBFieldNames.Supplies.ProofAcceptanceID}, ");
                    cmdBdr.Append($"{DataTempletes.DBFieldNames.Supplies.ProofSignOffID}");

                    cmdBdr.Append(") values(");
                    cmdBdr.Append("@P0, ");
                    cmd.Parameters.AddWithValue("@P0", supplyData.ID);
                    cmdBdr.Append("@P1, ");
                    cmd.Parameters.AddWithValue("@P1", user);
                    cmdBdr.Append("@P2, ");
                    cmd.Parameters.AddWithValue("@P2", supplyData.ProjectName);
                    cmdBdr.Append("@P10, ");
                    cmd.Parameters.AddWithValue("@P10", supplyData.Definition);
                    cmdBdr.Append("@P11, ");
                    cmd.Parameters.AddWithValue("@P11", GetNextTimeTicks());
                    cmdBdr.Append("@P3, ");
                    cmd.Parameters.AddWithValue("@P3", supplyData.Description);
                    cmdBdr.Append("@P4, ");
                    cmd.Parameters.AddWithValue("@P4", supplyData.Quantity);
                    cmdBdr.Append("@P5, ");
                    cmd.Parameters.AddWithValue("@P5", supplyData.Supplier);
                    cmdBdr.Append("@P6, ");
                    cmd.Parameters.AddWithValue("@P6", supplyData.DeliveryDate);
                    cmdBdr.Append("@P7, ");
                    cmd.Parameters.AddWithValue("@P7", GetNextTimeTicks());
                    cmdBdr.Append("@P8, ");
                    cmd.Parameters.AddWithValue("@P8", GetNextTimeTicks());
                    cmdBdr.Append("@P9");
                    cmd.Parameters.AddWithValue("@P9", GetNextTimeTicks());
                    cmdBdr.Append(");");
                }
                else
                {
                    cmdBdr.Append($"update {DataTempletes.DBFieldNames.Supplies.TableName} set ");
                    cmdBdr.Append($"{DataTempletes.DBFieldNames.Supplies.Creator}=@P1, ");
                    cmdBdr.Append($"{DataTempletes.DBFieldNames.Supplies.ProjectName}=@P2, ");
                    cmdBdr.Append($"{DataTempletes.DBFieldNames.Supplies.Definition}=@P7, ");  ////
                    cmdBdr.Append($"{DataTempletes.DBFieldNames.Supplies.Description}=@P3, ");
                    cmdBdr.Append($"{DataTempletes.DBFieldNames.Supplies.Quantity}=@P4, ");
                    cmdBdr.Append($"{DataTempletes.DBFieldNames.Supplies.Supplier}=@P5, ");
                    cmdBdr.Append($"{DataTempletes.DBFieldNames.Supplies.DeliveryDate}=@P6 ");
                    cmdBdr.Append($"where {DataTempletes.DBFieldNames.Supplies.ID}=@P0;");

                    cmd.Parameters.AddWithValue("@P1", user);
                    cmd.Parameters.AddWithValue("@P2", supplyData.ProjectName);
                    cmd.Parameters.AddWithValue("@P7", supplyData.Definition);
                    cmd.Parameters.AddWithValue("@P3", supplyData.Description);
                    cmd.Parameters.AddWithValue("@P4", supplyData.Quantity);
                    cmd.Parameters.AddWithValue("@P5", supplyData.Supplier);
                    cmd.Parameters.AddWithValue("@P6", supplyData.DeliveryDate);
                    cmd.Parameters.AddWithValue("@P0", supplyData.ID);

                    cmdBdr.Append(";");
                }
                cmd.CommandText = cmdBdr.ToString();
                return cmd.ExecuteNonQuery();
            }
        }

        internal long GetFileNextNo(long fileID)
        {
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append($"select max({DataTempletes.DBFieldNames.FileList.No}) ");
                cmdBdr.Append($"from {DataTempletes.DBFieldNames.FileList.TableName} ");
                cmdBdr.Append($"where {DataTempletes.DBFieldNames.FileList.ID}=@ID;");
                cmd.Parameters.AddWithValue("@ID", fileID);
                cmd.CommandText = cmdBdr.ToString();
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        try
                        {
                            return reader.GetInt64(0) + 1;
                        }
                        catch (Exception)
                        { }
                    }
                }
            }
            return 1;
        }

        internal bool HaveFile(long fileID, long fileNo)
        {
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append("select count(*) from ");
                cmdBdr.Append(DataTempletes.DBFieldNames.FileList.TableName);
                cmdBdr.Append($" where {DataTempletes.DBFieldNames.FileList.ID}=@ID");
                cmdBdr.Append($" and {DataTempletes.DBFieldNames.FileList.No}=@NO;");
                cmd.Parameters.AddWithValue("@ID", fileID);
                cmd.Parameters.AddWithValue("@NO", fileNo);
                cmd.CommandText = cmdBdr.ToString();

                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                        return reader.GetInt32(0) > 0;
                }
            }
            return false;
        }

        internal int InsertFile(long fileID, long fileNo, string fileName, string uploader, DateTime uploadTime)
        {
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append($"insert into {DataTempletes.DBFieldNames.FileList.TableName} (");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.FileList.ID}, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.FileList.No}, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.FileList.Name}, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.FileList.Uploader}, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.FileList.UploadTime}");
                cmdBdr.Append(") values (");
                cmdBdr.Append("@P1, ");
                cmd.Parameters.AddWithValue("@P1", fileID);
                cmdBdr.Append("@P2, ");
                cmd.Parameters.AddWithValue("@P2", fileNo);
                cmdBdr.Append("@P3, ");
                cmd.Parameters.AddWithValue("@P3", fileName);
                cmdBdr.Append("@P4, ");
                cmd.Parameters.AddWithValue("@P4", uploader);
                cmdBdr.Append("@P5");
                cmd.Parameters.AddWithValue("@P5", uploadTime);
                cmdBdr.Append(");");

                cmd.CommandText = cmdBdr.ToString();
                return cmd.ExecuteNonQuery();
            }
        }
        internal int UpdateFile(long fileID, long fileNo, string fileName, string uploader, DateTime uploadTime)
        {
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();

                cmdBdr.Append($"update {DataTempletes.DBFieldNames.FileList.TableName} set ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.FileList.Name}=@P1, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.FileList.Uploader}=@P2, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.FileList.UploadTime}=@P3 ");
                cmdBdr.Append($"where {DataTempletes.DBFieldNames.FileList.ID}=@ID ");
                cmdBdr.Append($"and {DataTempletes.DBFieldNames.FileList.No}=@NO;");

                cmd.Parameters.AddWithValue("@ID", fileID);
                cmd.Parameters.AddWithValue("@NO", fileNo);
                cmd.Parameters.AddWithValue("@P1", fileName);
                cmd.Parameters.AddWithValue("@P2", uploader);
                cmd.Parameters.AddWithValue("@P3", uploadTime);

                cmd.CommandText = cmdBdr.ToString();
                return cmd.ExecuteNonQuery();
            }
        }


        private class UniqueTimeTick
        { public long ticks; };
        private UniqueTimeTick preTime = new UniqueTimeTick();
        private long GetNextTimeTicks()
        {
            long result = DateTime.Now.Ticks;
            lock (preTime)
            {
                while (preTime.ticks >= result)
                {
                    Thread.Sleep(1);
                    result = DateTime.Now.Ticks;
                }
                preTime.ticks = result;
            }
            return result;
        }

        internal int DeleteSupply(Guid supplyID)
        {
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append($"delete from {DataTempletes.DBFieldNames.Supplies.TableName} ");
                cmdBdr.Append($"where {DataTempletes.DBFieldNames.Supplies.ID}=@ID;");
                cmd.Parameters.AddWithValue("@ID", supplyID);
                cmd.CommandText = cmdBdr.ToString();
                return cmd.ExecuteNonQuery();
            }
        }


        #endregion

        #region sign-offs


        internal Dictionary<int, string> GetSupplyStatus()
        {
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append("select * from ");
                cmdBdr.Append(DataTempletes.DBFieldNames.SupplyStatus.TableName);
                cmdBdr.Append(";");
                cmd.CommandText = cmdBdr.ToString();
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    Dictionary<int, string> result = new Dictionary<int, string>();
                    while (reader.Read())
                    {
                        result.Add(
                            reader.GetInt32(0),
                            reader.GetString(1));
                    }
                    return result;
                }
            }
        }

        internal bool HaveSignOff(Guid signOffID)
        {
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append("select count(*) from ");
                cmdBdr.Append(DataTempletes.DBFieldNames.SignOff.TableName);
                cmdBdr.Append($" where {DataTempletes.DBFieldNames.SignOff.ID}=@ID;");
                cmd.Parameters.AddWithValue("@ID", signOffID);
                cmd.CommandText = cmdBdr.ToString();

                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                        return reader.GetInt32(0) > 0;
                }
            }
            return false;
        }
        internal bool HaveSignOffs(Guid supplyID)
        {
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append("select count(*) from ");
                cmdBdr.Append(DataTempletes.DBFieldNames.SignOff.TableName);
                cmdBdr.Append($" where {DataTempletes.DBFieldNames.SignOff.SupplyID}=@S;");
                cmd.Parameters.AddWithValue("@S", supplyID);
                cmd.CommandText = cmdBdr.ToString();

                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                        return reader.GetInt32(0) > 0;
                }
            }
            return false;
        }

        internal DataTempletes.SignOffList.Item GetSignOff(Guid signOffID)
        {
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append("select * from ");
                cmdBdr.Append(DataTempletes.DBFieldNames.SignOff.TableName);
                cmdBdr.Append($" where {DataTempletes.DBFieldNames.SignOff.ID}=@ID;");
                cmd.Parameters.AddWithValue("@ID", signOffID);
                cmd.CommandText = cmdBdr.ToString();
                using (DataTable dt = new DataTable())
                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(cmd))
                {
                    adapter.Fill(dt);
                    if (dt.Rows.Count > 0)
                        return new DataTempletes.SignOffList.Item(dt.Rows[0]);
                    else
                        return null;
                }
            }
        }
        internal DataTempletes.SignOffList GetSignOffs(Guid supplyID)
        {
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append("select * from ");
                cmdBdr.Append(DataTempletes.DBFieldNames.SignOff.TableName);
                cmdBdr.Append($" where {DataTempletes.DBFieldNames.SignOff.SupplyID}=@S;");
                cmd.Parameters.AddWithValue("@S", supplyID);
                cmd.CommandText = cmdBdr.ToString();
                using (DataTable dt = new DataTable())
                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(cmd))
                {
                    adapter.Fill(dt);
                    DataTempletes.SignOffList result
                        = new DataTempletes.SignOffList(dt);
                    //result.StatusDict = GetSupplyStatusDict();
                    return result;
                }
            }
        }
        internal DataTempletes.SignOffList GetSignOffs(Guid supplyID, string userID)
        {
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append("select * from ");
                cmdBdr.Append(DataTempletes.DBFieldNames.SignOff.TableName);
                cmdBdr.Append($" where {DataTempletes.DBFieldNames.SignOff.SupplyID}=@S ");
                cmdBdr.Append($"and {DataTempletes.DBFieldNames.SignOff.UserID}=@U;");
                cmd.Parameters.AddWithValue("@S", supplyID);
                cmd.Parameters.AddWithValue("@U", userID);
                cmd.CommandText = cmdBdr.ToString();
                using (DataTable dt = new DataTable())
                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(cmd))
                {
                    adapter.Fill(dt);
                    DataTempletes.SignOffList result
                        = new DataTempletes.SignOffList(dt);
                    //result.StatusDict = GetSupplyStatusDict();
                    return result;
                }
            }
        }
        private Dictionary<int, string> GetSupplyStatusDict()
        {
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append($"select * from {DataTempletes.DBFieldNames.SupplyStatus.TableName};");
                cmd.CommandText = cmdBdr.ToString();
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    Dictionary<int, string> result = new Dictionary<int, string>();
                    while (reader.Read())
                    {
                        result.Add(reader.GetInt32(0), reader.GetString(1));
                    }
                    return result;
                }
            }
        }

        internal decimal? GetSignOffCount(Guid supplyID)
        {
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append($"select sum({DataTempletes.DBFieldNames.SignOff.Quantity}");
                cmdBdr.Append(") from ");
                cmdBdr.Append(DataTempletes.DBFieldNames.SignOff.TableName);
                cmdBdr.Append($" where {DataTempletes.DBFieldNames.SignOff.SupplyID}=@S;");
                cmd.Parameters.AddWithValue("@S", supplyID);
                cmd.CommandText = cmdBdr.ToString();
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                        if (reader.IsDBNull(0))
                            return 0;
                        else
                            return reader.GetDecimal(0);
                    else
                        return null;
                }
            }
        }

        internal void CheckInsertSignOffQuantity(Guid supplyID, decimal quantity)
        {
            DataTempletes.SupplyList.Item supply = GetSupply(supplyID);
            if (supply == null)
                throw new OperationCanceledException($"Supply [{supplyID}] not found.");

            decimal total = supply.Quantity;
            decimal? test = GetSignOffCount(supplyID);
            decimal signOffCount = test == null ? 0 : (decimal)test;
            if (total < signOffCount + quantity)
                throw new OperationCanceledException($"Maxium quantity reached, total [{total}], signoff [{signOffCount}], free [{(total - signOffCount)}].");
        }


        internal void CheckUpdateSignOffQuantity(Guid supplyID, Guid signOffID, decimal newQuantity)
        {
            DataTempletes.SupplyList.Item supply = GetSupply(supplyID);
            if (supply == null)
                throw new OperationCanceledException($"Supply [{supplyID}] not found.");

            decimal total = supply.Quantity;
            decimal? test = GetSignOffCount(supplyID);
            decimal signOffCount = test == null ? 0 : (decimal)test;

            DataTempletes.SignOffList.Item curSignOffRec = GetSignOff(signOffID);
            if (curSignOffRec == null)
                throw new OperationCanceledException($"Sign Off [{signOffID}] not found.");

            decimal incr = newQuantity - curSignOffRec.Quantity;
            if (total < signOffCount + incr)
                throw new OperationCanceledException($"Maxium quantity reached, total [{total}], signoff [{signOffCount}], free [{(total - signOffCount)}].");
        }

        internal int InsertSignOff(DataTempletes.SignOffList.Item signOffData, string user)
        {
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append($"insert into {DataTempletes.DBFieldNames.SignOff.TableName}(");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.ID}, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.SupplyID}, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.UserID}, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.Consumers}, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.Usage}, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.Model}, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.Manufacturer}, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.Quantity}, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.QuantityUnit}, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.ERP_PID}, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.StatusID}, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.DateOperated}, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.DateRetirement}, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.PlacementLocation}, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.Remark}");

                cmdBdr.Append(") values(");
                cmdBdr.Append("@P0, ");
                cmd.Parameters.AddWithValue("@P0", signOffData.ID);
                cmdBdr.Append("@P1, ");
                cmd.Parameters.AddWithValue("@P1", signOffData.SupplyID);
                cmdBdr.Append("@P2, ");
                cmd.Parameters.AddWithValue("@P2", user);
                cmdBdr.Append("@P14, ");
                cmd.Parameters.AddWithValue("@P14", signOffData.Consumers);
                cmdBdr.Append("@P3, ");
                cmd.Parameters.AddWithValue("@P3", signOffData.Usage);
                cmdBdr.Append("@P4, ");
                cmd.Parameters.AddWithValue("@P4", signOffData.Model);
                cmdBdr.Append("@P5, ");
                cmd.Parameters.AddWithValue("@P5", signOffData.Manufacturer);
                cmdBdr.Append("@P6, ");
                cmd.Parameters.AddWithValue("@P6", signOffData.Quantity);
                cmdBdr.Append("@P7, ");
                cmd.Parameters.AddWithValue("@P7", signOffData.QuantityUnit);
                cmdBdr.Append("@P8, ");
                cmd.Parameters.AddWithValue("@P8", signOffData.ERP_PID);
                cmdBdr.Append("@P9, ");
                cmd.Parameters.AddWithValue("@P9", signOffData.StatusID);
                cmdBdr.Append("@P10, ");
                cmd.Parameters.AddWithValue("@P10", signOffData.DateOperated);
                cmdBdr.Append("@P11, ");
                cmd.Parameters.AddWithValue("@P11", signOffData.DateRetirement);
                cmdBdr.Append("@P12, ");
                cmd.Parameters.AddWithValue("@P12", signOffData.PlacementLocation);
                cmdBdr.Append("@P13");
                cmd.Parameters.AddWithValue("@P13", signOffData.Remark);
                cmdBdr.Append(");");

                CheckInsertSignOffQuantity(
                    signOffData.SupplyID,
                    signOffData.Quantity);

                cmd.CommandText = cmdBdr.ToString();
                return cmd.ExecuteNonQuery();
            }
        }


        internal int UpdateSignOff(DataTempletes.SignOffList.Item signOffData, string user)
        {
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();

                cmdBdr.Append($"update {DataTempletes.DBFieldNames.SignOff.TableName} set ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.SupplyID}=@P1, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.UserID}=@P2, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.Consumers}=@P14, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.Usage}=@P3, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.Model}=@P4, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.Manufacturer}=@P5, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.Quantity}=@P6, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.QuantityUnit}=@P7, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.ERP_PID}=@P8, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.StatusID}=@P9, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.DateOperated}=@P10, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.DateRetirement}=@P11, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.PlacementLocation}=@P12, ");
                cmdBdr.Append($"{DataTempletes.DBFieldNames.SignOff.Remark}=@P13 ");
                cmdBdr.Append($"where {DataTempletes.DBFieldNames.SignOff.ID}=@P0;");

                cmd.Parameters.AddWithValue("@P0", signOffData.ID);
                cmd.Parameters.AddWithValue("@P1", signOffData.SupplyID);
                cmd.Parameters.AddWithValue("@P2", signOffData.UserID);
                cmd.Parameters.AddWithValue("@P14", signOffData.Consumers);
                cmd.Parameters.AddWithValue("@P3", signOffData.Usage);
                cmd.Parameters.AddWithValue("@P4", signOffData.Model);
                cmd.Parameters.AddWithValue("@P5", signOffData.Manufacturer);
                cmd.Parameters.AddWithValue("@P6", signOffData.Quantity);
                cmd.Parameters.AddWithValue("@P7", signOffData.QuantityUnit);
                cmd.Parameters.AddWithValue("@P8", signOffData.ERP_PID);
                cmd.Parameters.AddWithValue("@P9", signOffData.StatusID);
                cmd.Parameters.AddWithValue("@P10", signOffData.DateOperated);
                cmd.Parameters.AddWithValue("@P11", signOffData.DateRetirement);
                cmd.Parameters.AddWithValue("@P12", signOffData.PlacementLocation);
                cmd.Parameters.AddWithValue("@P13", signOffData.Remark);

                CheckUpdateSignOffQuantity(
                    signOffData.SupplyID,
                    signOffData.ID,
                    signOffData.Quantity);

                cmd.CommandText = cmdBdr.ToString();
                return cmd.ExecuteNonQuery();
            }
        }


        internal int DeleteSignOff(Guid signOffID)
        {
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append($"delete from {DataTempletes.DBFieldNames.SignOff.TableName} ");
                cmdBdr.Append($"where {DataTempletes.DBFieldNames.SignOff.ID}=@ID;");
                cmd.Parameters.AddWithValue("@ID", signOffID);
                cmd.CommandText = cmdBdr.ToString();
                return cmd.ExecuteNonQuery();
            }
        }
        internal int DeleteSignOffs(Guid supplyID)
        {
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append($"delete from {DataTempletes.DBFieldNames.SignOff.TableName} ");
                cmdBdr.Append($"where {DataTempletes.DBFieldNames.SignOff.SupplyID}=@ID;");
                cmd.Parameters.AddWithValue("@ID", supplyID);
                cmd.CommandText = cmdBdr.ToString();
                return cmd.ExecuteNonQuery();
            }
        }

        #endregion


        #region file
        internal DataTempletes.FileList GetFiles(long id)
        {
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append($"select * from {DataTempletes.DBFieldNames.FileList.TableName} ");
                cmdBdr.Append($"where {DataTempletes.DBFieldNames.FileList.ID}=@ID;");
                cmd.Parameters.AddWithValue("@ID", id);
                cmd.CommandText = cmdBdr.ToString();
                DataTable dt = new DataTable();
                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(cmd))
                {
                    adapter.Fill(dt);
                    return new DataTempletes.FileList(dt);
                }
            }
        }


        internal int DeleteFile(long id, long no)
        {
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append($"delete from {DataTempletes.DBFieldNames.FileList.TableName} ");
                cmdBdr.Append($"where {DataTempletes.DBFieldNames.FileList.ID}=@ID ");
                cmdBdr.Append($"and {DataTempletes.DBFieldNames.FileList.No}=@NO;");
                cmd.Parameters.AddWithValue("@ID", id);
                cmd.Parameters.AddWithValue("@NO", no);
                cmd.CommandText = cmdBdr.ToString();
                return cmd.ExecuteNonQuery();
            }
        }
        internal int DeleteFiles(long id)
        {
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append($"delete from {DataTempletes.DBFieldNames.FileList.TableName} ");
                cmdBdr.Append($"where {DataTempletes.DBFieldNames.FileList.ID}=@ID;");
                cmd.Parameters.AddWithValue("@ID", id);
                cmd.CommandText = cmdBdr.ToString();
                return cmd.ExecuteNonQuery();
            }
        }

        internal DataTempletes.SupplyList GetOutOfDate_NoneDeliveriedSupplies(string creator, DateTime reserveTime)
        {
            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append($"select* from {DataTempletes.DBFieldNames.Supplies.TableName} a ");
                cmdBdr.Append($"where a.{DataTempletes.DBFieldNames.Supplies.Creator}=@CTR ");
                cmdBdr.Append($"and a.{DataTempletes.DBFieldNames.Supplies.DeliveryDate}<=@ST ");
                cmdBdr.Append($"and (select count(*) from {DataTempletes.DBFieldNames.FileList.TableName} ");
                cmdBdr.Append($"where {DataTempletes.DBFieldNames.FileList.ID}");
                cmdBdr.Append($"=a.{DataTempletes.DBFieldNames.Supplies.ProofDeliveryID})=0;");
                cmd.Parameters.AddWithValue("@CTR", creator);
                cmd.Parameters.AddWithValue("@ST", reserveTime);
                cmd.CommandText = cmdBdr.ToString();
                DataTable dt = new DataTable();
                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(cmd))
                {
                    adapter.Fill(dt);
                    return new DataTempletes.SupplyList(dt);
                }
            }
        }


        #endregion




        #region productive data export, import, clean

        internal void ExportProductive(string packageName, DateTime startTime, DateTime endTime, bool clean,
            out int counterSupplyRecs, out int counterSignOffRecs, out int counterFileRecs, out int counterFiles)
        {
            List<Guid> supplyIDList = new List<Guid>();
            counterSupplyRecs = 0;
            counterSignOffRecs = 0;
            counterFileRecs = 0;
            counterFiles = 0;

            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append($"select * from {DataTempletes.DBFieldNames.Supplies.TableName} ");
                cmdBdr.Append($"where {DataTempletes.DBFieldNames.Supplies.DeliveryDate}>=@SD ");
                cmdBdr.Append($"and {DataTempletes.DBFieldNames.Supplies.DeliveryDate}<=@ED;");
                cmd.Parameters.AddWithValue("@SD", startTime);
                cmd.Parameters.AddWithValue("@ED", endTime);
                cmd.CommandText = cmdBdr.ToString();

                DataTempletes.SupplyList.Item supplyItem;
                DataTempletes.SignOffList signOffList;
                DataTempletes.FileList fileList;
                List<string> fileNames = new List<string>();
                string packageDir = Path.Combine(core.fileIO.DBExportDir, packageName);
                if (!Directory.Exists(packageDir))
                    Directory.CreateDirectory(packageDir);
                string phyFileFullname;

                using (FileStream csvFS = new FileStream(
                    Path.Combine(core.fileIO.DBExportDir, packageName + ".csv"),
                    FileMode.CreateNew, FileAccess.Write))
                using (StreamWriter csvWriter = new StreamWriter(csvFS))
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    Guid supplyID;
                    while (reader.Read())
                    {
                        supplyID = reader.GetGuid(0);

                        // write supply record
                        supplyItem = GetSupply(supplyID);
                        csvWriter.WriteLine(SimpleStringHelper.CSVLikeRows.RowToString(
                            DataTempletes.DBFieldNames.Supplies.TableName,
                            supplyID.ToString(),
                            supplyItem.ProjectName,
                            supplyItem.Definition,
                            supplyItem.ContractID.ToString(),
                            supplyItem.Description,
                            supplyItem.Quantity.ToString(),
                            supplyItem.Supplier,
                            supplyItem.DeliveryDate.ToString("yyyy-MM-dd HH:mm:ss.fffffff"),
                            supplyItem.ProofDeliveryID.ToString(),
                            supplyItem.ProofAcceptanceID.ToString(),
                            supplyItem.ProofSignOffID.ToString(),
                            supplyItem.Remark,
                            supplyItem.Creator
                            ));
                        counterSupplyRecs++;

                        if (clean)
                            supplyIDList.Add(supplyID);

                        // write sign-off record
                        signOffList = GetSignOffs(supplyID);
                        foreach (DataTempletes.SignOffList.Item sfItem in signOffList.Content)
                        {
                            csvWriter.WriteLine(SimpleStringHelper.CSVLikeRows.RowToString(
                                DataTempletes.DBFieldNames.SignOff.TableName,
                                sfItem.ID.ToString(),
                                sfItem.SupplyID.ToString(),
                                sfItem.UserID,
                                sfItem.Usage,
                                sfItem.Model,

                                sfItem.Manufacturer,
                                sfItem.Quantity.ToString(),
                                sfItem.QuantityUnit,
                                sfItem.ERP_PID,
                                sfItem.StatusID.ToString(),

                                sfItem.DateOperated.ToLongDateString(),
                                sfItem.DateRetirement.ToLongDateString(),
                                sfItem.PlacementLocation,
                                sfItem.Remark
                                ));
                            counterSignOffRecs++;
                        }
                        if (clean)
                        {
                            DeleteSignOffs(supplyID);
                        }

                        // write file-list record
                        fileNames.Clear();
                        fileList = GetFiles(supplyItem.ProofDeliveryID);
                        foreach (DataTempletes.FileList.Item dbF in fileList.Content)
                        {
                            csvWriter.WriteLine(SimpleStringHelper.CSVLikeRows.RowToString(
                                DataTempletes.DBFieldNames.FileList.TableName,
                                dbF.ID.ToString(),
                                dbF.No.ToString(),
                                dbF.Name,
                                dbF.Uploader,
                                dbF.UploadTime.ToString("yyyy-MM-dd HH:mm:ss.fffffff")
                                ));
                            counterFileRecs++;
                            fileNames.Add(dbF.GetPhysicalFileProfix() + dbF.NameSuffix);
                        }
                        if (clean)
                        {
                            DeleteFiles(supplyItem.ProofDeliveryID);
                        }
                        fileList = GetFiles(supplyItem.ProofAcceptanceID);
                        foreach (DataTempletes.FileList.Item dbF in fileList.Content)
                        {
                            csvWriter.WriteLine(SimpleStringHelper.CSVLikeRows.RowToString(
                                DataTempletes.DBFieldNames.FileList.TableName,
                                dbF.ID.ToString(),
                                dbF.No.ToString(),
                                dbF.Name,
                                dbF.Uploader,
                                dbF.UploadTime.ToString("yyyy-MM-dd HH:mm:ss.fffffff")
                                ));
                            counterFileRecs++;
                            fileNames.Add(dbF.GetPhysicalFileProfix() + dbF.NameSuffix);
                        }
                        if (clean)
                        {
                            DeleteFiles(supplyItem.ProofAcceptanceID);
                        }
                        fileList = GetFiles(supplyItem.ProofSignOffID);
                        foreach (DataTempletes.FileList.Item dbF in fileList.Content)
                        {
                            csvWriter.WriteLine(SimpleStringHelper.CSVLikeRows.RowToString(
                                DataTempletes.DBFieldNames.FileList.TableName,
                                dbF.ID.ToString(),
                                dbF.No.ToString(),
                                dbF.Name,
                                dbF.Uploader,
                                dbF.UploadTime.ToString("yyyy-MM-dd HH:mm:ss.fffffff")
                                ));
                            counterFileRecs++;
                            fileNames.Add(dbF.GetPhysicalFileProfix() + dbF.NameSuffix);
                        }
                        if (clean)
                        {
                            DeleteFiles(supplyItem.ProofSignOffID);
                        }
                        fileList = GetFiles(supplyItem.ContractID);
                        foreach (DataTempletes.FileList.Item dbF in fileList.Content)
                        {
                            csvWriter.WriteLine(SimpleStringHelper.CSVLikeRows.RowToString(
                                DataTempletes.DBFieldNames.FileList.TableName,
                                dbF.ID.ToString(),
                                dbF.No.ToString(),
                                dbF.Name,
                                dbF.Uploader,
                                dbF.UploadTime.ToString("yyyy-MM-dd HH:mm:ss.fffffff")
                                ));
                            counterFileRecs++;
                            fileNames.Add(dbF.GetPhysicalFileProfix() + dbF.NameSuffix);
                        }
                        if (clean)
                        {
                            DeleteFiles(supplyItem.ContractID);
                        }

                        // copy/move user files
                        foreach (string phyF in fileNames)
                        {
                            phyFileFullname = Path.Combine(core.fileIO.StorageDir, phyF);
                            if (File.Exists(phyFileFullname))
                            {
                                if (clean)
                                    File.Move(phyFileFullname, Path.Combine(packageDir, phyF));
                                else
                                    File.Copy(phyFileFullname, Path.Combine(packageDir, phyF));
                                counterFiles++;
                            }
                        }
                    }
                }
            }
            // delete supply records(if have)
            foreach (Guid supplyId in supplyIDList)
            {
                // in this case, clean is true
                DeleteSupply(supplyId);
            }
            if (clean)
                sqliteHelper.Vacuume();
        }

        internal void ImportProductive(string packageName,
            out int counterSupply, out int counterSighOff, out int counterFileRecs, out int counterFiles)
        {
            counterSupply = 0;
            counterSighOff = 0;
            counterFileRecs = 0;
            counterFiles = 0;

            // move files to user files
            string packageDir = Path.Combine(core.fileIO.DBExportDir, packageName);
            if (Directory.Exists(packageDir))
            {
                DirectoryInfo pDI = new DirectoryInfo(packageDir);
                foreach (FileInfo fi in pDI.GetFiles())
                {
                    fi.MoveTo(Path.Combine(core.fileIO.StorageDir, fi.Name));
                    counterFiles++;
                }
            }

            // insert or update db
            using (FileStream csvFS = new FileStream(
                packageDir + ".csv", FileMode.Open, FileAccess.Read))
            using (StreamReader csvReader = new StreamReader(csvFS))
            {
                DataTempletes.SignOffList.Item signOffItem;
                long fileID, fileNo;
                string line = csvReader.ReadLine();
                string[] parts;
                while (line != null)
                {
                    parts = SimpleStringHelper.CSVLikeRows.StringToRow(line);
                    if (parts.Length > 0)
                    {
                        switch (parts[0])
                        {
                            case DataTempletes.DBFieldNames.Supplies.TableName:
                                {
                                    InsertOrUpdateSupply(new DataTempletes.SupplyList.Item()
                                    {
                                        ID = Guid.Parse(parts[1]),
                                        ProjectName = parts[2],
                                        Definition = parts[3],
                                        ContractID = long.Parse(parts[4]),
                                        Description = parts[5],

                                        Quantity = decimal.Parse(parts[6]),
                                        Supplier = parts[7],
                                        DeliveryDate = DateTime.Parse(parts[8]),
                                        ProofDeliveryID = long.Parse(parts[9]),
                                        ProofAcceptanceID = long.Parse(parts[10]),

                                        ProofSignOffID = long.Parse(parts[11]),
                                        Remark = parts[12],
                                        Creator = parts[13],
                                    },
                                    parts[13]);
                                    counterSupply++;
                                    break;
                                }
                            case DataTempletes.DBFieldNames.SignOff.TableName:
                                {
                                    signOffItem = new DataTempletes.SignOffList.Item()
                                    {
                                        ID = Guid.Parse(parts[1]),
                                        SupplyID = Guid.Parse(parts[2]),
                                        UserID = parts[3],
                                        Usage = parts[4],
                                        Model = parts[5],

                                        Manufacturer = parts[6],
                                        Quantity = decimal.Parse(parts[7]),
                                        QuantityUnit = parts[8],
                                        ERP_PID = parts[9],
                                        StatusID = int.Parse(parts[10]),

                                        DateOperated = DateTime.Parse(parts[11]),
                                        DateRetirement = DateTime.Parse(parts[12]),
                                        PlacementLocation = parts[13],
                                        Remark = parts[14],
                                    };
                                    if (HaveSignOff(signOffItem.ID))
                                        UpdateSignOff(signOffItem, signOffItem.UserID);
                                    else
                                        InsertSignOff(signOffItem, signOffItem.UserID);
                                    counterSighOff++;
                                    break;
                                }
                            case DataTempletes.DBFieldNames.FileList.TableName:
                                {
                                    fileID = long.Parse(parts[1]);
                                    fileNo = long.Parse(parts[2]);
                                    if (HaveFile(fileID, fileNo))
                                        UpdateFile(fileID, fileNo, parts[3], parts[4], DateTime.Parse(parts[5]));
                                    else
                                        InsertFile(fileID, fileNo, parts[3], parts[4], DateTime.Parse(parts[5]));
                                    counterFileRecs++;
                                    break;
                                }
                        }
                    }
                    line = csvReader.ReadLine();
                }
            }
        }
        internal void CleanProductive(DateTime startTime, DateTime endTime,
            out int counterSupplyRecs, out int counterSignOffRecs, out int counterFileRecs, out int counterFiles)
        {
            List<Guid> supplyIDList = new List<Guid>();
            counterSupplyRecs = 0;
            counterSignOffRecs = 0;
            counterFileRecs = 0;
            counterFiles = 0;

            using (SQLiteCommand cmd = sqliteHelper.GetNewCommand())
            {
                StringBuilder cmdBdr = new StringBuilder();
                cmdBdr.Append($"select * from {DataTempletes.DBFieldNames.Supplies.TableName} ");
                cmdBdr.Append($"where {DataTempletes.DBFieldNames.Supplies.DeliveryDate}>=@SD ");
                cmdBdr.Append($"and {DataTempletes.DBFieldNames.Supplies.DeliveryDate}<=@ED;");
                cmd.Parameters.AddWithValue("@SD", startTime);
                cmd.Parameters.AddWithValue("@ED", endTime);
                cmd.CommandText = cmdBdr.ToString();

                DataTempletes.SupplyList.Item supplyItem;
                DataTempletes.SignOffList signOffList;
                DataTempletes.FileList fileList;
                List<string> fileNames = new List<string>();
                string phyFileFullname;

                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    Guid supplyID;
                    while (reader.Read())
                    {
                        supplyID = reader.GetGuid(0);
                        supplyItem = GetSupply(supplyID);

                        supplyIDList.Add(supplyID);

                        // clean sign-off record
                        counterSignOffRecs += DeleteSignOffs(supplyID);


                        // clean file-list record
                        fileNames.Clear();
                        fileList = GetFiles(supplyItem.ProofDeliveryID);
                        foreach (DataTempletes.FileList.Item dbF in fileList.Content)
                        {
                            DeleteFile(dbF.ID, dbF.No);
                            counterFileRecs++;
                            fileNames.Add(dbF.GetPhysicalFileProfix() + dbF.NameSuffix);
                        }
                        fileList = GetFiles(supplyItem.ProofAcceptanceID);
                        foreach (DataTempletes.FileList.Item dbF in fileList.Content)
                        {
                            DeleteFile(dbF.ID, dbF.No);
                            counterFileRecs++;
                            fileNames.Add(dbF.GetPhysicalFileProfix() + dbF.NameSuffix);
                        }
                        fileList = GetFiles(supplyItem.ProofSignOffID);
                        foreach (DataTempletes.FileList.Item dbF in fileList.Content)
                        {
                            DeleteFile(dbF.ID, dbF.No);
                            counterFileRecs++;
                            fileNames.Add(dbF.GetPhysicalFileProfix() + dbF.NameSuffix);
                        }
                        fileList = GetFiles(supplyItem.ContractID);
                        foreach (DataTempletes.FileList.Item dbF in fileList.Content)
                        {
                            DeleteFile(dbF.ID, dbF.No);
                            counterFileRecs++;
                            fileNames.Add(dbF.GetPhysicalFileProfix() + dbF.NameSuffix);
                        }

                        // delete user files
                        foreach (string phyF in fileNames)
                        {
                            phyFileFullname = Path.Combine(core.fileIO.StorageDir, phyF);
                            if (File.Exists(phyFileFullname))
                            {
                                File.Delete(phyFileFullname);
                                counterFiles++;
                            }
                        }
                    }
                }
            }
            // delete supply records
            foreach (Guid supplyId in supplyIDList)
            {
                DeleteSupply(supplyId);
                counterSupplyRecs++;
            }
            sqliteHelper.Vacuume();
        }



        #endregion

    }
}
