﻿using MadTomDev.CommonClasses;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace MadTomDev.WWWs
{
    class FileIO
    {
        private ServerCore core;
        public FileIO(ServerCore core)
        {
            this.core = core;
            StorageDir = Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory,
                "UserFiles");
            if (!Directory.Exists(StorageDir))
                Directory.CreateDirectory(StorageDir);
            RecycleBinDir = Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory,
                "UserFiles", "Recycle");
            if (!Directory.Exists(RecycleBinDir))
                Directory.CreateDirectory(RecycleBinDir);
            DBExportDir = Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory,
                "DBExports");
            if (!Directory.Exists(DBExportDir))
                Directory.CreateDirectory(DBExportDir);
        }

        public string StorageDir { private set; get; }
        public string RecycleBinDir { private set; get; }
        public string DBExportDir { private set; get; }

        public int GetFileCount(long id)
        { return GetFiles(id).Count; }
        private List<FileInfo> _GetFiles(string filter)
        {
            List<FileInfo> result = new List<FileInfo>();
            string filterLower = filter.ToLower();
            foreach (FileInfo fi in new DirectoryInfo(StorageDir).GetFiles(filter + "*"))
            {
                if (fi.Name.ToLower().StartsWith(filterLower))
                    result.Add(fi);
            }
            return result;
        }
        public List<FileInfo> GetFiles(long id)
        {
            return _GetFiles(SimpleStringHelper.ToHexString(id) + ".");
        }
        public FileInfo GetFile(long id, long no)
        {
            List<FileInfo> files = _GetFiles(SimpleStringHelper.ToHexString(id) + "." + no.ToString() + ".");
            if (files.Count > 0)
                return files[0];
            else
                return null;
        }


        public byte[] ReadFile(string fileName, int offset, int length, out bool isEndPack)
        {
            isEndPack = false;
            string fileFullName = Path.Combine(StorageDir, fileName);
            if (!File.Exists(fileFullName))
                return null;

            byte[] result = new byte[length];
            int readLength;
            using (FileStream fs = new FileStream(fileFullName, FileMode.Open, FileAccess.Read))
            {
                if (offset >= fs.Length)
                {
                    isEndPack = true;
                    return null;
                }
                readLength = fs.Read(result, offset, length);
                isEndPack = fs.Length == (offset + readLength);
                if (readLength < length)
                {
                    byte[] newArr = new byte[readLength];
                    Array.Copy(result, newArr, readLength);
                    return newArr;
                }
                else return result;
            }
        }
        public void WriteFile(string fileName, int offset, byte[] data)
        {
            using (Stream fileStream = new FileStream(
                Path.Combine(StorageDir, fileName),
                FileMode.OpenOrCreate, FileAccess.Write))
            {
                fileStream.Position = offset;
                fileStream.Write(data, 0, data.Length);
            }
        }
        public void DeleteFile(string fileName, bool toRecycleBin = true)
        {
            if (toRecycleBin)
                File.Move(
                    Path.Combine(StorageDir, fileName),
                    Path.Combine(RecycleBinDir, fileName + "." + SimpleStringHelper.ToHexString(DateTime.Now.Ticks)));
            else
                File.Delete(Path.Combine(StorageDir, fileName));
        }
        public void RenameFile(string fileName, string newName)
        {
            FileInfo fi = new FileInfo(Path.Combine(StorageDir, fileName));
            fi.MoveTo(Path.Combine(StorageDir, newName));
        }

        private Dictionary<Guid, FileStream> ioTasks = new Dictionary<Guid, FileStream>();

        public byte[] ReadFile_usingTask(Guid taskID, string fileName, int offset, int length, out bool isEndPack)
        {
            isEndPack = false;

            FileStream fs;
            if (ioTasks.ContainsKey(taskID))
            {
                fs = ioTasks[taskID];
            }
            else
            {
                string fileFullName = Path.Combine(StorageDir, fileName);
                if (!File.Exists(fileFullName))
                    return null;

                fs = new FileStream(fileFullName, FileMode.Open, FileAccess.Read);
                ioTasks.Add(taskID, fs);
            }

            byte[] result = new byte[length];
            int readLength;
            if (offset >= fs.Length)
            {
                isEndPack = true;
                return null;
            }
            if (fs.Position != offset)
                fs.Position = offset;
            readLength = fs.Read(result, 0, length);

            isEndPack = fs.Length <= (offset + length);
            if (isEndPack)
            {
                fs.Close();
                fs.Dispose();
                ioTasks.Remove(taskID);
            }

            if (readLength < length)
            {
                byte[] newArr = new byte[readLength];
                Array.Copy(result, newArr, readLength);
                return newArr;
            }
            else return result;
        }

        public void WriteFile_usingTask(Guid taskID, string fileName, int offset, byte[] data, bool isEndPack)
        {
            FileStream fs;
            if (ioTasks.ContainsKey(taskID))
            {
                fs = ioTasks[taskID];
            }
            else
            {
                fs = new FileStream(
                    Path.Combine(StorageDir, fileName),
                    FileMode.OpenOrCreate, FileAccess.Write);
                ioTasks.Add(taskID, fs);
            }

            if (fs.Position != offset)
                fs.Position = offset;
            fs.Write(data, 0, data.Length);

            if (isEndPack)
            {
                fs.Flush();
                fs.Close();
                fs.Dispose();
            }
        }
    }
}
