﻿using MadTomDev.App.YPLQDJ;
using MadTomDev.CommonClasses;
using MadTomDev.Data;
using MadTomDev.Math;
using MadTomDev.Network;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace MadTomDev.WWWs
{

    class ServerCore : IDisposable
    {
        public Commands cmd;
        public Logger logger;
        public ServerSettings settings;
        public SocketHelper.SocketTcpServer socketServer;
        public ClientConnectionChecker connectionChecker;
        public PasswordProtector pp;
        public DataBase db;
        public FileIO fileIO;
        public UserSessions sessions;

        public string Encryption_Password { private set; get; }
        public byte Encryption_ConfusionLength { private set; get; } = 13;

        public ServerCore()
        {
            logger = new Logger();
            logger.BaseDir += Path.DirectorySeparatorChar + "Log";

            //try
            //{
            settings = new ServerSettings(this);

            cmd = new Commands(this);

            StringBuilder infoBdr = new StringBuilder();
            infoBdr.Append("Listening ");
            if (settings.ListeningAddressIsIPV4orIPV6)
            {
                infoBdr.Append( "[IPV4] " );
                infoBdr.Append(settings.ListeningAddressIPV4 == null ?
                    "*Any" : settings.ListeningAddressIPV4.ToString());
            }
            else
            {
                infoBdr.Append( "[IPV6] ");
                infoBdr.Append(settings.ListeningAddressIPV6 == null ?
                    "*Any" : settings.ListeningAddressIPV6.ToString());
            }
            //infoBdr.Append(settings.ListeningAddress.ToString());
            infoBdr.Append(", port ");
            infoBdr.Append(settings.ListeningPort.ToString());
            infoBdr.Append(", max connection queue ");
            infoBdr.Append(settings.MaxConnQueue.ToString() + ";");
            infoBdr.Append(Environment.NewLine);
            infoBdr.Append("Receive buffer length ");
            infoBdr.Append(settings.ReceiveBufferLength);
            infoBdr.Append(", time out on seconds ");
            infoBdr.Append(settings.ReceiveTimeOutSec.ToString() + ".");
            ShowInfoNLog(infoBdr.ToString());

            if (settings.ListeningAddressIsIPV4orIPV6)
            {
                socketServer = new SocketHelper.SocketTcpServer(
                    settings.ListeningAddressIPV4 == null ? 
                        IPAddress.Any : settings.ListeningAddressIPV4,
                    settings.ListeningPort,
                    settings.MaxConnQueue,
                    settings.ReceiveBufferLength,
                    settings.ReceiveTimeOutSec);
            }
            else
            {
                socketServer = new SocketHelper.SocketTcpServer(
                    settings.ListeningAddressIPV6 == null ?
                        IPAddress.IPv6Any : settings.ListeningAddressIPV6,
                    settings.ListeningPort,
                    settings.MaxConnQueue,
                    settings.ReceiveBufferLength,
                    settings.ReceiveTimeOutSec);
            }

            socketServer.ClientConnected += SocketServer_ClientConnected;
            socketServer.ClientDataReceived += SocketServer_ClientDataReceived;
            socketServer.ClientReceiveTimeout += SocketServer_ClientReceiveTimeout;
            socketServer.ClientClosed += SocketServer_ClientClosed;
            socketServer.ErrorOccured += SocketServer_ErrorOccured;

            connectionChecker = new ClientConnectionChecker(this);
            string ppFile = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Encry.cer");
            string ppKey = "u$kjl!&wZv@%@qw*rNTh$DMBQ$t@D!rX*FOa";

                infoBdr.Clear();
                infoBdr.Append("Start password protector from file ");
                infoBdr.Append(ppFile);
                infoBdr.Append(Environment.NewLine);
            infoBdr.Append("Using key [......hiddenString......].");
            //infoBdr.Append($"Using key [{ppKey}].");
            ShowInfoNLog(infoBdr.ToString());
            
            pp = PasswordProtector.GetInstance(ppFile, ppKey);

            pp.Password = "this is a fixed password, do not change it.";
            Encryption_Password = pp.Password_forCipher;
            db = new DataBase(this);
            fileIO = new FileIO(this);
            sessions = new UserSessions(this);

            //}
            //catch (Exception err)
            //{
            //    ShowInfoNLog(err);
            //}
        }

        public void SendResponse(SocketHelper.SocketTcpServer.ConnectedClient client, DataServerResponse response)
        {
            client.socket.Send(
                EncryptedGZip.EncryptGZip(
                    response.Data, Encryption_Password, Encryption_ConfusionLength));
        }
        private void SendMessage(SocketHelper.SocketTcpServer.ConnectedClient client, DataMessage msg)
        {
            client.socket.Send(
                EncryptedGZip.EncryptGZip(msg.Data, Encryption_Password, Encryption_ConfusionLength));
        }

        private void SocketServer_ClientConnected(SocketHelper.SocketTcpServer sender,
            SocketHelper.SocketTcpServer.ConnectedClient client)
        {
            ShowInfoNLog("Client [" + client.socket.RemoteEndPoint.ToString() + "] connected.");

            string checkMsg;
            switch (connectionChecker.CheckNRegClintConnection(client.socket, out checkMsg))
            {
                case ClientConnectionChecker.Results.First:
                    {
                        ShowInfoNLog($"First connection: {client.RemoteEndPointString}");
                        break;
                    }
                case ClientConnectionChecker.Results.Retry:
                    {
                        ShowInfoNLog($"Retry connection: {checkMsg}");
                        break;
                    }
                case ClientConnectionChecker.Results.Refuse:
                    {
                        client.Dispose();
                        ShowInfoNLog($"Refuse connection: {checkMsg}");
                        break;
                    }
            }
        }

        private void SocketServer_ErrorOccured(SocketHelper.SocketTcpServer sender, Exception err)
        {
            //if (cmd.IsKickingUser
            //    && err is SocketException
            //    && ((SocketException)err).ErrorCode == 10004)
            //{
            //    // no show error in console
            //    logger.Log(err);
            //    return;
            //}
            sessions.RemoveDeadSessions();
            ShowInfoNLog(err);
            if (err.ToString().Contains("10004"))
                ShowInfoNLog("Error (code) 10004 is most likly caused by client close.");
        }

        private void SocketServer_ClientReceiveTimeout(SocketHelper.SocketTcpServer sender,
            SocketHelper.SocketTcpServer.ConnectedClient timeoutClient)
        {
            ShowInfoNLog($"Client [{timeoutClient.RemoteEndPointString}] timeout, "
                + "Connected at " + timeoutClient.ConnectedTime.ToString("yyyy-MM-dd HH:mm:ss.fff") + " .");

            sessions.RemoveSession(timeoutClient);
        }
        private void SocketServer_ClientClosed(SocketHelper.SocketTcpServer sender, SocketHelper.SocketTcpServer.ConnectedClient closedClient)
        {
            ShowInfoNLog($"Client [{closedClient.RemoteEndPointString}] closed.");
            sessions.RemoveSession(closedClient);
        }

        private void SocketServer_ClientDataReceived(SocketHelper.SocketTcpServer sender,
            SocketHelper.SocketTcpServer.ConnectedClient client, byte[] data)
        {
            ShowInfoNLog($"Data from {client.RemoteEndPointString},"
                + $"length [{data.Length}].");   //, data [{SimpleStringHelper.ToHexString(data)}].");
            if (data.Length == 1)
                return;

            data = EncryptedGZip.UnGZipDecrypt(data, Encryption_Password, Encryption_ConfusionLength);
            Flags.Types[] dataTypes;
            object[] dataObjs = DataReceiver.GetDataInstances(data, out dataTypes);
            if (dataTypes == null)
                return;

            object obj;
            Flags.Types dt;
            DataClientRequest dcRequest;
            for (int i = 0, iv = dataTypes.Length; i < iv; i++)
            {
                dt = dataTypes[i];
                obj = dataObjs[i];
                switch (dt)
                {
                    case Flags.Types.Message:
                        {
                            ShowInfoNLog($"Message from [{client.RemoteEndPointString}]:");
                            ShowInfoNLog(((DataMessage)obj).Message + Environment.NewLine);
                            break;
                        }
                    case Flags.Types.ConsoleIn:
                        {
                            dcRequest = (DataClientRequest)obj;
                            ShowInfoNLog($"Cmd from [{client.RemoteEndPointString}]: {dcRequest.Console_CmdIn}");
                            cmd.InputCmdNExe(dcRequest.Console_CmdIn, client);
                            break;
                        }
                    default:
                    case Flags.Types.Unknow:
                        {
                            ShowInfoNLog($"Unknow data from [{client.RemoteEndPointString}]:");
                            ShowInfoNLog(SimpleStringHelper.ToHexString(data) + Environment.NewLine);
                            break;
                        }
                    case Flags.Types.RequestLogin:
                        {
                            dcRequest = (DataClientRequest)obj;
                            DataTempletes.User userInfo = db.GetUser(dcRequest.Login_User, dcRequest.Login_Password);
                            bool response = true;
                            bool haveSession = false;
                            bool loginResult = false;
                            if (userInfo != null)
                            {
                                if (!userInfo.Authorities.Login)
                                {
                                    DataMessage dm = new DataMessage()
                                    {
                                        Message = $"You don't have the authority to login, contact administrator for more information.",
                                    };
                                    SendMessage(client, dm);
                                    response = false;
                                    client.Dispose();
                                    ShowInfoNLog($"Client {client.RemoteEndPointString} don't have auth to login.");
                                }
                                else
                                {
                                    // success
                                    loginResult = true;
                                    connectionChecker.UnReg(client.socket);
                                    sessions.RemoveDeadSessions();
                                    haveSession = sessions.HaveSession(dcRequest.Login_User);
                                    List<UserSessions.SessionData> existingSessions = sessions[dcRequest.Login_User];
                                    UserSessions.SessionData selfSession
                                        = existingSessions.Where(e =>
                                            e.client.RemoteEndPointString
                                            == client.RemoteEndPointString).FirstOrDefault();
                                    if (selfSession != null)
                                        existingSessions.Remove(selfSession);
                                    haveSession = existingSessions.Count > 0;
                                    if (dcRequest.Login_ForceEnter && haveSession)
                                    {
                                        DataMessage dm = new DataMessage()
                                        {
                                            Message = $"You have been kicked by another client[{client.RemoteEndPointString}].",
                                        };
                                        foreach (UserSessions.SessionData oldSession in existingSessions)
                                        {
                                            SendMessage(oldSession.client, dm);
                                            string oldClientIP = oldSession.client.RemoteEndPointString;
                                            sessions.RemoveSession(oldSession.client);
                                            ShowInfoNLog($"Client {client.RemoteEndPointString} kicked old client {oldClientIP}.");
                                        }
                                        ShowInfoNLog($"Client {client.RemoteEndPointString} successful logged in on user[{dcRequest.Login_User}], and kicked old clients.");
                                    }
                                    else
                                    {
                                        ShowInfoNLog($"Client {client.RemoteEndPointString} successful logged in on user[{dcRequest.Login_User}].");
                                    }
                                    sessions.AddSession(dcRequest.Login_User, client);
                                }
                            }
                            else
                            {
                                // fail
                                bool kick;
                                connectionChecker.RegLoginFail(client.socket, out kick);
                                if (kick)
                                {
                                    DataMessage dm = new DataMessage()
                                    {
                                        Message = $"You have tried too many times, please retry after one hour.",
                                    };
                                    SendMessage(client, dm);
                                    response = false;
                                    string clientIP = client.RemoteEndPointString;
                                    client.Dispose();
                                    ShowInfoNLog($"Client {clientIP} failed to login.");
                                }
                            }
                            if (response)
                            {
                                DataServerResponse dsResponse = new DataServerResponse(Flags.Types.ResponseLogin)
                                {
                                    Login_NeedSetPassword = userInfo == null ? false : userInfo.LoginPwdInited,
                                    Login_Result = loginResult,
                                    Login_HaveSession = haveSession,
                                    Login_UserData = userInfo,
                                };
                                SendResponse(client, dsResponse);
                            }
                            break;
                        }
                    case Flags.Types.RequestResetPwd:
                        {
                            dcRequest = (DataClientRequest)obj;
                            bool resetResult
                                = db.SetUserPassword(dcRequest.ResetPwd_User, dcRequest.ResetPwd_NewPassword, false);
                            DataServerResponse response = new DataServerResponse(Flags.Types.ResponseResetPwd)
                            { ResetPwd_Result = resetResult, };
                            SendResponse(client, response);
                            ShowInfoNLog($"User [{sessions.GetUserId(client)}], reset his/her/its password.");
                            break;
                        }
                    case Flags.Types.RequestSupplyList:
                        {
                            dcRequest = (DataClientRequest)obj;
                            int outTotalPages, outCurPage;
                            DataTempletes.SupplyList sl = db.GetSupplies(
                                dcRequest.SupplyList_SearchPattern,
                                settings.MaxSuppliesPerPage,
                                dcRequest.SupplyList_Page
                                , out outTotalPages, out outCurPage);
                            DataServerResponse response = new DataServerResponse(Flags.Types.ResponseSupplyList)
                            {
                                SupplyList_TotalPages = outTotalPages,
                                SupplyList_CurPage = outCurPage,
                                SupplyList_Data = sl,
                            };
                            SendResponse(client, response);
                            ShowInfoNLog($"User [{sessions.GetUserId(client)}], "
                                + $"request supply list ({dcRequest.SupplyList_SearchPattern}) with page ({outCurPage}/{outTotalPages}).");
                            break;
                        }
                    case Flags.Types.RequestSupplyFileCounts:
                        {
                            dcRequest = (DataClientRequest)obj;
                            // load ids
                            List<DataTempletes.SupplyList.FileCountInfo> proofCountInfoList
                                = db.GetSupplyFileIDs(dcRequest.SupplyFileCounts_SupplyIDList);

                            // NTFS can hold max 4,294,967,295 files total
                            // ext2 10^18 total; ~1.3 × 10^20 per dir (performance issues past 10,000)
                            // ext3 same as ext2
                            // ext4 2^32 - 1 (4,294,967,295) total; unlimited per dir

                            // from id, load file count
                            foreach (DataTempletes.SupplyList.FileCountInfo pci in proofCountInfoList)
                            {
                                pci.Contract = fileIO.GetFileCount(pci.ContractID);
                                pci.ProofDelivery = fileIO.GetFileCount(pci.ProofDeliveryID);
                                pci.ProofAcceptance = fileIO.GetFileCount(pci.ProofAcceptanceID);
                                pci.ProofSignOff = fileIO.GetFileCount(pci.ProofSignOffID);
                            }
                            DataServerResponse response = new DataServerResponse(Flags.Types.ResponseSupplyFileCounts)
                            {
                                SupplyFileCounts_List = proofCountInfoList,
                            };
                            SendResponse(client, response);
                            ShowInfoNLog($"User [{sessions.GetUserId(client)}], "
                                + "request supply proof file counts.");
                            break;
                        }
                    case Flags.Types.RequestAccessSupply:
                        {
                            dcRequest = (DataClientRequest)obj;
                            int dbResult = 0;
                            Exception err = null;
                            try
                            {
                                switch (dcRequest.AccessSupply_OpType)
                                {
                                    case DataTempletes.RequestDataOperatTypes.Insert:
                                    case DataTempletes.RequestDataOperatTypes.Update:
                                        dbResult = db.InsertOrUpdateSupply(dcRequest.AccessSupply_Data, sessions.GetUserId(client));
                                        break;
                                    case DataTempletes.RequestDataOperatTypes.Delete:
                                        dbResult = db.DeleteSupply(dcRequest.AccessSupply_ID);
                                        break;
                                }
                            }
                            catch (Exception e)
                            { err = e; }
                            DataServerResponse response = new DataServerResponse(Flags.Types.ResponseAccessSupply)
                            {
                                AccessSupply_ID = dcRequest.AccessSupply_ID,
                                AccessSupply_OpType = dcRequest.AccessSupply_OpType,
                                AccessSupply_Result = dbResult >= 1,
                                AccessSupply_Error = err,
                            };
                            SendResponse(client, response);
                            ShowInfoNLog($"User [{sessions.GetUserId(client)}], "
                                + $"[{dcRequest.AccessSupply_OpType}] supply [{dcRequest.AccessSupply_ID}].");
                            break;
                        }
                    case Flags.Types.RequestFileQuery:
                        {
                            dcRequest = (DataClientRequest)obj;
                            if (dcRequest.FileQuery_ID != null)
                            {
                                long fileID = (long)dcRequest.FileQuery_ID;
                                List<FileInfo> files = fileIO.GetFiles(fileID);
                                DataTempletes.FileList dbFileList = db.GetFiles(fileID);
                                List<DataTempletes.FileInfo> result = new List<DataTempletes.FileInfo>();
                                string filePre;
                                FileInfo fi;
                                foreach (DataTempletes.FileList.Item dbF in dbFileList.Content)
                                {
                                    filePre = dbF.GetPhysicalFileProfix();
                                    fi = files.Where(f => f.Name.StartsWith(filePre)).FirstOrDefault();
                                    if (fi != null)
                                    {
                                        result.Add(new DataTempletes.FileInfo()
                                        {
                                            ID = fileID,
                                            No = dbF.No,
                                            Size = fi.Length,
                                            ModifyTime = fi.LastWriteTime,
                                            Name = dbF.Name,
                                            Uploader = dbF.Uploader,
                                            UploadTime = dbF.UploadTime,
                                        });
                                    }
                                }

                                DataServerResponse response = new DataServerResponse(Flags.Types.ResponseFileQuery)
                                { FileQuery_ID = dcRequest.FileQuery_ID, FileQuery_NameList = result, };
                                SendResponse(client, response);
                                ShowInfoNLog($"User [{sessions.GetUserId(client)}], "
                                    + $"request file list [{dcRequest.FileQuery_ID}].");
                            }
                            else
                            {
                                DataServerResponse response = new DataServerResponse(Flags.Types.ResponseFileQuery)
                                { FileQuery_ID = -1, FileQuery_NameList = null, };
                                SendResponse(client, response);
                                ShowInfoNLog($"User [{sessions.GetUserId(client)}], "
                                    + $"request file id is null.");
                            }
                            break;
                        }
                    case Flags.Types.RequestFileUpload:
                        {
                            dcRequest = (DataClientRequest)obj;
                            string tmpFileName = dcRequest.FileUpload_TaskID.ToString();
                            int dataLength = dcRequest.FileUpload_FileData.Length;
                            Exception err = null;
                            long? fileNo = null;
                            try
                            {
                                if (dcRequest.FileUpload_IsStartPack == true)
                                {
                                    // check host disk free space first

                                    string driveName = AppDomain.CurrentDomain.BaseDirectory.Substring(0, 1);
                                    DriveInfo di = new DriveInfo(driveName);
                                    if (di.AvailableFreeSpace < (di.TotalSize / 10))
                                        throw new Exception("Can't upload, because server disk free space is lower than 10%.");
                                }



                                //fileIO.WriteFile(tmpFileName,
                                //    (int)dcRequest.FileUpload_Offset, dcRequest.FileUpload_FileData);
                                fileIO.WriteFile_usingTask(dcRequest.FileUpload_TaskID, tmpFileName,
                                    (int)dcRequest.FileUpload_Position, dcRequest.FileUpload_FileData,
                                    dcRequest.FileUpload_IsEndPack == true);
                                if (dcRequest.FileUpload_IsEndPack == true)
                                {
                                    fileNo = db.GetFileNextNo((long)dcRequest.FileUpload_ID);
                                    // rename tmp file to target file
                                    string filePre
                                        = DataTempletes.FileList.Item.GetPhysicalFileProfix(
                                            (long)dcRequest.FileUpload_ID, (long)fileNo);
                                    string fileSuf = Path.GetExtension(dcRequest.FileUpload_FileName);
                                    fileIO.RenameFile(tmpFileName, filePre + fileSuf);

                                    // write db
                                    int afr = db.InsertFile(
                                        (long)dcRequest.FileUpload_ID,
                                        (long)fileNo, dcRequest.FileUpload_FileName,
                                        sessions.GetUserId(client),
                                        DateTime.Now
                                        );
                                    if (afr <= 0)
                                        throw new Exception("No record insert into table 'FileList'");
                                    ShowInfoNLog($"User {sessions.GetUserId(client)} upload file \"{dcRequest.FileUpload_FileName}\" at ({dcRequest.FileUpload_ID}, {fileNo}).");
                                }
                            }
                            catch (Exception e)
                            {
                                err = e;
                                ShowInfoNLog($"User {sessions.GetUserId(client)} failed to upload file");
                                ShowInfoNLog(err);
                            }
                            DataServerResponse response = new DataServerResponse(Flags.Types.ResponseFileUpload)
                            {
                                FileUpload_ID = dcRequest.FileUpload_ID,
                                FileUpload_TaskID = dcRequest.FileUpload_TaskID,
                                FileUpload_Position = dcRequest.FileUpload_Position,
                                FileUpload_Length = dataLength,
                                FileUpload_Result = err == null,
                                FileUpload_No = fileNo,
                                FileUpload_Error = err,
                            };
                            SendResponse(client, response);
                            break;
                        }
                    case Flags.Types.RequestFileDownload:
                        {
                            dcRequest = (DataClientRequest)obj;
                            FileInfo sourceFile = fileIO.GetFile(
                                (long)dcRequest.FileDownload_ID,
                                (long)dcRequest.FileDownload_No);

                            DataServerResponse response;
                            if (sourceFile == null)
                            {
                                response = new DataServerResponse(Flags.Types.ResponseFileDownload)
                                {
                                    FileDownload_TaskID = dcRequest.FileDownload_TaskID,
                                    FileDownload_ID = dcRequest.FileDownload_ID,
                                    FileDownload_No = dcRequest.FileDownload_No,
                                    FileDownload_FileName = dcRequest.FileDownload_Name,
                                    FileDownload_Position = dcRequest.FileDownload_Position,
                                    FileDownload_IsEndPack = false,
                                    FileDownload_FileData = null,
                                    FileDownload_Result = false,
                                    FileDownload_Error = new FileNotFoundException(
                                        $"No file found with ID{dcRequest.FileDownload_ID} and No{dcRequest.FileDownload_No}"),
                                };
                            }
                            else
                            {
                                bool isEndPack;
                                data = fileIO.ReadFile_usingTask(
                                    dcRequest.FileDownload_TaskID,
                                    sourceFile.Name,
                                    (int)dcRequest.FileDownload_Position,
                                    (int)dcRequest.FileDownload_Length,
                                    out isEndPack
                                    );


                                response = new DataServerResponse(Flags.Types.ResponseFileDownload)
                                {
                                    FileDownload_TaskID = dcRequest.FileDownload_TaskID,
                                    FileDownload_ID = dcRequest.FileDownload_ID,
                                    FileDownload_No = dcRequest.FileDownload_No,
                                    FileDownload_FileName = dcRequest.FileDownload_Name,
                                    FileDownload_Position = dcRequest.FileDownload_Position,
                                    FileDownload_IsEndPack = isEndPack,
                                    FileDownload_FileData = data,
                                    FileDownload_Result = true,
                                    FileDownload_Error = null,
                                };
                                if (isEndPack)
                                    ShowInfoNLog($"User {sessions.GetUserId(client)} download file \"{dcRequest.FileDownload_Name}\", from ({dcRequest.FileDownload_ID},{dcRequest.FileDownload_No}).");
                            }
                            SendResponse(client, response);
                            break;
                        }
                    case Flags.Types.RequestFileDelete:
                        {
                            dcRequest = (DataClientRequest)obj;
                            DataServerResponse response
                                = new DataServerResponse(Flags.Types.ResponseFileDelete);
                            try
                            {
                                long fileID = (long)dcRequest.FileDelete_ID;
                                response.FileDelete_ID = fileID;
                                long fileNo = (long)dcRequest.FileDelete_No;
                                response.FileDelete_No = fileNo;

                                int recs = db.DeleteFile(fileID, fileNo);
                                if (recs <= 0)
                                {
                                    throw new EntryPointNotFoundException($"No file entry found in DataBase at ({fileID},{fileNo})");
                                }
                                else
                                {
                                    fileIO.DeleteFile(fileIO.GetFile(fileID, fileNo).Name);
                                    response.FileDelete_Result = true;
                                    ShowInfoNLog($"User {sessions.GetUserId(client)} delete file {fileID}:{fileNo}");
                                }
                            }
                            catch (Exception err)
                            {
                                response.FileDelete_Result = false;
                                response.FileDelete_Error = err;
                                ShowInfoNLog($"User {sessions.GetUserId(client)} failed to delete file {response.FileDelete_ID}:{response.FileDelete_No}");
                            }
                            SendResponse(client, response);
                            break;
                        }
                    case Flags.Types.RequestDeliveryWarning:
                        {
                            dcRequest = (DataClientRequest)obj;
                            DataServerResponse response;
                            if (dcRequest.DeliveryWarning_ReserveDays == null
                                || string.IsNullOrWhiteSpace(dcRequest.DeliveryWarning_UserID))
                            {
                                response = new DataServerResponse(Flags.Types.ResponseDeliveryWarning)
                                {
                                    DeliveryWarning_UserID = dcRequest.DeliveryWarning_UserID.ToString(),
                                    DeliveryWarning_HaveWarning = true,
                                    DeliveryWarning_WarningMessage = "未能获取预警提前天数",
                                };
                                SendResponse(client, response);
                                ShowInfoNLog($"Faile to warn user {sessions.GetUserId(client)}, income [dcRequest.DeliveryWarning_UserID] is null.");
                            }
                            else
                            {
                                DataTempletes.SupplyList sList = db.GetOutOfDate_NoneDeliveriedSupplies(
                                    dcRequest.DeliveryWarning_UserID.ToString(),
                                    DateTime.Now.AddDays((double)dcRequest.DeliveryWarning_ReserveDays));

                                int countInReserve = 0, countInOneDay = 0, countOutOfDate = 0;
                                DateTime now = DateTime.Now;
                                TimeSpan ts;
                                double totalDays;
                                foreach (DataTempletes.SupplyList.Item it in sList.Content)
                                {
                                    ts = it.DeliveryDate - now;
                                    totalDays = ts.TotalDays;
                                    if (totalDays > 0)
                                    {
                                        countInReserve++;
                                        if (totalDays < 1)
                                            countInOneDay++;
                                    }
                                    else
                                        countOutOfDate++;
                                }
                                StringBuilder warningBdr = new StringBuilder();
                                if (countInReserve > 0)
                                {
                                    warningBdr.Append($"您有{countInReserve}个项目的物资即将到货；{Environment.NewLine}");
                                    if (countInOneDay > 0)
                                        warningBdr.Append($"   其中有{countInOneDay}个项目的物资将在今天到货；{Environment.NewLine}");
                                }
                                if (countOutOfDate > 0)
                                    warningBdr.Append($"{Environment.NewLine}已有{countOutOfDate}个项目的物资超期未到货；");
                                response = new DataServerResponse(Flags.Types.ResponseDeliveryWarning)
                                {
                                    DeliveryWarning_UserID = dcRequest.DeliveryWarning_UserID.ToString(),
                                    DeliveryWarning_HaveWarning = warningBdr.Length > 0,
                                    DeliveryWarning_WarningMessage = warningBdr.ToString(),
                                };
                                if (countInReserve > 0 || countOutOfDate > 0)
                                {
                                    SendResponse(client, response);
                                    ShowInfoNLog($"Warn delivery to user {sessions.GetUserId(client)}.");
                                }
                            }
                            break;
                        }
                    case Flags.Types.RequestSupplyStatus:
                        {
                            //dcRequest = (DataClientRequest)obj;
                            DataServerResponse response = new DataServerResponse(Flags.Types.ResponseSupplyStatus)
                            { SupplyStatus_Dictionary = db.GetSupplyStatus(), };

                            SendResponse(client, response);
                            ShowInfoNLog($"Send status-dictionary to user {sessions.GetUserId(client)}.");
                            break;
                        }
                    case Flags.Types.RequestSignOffList:
                        {
                            dcRequest = (DataClientRequest)obj;
                            DataTempletes.SignOffList soList
                                = db.GetSignOffs(
                                    dcRequest.SignOffList_SupplyID,
                                    dcRequest.SignOffList_UserID);
                            DataServerResponse response = new DataServerResponse(Flags.Types.ResponseSignOffList)
                            {
                                SignOffList_SupplyID = dcRequest.SignOffList_SupplyID,
                                SignOffList_UserID = dcRequest.SignOffList_UserID,
                                SignOffList_Data = soList,
                            };
                            SendResponse(client, response);
                            ShowInfoNLog($"User {sessions.GetUserId(client)} request sign-off list.");
                            break;
                        }
                    case Flags.Types.RequestSignOffCount:
                        {
                            dcRequest = (DataClientRequest)obj;
                            DataServerResponse response = new DataServerResponse(Flags.Types.ResponseSignOffCount)
                            {
                                SignOffCount_SupplyID = dcRequest.SignOffCount_SupplyID,
                                SignOffCount_Count = db.GetSignOffCount(dcRequest.SignOffCount_SupplyID),
                            };
                            SendResponse(client, response);
                            ShowInfoNLog($"User {sessions.GetUserId(client)} request sign-off count.");
                            break;
                        }
                    case Flags.Types.RequestAccessSignOff:
                        {
                            dcRequest = (DataClientRequest)obj;
                            int dbResult = -1;
                            Exception err = null;
                            try
                            {
                                switch (dcRequest.AccessSignOff_OpType)
                                {
                                    case DataTempletes.RequestDataOperatTypes.Insert:
                                        {
                                            dbResult = db.InsertSignOff(dcRequest.AccessSignOff_Data, sessions.GetUserId(client));
                                            break;
                                        }
                                    case DataTempletes.RequestDataOperatTypes.Update:
                                        {
                                            dbResult = db.UpdateSignOff(dcRequest.AccessSignOff_Data, sessions.GetUserId(client));
                                            break;
                                        }
                                    case DataTempletes.RequestDataOperatTypes.Delete:
                                        {
                                            dbResult = db.DeleteSignOff(dcRequest.AccessSignOff_ID);
                                            break;
                                        }
                                    default:
                                    case DataTempletes.RequestDataOperatTypes.Select:
                                        {
                                            err = new NotSupportedException("Case \'default\' or \'Select\' are not supported.");
                                            break;
                                        }
                                }
                            }
                            catch (Exception e)
                            {
                                err = e;
                                ShowInfoNLog(e);
                            }
                            DataServerResponse response = new DataServerResponse(Flags.Types.ResponseAccessSignOff)
                            {
                                AccessSignOff_ID = dcRequest.AccessSignOff_ID,
                                AccessSignOff_OpType = dcRequest.AccessSignOff_OpType,
                                AccessSignOff_Result = dbResult > 0,
                                AccessSignOff_Error = err,
                            };
                            SendResponse(client, response);
                            ShowInfoNLog($"User [{sessions.GetUserId(client)}], "
                                + $"[{dcRequest.AccessSignOff_OpType}] sign-off [{dcRequest.AccessSignOff_ID}].");
                            break;
                        }

                    case Flags.Types.RequestUniversalDir:
                        {
                            dcRequest = (DataClientRequest)obj;
                            if (dcRequest.UniversalDir_BaseDir == null)
                            {
                                dcRequest.UniversalDir_BaseDir = AppDomain.CurrentDomain.BaseDirectory;
                            }
                            DataServerResponse response = new DataServerResponse(Flags.Types.ResponseUniversalDir);
                            response.UniversalDir_BaseDir = dcRequest.UniversalDir_BaseDir;
                            try
                            {
                                List<DataTempletes.UniversalFileSystemInfo> subs
                                    = new List<DataTempletes.UniversalFileSystemInfo>();
                                DirectoryInfo di = new DirectoryInfo(dcRequest.UniversalDir_BaseDir);
                                foreach (FileSystemInfo fsi in di.GetDirectories())
                                {
                                    subs.Add(new DataTempletes.UniversalFileSystemInfo()
                                    {
                                        DirectorySeparatorChar = Path.DirectorySeparatorChar,
                                        FullName = fsi.FullName,
                                        Attributes = fsi.Attributes,
                                        CreationTime = fsi.CreationTime,
                                        LastWriteTime = fsi.LastWriteTime,
                                    });
                                }
                                foreach (FileInfo fi in di.GetFiles())
                                {
                                    subs.Add(new DataTempletes.UniversalFileSystemInfo()
                                    {
                                        DirectorySeparatorChar = Path.DirectorySeparatorChar,
                                        FullName = fi.FullName,
                                        Size = fi.Length,
                                        Attributes = fi.Attributes,
                                        CreationTime = fi.CreationTime,
                                        LastWriteTime = fi.LastWriteTime,
                                    });
                                }
                                response.UniversalDir_FSList = subs;
                                ShowInfoNLog($"User [{sessions.GetUserId(client)}], "
                                    + $"Get dir[{ dcRequest.UniversalDir_BaseDir}].");
                            }
                            catch (Exception err)
                            {
                                response.UniversalDir_Error = err;
                                ShowInfoNLog(err);
                                ShowInfoNLog($"User [{sessions.GetUserId(client)}], "
                                    + $"Failed to get dir[{ dcRequest.UniversalDir_BaseDir}].");
                            }
                            SendResponse(client, response);
                            break;
                        }
                    case Flags.Types.RequestUniversalCreateDir:
                        {
                            dcRequest = (DataClientRequest)obj;
                            DataServerResponse response = new DataServerResponse(Flags.Types.ResponseUniversalCreateDir)
                            {
                                UniversalCreateDir_DirFullName = dcRequest.UniversalCreateDir_DirFullName,
                            };
                            try
                            {
                                Directory.CreateDirectory(dcRequest.UniversalCreateDir_DirFullName);
                                response.UniversalCreateDir_Result = true;
                                ShowInfoNLog($"User [{sessions.GetUserId(client)}], "
                                    + $"create dir [{dcRequest.UniversalCreateDir_DirFullName}].");
                            }
                            catch (Exception err)
                            {
                                response.UniversalCreateDir_Result = false;
                                response.UniversalCreateDir_Error = err;
                                ShowInfoNLog(err);
                                ShowInfoNLog($"User [{sessions.GetUserId(client)}], "
                                    + $"failed to create dir [{dcRequest.UniversalCreateDir_DirFullName}].");
                            }
                            SendResponse(client, response);
                            break;
                        }
                    case Flags.Types.RequestUniversalMove:
                        {
                            dcRequest = (DataClientRequest)obj;
                            DataServerResponse response = new DataServerResponse(Flags.Types.ResponseUniversalMove)
                            {
                                UniversalMove_NewFullName = dcRequest.UniversalMove_NewFullName,
                            };
                            try
                            {
                                if (Directory.Exists(dcRequest.UniversalMove_OriFullName))
                                {
                                    Directory.Move(dcRequest.UniversalMove_OriFullName, dcRequest.UniversalMove_NewFullName);
                                }
                                else
                                {
                                    File.Move(dcRequest.UniversalMove_OriFullName, dcRequest.UniversalMove_NewFullName);
                                }
                                response.UniversalMove_Result = true;
                                ShowInfoNLog($"User [{sessions.GetUserId(client)}], "
                                    + $"rename [{dcRequest.UniversalMove_OriFullName}] to [{dcRequest.UniversalMove_NewFullName}].");
                            }
                            catch (Exception err)
                            {
                                response.UniversalMove_Result = false;
                                response.UniversalMove_Error = err;
                                ShowInfoNLog(err);
                                ShowInfoNLog($"User [{sessions.GetUserId(client)}], "
                                    + $"failed to rename [{dcRequest.UniversalMove_OriFullName}] to [{dcRequest.UniversalMove_NewFullName}].");
                            }
                            SendResponse(client, response);
                            break;
                        }
                    case Flags.Types.RequestUniversalDelete:
                        {
                            dcRequest = (DataClientRequest)obj;
                            List<bool> results = new List<bool>();
                            DataServerResponse response = new DataServerResponse(Flags.Types.ResponseUniversalDelete)
                            {
                                UniversalDelete_FileList = dcRequest.UniversalDelete_FileList,
                                UniversalDelete_ResultList = results,
                            };
                            DataTempletes.UniversalFileSystemInfo curFSI = null;
                            try
                            {
                                for (int j = 0, jv = dcRequest.UniversalDelete_FileList.Count; j < jv; j++)
                                {
                                    curFSI = dcRequest.UniversalDelete_FileList[j];
                                    if (Directory.Exists(curFSI.FullName))
                                    {
                                        Directory.Delete(curFSI.FullName, true);
                                    }
                                    else
                                    {
                                        File.Delete(curFSI.FullName);
                                    }
                                    results.Add(true);
                                    ShowInfoNLog($"User [{sessions.GetUserId(client)}], "
                                        + $"delete [{curFSI.FullName}].");
                                }
                            }
                            catch (Exception err)
                            {
                                results.Add(false);
                                response.UniversalDelete_Error = err;
                                ShowInfoNLog(err);
                                if (curFSI == null)
                                    ShowInfoNLog($"User [{sessions.GetUserId(client)}], "
                                        + $"failed to delete [].");
                                else
                                    ShowInfoNLog($"User [{sessions.GetUserId(client)}], "
                                        + $"failed to delete [{curFSI.FullName}].");
                            }
                            SendResponse(client, response);
                            break;
                        }
                    case Flags.Types.RequestUniversalDownload:
                        {
                            dcRequest = (DataClientRequest)obj;
                            DataServerResponse response = new DataServerResponse(Flags.Types.ResponseUniversalDownload)
                            {
                                UniversalDownload_FileFullName = dcRequest.UniversalDownload_FileFullName,
                                UniversalDownload_Position = dcRequest.UniversalDownload_Position,
                                //UniversalDownload_Data = null,
                                //UniversalDownload_FileLength = 0,
                                //UniversalDownload_Error = null,
                            };
                            try
                            {
                                if (dcRequest.UniversalDownload_Position == 0)
                                {
                                    ShowInfoNLog($"User [{sessions.GetUserId(client)}], "
                                        + $"start downloading file [{dcRequest.UniversalDownload_FileFullName}].");

                                    fileStream_UFTDownload?.Dispose();
                                    fileStream_UFTDownload = new FileStream(
                                        dcRequest.UniversalDownload_FileFullName,
                                        FileMode.Open, FileAccess.Read
                                        );
                                }
                                response.UniversalDownload_FileLength = fileStream_UFTDownload.Length;

                                fileStream_UFTDownload.Position = (long)dcRequest.UniversalDownload_Position;
                                int bufferLength = 524288; // 0.5M
                                byte[] readBuffer = new byte[bufferLength];
                                int readLength = fileStream_UFTDownload.Read(readBuffer, 0, bufferLength);

                                if (readLength != bufferLength)
                                {
                                    byte[] shortBuffer = new byte[readLength];
                                    Array.Copy(readBuffer, shortBuffer, readLength);
                                    response.UniversalDownload_Data = shortBuffer;
                                }
                                else
                                {
                                    response.UniversalDownload_Data = readBuffer;
                                }

                                if (dcRequest.UniversalDownload_Position + readLength
                                    >= fileStream_UFTDownload.Length)
                                {
                                    ShowInfoNLog($"User [{sessions.GetUserId(client)}], "
                                        + $"complete downloading file [{dcRequest.UniversalDownload_FileFullName}].");
                                    fileStream_UFTDownload.Flush();
                                    fileStream_UFTDownload.Dispose();
                                }
                            }
                            catch (Exception err)
                            {
                                ShowInfoNLog(err);
                                ShowInfoNLog($"User [{sessions.GetUserId(client)}], "
                                    + $"failed to download file [{dcRequest.UniversalDownload_FileFullName}], "
                                    + $"at position [{dcRequest.UniversalDownload_Position}].");
                                response.UniversalDownload_Error = err;
                                fileStream_UFTDownload?.Dispose();
                            }
                            SendResponse(client, response);
                            break;
                        }
                    case Flags.Types.RequestUniversalUpload:
                        {
                            dcRequest = (DataClientRequest)obj;
                            DataServerResponse response = new DataServerResponse(Flags.Types.ResponseUniversalUpload)
                            {
                                UniversalUpload_FileFullName = dcRequest.UniversalUpload_FileFullName,
                                UniversalUpload_Position = dcRequest.UniversalUpload_Position,
                                UniversalUpload_DataLength = dcRequest.UniversalUpload_Data.Length,
                                //UniversalUpload_Error = null,
                                //UniversalUpload_Result = false,
                            };
                            try
                            {
                                if (dcRequest.UniversalUpload_Position == 0
                                    && dcRequest.UniversalUpload_Data.Length == 0)
                                {
                                    File.WriteAllText(dcRequest.UniversalUpload_FileFullName, "");
                                }
                                else
                                {
                                    if (dcRequest.UniversalUpload_Position == 0)
                                    {
                                        ShowInfoNLog($"User [{sessions.GetUserId(client)}], "
                                            + $"start uploading file [{dcRequest.UniversalUpload_FileFullName}].");

                                        fileStream_UFTUpload?.Dispose();
                                        fileStream_UFTUpload = new FileStream(
                                            dcRequest.UniversalUpload_FileFullName,
                                            FileMode.CreateNew, FileAccess.Write
                                            );
                                    }

                                    if (fileStream_UFTUpload.Position != dcRequest.UniversalUpload_Position)
                                    {
                                        throw new IndexOutOfRangeException(
                                            $"Request writing position[{dcRequest.UniversalUpload_Position}] "
                                                + $"is out of sync with writer position[{fileStream_UFTUpload.Position}].");
                                    }

                                    fileStream_UFTUpload.Write(
                                        dcRequest.UniversalUpload_Data,
                                        0,
                                        dcRequest.UniversalUpload_Data.Length);

                                    if (dcRequest.UniversalUpload_IsEndPack == true)
                                    {
                                        ShowInfoNLog($"User [{sessions.GetUserId(client)}], "
                                            + $"complete uploading file [{dcRequest.UniversalUpload_FileFullName}].");
                                        fileStream_UFTUpload.Flush();
                                        fileStream_UFTUpload.Dispose();
                                    }
                                }
                                response.UniversalUpload_Result = true;
                            }
                            catch (Exception err)
                            {
                                ShowInfoNLog(err);
                                ShowInfoNLog($"User [{sessions.GetUserId(client)}], "
                                    + $"failed to upload file [{dcRequest.UniversalUpload_FileFullName}], "
                                    + $"at position [{dcRequest.UniversalUpload_Position}].");
                                response.UniversalUpload_Error = err;
                                response.UniversalUpload_Result = false;
                                fileStream_UFTUpload?.Dispose();
                            }

                            SendResponse(client, response);
                            break;
                        }
                }
            }
        }
        private FileStream fileStream_UFTDownload = null;
        private FileStream fileStream_UFTUpload = null;


        public void ShowInfoNLog(string msg)
        {
            Console.WriteLine(msg);
            logger.Log(msg);
        }
        public void ShowInfoNLog(Exception err)
        {
            Console.WriteLine(err.ToString());
            logger.Log(err);
        }

        internal void Start()
        {
            socketServer.Start();
        }

        public void Dispose()
        {
            socketServer.Dispose();
        }
    }
}
