﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;

using MadTomDev.CommonClasses;
using MadTomDev.Network;
using MadTomDev.Data;
using MadTomDev.App.YPLQDJ;
using System.ComponentModel;
using MadTomDev.Math;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace MadTomDev.WWWs
{
    class Program
    {
        static void Main(string[] args)
        {
            string serverAppName = "YPLQDJServer by MadTom 2020 0429";
            bool createdNew;
            Mutex m = new Mutex(true, serverAppName, out createdNew);

            if (!createdNew)
            {
                // app is already running...
                Console.WriteLine("A server, " + serverAppName + ", is already running, starting aborted.");
                Console.WriteLine("Press any key to exit.");
                Console.ReadKey();
                return;
            }

            Console.WriteLine("Server starting...");
            ServerCore core = null;
            try
            {
                //Console.WriteLine("For debuging, press Enter to continue...");
                //string tmp = Console.ReadLine();

                core = new ServerCore();
                core.Start();

                Console.WriteLine("Server ready, input 'help' for more commands.");
                do
                {                    
                    core.cmd.InputCmdNExe(Console.ReadLine());
                }
                while (!core.cmd.IsExiting);

                core.Dispose();
                Console.WriteLine("Bye-bye.");
            }
            catch (Exception err)
            {
                core?.logger.Log(err);
                Console.WriteLine(err.ToString());
            }
        }
    }


}
