﻿using MadTomDev.App.YPLQDJ;
using MadTomDev.CommonClasses;
using MadTomDev.Data;
using MadTomDev.Network;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MadTomDev.WWWs
{

    class Commands
    {
        private ServerCore core;
        public Commands(ServerCore core)
        {
            core.cmd = this;
            this.core = core;
        }

        public bool IsExiting { private set; get; } = false;

        public enum CmdTypes
        {
            None, Unknow,
            Help,
            ListeningIp,
            ClientsInfo, BlockedConnectionsInfo,
            Kick, RemoveBlock,
            KickAll, RemoveBlockAll,
            Message,
            ResetPassword,
            Exit,

            AddUser, CheckUser,
            SetUserAuthes,
            SetSuppliesPerPage,

            CPUUsage, MemUsage, DiskUsage,

            DBExport, DBImport, DBClean,

            ConsoleOnly,

            Testing,
        }
        public CmdTypes CmdType { private set; get; } = CmdTypes.None;

        public string RawCommand { private set; get; }
        private string[] inputParts;

        public void InputCmdNExe(string cmd, SocketHelper.SocketTcpServer.ConnectedClient client = null)
        {
            if (string.IsNullOrWhiteSpace(cmd))
                return;

            //if (ignoreInput)
            //{
            //    core.logger.Log($"Ignore cmd input: {cmd}");
            //    return;
            //}
            _CmdInput(cmd, client);
            _CmdExe(client);
        }

        public bool IsKickingUser { private set; get; } = false;
        //private bool ignoreInput = false;
        private void _CmdInput(string cmd, SocketHelper.SocketTcpServer.ConnectedClient client = null)
        {

            RawCommand = cmd;
            inputParts = cmd.Trim().ToLower().Split(
                new string[] { " " },
                StringSplitOptions.RemoveEmptyEntries);
            if (inputParts.Length == 0)
            {
                CmdType = CmdTypes.None;
                return;
            }
            else if (inputParts[0] == "help" || inputParts[0] == "commands"
                || inputParts[0] == "cmds")
            {
                CmdType = CmdTypes.Help;
            }
            else if (inputParts[0] == "ip" || inputParts[0] == "listeningip"
                || inputParts[0] == "listening")
            {
                CmdType = CmdTypes.ListeningIp;
            }
            else if (inputParts[0] == "clients" || inputParts[0] == "clientsInfo"
                || inputParts[0] == "clientsList")
            {
                CmdType = CmdTypes.ClientsInfo;
            }
            else if (inputParts[0] == "blocked" || inputParts[0] == "blockedInfo"
                || inputParts[0] == "blockedList")
            {
                CmdType = CmdTypes.BlockedConnectionsInfo;
            }
            else if (inputParts[0] == "kick" || inputParts[0] == "kill"
                || inputParts[0] == "disconnect")
            {
                CmdType = CmdTypes.Kick;
            }
            else if (inputParts[0] == "kickall" || inputParts[0] == "killall")
            {
                CmdType = CmdTypes.KickAll;
            }
            else if (inputParts[0] == "removeblock" || inputParts[0] == "deleteblock"
                || inputParts[0] == "delblock")
            {
                CmdType = CmdTypes.RemoveBlock;
            }
            else if (inputParts[0] == "unblockall")
            {
                CmdType = CmdTypes.RemoveBlockAll;
            }
            else if (inputParts[0] == "message" || inputParts[0] == "msg"
                || inputParts[0] == "sendmessage" || inputParts[0] == "sendmsg")
            {
                CmdType = CmdTypes.Message;
            }
            else if (inputParts[0] == "resetpassword" || inputParts[0] == "resetpwd"
                || inputParts[0] == "repassword" || inputParts[0] == "repwd")
            {
                CmdType = CmdTypes.ResetPassword;
            }
            else if (inputParts[0] == "close" || inputParts[0] == "exit"
               || inputParts[0] == "shutdown")
            {
                CmdType = CmdTypes.Exit;
            }
            else if (inputParts[0] == "adduser")
            {
                CmdType = CmdTypes.AddUser;
            }
            else if (inputParts[0] == "checkuser")
            {
                CmdType = CmdTypes.CheckUser;
            }
            else if (inputParts[0] == "setuserauthes")
            {
                CmdType = CmdTypes.SetUserAuthes;
            }
            else if (inputParts[0] == "setsuppliesperpage"
                || inputParts[0] == "suppliesperpage"
                || inputParts[0] == "spp")
            {
                CmdType = CmdTypes.SetSuppliesPerPage;
            }
            else if (inputParts[0] == "cpuusage")
            {
                CmdType = CmdTypes.CPUUsage;
            }
            else if (inputParts[0] == "memusage")
            {
                CmdType = CmdTypes.MemUsage;
            }
            else if (inputParts[0] == "diskusage")
            {
                CmdType = CmdTypes.DiskUsage;
            }
            else if (inputParts[0] == "dbexport")
            {
                CmdType = CmdTypes.DBExport;
            }
            else if (inputParts[0] == "dbimport")
            {
                CmdType = CmdTypes.DBImport;
            }
            else if (inputParts[0] == "dbclean")
            {
                CmdType = CmdTypes.DBClean;
            }
            else if (inputParts[0] == "testing")
            {
                CmdType = CmdTypes.Testing;
            }
            else if (inputParts[0] == "uft")
            {
                CmdType = CmdTypes.ConsoleOnly;
            }
            else
            {
                CmdType = CmdTypes.Unknow;
            }

            string user = client == null ? null : client.RemoteEndPointString;
            if (CmdType == CmdTypes.ResetPassword)
                core.logger.Log($"User[{user}] input command: [ResetPassword]");
            else
                core.logger.Log($"User[{user}] input command: " + RawCommand);
        }
        private void _CmdExe(SocketHelper.SocketTcpServer.ConnectedClient client = null)
        {
            string resultStr;
            StringBuilder resultStrAll = null;
            bool isPrintHelp = false;
            if (client != null)
                resultStrAll = new StringBuilder();
            switch (CmdType)
            {
                default:
                case CmdTypes.None:
                    return;
                case CmdTypes.Unknow:
                    {
                        resultStr = "Unknow command: " + inputParts[0];
                        _CmdResult_AppendLine(resultStrAll, resultStr);
                        core.ShowInfoNLog(resultStr);
                        break;
                    }
                case CmdTypes.ConsoleOnly:
                    {
                        resultStr = "Can't exec on server, console command: " + inputParts[0];
                        _CmdResult_AppendLine(resultStrAll, resultStr);
                        core.ShowInfoNLog(resultStr);
                        break;
                    }
                case CmdTypes.Message:
                    {
                        //inputParts
                        // [cmd]  [c1]  [c2] ...  [msg]
                        if (inputParts.Length < 2)
                        {
                            resultStr = "No message.";
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                            break;
                        }
                        else
                        {
                            List<string> userList = new List<string>();
                            StringBuilder msgBdr = new StringBuilder();
                            bool foundDoubleQ = false;
                            bool toAll = false;
                            string p;
                            for (int i = 1, iv = inputParts.Length; i < iv; i++)
                            {
                                p = inputParts[i];
                                if (p.StartsWith('\"'))
                                {
                                    foundDoubleQ = true;
                                    if (i == 1)
                                        toAll = true;

                                    if (msgBdr.Length > 0)
                                        msgBdr.Append(" ");
                                    msgBdr.Append(p);
                                }
                                else if (!foundDoubleQ)
                                {
                                    userList.Add(p);
                                }
                            }
                            if (!foundDoubleQ)
                            {
                                resultStr = "No message found, use pair of quotes to mark.";
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                                break;
                            }

                            if ((toAll && core.sessions.Count == 0)
                                || (!toAll && userList.Count == 0))
                            {
                                resultStr = "Can't find any client.";
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                                break;
                            }

                            resultStr = "Sending message...";
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                            DataMessage dm = new DataMessage()
                            { Message = msgBdr.ToString(), };
                            byte[] encryDMData
                                = EncryptedGZip.EncryptGZip(
                                    dm.Data, core.Encryption_Password, core.Encryption_ConfusionLength);
                            if (toAll)
                            {
                                Parallel.ForEach<UserSessions.SessionData>(core.sessions.list, (kvp, lState, idx) =>
                               {
                                   kvp.client.socket.Send(encryDMData);
                               });
                                resultStr = "Have sent message to all clients.";
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                            }
                            else
                            {
                                List<string> notExistUserList = new List<string>();
                                List<string> sendMsgUserList = new List<string>();
                                Parallel.ForEach<string>(userList, (u, lState, idx) =>
                                {
                                    bool notSent = true;
                                    foreach (UserSessions.SessionData found in core.sessions[u])
                                    {
                                        found.client.socket.Send(encryDMData);
                                        sendMsgUserList.Add(u);
                                        notSent = false;
                                    }
                                    if (notSent)
                                    {
                                        notExistUserList.Add(u);
                                    }
                                });

                                StringBuilder resultBdr = new StringBuilder();
                                if (sendMsgUserList.Count == 0)
                                {
                                    resultStr = "No client to sent.";
                                    _CmdResult_AppendLine(resultStrAll, resultStr);
                                    core.ShowInfoNLog(resultStr);
                                }
                                else
                                {
                                    resultBdr.Append("Have sent message to clients below:");
                                    resultBdr.Append(Environment.NewLine);
                                    foreach (string u in sendMsgUserList)
                                    {
                                        resultBdr.Append(u);
                                        resultBdr.Append("    ");
                                    }
                                    resultStr = resultBdr.ToString();
                                    _CmdResult_AppendLine(resultStrAll, resultStr);
                                    core.ShowInfoNLog(resultStr);
                                }
                                if (notExistUserList.Count > 0)
                                {
                                    resultBdr.Clear();
                                    resultBdr.Append("Can't find clients below:");
                                    resultBdr.Append(Environment.NewLine);
                                    foreach (string u in notExistUserList)
                                    {
                                        resultBdr.Append(u);
                                        resultBdr.Append("    ");
                                    }
                                    resultStr = resultBdr.ToString();
                                    _CmdResult_AppendLine(resultStrAll, resultStr);
                                    core.ShowInfoNLog(resultStr);
                                }
                            }
                        }
                        break;
                    }
                case CmdTypes.Help:
                    {
                        PrintHelp(client);
                        isPrintHelp = true;
                        break;
                    }
                case CmdTypes.ListeningIp:
                    {
                        resultStr = $"Server listening @ {core.socketServer.socket.LocalEndPoint}";
                        _CmdResult_AppendLine(resultStrAll, resultStr);
                        core.ShowInfoNLog(resultStr);
                        break;
                    }
                case CmdTypes.ClientsInfo:
                    {
                        resultStr = core.sessions.ToInfoString();
                        _CmdResult_AppendLine(resultStrAll, resultStr);
                        core.ShowInfoNLog(resultStr);
                        break;
                    }
                case CmdTypes.Kick:
                    {
                        // {client} 
                        if (inputParts.Length != 2)
                        {
                            resultStr = "Parameters not right, please using only one userId at a time.";
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                            break;
                        }

                        string userId = inputParts[1];
                        if (core.sessions.HaveSession(userId))
                        {
                            IsKickingUser = true;
                            core.sessions.RemoveSessionByUserID(userId);
                            resultStr = $"Have kicked user [{userId}]";
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                            ThreadPool.QueueUserWorkItem((e1) =>
                            {
                                Thread.Sleep(500);
                                IsKickingUser = false;
                            });
                        }
                        else
                        {
                            resultStr = $"Can't find user [{userId}] in sessions.";
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                        }
                        break;
                    }
                case CmdTypes.KickAll:
                    {
                        // -confirm
                        if (inputParts.Length != 2 || inputParts[1] != "-confirm")
                        {
                            resultStr = "Parameters not right, using \"-confirm\" to confirm.";
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                            break;
                        }


                        int counter = 0;
                        for (int i = core.sessions.list.Count - 1; i >= 0; i--)
                        {
                            IsKickingUser = true;
                            core.sessions.RemoveSession(core.sessions.list[i].client);
                            counter++;
                        }
                        if (IsKickingUser)
                        {
                            ThreadPool.QueueUserWorkItem((e1) =>
                            {
                                Thread.Sleep(500);
                                IsKickingUser = false;
                            });
                        }
                        if (counter == 0)
                        {
                            resultStr = "No user to kick.";
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                        }
                        else
                        {
                            resultStr = $"All users kicked, [{counter}] in total.";
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                        }
                        break;
                    }
                case CmdTypes.BlockedConnectionsInfo:
                    {
                        resultStr = core.connectionChecker.ToInfoString();
                        _CmdResult_AppendLine(resultStrAll, resultStr);
                        core.ShowInfoNLog(resultStr);
                        break;
                    }
                case CmdTypes.RemoveBlock:
                    {
                        // {remotePoint}
                        if (inputParts.Length != 2)
                        {
                            resultStr = "Parameters not right, please using only one IPAddress at a time.";
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                            break;
                        }
                        string ipStr = inputParts[1];
                        try
                        {
                            IPAddress test = IPAddress.Parse(ipStr);
                        }
                        catch (Exception)
                        {
                            resultStr = $"IPAddress [{ipStr}] is not valied.";
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                            break;
                        }

                        ClientConnectionChecker.ConnectionInfo ci
                            = core.connectionChecker.connectionInfoList
                                .Where(i => i.IsLocked && i.IPAddressString == ipStr)
                                .FirstOrDefault();
                        if (ci == null)
                        {
                            resultStr = $"Can't find block [{ipStr}].";
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                        }
                        else
                        {
                            core.connectionChecker.UnReg(ipStr);
                            resultStr = $"Have removed block to [{ipStr}].";
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                        }
                        break;
                    }
                case CmdTypes.RemoveBlockAll:
                    {
                        // -confirm 
                        if (inputParts.Length != 2 || inputParts[1] != "-confirm")
                        {
                            resultStr = "Parameters not right, using \"-confirm\" to confirm.";
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                            break;
                        }

                        int counter = 0;
                        foreach (ClientConnectionChecker.ConnectionInfo ci
                            in core.connectionChecker.connectionInfoList
                                .Where(i => i.IsLocked).ToArray())
                        {
                            core.connectionChecker.connectionInfoList.Remove(ci);
                            counter++;
                        }
                        if (counter == 0)
                        {
                            resultStr = "No block to remove.";
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                        }
                        else
                        {
                            resultStr = $"All blocks removed, [{counter}] in total.";
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                        }
                        break;
                    }
                case CmdTypes.ResetPassword:
                    {
                        //repwd {client} {newPwd}
                        if (inputParts.Length != 3)
                        {
                            resultStr = "Parameters must be {user id} {new password}.";
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                        }
                        else
                        {
                            string userId = inputParts[1];
                            if (core.db.HaveUser(userId))
                            {
                                if (core.db.SetUserPassword(userId, inputParts[2]))
                                {
                                    resultStr = $"Set new password for user [{userId}].";
                                    _CmdResult_AppendLine(resultStrAll, resultStr);
                                    core.ShowInfoNLog(resultStr);
                                }
                                else
                                {
                                    resultStr = $"Failed to set new password.";
                                    _CmdResult_AppendLine(resultStrAll, resultStr);
                                    core.ShowInfoNLog(resultStr);
                                }
                            }
                            else
                            {
                                resultStr = $"Can't find user [{userId}].";
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                            }
                        }
                        break;
                    }
                case CmdTypes.Exit:
                    {
                        resultStr = "Shuting down...";
                        _CmdResult_AppendLine(resultStrAll, resultStr);
                        core.ShowInfoNLog(resultStr);
                        IsExiting = true;
                        break;
                    }
                case CmdTypes.AddUser:
                    {
                        //addUser {ID} {Name} {Password} {Authes} [Sex] [Unit]
                        if (inputParts.Length < 5)
                        {
                            resultStr = "Parameters must be at least {ID} {Name} {Password} {Authes}.";
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                        }
                        else
                        {
                            string userId = inputParts[1];
                            string userName = inputParts[2];
                            string initPassword = inputParts[3];
                            string userAuthes = inputParts[4];
                            string userSex = null, userUnit = null;
                            if (inputParts.Length >= 6) userSex = inputParts[5];
                            if (inputParts.Length >= 7) userUnit = inputParts[6];

                            if (core.db.HaveUser(userId))
                            {
                                resultStr = $"Can't create, user [{userId}] had already exist.";
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                            }
                            else if (core.db.CreateUser(userId, userName, userSex, userUnit, initPassword, userAuthes))
                            {
                                resultStr = $"User [{userId}] created.";
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                            }
                            else
                            {
                                resultStr = $"Can't create user.";
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                            }
                        }
                        break;
                    }
                case CmdTypes.CheckUser:
                    {
                        //checkuser {ID}
                        if (inputParts.Length < 2)
                        {
                            resultStr = "Parameters must be {ID}.";
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                        }
                        else
                        {
                            string userId = inputParts[1];

                            DataTempletes.User userData = core.db.GetUser(userId);

                            if (userData == null)
                            {
                                resultStr = $"User [{userId}] not exists.";
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                            }
                            else
                            {
                                StringBuilder strBdr = new StringBuilder();
                                strBdr.Append($"Details of user {userId}." + Environment.NewLine);
                                strBdr.Append($"    Name:       {userData.Name}" + Environment.NewLine);
                                strBdr.Append($"    SexID:      {userData.SexID}" + Environment.NewLine);
                                strBdr.Append($"    UnitID:     {userData.UnitID}" + Environment.NewLine);
                                strBdr.Append($"    IsInitPwd:  {userData.LoginPwdInited}" + Environment.NewLine);
                                strBdr.Append($"    Authes:     {userData.Authorities.TextValue}");
                                resultStr = strBdr.ToString();
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                            }
                        }


                        break;
                    }
                case CmdTypes.SetUserAuthes:
                    {
                        //setUserAuthes {UserID} {Authes}
                        if (inputParts.Length < 3)
                        {
                            resultStr = "Parameters must be {UserID} {Authes}.";
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                        }
                        else
                        {
                            string userId = inputParts[1];
                            string userAuthes = inputParts[2];

                            if (!core.db.HaveUser(userId))
                            {
                                resultStr = $"Can't set authes, user [{userId}] not exists.";
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                            }
                            else if (core.db.SetUserAuthes(userId, userAuthes) > 0)
                            {
                                resultStr = $"Authes of User [{userId}] changed.";
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                            }
                            else
                            {
                                resultStr = $"Can't set user authes.";
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                            }
                        }
                        break;
                    }
                case CmdTypes.SetSuppliesPerPage:
                    {

                        //SPP {count}
                        if (inputParts.Length < 2)
                        {
                            resultStr = "Parameters must be {count}.";
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                        }
                        else
                        {
                            int count = SimpleValueHelper.TryGetInt(inputParts[1]);
                            if (count <= 0)
                            {
                                resultStr = "Count must be greater than 0.";
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                            }
                            else if (count > 200)
                            {
                                resultStr = "Greater than 200, not practical.";
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                            }
                            else
                            {
                                core.settings.MaxSuppliesPerPage = count;
                                core.settings.Save();

                                resultStr = $"New value[{count}] has been set.";
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                            }
                        }
                        break;
                    }
                case CmdTypes.CPUUsage:
                    {
                        //ignoreInput = true;
                        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                        {
                            resultStr = _GetWindowsCPUUsage();
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                        }
                        else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
                        {
                            resultStr = _GetLinuxTop();
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                        }
                        else
                        {
                            resultStr = $"Not supported OS: {RuntimeInformation.OSArchitecture}, {RuntimeInformation.OSDescription}";
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                        }
                        //ignoreInput = false;
                        break;
                    }
                case CmdTypes.MemUsage:
                    {
                        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                        {
                            resultStr = _GetWindowsMemUsage();
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                        }
                        else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
                        {
                            resultStr = _GetLinuxTop();
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                        }
                        else
                        {
                            resultStr = $"Not supported OS: {RuntimeInformation.OSArchitecture}, {RuntimeInformation.OSDescription}";
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                        }

                        break;
                    }
                case CmdTypes.DiskUsage:
                    {
                        SimpleStringHelper.TableFormater tf = new SimpleStringHelper.TableFormater()
                        {
                            TableBorderLineStyle = SimpleStringHelper.TableFormater.TableBorderStyles.None,
                            TableHeaderLineStyle = SimpleStringHelper.TableFormater.TableBorderStyles.None,
                            TableDataRowLineStyle = SimpleStringHelper.TableFormater.TableBorderStyles.None,
                            ColumnHeaders = new List<string>()
                            { " Volumn name", " Ready", " Total size", " Free space", " Used(%)", " Server using" },
                            ColumnFormats = new List<SimpleStringHelper.TableFormater.CellFormats>()
                            {
                                SimpleStringHelper.TableFormater.CellFormats.AlignLeft,
                                SimpleStringHelper.TableFormater.CellFormats.AlignCenter,
                                SimpleStringHelper.TableFormater.CellFormats.AlignRight,
                                SimpleStringHelper.TableFormater.CellFormats.AlignRight,
                                SimpleStringHelper.TableFormater.CellFormats.AlignRight,
                                SimpleStringHelper.TableFormater.CellFormats.AlignCenter,
                            },
                            ColumnWidthes = new List<int>()
                            { 0, 0, 0, 0, 0, 14, },
                        };
                        string appDir = AppDomain.CurrentDomain.BaseDirectory;
                        List<DriveInfo> sortedDIList = new List<DriveInfo>();
                        sortedDIList.AddRange(DriveInfo.GetDrives());
                        sortedDIList.Sort((a, b) => a.Name.CompareTo(b.Name));
                        for (int i = sortedDIList.Count - 1; i > 0; i--)
                        {
                            if (sortedDIList[i].Name == sortedDIList[i - 1].Name)
                                sortedDIList.RemoveAt(i);
                        }
                        foreach (DriveInfo drive in sortedDIList)
                        {
                            if (drive.IsReady)
                            {
                                if (drive.TotalSize == 0)
                                {
                                    tf.AddRow(
                                        " " + drive.Name,
                                        "Y",
                                        "0  B",
                                        "--",
                                        "--",
                                        (appDir == drive.RootDirectory.FullName
                                            || appDir.StartsWith(drive.RootDirectory.FullName)) ?
                                            "Y" : "-");
                                }
                                else
                                {
                                    tf.AddRow(
                                        " " + drive.Name,
                                        "Y",
                                        SimpleStringHelper.UnitsOfMeasure.GetShortString(
                                            drive.TotalSize, "B", 1024, 2, true),
                                        SimpleStringHelper.UnitsOfMeasure.GetShortString(
                                            drive.AvailableFreeSpace, "B", 1024, 2, true),
                                        " " + (((double)drive.TotalSize - drive.AvailableFreeSpace) / drive.TotalSize).ToString("P2"),
                                        (appDir == drive.RootDirectory.FullName
                                            || appDir.StartsWith(drive.RootDirectory.FullName)) ?
                                            "Y" : "-");
                                }
                            }
                            else
                                tf.AddRow(
                                    " " + drive.Name,
                                    "--",
                                    "--",
                                    "--",
                                    "--",
                                    "--");
                        }
                        resultStr = Environment.NewLine + tf.ToFullString();
                        _CmdResult_AppendLine(resultStrAll, resultStr);
                        core.ShowInfoNLog(resultStr);
                        break;
                    }

                case CmdTypes.DBExport:
                    {
                        if (inputParts.Length < 3)
                        {
                            resultStr = "Parameters least be {startTime} {endTime}.";
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                        }
                        else
                        {
                            DateTime startTime = SimpleValueHelper.TryGetDate(inputParts[1]);
                            if (startTime == DateTime.MinValue)
                            {
                                resultStr = $"StartTime [{inputParts[1]}] is invalid.";
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                                break;
                            }
                            DateTime endTime = SimpleValueHelper.TryGetDate(inputParts[2]);
                            if (endTime == DateTime.MinValue)
                            {
                                resultStr = $"EndTime [{inputParts[2]}] is invalid.";
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                                break;
                            }
                            bool clean = false;
                            if (inputParts.Length > 3 && inputParts[3] == "clean")
                                clean = true;

                            string package = SimpleStringHelper.ToHexString(DateTime.Now.Ticks);

                            try
                            {
                                int counterSupplyRecs, counterSignOffRecs, counterFileRecs, counterFiles;
                                core.db.ExportProductive(package, startTime, endTime, clean,
                                    out counterSupplyRecs, out counterSignOffRecs, out counterFileRecs, out counterFiles);
                                resultStr = $"Export complete, check package [{package}]." + Environment.NewLine
                                    + (clean ? "Move data: " : "Copy data: ") + $"{counterSupplyRecs} supply-records, {counterSignOffRecs} sigh-off-records, {counterFileRecs} file-records, {counterFiles} files.";
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                            }
                            catch (Exception err)
                            {
                                resultStr = "Failed to export Productive DB-data:" + Environment.NewLine
                                    + err.ToString();
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                            }

                        }

                        break;
                    }
                case CmdTypes.DBImport:
                    {
                        if (inputParts.Length < 2)
                        {
                            resultStr = "Parameters must be {packageName}.";
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                        }
                        else
                        {
                            string packageName = inputParts[1];
                            string fromFile = Path.Combine(core.fileIO.DBExportDir, packageName + ".csv");
                            if (!File.Exists(fromFile))
                            {
                                resultStr = $"CSV file [{inputParts[1]}] is not exist.";
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                                break;
                            }

                            try
                            {
                                int counterSupplyRecs, counterSignOffRecs, counterFileRecs, counterFiles;
                                core.db.ImportProductive(packageName,
                                    out counterSupplyRecs, out counterSignOffRecs, out counterFileRecs, out counterFiles);
                                resultStr = $"Import complete." + Environment.NewLine
                                    + $"Import data: {counterSupplyRecs} supply-records, {counterSignOffRecs} sigh-off-records, {counterFileRecs} file-records, {counterFiles} files.";
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                            }
                            catch (Exception err)
                            {
                                resultStr = "Failed to import Productive DB-data:" + Environment.NewLine
                                    + err.ToString();
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                            }


                        }

                        break;
                    }
                case CmdTypes.DBClean:
                    {
                        if (inputParts.Length < 3)
                        {
                            resultStr = "Parameters must be {startTime} {endTime}.";
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            core.ShowInfoNLog(resultStr);
                        }
                        else
                        {
                            DateTime startTime = SimpleValueHelper.TryGetDate(inputParts[1]);
                            if (startTime == DateTime.MinValue)
                            {
                                resultStr = $"StartTime [{inputParts[1]}] is invalid.";
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                                break;
                            }
                            DateTime endTime = SimpleValueHelper.TryGetDate(inputParts[2]);
                            if (endTime == DateTime.MinValue)
                            {
                                resultStr = $"EndTime [{inputParts[2]}] is invalid.";
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                                break;
                            }

                            try
                            {
                                int counterSupplyRecs, counterSignOffRecs, counterFileRecs, counterFiles;
                                core.db.CleanProductive(startTime, endTime,
                                    out counterSupplyRecs, out counterSignOffRecs, out counterFileRecs, out counterFiles);
                                resultStr = $"Clean complete." + Environment.NewLine
                                    + $"Remove data: {counterSupplyRecs} supply-records, {counterSignOffRecs} sigh-off-records, {counterFileRecs} file-records, {counterFiles} files.";
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                            }
                            catch (Exception err)
                            {
                                resultStr = "Failed to clean Productive DB-data:" + Environment.NewLine
                                    + err.ToString();
                                _CmdResult_AppendLine(resultStrAll, resultStr);
                                core.ShowInfoNLog(resultStr);
                            }
                        }

                        break;
                    }

                case CmdTypes.Testing:
                    {
                        string appDir = AppDomain.CurrentDomain.BaseDirectory;
                        string driveName = appDir.Substring(0, 1);
                        DriveInfo di = new DriveInfo(driveName);
                        core.ShowInfoNLog($"app dir[{appDir}] in drive[{driveName}], total size [{di.TotalSize}], free [{di.AvailableFreeSpace}]");



                        break;
                    }
            }
            if (client != null && !isPrintHelp)
            {
                DataServerResponse dsResponse = new DataServerResponse(Flags.Types.ConsoleOut)
                { Console_ResultOut = resultStrAll.ToString(), };

                core.SendResponse(client, dsResponse);
            }
        }
        private string _GetLinuxTop()
        {
            StringBuilder result = new StringBuilder();
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo("top", " -b -n 1") { RedirectStandardOutput = true };
                Process proc = new Process();
                proc.StartInfo = psi;
                proc.Start();

                if (proc == null)
                {
                    _CmdResult_AppendLine(result, "Failed to exec shell \"top\".");
                }
                else
                {
                    using (var sr = proc.StandardOutput)
                    {
                        DateTime procStartTime = proc.StartTime;
                        while (!sr.EndOfStream)
                        {
                            _CmdResult_AppendLine(result, sr.ReadLine());
                        }


                        if (!proc.HasExited)
                        {
                            proc.Kill();
                            proc.WaitForExit();
                        }
                        _CmdResult_AppendLine(result, $"Total execute time :{(proc.ExitTime - procStartTime).TotalMilliseconds} ms");
                        _CmdResult_AppendLine(result, $"Exited Code ： {proc.ExitCode}");
                    }
                }
            }
            catch (Exception err)
            {
                _CmdResult_AppendLine(result, "Failed to exec \"Top\" using Shell.");
                _CmdResult_AppendLine(result, err.ToString());
            }
            return result.ToString();
        }
        private string _GetWindowsCPUUsage()
        {
            ProcessStartInfo info = new ProcessStartInfo("wmic");
            info.Arguments = "CPU get Name,LoadPercentage /Value";
            info.RedirectStandardOutput = true;
            string output = "";
            using (var process = Process.Start(info))
            {
                output = process.StandardOutput.ReadToEnd();
            }
            string[] cpuLines = output.Trim().Split("\n"); ;

            float CpuUse = float.Parse(cpuLines[0].Split("=", StringSplitOptions.RemoveEmptyEntries)[1]);
            string CpuName = cpuLines[1].Split("=", StringSplitOptions.RemoveEmptyEntries)[1];

            return $"{CpuName}{Environment.NewLine}Total usage: {(CpuUse / 100).ToString("P0")}";
        }
        private string _GetWindowsMemUsage()
        {
            ProcessStartInfo info = new ProcessStartInfo("wmic");
            info.Arguments = "OS get FreePhysicalMemory,TotalVisibleMemorySize /Value";
            info.RedirectStandardOutput = true;
            string output = "";
            using (var process = Process.Start(info))
            {
                output = process.StandardOutput.ReadToEnd();
            }
            string[] memLines = output.Trim().Split("\n"); ;

            long freeMemory = long.Parse(memLines[0].Split("=", StringSplitOptions.RemoveEmptyEntries)[1]);
            long totalMemory = long.Parse(memLines[1].Split("=", StringSplitOptions.RemoveEmptyEntries)[1]);
            long usedMemory = totalMemory - freeMemory;

            return $"Total mem { SimpleStringHelper.UnitsOfMeasure.GetShortString(totalMemory, "B", 1024, 2, true)}, used {SimpleStringHelper.UnitsOfMeasure.GetShortString(usedMemory, "B", 1024, 2, true)}, used in {((double)usedMemory / totalMemory).ToString("P2")}";
        }
        private void _CmdResult_AppendLine(StringBuilder strBdr, string msg)
        {
            if (strBdr == null)
                return;
            if (strBdr.Length > 0)
                strBdr.Append(Environment.NewLine);
            strBdr.Append(msg);
        }

        private Dictionary<string, string> _HelpDIct = new Dictionary<string, string>();
        public Dictionary<string, string> HelpDIct
        { private set; get; }
        private void PrintHelp(SocketHelper.SocketTcpServer.ConnectedClient client = null)
        {
            if (_HelpDIct.Keys.Count == 0)
            {
                // init help dict
                _HelpDIct.Add("help", "help [cmd1] [cmd2]...        Show usage and effects of all commands, or given commands.");
                _HelpDIct.Add("commands", "commands [cmd1] [cmd2]...    Show usage and effects of all commands, or given commands.");
                _HelpDIct.Add("cmds", "cmds [cmd1] [cmd2]...        Show usage and effects of all commands, or given commands.");

                _HelpDIct.Add("clients", "clients [c1] [c2]...         Show info of all clients, or given clients.");
                _HelpDIct.Add("clientslist", "clientsList [c1] [c2]...     Show info of all clients, or given clients.");
                _HelpDIct.Add("clientsinfo", "clientsInfo [c1] [c2]...     Show info of all clients, or given clients.");

                _HelpDIct.Add("blocked", "blocked          Show info of all blocked clients.");
                _HelpDIct.Add("blockedinfo", "blockedInfo      Show info of all blocked clients.");
                _HelpDIct.Add("blockedlist", "blockedList      Show info of all blocked clients.");

                _HelpDIct.Add("kick", "kick {client}            Force a client to disconnect.");
                _HelpDIct.Add("kill", "kill {client}            Force a client to disconnect.");
                _HelpDIct.Add("disconnect", "disconnect {client}      Force a client to disconnect.");
                _HelpDIct.Add("kickall", "kickall -confirm         Force all clients to disconnect.");
                _HelpDIct.Add("killall", "killall -confirm         Force all clients to disconnect.");

                _HelpDIct.Add("removeblock", "removeBlock {remotePoint}     Cancel the block to a connection.");
                _HelpDIct.Add("deleteblock", "deleteBlock {remotePoint}     Cancel the block to a connection.");
                _HelpDIct.Add("delblock", "delBlock {remotePoint}        Cancel the block to a connection.");
                _HelpDIct.Add("unblockall", "unBlockAll -confirm           Cancel all blocks.");

                _HelpDIct.Add("message", "message [c1] [c2]...{\"msg\"}      Send message to all clients, or given clients; Cant use fuzzy client name.");
                _HelpDIct.Add("msg", "msg [c1] [c2]...{\"msg\"}          Send message to all clients, or given clients; Cant use fuzzy client name.");
                _HelpDIct.Add("sendmessage", "sendmessage [c1] [c2]...{\"msg\"}  Send message to all clients, or given clients; Cant use fuzzy client name.");
                _HelpDIct.Add("sendmsg", "sendmsg [c1] [c2]...{\"msg\"}      Send message to all clients, or given clients; Cant use fuzzy client name.");

                _HelpDIct.Add("resetpassword", "resetpassword {client} {newPwd}  Initialize login password of a client.");
                _HelpDIct.Add("resetpwd", "resetpwd {client} {newPwd}       Initialize login password of a client.");
                _HelpDIct.Add("repassword", "repassword {client} {newPwd}     Initialize login password of a client.");
                _HelpDIct.Add("repwd", "repwd {client} {newPwd}          Initialize login password of a client.");

                _HelpDIct.Add("ip", "ip              Show listening ip of this server.");
                _HelpDIct.Add("listeningip", "listeningIp     Show listening ip of this server.");
                _HelpDIct.Add("listening", "listening       Show listening ip of this server.");

                _HelpDIct.Add("cpuusage", "cpuUsage          Show host CPU total performance within 10 seconds.");
                _HelpDIct.Add("memusage", "memUsage          Show host Memory usage.");
                _HelpDIct.Add("diskusage", "diskUsage         Show host disk(partitions) usage.");

                _HelpDIct.Add("close", "close         Shutdown server!");
                _HelpDIct.Add("exit", "exit          Shutdown server!");
                _HelpDIct.Add("shutdown", "shutdown      Shutdown server!");

                StringBuilder strBdr = new StringBuilder();
                strBdr.Append("addUser {ID} {Name} {Password} {Authes} [Sex] [Unit]    Add a new user into user data base!" + Environment.NewLine);
                strBdr.Append("        {ID}       the empno of this user;" + Environment.NewLine);
                strBdr.Append("        {Name}     as said, the name of this user;" + Environment.NewLine);
                strBdr.Append("        {Password} the init pwd, tell user immediately;" + Environment.NewLine);
                strBdr.Append("        {Authes}   it's complicated, type \"help Authes\" for details;" + Environment.NewLine);
                strBdr.Append("        [Sex]      0-female, 1-male, 2-Diphallia, 3-both, 4-unknown;" + Environment.NewLine);
                strBdr.Append("        [Unit]     if you don't know the unit-code, leave it;");
                _HelpDIct.Add("adduser", strBdr.ToString());
                _HelpDIct.Add("checkuser", "checkUser {ID}    Give details of the user.");

                strBdr.Clear();
                strBdr.Append("About Authorities, it's a string by each char representat a specific function;" + Environment.NewLine);
                strBdr.Append("If the char is '1', then it's ON, otherwise, OFF;" + Environment.NewLine);
                strBdr.Append("From first chat to 9th char(for now), they represent as:" + Environment.NewLine);
                strBdr.Append("    1st - whether can login;" + Environment.NewLine);
                strBdr.Append("    2nd - whether can query supplies;" + Environment.NewLine);
                strBdr.Append("    3rd - whether can download proof files;" + Environment.NewLine);
                strBdr.Append("    4th - whether can maintain supplies;" + Environment.NewLine);
                strBdr.Append("    5th - whether can upload proof files;" + Environment.NewLine);
                strBdr.Append("    6th - whether can delete proof files;" + Environment.NewLine);
                strBdr.Append("    7th - whether can query sign-offs;" + Environment.NewLine);
                strBdr.Append("    8th - whether can maintain sign-offs;" + Environment.NewLine);
                strBdr.Append("    9th - whether can use console-client;" + Environment.NewLine);
                strBdr.Append("    10th- whether can re-upload sign-off templete xls file;" + Environment.NewLine);
                strBdr.Append("    11th- whether can download(& fill) sign-off templete xls file;" + Environment.NewLine);
                strBdr.Append("    12th- whether can use UFT to manage server(app) files;" + Environment.NewLine);
                strBdr.Append("    13th- whether can export or import productive data;");
                _HelpDIct.Add("-authes", strBdr.ToString());

                _HelpDIct.Add("setsuppliesperpage", "setSuppliesPerPage {count}    Set the supply entrys give to client per page.");
                _HelpDIct.Add("suppliesperpage", "suppliesPerPage {count}       Set the supply entrys give to client per page.");
                _HelpDIct.Add("spp", "SPP {count}                   Set the supply entrys give to client per page.");

                strBdr.Clear();
                strBdr.Append(Environment.NewLine);
                strBdr.Append("              {ID}       the empno of this user;" + Environment.NewLine);
                strBdr.Append("              {Authes}   it's complicated, type \"help Authes\" for details;");
                _HelpDIct.Add("setuserauthes", "setUserAuthes {UserID} {Authes}    Set user authorities." + strBdr.ToString());

                strBdr.Clear();
                strBdr.Append(Environment.NewLine);
                strBdr.Append("                                with [clean] it will clean db-data after export, and move user files");
                _HelpDIct.Add("dbexport", "DBExport {startTime} {endTime} [clean]   Generate a CSV file contains all productive DB-data durn given time, and copy user files." + strBdr.ToString());
                _HelpDIct.Add("dbimport", "DBImport {packageName}                   Insert or update all productive data using CSV file(byName).");
                _HelpDIct.Add("dbclean", "DBClean {startTime} {endTime}            Delete all productive DB-data durn given time, then vacuum the DB-files.");
                _HelpDIct.Add("uft", "UFT                                      Universal File Tranfer!");
            }

            string resultStr;
            StringBuilder resultStrAll = null;
            if (client != null)
                resultStrAll = new StringBuilder();
            if (inputParts.Length == 1)
            {
                // show all help
                foreach (string k in _HelpDIct.Keys)
                {
                    if (k.StartsWith("-"))
                        continue;
                    resultStr = _HelpDIct[k];
                    _CmdResult_AppendLine(resultStrAll, resultStr);
                    Console.WriteLine(resultStr);
                }
                _CmdResult_AppendLine(resultStrAll, Environment.NewLine);
                Console.WriteLine("");
            }
            else
            {
                // show some help
                bool printed, totalPrinted = false;
                string iKey, searchTx;
                for (int i = 1, iv = inputParts.Length; i < iv; i++)
                {
                    printed = false;

                    foreach (KeyValuePair<string, string> kvP in _HelpDIct)
                    {
                        searchTx = "*" + inputParts[i] + "*";
                        iKey = kvP.Key.StartsWith("-") ? kvP.Key.Substring(1) : kvP.Key;
                        if (SimpleStringHelper.CheckMatch_starNQues(searchTx, iKey)
                            || SimpleStringHelper.CheckMatch_starNQues(searchTx, kvP.Value))
                        {
                            resultStr = _HelpDIct[kvP.Key];
                            _CmdResult_AppendLine(resultStrAll, resultStr);
                            Console.WriteLine(resultStr);
                            printed = true;
                            totalPrinted = true;
                        }
                    }
                    if (printed)
                    {
                        _CmdResult_AppendLine(resultStrAll, Environment.NewLine);
                        Console.WriteLine("");
                    }
                }
                if (!totalPrinted)
                {
                    resultStr = "Given commands are not found.";
                    _CmdResult_AppendLine(resultStrAll, resultStr);
                    Console.WriteLine(resultStr);
                }
            }
            if (client != null)
            {
                DataServerResponse dsResponse = new DataServerResponse(Flags.Types.ConsoleOut)
                { Console_ResultOut = resultStrAll.ToString(), };
                core.SendResponse(client, dsResponse);
            }
        }
    }
}
