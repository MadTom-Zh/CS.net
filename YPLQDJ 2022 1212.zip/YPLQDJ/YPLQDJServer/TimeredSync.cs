﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace MadTomDev.WWWs
{            
    class TimeredSync
    {
        private TimeredSync() { }
        private static TimeredSync instance = null;
        public static TimeredSync GetInstance()
        {
            if (instance == null)
            {
                instance = new TimeredSync();
            }
            return instance;
        }

        public bool IsSyncing { private set; get; }


        public void SyncNow()
        {
            ThreadPool.QueueUserWorkItem(new WaitCallback(_Sync));
        }
        private void _Sync(object state)
        {
            if (IsSyncing)
                throw new Exception("Server is syncing, can't sync repeately.");

            IsSyncing = true;





            IsSyncing = false;
        }
    }
}
