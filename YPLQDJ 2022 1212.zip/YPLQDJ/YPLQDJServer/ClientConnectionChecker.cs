﻿using MadTomDev.CommonClasses;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace MadTomDev.WWWs
{
    class ClientConnectionChecker
    {
        public ServerCore core;
        public ClientConnectionChecker(ServerCore core)
        {
            this.core = core;
            //settings.SessionMaxLoginFaildCount = 5;
            //settings.SessionMaxRefuseTimeSpan = new TimeSpan(1, 0, 0);  // one hour
        }

        public class ConnectionInfo
        {
            public string IPAddressString;
            public List<DateTime> connectTimeList = new List<DateTime>();
            public DateTime lockTime = DateTime.MinValue;
            public int loginFailedCount = 0;

            public bool IsLocked { get => lockTime > DateTime.MinValue; }
            public bool IsNotLockMsged = true;
        }
        private string GetIpStr(EndPoint endPoint)
        {
            string result = endPoint.ToString();
            result = result.Substring(0, result.LastIndexOf(':'));
            return result;
        }
        public List<ConnectionInfo> connectionInfoList = new List<ConnectionInfo>();

        public enum Results
        { First, Retry, Refuse }
        public Results CheckNRegClintConnection(Socket clientSocket, out string resultMsg)
        {
            resultMsg = null;

            string clientIpStr = GetIpStr(clientSocket.RemoteEndPoint);
            ConnectionInfo curSD
                = connectionInfoList.Where(ci =>
                    ci.IPAddressString == clientIpStr)
                .FirstOrDefault();

            if (curSD == null)
            {
                // new entry
                ConnectionInfo newConn = new ConnectionInfo()
                {
                    IPAddressString = clientIpStr,
                };
                newConn.connectTimeList.Add(DateTime.Now);
                connectionInfoList.Add(newConn);
                return Results.First;
            }

            StringBuilder resBdr = new StringBuilder();
            if (curSD.IsLocked)
            {
                TimeSpan lockTimeDur = DateTime.Now - curSD.lockTime;
                if (lockTimeDur < core.settings.SessionMaxRefuseTimeSpan)
                {
                    if (curSD.IsNotLockMsged)
                    {
                        resBdr.Clear();
                        resBdr.Append($"Client [{clientIpStr}] login failed over {core.settings.SessionMaxLoginFaildCount} times ");
                        resBdr.Append($"within {core.settings.SessionMaxLoginFaildWithin.TotalSeconds} seconds, ");
                        resBdr.Append($"release in {(core.settings.SessionMaxRefuseTimeSpan - lockTimeDur).TotalSeconds} seconds.");
                        resultMsg = resBdr.ToString();
                        curSD.IsNotLockMsged = false;
                    }
                    return Results.Refuse;
                }
                else
                {
                    connectionInfoList.Remove(curSD);
                    return CheckNRegClintConnection(clientSocket, out resultMsg);
                }
            }



            #region clear out dated entries
            TimeSpan connectTimeDur;
            DateTime oldestTime;
            while (curSD.connectTimeList.Count > 0)
            {
                oldestTime = curSD.connectTimeList.Last();
                connectTimeDur = DateTime.Now - oldestTime;
                if (connectTimeDur >= core.settings.SessionMaxLoginFaildWithin)
                    curSD.connectTimeList.Remove(oldestTime);
                else
                    break;
            }
            if (curSD.connectTimeList.Count == 0)
            {
                connectionInfoList.Remove(curSD);
                return CheckNRegClintConnection(clientSocket, out resultMsg);
            }
            #endregion

            // re connect too many times, refuse
            if (curSD.connectTimeList.Count + curSD.loginFailedCount >= core.settings.SessionMaxLoginFaildCount)
            {
                curSD.lockTime = DateTime.Now;
                resBdr.Clear();
                resBdr.Append($"Client [{clientIpStr}] had invalid connections and logins over {core.settings.SessionMaxLoginFaildCount} times ");
                resBdr.Append($"within {core.settings.SessionMaxLoginFaildWithin.TotalSeconds} seconds, ");
                resBdr.Append($"release in {core.settings.SessionMaxRefuseTimeSpan.TotalSeconds} seconds.");
                resultMsg = resBdr.ToString();
                curSD.IsNotLockMsged = false;
                return Results.Refuse;
            }

            // Retry
            curSD.connectTimeList.Add(DateTime.Now);
            resBdr.Clear();
            resBdr.Append($"Client [{clientIpStr}] retry connect {curSD.connectTimeList.Count} times,");
            resBdr.Append($"within {core.settings.SessionMaxLoginFaildWithin.TotalSeconds} seconds.");
            resultMsg = resBdr.ToString();
            return Results.Retry;
        }

        internal bool UnReg(Socket clientSocket)
        {
            bool result = false;
            string ip = GetIpStr(clientSocket.RemoteEndPoint);
            foreach (ConnectionInfo ci
                in connectionInfoList.Where(
                    e => e.IPAddressString == ip)
                .ToArray())
            {
                connectionInfoList.Remove(ci);
                result = true;
            }
            return result;
        }
        internal bool UnReg(string ipAddress)
        {
            bool result = false;
            foreach (ConnectionInfo ci
                in connectionInfoList.Where(
                    e => e.IPAddressString == ipAddress)
                .ToArray())
            {
                connectionInfoList.Remove(ci);
                result = true;
            }
            return result;
        }

        internal void RegLoginFail(Socket clientSocket, out bool kick)
        {
            kick = false;
            string ip = GetIpStr(clientSocket.RemoteEndPoint);
            ConnectionInfo ci
                = connectionInfoList.Where(
                    e => e.IPAddressString == ip)
                    .FirstOrDefault();

            if (ci == null)
            {
                ConnectionInfo newConn = new ConnectionInfo()
                {
                    IPAddressString = ip,
                    loginFailedCount = 1,
                };
                newConn.connectTimeList.Add(DateTime.Now);
                connectionInfoList.Add(newConn);
            }
            else
            {
                ci.loginFailedCount++;
                if (ci.loginFailedCount >= core.settings.SessionMaxLoginFaildCount)
                {
                    ci.lockTime = DateTime.Now;
                    kick = true;
                }
            }
        }

        internal string ToInfoString()
        {
            string result;
            if (connectionInfoList.Count > 0)
            {
                SimpleStringHelper.TableFormater tf = new SimpleStringHelper.TableFormater();
                tf.TableBorderLineStyle = SimpleStringHelper.TableFormater.TableBorderStyles.None;
                tf.TableHeaderLineStyle = SimpleStringHelper.TableFormater.TableBorderStyles.None;
                tf.TableDataRowLineStyle = SimpleStringHelper.TableFormater.TableBorderStyles.None;
                tf.AddColumnHeader("Connection");
                tf.AddColumnHeader("Lock@");
                tf.AddColumnHeader("ReleaseIn");
                foreach (ConnectionInfo ci in connectionInfoList.Where(i => i.IsLocked))
                {
                    tf.AddRow(new string[] 
                    {
                        ci.IPAddressString,
                        ci.lockTime.ToString(),
                        (core.settings.SessionMaxRefuseTimeSpan - (DateTime.Now - ci.lockTime)).TotalSeconds.ToString("0") 
                            + " seconds",
                    });
                }
                tf.AutoSetColumnWidthes();
                result = Environment.NewLine + tf.ToFullString();
            }
            else
            {
                result = "Block list empty.";
            }
            return result;
        }
    }
}
