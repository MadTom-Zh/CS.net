﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MadTomDev.CommonClasses;
using MadTomDev.Data;
using MadTomDev.Math;
using MadTomDev.Network;

namespace MadTomDev.App.YPLQDJ
{
    public class ConsoleCore : IDisposable
    {
        public Logger logger;
        public PasswordProtector pp;
        public SocketHelper.SocketTcpClient socketClient;
        public SettingsTxt settingsTxt;
        public DataTempletes.User LoginUser = null;

        public FormLogin formLogin;
        public FormConsole formConsole;

        public string Encryption_Password { private set; get; }
        public byte Encryption_ConfusionLength { private set; get; } = 13;
        private ConsoleCore()
        {
            string startUpPath = Application.StartupPath;
            logger = new Logger()
            { BaseDir = Path.Combine(startUpPath, "Log"), };

            pp = PasswordProtector.GetInstance(
                Path.Combine(startUpPath, "Encry.cer"),
                "u$kjl!&wZv@%@qw*rNTh$DMBQ$t@D!rX*FOa");

            pp.Password = "this is a fixed password, do not change it.";
            Encryption_Password = pp.Password_forCipher;


            settingsTxt = new SettingsTxt(Path.Combine(startUpPath, "setting.txt"));

            socketClient = new SocketHelper.SocketTcpClient();
            socketClient.ServerConnected += SocketClient_ServerConnected; ;
            socketClient.ServerDataReceived += SocketClient_ServerDataReceived; ;
            socketClient.ServerReceiveError += SocketClient_ServerReceiveError; ;
            socketClient.ServerReceiveTimeout += SocketClient_ServerReceiveTimeout; ;
        }

        #region console
        public void InitFormConsole(FormConsole form)
        {
            formConsole = form;
            formConsole.CallCmd += FormConsole_CallCmd;
        }

        public bool Login_ServerIPV4orIPV6
        {
            get
            {
                bool result;
                if (bool.TryParse(settingsTxt["Login_ServerIPV4orIPV6"], out result))
                    return result;
                result = true;
                settingsTxt["Login_ServerIPV4orIPV6"] = result.ToString();
                return result;
            }
            set
            {
                settingsTxt["Login_ServerIPV4orIPV6"] = value.ToString();
            }
        }
        public string Login_ServerIPV4
        {
            get => settingsTxt["Login_ServerIPV4"];
            set
            {
                settingsTxt["Login_ServerIPV4"] = value;
            }
        }
        public string Login_ServerIPV6
        {
            get => settingsTxt["Login_ServerIPV6"];
            set
            {
                settingsTxt["Login_ServerIPV6"] = value;
            }
        }
        public string Login_ServerPort
        {
            get => settingsTxt["Login_ServerPort"];
            set
            {
                settingsTxt["Login_ServerPort"] = value;
            }
        }
        public string LoginUserID
        {
            get => settingsTxt["LoginUserID"];
            set
            {
                settingsTxt["LoginUserID"] = value;
            }
        }


        private static ConsoleCore instance = null;
        public static ConsoleCore GetInstance()
        {
            if (instance == null)
            {
                instance = new ConsoleCore();
            }
            return instance;
        }

        public void Login(string server, string port, string user, string pwd)
        {
            ConsoleNLog("Connecting to server...");
            try
            {
                Exception err;

                IPAddress ip = IPAddress.Parse(server);
                bool result = socketClient.Connect(
                    ip, int.Parse(port), out err);
                if (err != null)
                {
                    logger.Log(err);
                    formLogin.ShowError(err);

                    return;
                }
                if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                {
                    Login_ServerIPV4orIPV6 = true;
                    Login_ServerIPV4 = server;
                }
                else if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetworkV6)
                {
                    Login_ServerIPV4orIPV6 = false;
                    Login_ServerIPV6 = server;
                }
                else
                {
                }
                Login_ServerPort = port;
                LoginUserID = user;
                settingsTxt.Save();
            }
            catch (Exception err)
            {
                logger.Log(err);
                formLogin.ShowError(err);
                return;
            }

            ConsoleNLog("Login...");
            DataClientRequest newRequest = new DataClientRequest(Flags.Types.RequestLogin)
            { Login_ForceEnter = true, Login_User = user, Login_Password = pwd, };
            SendRequest(newRequest);
        }
        public void ConsoleNLog(string msg)
        {
            logger.Log(msg);
            formConsole.ShowMsg(msg);
        }
        public void ConsoleNLog(Exception err, string additionalMsg = null)
        {
            if (!string.IsNullOrWhiteSpace(additionalMsg))
            {
                err = new Exception(additionalMsg, err);
            }
            logger.Log(err);
            formConsole.ShowMsg(err.ToString());
        }


        private void FormConsole_CallCmd(string cmd)
        {
            DataClientRequest inputCmdRequest = new DataClientRequest(Flags.Types.ConsoleIn)
            { Console_CmdIn = cmd, };
            SendRequest(inputCmdRequest);
        }
        private void SendRequest(DataClientRequest request)
        {
            try
            {
                socketClient.socket.Send(
                    EncryptedGZip.EncryptGZip(
                        request.Data, Encryption_Password, Encryption_ConfusionLength));
            }
            catch (Exception err)
            {
                ConsoleNLog("Failed to send request:" + Environment.NewLine + err.ToString());
            }
        }
        private void Exit()
        {
            formConsole?.Close();
            formLogin.Close();
        }

        #endregion

        #region universal file transfer

        public string UFTGetDir_serverAppDir;
        public string UFTGetDir_serverDirectorySeparator;
        private string _UFTGetDir_baseDir;
        public FormUniversalFileTransfer formUFT = null;
        public void ShowUFTForm(FormConsole caller)
        {
            if (formUFT == null)
            {
                ConsoleNLog("Start UFT.");
                formUFT = new FormUniversalFileTransfer()
                { core = this, };
                formUFT.FormClosed += (s1, e1) =>
                {
                    formUFT = null;
                    ConsoleNLog("UFT closed.");
                };
                formUFT.Show();
            }
            else
            {
                ConsoleNLog("UFT is already running.");
                formUFT.Activate();
            }
        }
        public void UFTGetDir(string baseDir = null)
        {
            ConsoleNLog($"UFTGetDir:[{baseDir}]");
            _UFTGetDir_baseDir = baseDir;
            DataClientRequest inputCmdRequest = new DataClientRequest(Flags.Types.RequestUniversalDir)
            { UniversalDir_BaseDir = baseDir, };
            SendRequest(inputCmdRequest);
        }
        internal void UFTCreateDir(string basePath, string newDirName)
        {
            string newDirFullName = basePath + UFTGetDir_serverDirectorySeparator + newDirName;
            ConsoleNLog($"UFTCreateDir:[{newDirFullName }]");
            DataClientRequest inputCmdRequest = new DataClientRequest(Flags.Types.RequestUniversalCreateDir)
            { UniversalCreateDir_DirFullName = newDirFullName, };
            SendRequest(inputCmdRequest);
        }
        internal void UFTMove(DataTempletes.UniversalFileSystemInfo oriFSI, string newFullName)
        {
            ConsoleNLog($"UFTMove: from [{oriFSI.FullName}] to [{newFullName}]");
            DataClientRequest inputCmdRequest = new DataClientRequest(Flags.Types.RequestUniversalMove)
            { UniversalMove_OriFullName = oriFSI.FullName, UniversalMove_NewFullName = newFullName, };
            SendRequest(inputCmdRequest);
        }
        internal void UFTDelete(List<DataTempletes.UniversalFileSystemInfo> toDelList)
        {
            StringBuilder delMsg = new StringBuilder();
            delMsg.Append($"UFTDelete:");
            foreach (DataTempletes.UniversalFileSystemInfo fsi in toDelList)
            {
                delMsg.Append(Environment.NewLine);
                if (fsi.IsDir)
                    delMsg.Append($"    [D]{fsi.FullName}");
                else
                    delMsg.Append($"    [F]{fsi.FullName}");
            }
            ConsoleNLog(delMsg.ToString());
            DataClientRequest inputCmdRequest = new DataClientRequest(Flags.Types.RequestUniversalDelete)
            { UniversalDelete_FileList = toDelList, };
            SendRequest(inputCmdRequest);
        }


        public bool UFTCancelFlag = false;

        public delegate void UFTDataDownDelegate(
            string fileFullName, long fileLength,
            long position, byte[] data, Exception err);
        public event UFTDataDownDelegate UFTDataDowned;
        internal void UFTDownload(DataTempletes.UniversalFileSystemInfo ufsi, long offset)
        {
            DataClientRequest newRequest = new DataClientRequest(Flags.Types.RequestUniversalDownload)
            {
                UniversalDownload_FileFullName = ufsi.FullName,
                UniversalDownload_Position = offset,
            };
            SendRequest(newRequest);
        }


        public delegate void UFTDataUpDelegate(
            string fileFullName, long startPosition, int writenLength, Exception err);
        public event UFTDataUpDelegate UFTDataUped;
        internal void UFTUpload(string targetFullName, long position, byte[] data, bool isEndPack)
        {
            DataClientRequest newRequest = new DataClientRequest(Flags.Types.RequestUniversalUpload)
            {
                UniversalUpload_FileFullName = targetFullName,
                UniversalUpload_Position = position,
                UniversalUpload_Data = data,
                UniversalUpload_IsEndPack = isEndPack,
            };
            SendRequest(newRequest);
        }

        #endregion


        private void SocketClient_ServerConnected(SocketHelper.SocketTcpClient sender)
        {
            ConsoleNLog($"SocketClient: Connected to server [{sender.socket.RemoteEndPoint}]");
        }
        private void SocketClient_ServerReceiveTimeout(SocketHelper.SocketTcpClient sender)
        {
            ConsoleNLog($"SocketClient: Receive timeout.");
        }
        private void SocketClient_ServerReceiveError(SocketHelper.SocketTcpClient sender, Exception err)
        {
            if (formLogin.Visible)
                formLogin.ShowError(err);
            ConsoleNLog(err, "SocketClient ServerReceiveError");
        }

        private void SocketClient_ServerDataReceived(SocketHelper.SocketTcpClient sender, byte[] data)
        {
            ConsoleNLog($"Receive data from server, [{data.Length}] bytes.");
            data = EncryptedGZip.UnGZipDecrypt(data, Encryption_Password, Encryption_ConfusionLength);

            Flags.Types[] outTypes;
            object[] dataArray = DataReceiver.GetDataInstances(data, out outTypes);
            object dataObj;
            DataServerResponse dsResponse;
            string msg;
            for (int i = 0, iv = outTypes.Length; i < iv; i++)
            {
                dataObj = dataArray[i];
                switch (outTypes[i])
                {
                    default:
                    case Flags.Types.Unknow:
                        {
                            msg = "Unknow data: " + SimpleStringHelper.ToHexString(data);
                            ConsoleNLog(msg);
                            break;
                        }
                    case Flags.Types.Message:
                        {
                            DataMessage dm = (DataMessage)dataObj;
                            msg = "Server message: " + ChangeNewLine2EnvirmentNewLine(dm.Message);
                            ConsoleNLog(msg);
                            break;
                        }
                    case Flags.Types.ResponseLogin:
                        {
                            dsResponse = (DataServerResponse)dataObj;
                            if (dsResponse.Login_Result == true)
                            {
                                LoginUser = dsResponse.Login_UserData;
                                if (!LoginUser.Authorities.Login)
                                {
                                    msg = "You were forbidden to login.";
                                    ConsoleNLog(msg);
                                }
                                else if (!LoginUser.Authorities.Console)
                                {
                                    msg = "You were not allowed to use console.";
                                    ConsoleNLog(msg);
                                }
                                else
                                {
                                    logger.Log("Login success.");
                                    formLogin.DialogResult = DialogResult.OK;
                                    ConsoleNLog($"Login success, welcome user: {LoginUserID}");
                                }
                            }
                            else
                            {
                                msg = "Login failed.";
                                ConsoleNLog(msg);
                            }
                            break;
                        }
                    case Flags.Types.ConsoleOut:
                        {
                            dsResponse = (DataServerResponse)dataObj;
                            string msgOut = ChangeNewLine2EnvirmentNewLine(dsResponse.Console_ResultOut);
                            ConsoleNLog(msgOut);
                            break;
                        }

                    case Flags.Types.ResponseUniversalDir:
                        {
                            dsResponse = (DataServerResponse)dataObj;
                            if (dsResponse.UniversalDir_Error != null)
                            {
                                ConsoleNLog(dsResponse.UniversalDir_Error);
                            }
                            else
                            {
                                ConsoleNLog("UFTGetDir: Set dir info");
                                if (_UFTGetDir_baseDir == null)
                                {
                                    UFTGetDir_serverAppDir = dsResponse.UniversalDir_BaseDir;
                                    while (UFTGetDir_serverAppDir.EndsWith("\\"))
                                        UFTGetDir_serverAppDir = UFTGetDir_serverAppDir.Substring(0, UFTGetDir_serverAppDir.Length - 1);
                                    while (UFTGetDir_serverAppDir.EndsWith("/"))
                                        UFTGetDir_serverAppDir = UFTGetDir_serverAppDir.Substring(0, UFTGetDir_serverAppDir.Length - 1);
                                }

                                // check https://docs.microsoft.com/zh-cn/dotnet/api/system.io.path.directoryseparatorchar?view=netcore-3.1
                                // Path.DirectorySeparatorChar will auto give the right char with OS
                                // Path.AltDirectorySeparatorChar always give '/'
                                if (UFTGetDir_serverAppDir.Contains("\\"))
                                    UFTGetDir_serverDirectorySeparator = "\\";
                                else
                                    UFTGetDir_serverDirectorySeparator = "/";

                                formUFT.SetDirSubs(
                                    dsResponse.UniversalDir_BaseDir,
                                    dsResponse.UniversalDir_FSList);
                            }
                            break;
                        }
                    case Flags.Types.ResponseUniversalCreateDir:
                        {
                            dsResponse = (DataServerResponse)dataObj;
                            if (dsResponse.UniversalCreateDir_Result == true)
                            {
                                ConsoleNLog("UFTCreateDir: Sucess");
                                formUFT.ReLoadSelectDir(dsResponse.UniversalCreateDir_DirFullName);
                                formUFT.PasteOrDrag_SetCreatedDir(dsResponse.UniversalCreateDir_DirFullName);
                                //formUFT.ShowInfo("成功新建文件夹");
                            }
                            else
                            {
                                ConsoleNLog(dsResponse.UniversalCreateDir_Error, "UFTCreateDir Failed");
                            }
                            break;
                        }
                    case Flags.Types.ResponseUniversalDelete:
                        {
                            dsResponse = (DataServerResponse)dataObj;
                            if (dsResponse.UniversalDelete_Error == null)
                            {
                                ConsoleNLog("UFTDelete: Success");
                                formUFT.ReLoadSelectDir(dsResponse.UniversalDelete_FileList[0].FullName);
                                //formUFT.ShowInfo("成功删除");
                            }
                            else
                            {
                                ConsoleNLog(dsResponse.UniversalDelete_Error, "UFTDelete Failed");
                                if (dsResponse.UniversalDelete_ResultList.Count > 1)
                                {
                                    ConsoleNLog($"成功({dsResponse.UniversalDelete_ResultList.Count - 1})，"
                                        + $"删除失败：{dsResponse.UniversalDelete_Error.Message}");
                                }
                                else
                                {
                                    ConsoleNLog($"成功(0)，"
                                        + $"删除失败：{dsResponse.UniversalDelete_Error.Message}");
                                }
                            }
                            break;
                        }
                    case Flags.Types.ResponseUniversalMove:
                        {
                            dsResponse = (DataServerResponse)dataObj;
                            if (dsResponse.UniversalMove_Result == true)
                            {
                                ConsoleNLog("UFTMove: Success");
                                if (formUFT.PasteOrDrag_blockReloadAfterRename)
                                {
                                    formUFT.ReLoadSelectDir();
                                    //formUFT.ShowInfo("成功重命名");
                                }
                                formUFT.PasteOrDrag_SetMovedFS(dsResponse.UniversalMove_NewFullName);
                            }
                            else
                            {
                                ConsoleNLog(dsResponse.UniversalMove_Error, "UFTMove Failed");
                            }
                            break;
                        }
                    case Flags.Types.ResponseUniversalDownload:
                        {
                            dsResponse = (DataServerResponse)dataObj;
                            UFTDataDowned?.Invoke(
                                dsResponse.UniversalDownload_FileFullName,
                                dsResponse.UniversalDownload_FileLength != null ?
                                    (long)dsResponse.UniversalDownload_FileLength : -1,
                                dsResponse.UniversalDownload_Position != null ?
                                    (long)dsResponse.UniversalDownload_Position : -1,
                                dsResponse.UniversalDownload_Data,
                                dsResponse.UniversalDownload_Error);
                            break;
                        }
                    case Flags.Types.ResponseUniversalUpload:
                        {
                            dsResponse = (DataServerResponse)dataObj;
                            UFTDataUped?.Invoke(
                                dsResponse.UniversalUpload_FileFullName,
                                dsResponse.UniversalUpload_Position != null ?
                                    (long)dsResponse.UniversalUpload_Position : -1,
                                dsResponse.UniversalUpload_DataLength != null ?
                                    (int)dsResponse.UniversalUpload_DataLength : -1,
                                dsResponse.UniversalUpload_Error);
                            break;
                        }
                }
            }
        }



        #region helper
        private string ChangeNewLine2EnvirmentNewLine(string text)
        {
            // check https://docs.microsoft.com/zh-cn/dotnet/api/system.environment.newline?view=netcore-3.1
            string curNewLine = Environment.NewLine;
            if (curNewLine == "\r\n") // non-unix
            {
                if (text.Contains("\n") && !text.Contains(curNewLine))
                {
                    return text.Replace("\n", curNewLine);
                }
            }
            else // "\n" unix
            {
                if (text.Contains("\r\n"))
                {
                    return text.Replace("\r\n", curNewLine);
                }
            }
            return text;
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
