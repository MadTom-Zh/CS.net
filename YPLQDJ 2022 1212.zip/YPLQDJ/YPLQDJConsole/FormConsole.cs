﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadTomDev.App.YPLQDJ
{
    public partial class FormConsole : Form
    {
        public FormConsole()
        {
            InitializeComponent();
        }
        private ConsoleCore core = ConsoleCore.GetInstance();
        private void FormConsole_Shown(object sender, EventArgs e)
        {
            core.InitFormConsole(this);

            FormLogin formLogin = new FormLogin();
            if (formLogin.ShowDialog() != DialogResult.OK)
                Close();
            else
                textBox_input.Focus();
        }


        private delegate void ShowMsgCallbackDelegate(string msg);
        public void ShowMsg(string msg)
        {
            if (InvokeRequired)
            {
                ShowMsgCallbackDelegate callback
                    = new ShowMsgCallbackDelegate(ShowMsg);
                this.Invoke(callback, msg);
            }
            else
            {
                textBox_msg.AppendText(msg);
                textBox_msg.AppendText(Environment.NewLine);
                textBox_input.Enabled = true;
                toolStripStatusLabel_info.Text = "Ready.";
                Update();
                if (isActivated)
                {
                    textBox_input.Text = "";
                    textBox_input.Focus();
                }
            }
        }

        public delegate void CallCmdDelegate(string cmd);
        public event CallCmdDelegate CallCmd;
        private void textBox_input_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true;
                bool sendCmd = false;
                string inputText = textBox_input.Text.Trim();
                textBox_input.Clear();
                if (string.IsNullOrWhiteSpace(inputText))
                {
                    return;
                }
                string inputTextLower = inputText.ToLower();
                if (inputTextLower == "cls")
                {
                    textBox_msg.Clear();
                }
                else if (inputTextLower == "close"
                    || inputTextLower == "exit"
                    || inputTextLower == "shutdown")
                {
                    this.Close();
                }
                else if (inputTextLower == "uft")
                {
                    if (!core.LoginUser.Authorities.ConsoleUFT)
                    {
                        core.ConsoleNLog("You don't have Authorities.ConsoleUFT .");
                    }
                    else
                    {
                        core.ShowUFTForm(this);
                    }
                }
                else if (inputTextLower == "dbexport"
                    || inputTextLower == "dbimport"
                    || inputTextLower == "dbclean"
                    || inputTextLower.StartsWith("dbexport ")
                    || inputTextLower.StartsWith("dbimport ")
                    || inputTextLower.StartsWith("dbclean "))
                {
                    if (!core.LoginUser.Authorities.DBExportImport)
                    {
                        core.ConsoleNLog("You don't have Authorities.ConsoleUFT .");
                    }
                    else
                    {
                        sendCmd = true;
                    }
                }
                else
                {
                    sendCmd = true;
                }
                if (sendCmd)
                {
                    textBox_msg.AppendText(Environment.NewLine + inputText + Environment.NewLine);
                    textBox_input.Enabled = false;
                    toolStripStatusLabel_info.Text = "Comm...";
                    CallCmd?.Invoke(inputText);
                }
                AddCmdHistory(textBox_input.Text.Trim());
            }
            else if (e.KeyCode == Keys.Up)   //////// not working
            {
                if (cmdHistoryIndex < 0)
                    cmdHistoryIndex = cmdHistory.Count - 1;
                else if (cmdHistoryIndex > 0)
                    cmdHistoryIndex--;

                textBox_input.Text = cmdHistory[cmdHistoryIndex];
            }
            else if (e.KeyCode == Keys.Down)   //////// not working
            {
                if (cmdHistoryIndex >= 0)
                    cmdHistoryIndex++;
                if (cmdHistoryIndex >= cmdHistory.Count)
                    cmdHistoryIndex--;

                textBox_input.Text = cmdHistory[cmdHistoryIndex];
            }
        }
        private List<string> cmdHistory = new List<string>();
        private int cmdHistoryIndex = -1;
        private void AddCmdHistory(string cmd)
        {
            cmdHistoryIndex = -1;
            if (cmdHistory.Count > 0
                && cmdHistory[cmdHistory.Count - 1] == cmd)
                return;

            cmdHistory.Add(cmd);
            if (cmdHistory.Count > 10)
                cmdHistory.RemoveAt(0);
        }

        private void textBox_input_KeyUp(object sender, KeyEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox_input.Text))
                textBox_input.Clear();
        }

        private bool isActivated = true;
        private void FormConsole_Activated(object sender, EventArgs e)
        { isActivated = true; }

        private void FormConsole_Deactivate(object sender, EventArgs e)
        { isActivated = false; }
    }
}
