﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MadTomDev.App.YPLQDJ
{
    class UniversalFileStream
    {
        public delegate void ReportProgressDelegate(long cur, long total);
        public static TimeSpan NetTimeout = new TimeSpan(0, 0, 10);
        public delegate void ReportWaitingDelegate(int sec);
        public interface IUFStreamEvents
        {
            event ReportProgressDelegate ReportProgress;
            event ReportWaitingDelegate ReportWaiting;
        }
        public class UploadStream : Stream, IUFStreamEvents
        {
            public override bool CanRead => false;

            public override bool CanSeek => false;

            public override bool CanWrite => true;
            public override long Length => position;
            public long SourceFileLength { private set; get; }

            private long position = 0;
            public override long Position
            {
                get => position;
                set
                {
                    if (value != position)
                        throw new IndexOutOfRangeException("Write-only stream, Position must be equal with Length.");
                }
            }

            private ConsoleCore core;
            private string fileFullName;
            public UploadStream(ConsoleCore core, string fileFullName, long sourceFileLength)
            {
                this.core = core;
                this.fileFullName = fileFullName;
                SourceFileLength = sourceFileLength;
                core.UFTDataUped += Core_UFTDataUped;
            }

            private bool isUploading;

            public event ReportProgressDelegate ReportProgress;
            public event ReportWaitingDelegate ReportWaiting;

            private void Core_UFTDataUped(
                string fileFullName,
                long startPosition, int writenLength,
                Exception err)
            {
                if (cancelFlag)
                    return;
                if (fileFullName != this.fileFullName)
                    return;
                if (err != null)
                    throw new Exception("上传文件时发生错误。", err);
                if (startPosition != position)
                    throw new Exception("上传失败，文件写入位置失去同步。");


                position += writenLength;
                isUploading = false;

            }

            private bool cancelFlag = false;
            public void Cancel()
            {
                cancelFlag = true;
            }
            public override void Write(byte[] buffer, int offset, int count)
            {
                if (cancelFlag)
                    return;
                // get ready data
                if (offset > 0 || count < buffer.Length)
                {
                    byte[] shortBuf = new byte[count];
                    if (offset <= 0)
                    {
                        Array.Copy(buffer, shortBuf, count);
                    }
                    else
                    {
                        for (int ii = 0, i = offset, iv = System.Math.Min(offset + count, buffer.Length);
                            i < iv; i++)
                        {
                            shortBuf[ii++] = buffer[i];
                        }
                    }
                    buffer = shortBuf;
                }
                if (buffer.Length > 0
                    || (position == 0 && buffer.Length == 0))
                {
                    isUploading = true;
                    DateTime netTimeStart = DateTime.Now;
                    int waitingSecs = 0;
                    core.UFTUpload(
                        fileFullName,
                        position,
                        buffer,
                        SourceFileLength <= position + buffer.Length);

                    while (isUploading)
                    {
                        Thread.Sleep(10);
                        if (cancelFlag)
                            return;
                        if ((DateTime.Now - netTimeStart).TotalSeconds > (waitingSecs + 1))
                        {
                            waitingSecs++;
                            if (waitingSecs > 10)
                                throw new TimeoutException($"Timeout uploading file[{fileFullName}].");
                            ReportWaiting?.Invoke(waitingSecs);
                        }
                    }
                }

                ReportProgress?.Invoke(position, SourceFileLength);
                if (buffer.Length == 0)
                    Dispose();
            }
            public bool IsDisposed { private set; get; } = false;
            public new void Dispose()
            {
                if (IsDisposed)
                    return;

                IsDisposed = true;
                base.Dispose();

                core.UFTDataUped -= Core_UFTDataUped;
                this.core = null;
                this.fileFullName = null;
                SourceFileLength = -1;
            }

            #region disabled methods
            public override int Read(byte[] buffer, int offset, int count)
            { throw new InvalidOperationException("Write-only stream, can't read."); }

            public override long Seek(long offset, SeekOrigin origin)
            { throw new InvalidOperationException("Write-only stream, can't seek."); }

            public override void SetLength(long value)
            { throw new InvalidOperationException("Write-only stream, can't set length."); }
            public override void Flush()
            { /* do nothing */ }
            #endregion
        }
        public class DownloadStream : Stream, IUFStreamEvents
        {
            public override bool CanRead => true;

            public override bool CanSeek => false;

            public override bool CanWrite => false;

            public override long Length => remoteFileInfo.Size;

            private long position;
            public override long Position
            {
                get => position;
                set
                {
                    if (value != position)
                        throw new IndexOutOfRangeException("Read-only stream, and can not change Position manually.");
                }
            }

            public bool EoF { private set; get; } = false;
            public bool IsCanceled { private set; get; } = false;

            private ConsoleCore core;
            public DataTempletes.UniversalFileSystemInfo remoteFileInfo;
            public DownloadStream(ConsoleCore core, DataTempletes.UniversalFileSystemInfo ufsi)
            {
                this.core = core;
                this.remoteFileInfo = ufsi;
                core.UFTDataDowned += Core_UFTDataDowned;
            }

            private bool netFileDownedtriger = false;
            private long netFileLength;
            private long netFilePosition;
            private byte[] netFileDataPackage = null;
            private void Core_UFTDataDowned(
                string fileFullName, long fileLength,
                long position, byte[] data,
                Exception err)
            {
                if (fileFullName != remoteFileInfo.FullName)
                    return;
                if (err != null)
                {
                    netFileDownedtriger = true;
                    IsCanceled = true;
                    ReportError?.Invoke(this, new Exception("下载文件时发生错误。", err));
                    return;
                }
                if (position != Position)
                {
                    netFileDownedtriger = true;
                    IsCanceled = true;
                    ReportError?.Invoke(this, new Exception("下载失败，文件读取位置失去同步。"));
                }


                netFileLength = fileLength;
                netFilePosition = position;
                netFileDataPackage = data;
                netFileDownedtriger = true;
            }


            private Queue<byte> netDataBuffer = new Queue<byte>();

            public event ReportProgressDelegate ReportProgress;
            public event ReportWaitingDelegate ReportWaiting;
            public delegate void ReportCancelDelegate(DownloadStream sender);
            public event ReportCancelDelegate ReportCancel;
            public delegate void ReportErrorDelegate(DownloadStream sender, Exception err);
            public event ReportErrorDelegate ReportError;

            public override int Read(byte[] buffer, int offset, int count)
            {
                if (core.UFTCancelFlag)
                {
                    IsCanceled = true;
                }
                if (IsCanceled)
                {
                    ReportCancel?.Invoke(this);
                    if (position >= Length)
                        Dispose();
                    return 0;
                }
                if (EoF)
                {
                    if (position >= Length)
                        Dispose();
                    return 0;
                }

                // get data from server
                DateTime netTimeStart;
                while (netDataBuffer.Count < (offset + count)
                    && !EoF)
                {
                    // download request
                    netTimeStart = DateTime.Now;
                    int waitingSecs = 0;
                    core.UFTDownload(remoteFileInfo, Position);

                    // wait for data receive
                    while (!netFileDownedtriger)
                    {
                        Thread.Sleep(10);
                        if (core.UFTCancelFlag)
                        {
                            IsCanceled = true;
                        }
                        if (IsCanceled)
                        {
                            ReportCancel?.Invoke(this);
                            return 0;
                        }
                        if ((DateTime.Now - netTimeStart).TotalSeconds > (waitingSecs + 1))
                        {
                            waitingSecs++;
                            if (waitingSecs > 30)
                                throw new TimeoutException($"Timeout downloading file[{remoteFileInfo.FullName}].");
                            ReportWaiting?.Invoke(waitingSecs);
                        }
                    }
                    netFileDownedtriger = false;


                    if (netFileDataPackage != null)
                    {
                        lock (netDataBuffer)
                        {
                            foreach (byte b in netFileDataPackage)
                                netDataBuffer.Enqueue(b);
                        }


                        if (netFilePosition + netFileDataPackage.Length
                            >= netFileLength)
                        {
                            EoF = true;
                        }
                    }
                }

                // return data
                int readLength = 0;
                lock (netDataBuffer)
                {
                    int i = 0;
                    for (; i < offset && netDataBuffer.Any(); i++)
                    {
                        netDataBuffer.Dequeue();
                        readLength++;
                    }
                    i = 0;
                    for (; i < count && netDataBuffer.Any(); i++)
                    {
                        buffer[i] = netDataBuffer.Dequeue();
                        readLength++;
                    }
                }
                position += readLength;
                ReportProgress?.Invoke(position, Length);
                return readLength;
            }

            public bool IsDisposed { private set; get; } = false;
            public new void Dispose()
            {
                if (IsDisposed)
                    return;

                IsDisposed = true;
                base.Dispose();

                core.UFTDataDowned -= Core_UFTDataDowned;
                this.core = null;
                this.remoteFileInfo = null;
            }

            #region disabled methods
            public override void Flush()
            { throw new InvalidOperationException("Read-only stream, and can't flush."); }
            public override long Seek(long offset, SeekOrigin origin)
            { throw new InvalidOperationException("Read-only stream, and can't seek."); }
            public override void SetLength(long value)
            { throw new InvalidOperationException("Read-only stream, and can't set length."); }
            public override void Write(byte[] buffer, int offset, int count)
            { throw new InvalidOperationException("Read-only stream, and can't write."); }
            #endregion
        }
    }
}
