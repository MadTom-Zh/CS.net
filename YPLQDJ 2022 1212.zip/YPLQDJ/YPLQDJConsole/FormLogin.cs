﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MadTomDev.App.YPLQDJ
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        private ConsoleCore core = ConsoleCore.GetInstance();
        private void FormLogin_Load(object sender, EventArgs e)
        {
            if (core.Login_ServerIPV4orIPV6)
                textBox_server.Text = core.Login_ServerIPV4;
            else
                textBox_server.Text = core.Login_ServerIPV6;
            textBox_port.Text = core.Login_ServerPort;
            textBox_user.Text = core.LoginUserID;
            core.formLogin = this;
        }

        private void button_login_Click(object sender, EventArgs e)
        {
            core.Login(textBox_server.Text, textBox_port.Text, textBox_user.Text, maskedTextBox_password.Text);
        }

        private delegate void ShowInfoCallbackDelegate(string message);
        internal void ShowInfo(string message)
        {
            if (InvokeRequired)
            {
                ShowInfoCallbackDelegate callback
                    = new ShowInfoCallbackDelegate(ShowInfo);
                this.Invoke(callback, message);
            }
            else
            {
                label_info.Text = message;
                Update();
            }
        }
        private delegate void ShowErrorCallbackDelegate(Exception err);
        internal void ShowError(Exception err)
        {
            if (InvokeRequired)
            {
                ShowErrorCallbackDelegate callback
                    = new ShowErrorCallbackDelegate(ShowError);
                this.Invoke(callback, err);
            }
            else
            {
                label_info.Text = err.Message;
                MessageBox.Show(
                    this,
                    err.ToString(),
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                Update();
            }
        }

        private void maskedTextBox_password_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                button_login_Click(sender, e);
        }
    }
}
