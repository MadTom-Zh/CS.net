﻿namespace MadTomDev.App.YPLQDJ
{
    partial class FormUniversalFileTransfer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("读取中……");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("ServerDir", new System.Windows.Forms.TreeNode[] {
            treeNode1});
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormUniversalFileTransfer));
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.treeView = new System.Windows.Forms.TreeView();
            this.imageListIO24 = new System.Windows.Forms.ImageList(this.components);
            this.listView = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.toolStrip_general = new System.Windows.Forms.ToolStrip();
            this.toolStripButton_newDir = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton_rename = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton_delete = new System.Windows.Forms.ToolStripButton();
            this.toolStrip_path = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel_path = new System.Windows.Forms.ToolStripLabel();
            this.toolStripTextBox_path = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripButton_path = new System.Windows.Forms.ToolStripButton();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel_info = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripSplitButton_clipBoard = new System.Windows.Forms.ToolStripSplitButton();
            this.toolStripSplitButton_cancel = new System.Windows.Forms.ToolStripSplitButton();
            this.toolStripProgressBar_info = new System.Windows.Forms.ToolStripProgressBar();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.imageListIcon16 = new System.Windows.Forms.ImageList(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            this.toolStrip_general.SuspendLayout();
            this.toolStrip_path.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer
            // 
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.Location = new System.Drawing.Point(0, 50);
            this.splitContainer.Name = "splitContainer";
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.treeView);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(this.listView);
            this.splitContainer.Size = new System.Drawing.Size(961, 497);
            this.splitContainer.SplitterDistance = 273;
            this.splitContainer.SplitterWidth = 8;
            this.splitContainer.TabIndex = 0;
            // 
            // treeView
            // 
            this.treeView.AllowDrop = true;
            this.treeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView.HideSelection = false;
            this.treeView.ImageKey = "Global";
            this.treeView.ImageList = this.imageListIO24;
            this.treeView.Location = new System.Drawing.Point(0, 0);
            this.treeView.Name = "treeView";
            treeNode1.ImageKey = "(default)";
            treeNode1.Name = "Node1";
            treeNode1.SelectedImageIndex = -2;
            treeNode1.Text = "读取中……";
            treeNode2.Name = "ServerDir";
            treeNode2.Text = "ServerDir";
            this.treeView.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode2});
            this.treeView.SelectedImageIndex = 0;
            this.treeView.Size = new System.Drawing.Size(273, 497);
            this.treeView.TabIndex = 0;
            this.treeView.AfterCollapse += new System.Windows.Forms.TreeViewEventHandler(this.treeView_AfterCollapse);
            this.treeView.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeView_BeforeExpand);
            this.treeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView_AfterSelect);
            this.treeView.DragDrop += new System.Windows.Forms.DragEventHandler(this.treeView_DragDrop);
            this.treeView.DragEnter += new System.Windows.Forms.DragEventHandler(this.treeView_DragEnter);
            this.treeView.DragOver += new System.Windows.Forms.DragEventHandler(this.treeView_DragOver);
            this.treeView.DragLeave += new System.EventHandler(this.treeView_DragLeave);
            this.treeView.Enter += new System.EventHandler(this.treeView_Enter);
            this.treeView.MouseDown += new System.Windows.Forms.MouseEventHandler(this.treeView_MouseDown);
            this.treeView.MouseLeave += new System.EventHandler(this.treeView_MouseLeave);
            this.treeView.MouseMove += new System.Windows.Forms.MouseEventHandler(this.treeView_MouseMove);
            this.treeView.MouseUp += new System.Windows.Forms.MouseEventHandler(this.treeView_MouseUp);
            // 
            // imageListIO24
            // 
            this.imageListIO24.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageListIO24.ImageStream")));
            this.imageListIO24.TransparentColor = System.Drawing.Color.Transparent;
            this.imageListIO24.Images.SetKeyName(0, "Global");
            // 
            // listView
            // 
            this.listView.AllowDrop = true;
            this.listView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.listView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView.FullRowSelect = true;
            this.listView.HideSelection = false;
            this.listView.Location = new System.Drawing.Point(0, 0);
            this.listView.Name = "listView";
            this.listView.Size = new System.Drawing.Size(680, 497);
            this.listView.SmallImageList = this.imageListIO24;
            this.listView.TabIndex = 0;
            this.listView.UseCompatibleStateImageBehavior = false;
            this.listView.View = System.Windows.Forms.View.Details;
            this.listView.ItemActivate += new System.EventHandler(this.listView_ItemActivate);
            this.listView.SelectedIndexChanged += new System.EventHandler(this.listView_SelectedIndexChanged);
            this.listView.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView_DragDrop);
            this.listView.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView_DragEnter);
            this.listView.DragOver += new System.Windows.Forms.DragEventHandler(this.listView_DragOver);
            this.listView.DragLeave += new System.EventHandler(this.listView_DragLeave);
            this.listView.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listView_MouseDown);
            this.listView.MouseLeave += new System.EventHandler(this.listView_MouseLeave);
            this.listView.MouseMove += new System.Windows.Forms.MouseEventHandler(this.listView_MouseMove);
            this.listView.MouseUp += new System.Windows.Forms.MouseEventHandler(this.listView_MouseUp);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "名称";
            this.columnHeader1.Width = 282;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "尺寸";
            this.columnHeader2.Width = 75;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "创建时间";
            this.columnHeader3.Width = 105;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "修改时间";
            this.columnHeader4.Width = 105;
            // 
            // toolStrip_general
            // 
            this.toolStrip_general.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton_newDir,
            this.toolStripButton_rename,
            this.toolStripSeparator1,
            this.toolStripButton_delete});
            this.toolStrip_general.Location = new System.Drawing.Point(0, 0);
            this.toolStrip_general.Name = "toolStrip_general";
            this.toolStrip_general.Size = new System.Drawing.Size(961, 25);
            this.toolStrip_general.TabIndex = 1;
            this.toolStrip_general.Text = "toolStrip1";
            // 
            // toolStripButton_newDir
            // 
            this.toolStripButton_newDir.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_newDir.Image")));
            this.toolStripButton_newDir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_newDir.Name = "toolStripButton_newDir";
            this.toolStripButton_newDir.Size = new System.Drawing.Size(79, 22);
            this.toolStripButton_newDir.Text = "新文件夹";
            this.toolStripButton_newDir.Click += new System.EventHandler(this.toolStripButton_newDir_Click);
            // 
            // toolStripButton_rename
            // 
            this.toolStripButton_rename.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_rename.Image")));
            this.toolStripButton_rename.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_rename.Name = "toolStripButton_rename";
            this.toolStripButton_rename.Size = new System.Drawing.Size(66, 22);
            this.toolStripButton_rename.Text = "重命名";
            this.toolStripButton_rename.Click += new System.EventHandler(this.toolStripButton_rename_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton_delete
            // 
            this.toolStripButton_delete.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_delete.Image")));
            this.toolStripButton_delete.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_delete.Name = "toolStripButton_delete";
            this.toolStripButton_delete.Size = new System.Drawing.Size(53, 22);
            this.toolStripButton_delete.Text = "删除";
            this.toolStripButton_delete.Click += new System.EventHandler(this.toolStripButton_delete_Click);
            // 
            // toolStrip_path
            // 
            this.toolStrip_path.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel_path,
            this.toolStripTextBox_path,
            this.toolStripButton_path});
            this.toolStrip_path.Location = new System.Drawing.Point(0, 25);
            this.toolStrip_path.Name = "toolStrip_path";
            this.toolStrip_path.Size = new System.Drawing.Size(961, 25);
            this.toolStrip_path.TabIndex = 2;
            this.toolStrip_path.Text = "toolStrip2";
            this.toolStrip_path.SizeChanged += new System.EventHandler(this.toolStrip_path_SizeChanged);
            // 
            // toolStripLabel_path
            // 
            this.toolStripLabel_path.Name = "toolStripLabel_path";
            this.toolStripLabel_path.Size = new System.Drawing.Size(46, 22);
            this.toolStripLabel_path.Text = "路径：";
            // 
            // toolStripTextBox_path
            // 
            this.toolStripTextBox_path.AutoSize = false;
            this.toolStripTextBox_path.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripTextBox_path.Name = "toolStripTextBox_path";
            this.toolStripTextBox_path.Size = new System.Drawing.Size(500, 25);
            // 
            // toolStripButton_path
            // 
            this.toolStripButton_path.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_path.Image")));
            this.toolStripButton_path.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_path.Name = "toolStripButton_path";
            this.toolStripButton_path.Size = new System.Drawing.Size(84, 22);
            this.toolStripButton_path.Text = "前往\\刷新";
            this.toolStripButton_path.Click += new System.EventHandler(this.toolStripButton_path_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel_info,
            this.toolStripStatusLabel2,
            this.toolStripSplitButton_clipBoard,
            this.toolStripSplitButton_cancel,
            this.toolStripProgressBar_info});
            this.statusStrip1.Location = new System.Drawing.Point(0, 547);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(961, 22);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel_info
            // 
            this.toolStripStatusLabel_info.Name = "toolStripStatusLabel_info";
            this.toolStripStatusLabel_info.Size = new System.Drawing.Size(59, 17);
            this.toolStripStatusLabel_info.Text = "Loading...";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(785, 17);
            this.toolStripStatusLabel2.Spring = true;
            // 
            // toolStripSplitButton_clipBoard
            // 
            this.toolStripSplitButton_clipBoard.DropDownButtonWidth = 0;
            this.toolStripSplitButton_clipBoard.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton_clipBoard.Image")));
            this.toolStripSplitButton_clipBoard.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton_clipBoard.Name = "toolStripSplitButton_clipBoard";
            this.toolStripSplitButton_clipBoard.Size = new System.Drawing.Size(102, 20);
            this.toolStripSplitButton_clipBoard.Text = "(?)->Svr->Loc";
            this.toolStripSplitButton_clipBoard.Visible = false;
            // 
            // toolStripSplitButton_cancel
            // 
            this.toolStripSplitButton_cancel.DropDownButtonWidth = 0;
            this.toolStripSplitButton_cancel.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton_cancel.Image")));
            this.toolStripSplitButton_cancel.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton_cancel.Name = "toolStripSplitButton_cancel";
            this.toolStripSplitButton_cancel.Size = new System.Drawing.Size(54, 20);
            this.toolStripSplitButton_cancel.Text = "取消";
            this.toolStripSplitButton_cancel.Visible = false;
            this.toolStripSplitButton_cancel.ButtonClick += new System.EventHandler(this.toolStripSplitButton_cancel_ButtonClick);
            // 
            // toolStripProgressBar_info
            // 
            this.toolStripProgressBar_info.MarqueeAnimationSpeed = 300;
            this.toolStripProgressBar_info.Name = "toolStripProgressBar_info";
            this.toolStripProgressBar_info.Size = new System.Drawing.Size(100, 16);
            this.toolStripProgressBar_info.Step = 1;
            // 
            // timer
            // 
            this.timer.Enabled = true;
            this.timer.Interval = 300;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // imageListIcon16
            // 
            this.imageListIcon16.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageListIcon16.ImageStream")));
            this.imageListIcon16.TransparentColor = System.Drawing.Color.Transparent;
            this.imageListIcon16.Images.SetKeyName(0, "CBCopy");
            this.imageListIcon16.Images.SetKeyName(1, "CBCut");
            this.imageListIcon16.Images.SetKeyName(2, "Error");
            // 
            // FormUniversalFileTransfer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(961, 569);
            this.Controls.Add(this.splitContainer);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip_path);
            this.Controls.Add(this.toolStrip_general);
            this.KeyPreview = true;
            this.Name = "FormUniversalFileTransfer";
            this.Text = "FormUniversalFileTransfer";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormUniversalFileTransfer_FormClosing);
            this.Shown += new System.EventHandler(this.FormUniversalFileTransfer_Shown);
            this.SizeChanged += new System.EventHandler(this.FormUniversalFileTransfer_SizeChanged);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.FormUniversalFileTransfer_Paint);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FormUniversalFileTransfer_KeyDown);
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            this.toolStrip_general.ResumeLayout(false);
            this.toolStrip_general.PerformLayout();
            this.toolStrip_path.ResumeLayout(false);
            this.toolStrip_path.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.ToolStrip toolStrip_general;
        private System.Windows.Forms.ToolStripButton toolStripButton_newDir;
        private System.Windows.Forms.ToolStripButton toolStripButton_rename;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButton_delete;
        private System.Windows.Forms.ToolStrip toolStrip_path;
        private System.Windows.Forms.ToolStripLabel toolStripLabel_path;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox_path;
        private System.Windows.Forms.ToolStripButton toolStripButton_path;
        private System.Windows.Forms.TreeView treeView;
        private System.Windows.Forms.ListView listView;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ImageList imageListIO24;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel_info;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar_info;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton_cancel;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton_clipBoard;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.ImageList imageListIcon16;
    }
}