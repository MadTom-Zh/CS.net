﻿using MadTomDev.CommonClasses;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MadTomDev.UIs;
using MadTomDev.UIs.ExDialogs;
using System.Threading;

namespace MadTomDev.App.YPLQDJ
{
    public partial class FormUniversalFileTransfer : Form
    {
        public ConsoleCore core;
        private IconHelper iconHelper = null;
        private string tmpDir = Path.Combine(Application.StartupPath, "tmp");
        public FormUniversalFileTransfer()
        {
            InitializeComponent();
        }
        private void FormUniversalFileTransfer_Shown(object sender, EventArgs e)
        {
            toolStrip_path_SizeChanged(sender, e);

        }

        #region Treeview select & dir loading

        private TreeNode TreeNode_Server;
        private delegate void SetDirSubsDelegate(string baseDir, List<DataTempletes.UniversalFileSystemInfo> subFSList);
        internal void SetDirSubs(string baseDir, List<DataTempletes.UniversalFileSystemInfo> subFSList)
        {
            if (InvokeRequired)
            {
                SetDirSubsDelegate callback = new SetDirSubsDelegate(SetDirSubs);
                Invoke(callback, baseDir, subFSList);
            }
            else
            {
                treeView.PathSeparator = core.UFTGetDir_serverDirectorySeparator;
                loadedUFSIs = subFSList;
                if (baseDir == core.UFTGetDir_serverAppDir)
                {
                    SyncTreeNode(TreeNode_Server, subFSList);
                    treeView_loadedNode = TreeNode_Server;
                }
                else
                {
                    string relaDir = baseDir.Substring(core.UFTGetDir_serverAppDir.Length);
                    string[] relaPath = relaDir.Split(
                        new string[] { core.UFTGetDir_serverDirectorySeparator },
                        StringSplitOptions.RemoveEmptyEntries);
                    TreeNode targetDirTN = FindDirTreeNode(TreeNode_Server, relaPath);
                    if (targetDirTN == null)
                    {
                        ShowInfo($"未能找到树目录地址[{relaDir}]，请刷新上级目录。", false, 0);
                        return;
                    }

                    SyncTreeNode(targetDirTN, subFSList);
                    treeView_loadedNode = targetDirTN;
                }
                if (treeView_loadedNode.FullPath == treeView.SelectedNode.FullPath)
                {
                    SetListViewItem(subFSList);
                }
                ShowInfo("已载入目录", false, 0);
            }
        }
        private TreeNode FindDirTreeNode(TreeNode startTN, string[] path)
        {
            TreeNode result = startTN;
            if (path == null || path.Length == 0)
                return result;
            string curName;
            TreeNode[] foundTNs;
            for (int i = 0, iv = path.Length; i < iv; i++)
            {
                result.Expand();
                curName = path[i];
                foundTNs = result.Nodes.Find(curName, false);
                if (foundTNs.Length > 0)
                {
                    result = foundTNs[0];
                }
                else
                {
                    return null;
                }
            }
            return result;
        }
        private void SyncTreeNode(TreeNode targetNode, List<DataTempletes.UniversalFileSystemInfo> fsiList)
        {
            if (!imageListIO24.Images.ContainsKey("dir"))
            {
                imageListIO24.Images.Add("dir", GetIconDir());
            }
            TreeNode testingTN;
            List<DataTempletes.UniversalFileSystemInfo> fsiListCopy
                = new List<DataTempletes.UniversalFileSystemInfo>();
            fsiListCopy.AddRange(fsiList.ToArray());
            DataTempletes.UniversalFileSystemInfo foundFSI;
            for (int i = 0, iv = targetNode.Nodes.Count; i < iv; i++)
            {
                testingTN = targetNode.Nodes[i];
                foundFSI = fsiListCopy.Find(a => a.Name == testingTN.Name && a.IsDir == true);
                if (foundFSI == null)
                {
                    targetNode.Nodes.Remove(testingTN);
                    iv--;
                }
                else fsiListCopy.Remove(foundFSI);
            }

            foreach (DataTempletes.UniversalFileSystemInfo fsi in fsiListCopy)
            {
                if (fsi.Attributes.HasFlag(FileAttributes.Directory))
                {
                    targetNode.Nodes.Add(new TreeNode(fsi.Name, new TreeNode[] { new TreeNode("读取中……") })
                    { Tag = fsi, Name = fsi.Name, SelectedImageKey = "dir", ImageKey = "dir", });

                }
            }


        }
        private void SetListViewItem(List<DataTempletes.UniversalFileSystemInfo> fsiList)
        {
            listView.Items.Clear();
            foreach (DataTempletes.UniversalFileSystemInfo fsi in fsiList)
            {
                string ext = fsi.Extension;
                if (string.IsNullOrWhiteSpace(ext))
                {
                    ext = "dir";
                }
                else
                {
                    if (!imageListIO24.Images.ContainsKey(ext))
                        imageListIO24.Images.Add(ext, GetIcon(ext));
                }
                listView.Items.Add(new ListViewItem(new string[]
                {
                fsi.Name,
                fsi.IsDir ? "--" : SimpleStringHelper.UnitsOfMeasure.GetShortString(fsi.Size, "B", 1024, 2, true),
                fsi.CreationTime.ToString("yyyy-MM-dd HH:mm"),
                fsi.LastWriteTime.ToString("yyyy-MM-dd HH:mm")
                })
                { Tag = fsi, ImageKey = ext, });
            }
        }

        private TreeNode treeView_loadedNode;
        private List<DataTempletes.UniversalFileSystemInfo> loadedUFSIs;
        private bool? treeView_hasSelectedOrExpanded = null;
        private bool treeView_AfterSelect_stopLoading = false;
        private void treeView_AfterSelect(object sender, TreeViewEventArgs e)
        {
            treeView_AfterSelect(e.Node);
        }
        private void treeView_AfterSelect(TreeNode selectTN)
        {
            treeView.SelectedNode = selectTN;
            treeView_hasSelectedOrExpanded = true;
            if (treeView_AfterSelect_stopLoading
                || selectTN == null)
                return;

            listView.Items.Clear();

            treeView_LoadDir(selectTN);
            toolStripTextBox_path.Text = selectTN.FullPath;
        }
        private void treeView_BeforeExpand(object sender, TreeViewCancelEventArgs e)
        {
            treeView_hasSelectedOrExpanded = false;
            if (e.Node.FullPath == treeView_loadedNode.FullPath)
            {
                treeView_loadedNode.Nodes.Clear();
                SyncTreeNode(treeView_loadedNode, loadedUFSIs);
                return;
            }
            treeView_LoadDir(e.Node);
        }
        private delegate void ReLoadSelectDirDelegate(string createdRemoteDir);
        internal void ReLoadSelectDir(string anySubRemoteDir = null)
        {
            if (InvokeRequired)
            {
                ReLoadSelectDirDelegate callback = new ReLoadSelectDirDelegate(ReLoadSelectDir);
                Invoke(callback, anySubRemoteDir);
            }
            else
            {
                if (string.IsNullOrWhiteSpace(anySubRemoteDir))
                {
                    treeView_LoadDir(treeView.SelectedNode);
                }
                else
                {
                    string selectRDir;
                    if (treeView.SelectedNode.FullPath == TreeNode_Server.FullPath)
                        selectRDir = core.UFTGetDir_serverAppDir;
                    else
                        selectRDir = ((DataTempletes.UniversalFileSystemInfo)treeView.SelectedNode.Tag).FullName;

                    if (anySubRemoteDir.StartsWith(selectRDir)
                        && anySubRemoteDir.Length > selectRDir.Length
                        && !anySubRemoteDir.Substring(selectRDir.Length + 1)
                            .Contains(core.UFTGetDir_serverDirectorySeparator))
                    {
                        treeView_LoadDir(treeView.SelectedNode);
                    }
                }
            }
        }
        private void treeView_LoadDir(TreeNode targetTN)
        {
            ShowInfo("正在读取目录……", true, 50);

            if (TreeNode_Server == null)
                TreeNode_Server = treeView.Nodes[0];
            if (targetTN.FullPath == TreeNode_Server.FullPath)
                core.UFTGetDir();
            else
                core.UFTGetDir(((DataTempletes.UniversalFileSystemInfo)targetTN.Tag).FullName);
        }

        private void treeView_AfterCollapse(object sender, TreeViewEventArgs e)
        {
            foreach (TreeNode subTN in e.Node.Nodes)
            {
                if (subTN.Nodes.Count > 0)
                {
                    subTN.Nodes.Clear();
                    subTN.Nodes.Add("读取中……");
                    subTN.Collapse();
                }
            }
        }

        #endregion

        private void FormUniversalFileTransfer_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Enter:
                    {
                        if (toolStripTextBox_path.Focused)
                            toolStripButton_path_Click(sender, e);
                        break;
                    }
                case Keys.Delete:
                    {
                        toolStripButton_delete_Click(sender, e);
                        break;
                    }
                case Keys.Back:
                case Keys.BrowserBack:
                    {
                        if (!toolStripTextBox_path.Focused)
                        {
                            if (toolStripTextBox_path.Text.Contains(treeView.PathSeparator))
                            {
                                toolStripTextBox_path.Text =
                                    toolStripTextBox_path.Text.Substring(
                                        0,
                                        toolStripTextBox_path.Text.LastIndexOf(treeView.PathSeparator));
                                toolStripButton_path_Click(sender, e);
                            }
                        }
                        break;
                    }
                case Keys.F2:
                    {
                        toolStripButton_rename_Click(sender, null);
                        break;
                    }
                case Keys.F5:
                    {
                        treeView_AfterSelect(treeView.SelectedNode);

                        break;
                    }
            }
            if (e.Control)
            {
                switch (e.KeyCode)
                {
                    case Keys.C:
                        {
                            Copy();
                            break;
                        }
                    case Keys.X:
                        {
                            Cut();
                            break;
                        }
                    case Keys.V:
                        {
                            Paste();
                            break;
                        }
                }
            }
        }


        #region main tool bar, createDir, rename, delete

        private void toolStripButton_newDir_Click(object sender, EventArgs e)
        {
            InputBox ib = new InputBox()
            {
                Text = "新建文件夹",
                Info = $"将在[{treeView.SelectedNode.FullPath}]创建文件夹，{Environment.NewLine}请输入新文件夹的名字。",
            };
            ib.SetInputCount(1);
            ib.SetLabel(0, "文件夹名");
            if (ib.ShowDialog() == DialogResult.OK)
            {
                core.UFTCreateDir(
                    ((DataTempletes.UniversalFileSystemInfo)treeView.SelectedNode.Tag).FullName,
                    ib.InputTexts[0]);
            }
        }
        private void toolStripButton_rename_Click(object sender, EventArgs e)
        {
            if (!toolStripButton_rename.Enabled
                || listView.SelectedItems.Count != 1)
                return;

            DataTempletes.UniversalFileSystemInfo selectFSI
                = (DataTempletes.UniversalFileSystemInfo)listView.SelectedItems[0].Tag;
            InputBox ib = new InputBox()
            {
                Text = "重新命名",
                Info = $"将[{selectFSI.Name}]重新命名，{Environment.NewLine}请输入新名称。",
            };
            ib.SetInputCount(1);
            ib.SetLabel(0, "新名称");
            if (ib.ShowDialog() == DialogResult.OK)
            {
                core.UFTMove(
                    selectFSI,
                    selectFSI.DirPath + core.UFTGetDir_serverDirectorySeparator + ib.InputTexts[0]);
            }
        }

        private void toolStripButton_delete_Click(object sender, EventArgs e)
        {
            if (!toolStripButton_delete.Enabled)
                return;

            if (listView.SelectedItems.Count == 0
                && treeView.SelectedNode.FullPath == TreeNode_Server.FullPath)
                ShowInfo("无法删除服务器节点", false, 0);

            List<DataTempletes.UniversalFileSystemInfo> toDelList
                = new List<DataTempletes.UniversalFileSystemInfo>();
            if (listView.SelectedItems.Count > 0)
            {
                foreach (ListViewItem lvi in listView.SelectedItems)
                {
                    toDelList.Add((DataTempletes.UniversalFileSystemInfo)lvi.Tag);
                }
            }
            else
            {
                toDelList.Add((DataTempletes.UniversalFileSystemInfo)treeView.SelectedNode.Tag);
            }
            StringBuilder delDescription = new StringBuilder();
            delDescription.Append("即将删除" + Environment.NewLine);
            int c = toDelList.Count;
            for (int i = 0;
                (c > 3 && i < 2) || (c <= 3 && i < c);
                i++)
            {
                delDescription.Append(toDelList[i].IsDir ? "[文件夹]" : "[文件]");
                delDescription.Append(toDelList[i].Name + Environment.NewLine);
            }
            if (c > 3)
                delDescription.Append($"……等{c}个文件(和文件夹)" + Environment.NewLine);
            delDescription.Append(Environment.NewLine);
            delDescription.Append("删除失误可导致服务器损坏，" + Environment.NewLine);
            delDescription.Append("要继续删除吗？！");
            if (MessageBox.Show(
                    this,
                    delDescription.ToString(),
                    "警告",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning,
                    MessageBoxDefaultButton.Button2)
                != DialogResult.Yes)
                return;

            core.UFTDelete(toDelList);
            ClearClipBoard();
        }

        #endregion


        #region navigate/address bar
        private void toolStripButton_path_Click(object sender, EventArgs e)
        {
            string relaDir = toolStripTextBox_path.Text;
            if (relaDir == TreeNode_Server.Name
                || relaDir == TreeNode_Server.Name + treeView.PathSeparator)
            {
                treeView.SelectedNode = TreeNode_Server;
                return;
            }

            if (relaDir.StartsWith(TreeNode_Server.Name + treeView.PathSeparator))
                relaDir = relaDir.Substring((TreeNode_Server.Name + treeView.PathSeparator).Length);
            string[] relaPath = relaDir.Split(
                new string[] { core.UFTGetDir_serverDirectorySeparator },
                StringSplitOptions.RemoveEmptyEntries);
            TreeNode targetDirTN = FindDirTreeNode(TreeNode_Server, relaPath);
            if (targetDirTN == null)
            {
                ShowInfo($"未能找到地址[{relaDir}]，请刷新上级目录。", false, 0);
                return;
            }
            treeView.SelectedNode = targetDirTN;
        }

        #endregion




        #region listview select, item activate
        private void listView_SelectedIndexChanged(object sender, EventArgs e)
        {
            toolStripButton_rename.Enabled = listView.SelectedItems.Count == 1;
        }
        private void listView_ItemActivate(object sender, EventArgs e)
        {
            if (listView.SelectedItems.Count == 1)
            {
                string fullname = ((DataTempletes.UniversalFileSystemInfo)listView.SelectedItems[0].Tag).FullName;
                string relaDir = fullname.Substring(core.UFTGetDir_serverAppDir.Length);
                string[] relaPath = relaDir.Split(
                    new string[] { core.UFTGetDir_serverDirectorySeparator },
                    StringSplitOptions.RemoveEmptyEntries);
                TreeNode targetDirTN = FindDirTreeNode(TreeNode_Server, relaPath);
                if (targetDirTN == null)
                {
                    //ShowInfo($"未能找到树目录地址[{relaDir}]，请刷新上级目录。", false, 0);
                    return;
                }
                treeView.SelectedNode = targetDirTN;
            }
        }
        #endregion




        #region helper
        public Icon GetIcon(string fileExtension)
        {
            if (iconHelper == null)
            {
                iconHelper = IconHelper.GetInstance();
            }
            if (!Directory.Exists(tmpDir))
                Directory.CreateDirectory(tmpDir);
            string targetIconFile = Path.Combine(tmpDir, "f" + fileExtension);
            if (!File.Exists(targetIconFile))
                File.WriteAllText(targetIconFile, "");
            return iconHelper.IconFromExistIOPath(targetIconFile);
        }
        public Icon GetIconDir()
        {
            if (iconHelper == null)
            {
                iconHelper = IconHelper.GetInstance();
            }
            if (!Directory.Exists(tmpDir))
                Directory.CreateDirectory(tmpDir);
            return iconHelper.IconFromExistIOPath(tmpDir);
        }
        private void FormUniversalFileTransfer_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Directory.Exists(tmpDir))
                Directory.Delete(tmpDir, true);
        }
        private void toolStrip_path_SizeChanged(object sender, EventArgs e)
        {
            toolStripTextBox_path.Width
                = toolStrip_path.Width - toolStripLabel_path.Width - toolStripButton_path.Width - 18;
        }
        private void FormUniversalFileTransfer_SizeChanged(object sender, EventArgs e)
        {
        }


        private delegate void ShowErrorDelegate(Exception err, string additionalMsg = null);
        public void ShowErr(Exception err, string additionalMsg = null)
        {
            if (InvokeRequired)
            {
                ShowErrorDelegate callback = new ShowErrorDelegate(ShowErr);
                Invoke(callback, err, additionalMsg);
            }
            else
            {
                string msg;
                if (string.IsNullOrWhiteSpace(additionalMsg))
                    msg = additionalMsg + ": " + err.Message;
                else
                    msg = err.Message;
                MessageBox.Show(this,
                    additionalMsg + Environment.NewLine + err.ToString(),
                    "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ShowInfo(msg, false, 0);
            }
        }
        private delegate void ShowInfoDelegate1(string msg);
        public void ShowInfo(string msg)
        {
            if (InvokeRequired)
            {
                ShowInfoDelegate1 callback = new ShowInfoDelegate1(ShowInfo);
                this.Invoke(callback, msg);
            }
            else
            {
                toolStripStatusLabel_info.Text = msg;
            }
        }
        private delegate void ShowInfoDelegate2(string msg, bool showProgress, int progress_0to100);
        public void ShowInfo(string msg, bool showProgress, int progress_0to100)
        {
            if (InvokeRequired)
            {
                ShowInfoDelegate2 callback = new ShowInfoDelegate2(ShowInfo);
                this.Invoke(callback, msg, showProgress, progress_0to100);
            }
            else
            {
                toolStripStatusLabel_info.Text = msg;
                if (showProgress)
                {
                    toolStripProgressBar_info.Visible = true;
                    toolStripProgressBar_info.Value = progress_0to100;
                }
                else toolStripProgressBar_info.Visible = false;
            }
        }
        private delegate void ShowProgressBarDelegate(bool show, int progress_0to100);
        public void ShowProgressBar(bool show, int progress_0to100)
        {
            if (InvokeRequired)
            {
                ShowProgressBarDelegate callback = new ShowProgressBarDelegate(ShowProgressBar);
                this.Invoke(callback, show, progress_0to100);
            }
            else
            {
                if (show)
                {
                    toolStripProgressBar_info.Visible = true;
                    toolStripProgressBar_info.Value = progress_0to100;
                }
                else toolStripProgressBar_info.Visible = false;
            }
        }

        private void treeView_Enter(object sender, EventArgs e)
        {
            for (int i = listView.SelectedItems.Count - 1;
                i >= 0; i--)
            {
                listView.SelectedItems[i].Selected = false;
            }
        }

        private string GetName(string path)
        {
            if (path.Contains("\\"))
                return path.Substring(path.LastIndexOf("\\") + 1);
            else if (path.Contains("/"))
                return path.Substring(path.LastIndexOf("/") + 1);
            else
                return path;
        }


        private void FormUniversalFileTransfer_Paint(object sender, PaintEventArgs e)
        {
        }

        #endregion


        #region copy, cut & paste, drag & drop , move within server

        private bool clipboardForLocal = false, clipboardForServer = false;
        private RemoteFilesInClipboard clipboardInner = null;
        private RemoteFilesInClipboard dragDataInner = null;

        private int downloadCount, downloadTotal;
        private void _CopyCutOrDrag(
            Control dragSource,
            List<DataTempletes.UniversalFileSystemInfo> remoteFileList,
            bool isCopyOrCut, bool isDragingOrCliping)
        {
            var virtualFileDataObject = new VirtualFilesOverClipboard(
                (sa) => this.BeginInvoke((Action)(() =>
                {
                    if (dragDataInner != null)
                    {
                        if (ModifierKeys.HasFlag(Keys.Shift))
                            isCopyOrCut = false;
                    }
                    ShowInfo("开始传输数据……", true, 0);
                    toolStripSplitButton_cancel.Visible = true;
                })),
                (ea) => this.BeginInvoke((Action)(() =>
                {
                    if (!isCopyOrCut)
                    {
                        core.UFTDelete(remoteFileList);
                    }
                    ShowInfo("数据传输结束", false, 0);
                    toolStripSplitButton_cancel.Visible = false;
                })));

            downloadCount = 0;
            downloadTotal = remoteFileList.Count;
            List<VirtualFilesOverClipboard.FileDescriptor> dataList
             = new List<VirtualFilesOverClipboard.FileDescriptor>();
            foreach (DataTempletes.UniversalFileSystemInfo ufsi in remoteFileList)
            {
                dataList.Add(new VirtualFilesOverClipboard.FileDescriptor()
                {
                    Name = ufsi.Name,
                    Length = ufsi.Size,
                    ChangeTime = ufsi.LastWriteTime,
                    StreamContents = () =>
                    {
                        UniversalFileStream.DownloadStream ds
                        = new UniversalFileStream.DownloadStream(core, ufsi);
                        ds.ReportWaiting += (sec) => this.BeginInvoke((Action)(() =>
                        {
                            ShowInfo($"等待下载文件[{ufsi.Name}]，[{sec}/30]秒。",
                                true, (int)((float)sec / 30 * 100));
                        }));
                        ds.ReportProgress += (cur, total) => this.BeginInvoke((Action)(() =>
                        {
                            if (cur >= total)
                            {
                                downloadCount++;
                                core.logger.Log($"Complete downloading file[{ufsi.FullName}].");
                                ShowInfo($"完成下载文件[{ufsi.Name}]。", false, 0);
                            }
                            else
                            {
                                ShowInfo($"下载文件[{ufsi.Name}]，当前进度[{cur}/{total}]，总进度[{downloadCount}/{downloadTotal}]。",
                                    true, total > 0 ? (int)((float)cur / total * 100) : 100);
                            }
                        }));
                        ds.ReportCancel += (sender) => this.BeginInvoke((Action)(() =>
                        {
                            core.logger.Log($"Cancel downloading file[{ufsi.FullName}].");
                            ShowInfo($"正在取消下载文件[{ufsi.Name}]……",
                                false, 50);
                            ds.Dispose();
                        }));
                        ds.ReportError += (sender, err) => this.BeginInvoke((Action)(() =>
                        {
                            core.logger.Log(err);
                            ShowErr(err);
                            ds.Dispose();
                        }));
                        return ds;
                    }
                });
            }
            virtualFileDataObject.SetData(dataList.ToArray());

            if (isDragingOrCliping)
            {
                VirtualFilesOverClipboard.DoDragDrop(
                    dragSource, virtualFileDataObject,
                     System.Windows.DragDropEffects.Copy | System.Windows.DragDropEffects.Move);
            }
            else
            {
                virtualFileDataObject.PreferredDropEffect
                    = System.Windows.DragDropEffects.Copy | System.Windows.DragDropEffects.Move;
                Clipboard.SetDataObject(virtualFileDataObject);
            }
        }

        #region sub paste, drag

        private int uploadCount, uploadTotal;
        private bool _PasteOrDrag_uploadToServer(string[] localFiles, string remoteDir, bool deleteSource)
        {
            createdRemoteDir.Clear();
            uploadCount = 0;
            uploadTotal = localFiles.Length;
            try
            {
                foreach (string f in localFiles)
                {
                    core.logger.Log($"Upload file[{f}] to dir[{remoteDir}].");
                    _PasteOrDrag_Loop(f, remoteDir, deleteSource);
                    uploadCount++;
                }
                return true;
            }
            catch (Exception err)
            {
                core.logger.Log(new Exception("Error uploading files", err));
                ShowInfo($"上传文件失败：{err.Message}", false, 0);
                return false;
            }
        }
        public bool PasteOrDrag_blockReloadAfterRename = false;
        private bool _PasteOrDrag_moveWithinServer(List<DataTempletes.UniversalFileSystemInfo> movingRemoteFiles, string remoteDir)
        {
            PasteOrDrag_blockReloadAfterRename = true;
            movedRemoteFS.Clear();

            string sourceR, targetR;
            try
            {
                string newFullName;
                DateTime waitingStartTime;
                int waitingSecs;
                int counter = 0;
                int total = movingRemoteFiles.Count;
                foreach (DataTempletes.UniversalFileSystemInfo sor in movingRemoteFiles)
                {
                    newFullName = remoteDir + core.UFTGetDir_serverDirectorySeparator + sor.Name;
                    core.UFTMove(sor, newFullName);

                    ShowInfo($"服务器内移动文件，进度[{counter++}/{total}]", true, (int)((float)counter / total * 100));

                    waitingStartTime = DateTime.Now;
                    waitingSecs = 0;
                    while (!movedRemoteFS.Contains(newFullName))
                    {
                        Thread.Sleep(10);
                        if ((DateTime.Now - waitingStartTime).TotalSeconds >= (waitingSecs + 1))
                        {
                            waitingSecs++;
                            if (waitingSecs >= 30)
                            {
                                throw new TimeoutException($"服务器移动文件(夹)[{sor.FullName}]超时[{waitingSecs}]秒。");
                            }
                            ShowInfo($"等待服务器创建文件夹[{waitingSecs}]秒", true, (int)((float)waitingSecs / 30 * 100));
                        }
                    }

                }

                PasteOrDrag_blockReloadAfterRename = false;
                return true;
            }
            catch (Exception err)
            {
                core.logger.Log(new Exception("Error uploading files", err));
                ShowInfo($"上传文件失败：{err.Message}", false, 0);

                PasteOrDrag_blockReloadAfterRename = false;
                return false;
            }
        }

        private HashSet<string> createdRemoteDir = new HashSet<string>();
        private HashSet<string> movedRemoteFS = new HashSet<string>();
        public void PasteOrDrag_SetCreatedDir(string remoteDir)
        {
            createdRemoteDir.Add(remoteDir);
        }
        public void PasteOrDrag_SetMovedFS(string remoteFileOrDir)
        {
            movedRemoteFS.Add(remoteFileOrDir);
        }
        private void _PasteOrDrag_Loop(string localFileOrDir, string remoteDir, bool deleteSource)
        {
            string remoteDirPre
                = remoteDir + core.UFTGetDir_serverDirectorySeparator;
            if (Directory.Exists(localFileOrDir))
            {
                DirectoryInfo di = new DirectoryInfo(localFileOrDir);

                // create dir remote
                string newRemoteDir = remoteDir + core.UFTGetDir_serverDirectorySeparator + di.Name;
                core.UFTCreateDir(remoteDir, di.Name);

                // wait for dir creation complete
                DateTime waitingStartTime = DateTime.Now;
                int waitingSecs = 0;
                while (!createdRemoteDir.Contains(newRemoteDir))
                {
                    Thread.Sleep(10);
                    if ((DateTime.Now - waitingStartTime).TotalSeconds >= (waitingSecs + 1))
                    {
                        waitingSecs++;
                        if (waitingSecs >= 30)
                        {
                            throw new TimeoutException($"服务器创建文件夹[{newRemoteDir}]超时[{waitingSecs}]秒。");
                        }
                        ShowInfo($"等待服务器创建文件夹[{waitingSecs}]秒", true, (int)((float)waitingSecs / 30 * 100));
                    }
                }

                // transfer sub files
                foreach (FileInfo subFI in di.GetFiles())
                {
                    _PasteOrDrag_Loop(subFI.FullName, newRemoteDir, deleteSource);
                }

                // loop sub dirs
                foreach (DirectoryInfo subDI in di.GetDirectories())
                {
                    _PasteOrDrag_Loop(subDI.FullName, newRemoteDir, deleteSource);
                }

                // after transfer all subs(deleted already, if so), delete itself, if needed
                if (deleteSource)
                    Directory.Delete(localFileOrDir);
            }
            else if (File.Exists(localFileOrDir))
            {
                FileInfo fi = new FileInfo(localFileOrDir);
                using (FileStream localFS
                    = new FileStream(localFileOrDir, FileMode.Open, FileAccess.Read))
                using (UniversalFileStream.UploadStream remoteFS
                    = new UniversalFileStream.UploadStream(
                        core,
                        remoteDirPre + fi.Name,
                        fi.Length))
                {
                    int bufferLength = 524288; // 0.5M
                    byte[] readBuffer = new byte[bufferLength];
                    byte[] shortBuf;
                    int localFSRead = 1;
                    while (localFSRead > 0)
                    {
                        if (core.UFTCancelFlag)
                        {
                            ShowInfo("已取消上传", false, 0);
                            return;
                        }

                        ShowInfo(
                            $"正在上传文件[{fi.Name}]，当前进度[{localFS.Position}/{fi.Length}]，总进度[{uploadCount}/{uploadTotal}]",
                            true,
                            fi.Length > 0 ? (int)((float)localFS.Position / fi.Length * 100) : 100);
                        localFSRead = localFS.Read(readBuffer, 0, bufferLength);
                        if (localFSRead < bufferLength)
                        {
                            shortBuf = new byte[localFSRead];
                            Array.Copy(readBuffer, shortBuf, localFSRead);
                            remoteFS.Write(shortBuf, 0, localFSRead);
                        }
                        else
                        {
                            remoteFS.Write(readBuffer, 0, bufferLength);
                        }
                    }
                }

                if (deleteSource)
                    File.Delete(localFileOrDir);
            }
        }

        #endregion

        #region copy, cut & paste

        private void Copy()
        {
            // copy server files(no dir),
            // for downloading only, paste within server is not allowed
            // ->Loc

            if (listView.SelectedItems.Count == 0)
            {
                ShowInfo("无法复制，无选中项目", false, 0);
                ClearClipBoard();
                return;
            }
            List<DataTempletes.UniversalFileSystemInfo> rFiles
                = new List<DataTempletes.UniversalFileSystemInfo>();
            DataTempletes.UniversalFileSystemInfo curUFSI;
            foreach (ListViewItem lvi in listView.SelectedItems)
            {
                curUFSI = (DataTempletes.UniversalFileSystemInfo)lvi.Tag;
                if (curUFSI.IsDir)
                {
                    ShowInfo("无法复制，不支持复制远程文件夹", false, 0);
                    ClearClipBoard();
                    return;
                }
                rFiles.Add(curUFSI);
            }

            clipboardForLocal = true;
            clipboardForServer = false;
            _CopyCutOrDrag(listView, rFiles, true, false);

            CheckNShowClipboardIcon();
            ShowInfo("已复制到剪贴板(复制)");
        }
        private void Cut()
        {
            // cut server files(delete after transfer)
            // for moving within server, if have dir(s)
            // ->Svr
            // for downloading AND moving within server, if only have files
            // ->Svr->Loc

            List<DataTempletes.UniversalFileSystemInfo> rFiles
                = new List<DataTempletes.UniversalFileSystemInfo>();
            Control sourceUI;
            if (listView.SelectedItems.Count == 0)
            {
                if (treeView.SelectedNode.FullPath == TreeNode_Server.FullPath)
                {
                    ShowInfo("无法剪切根节点", false, 0);
                    ClearClipBoard();
                    return;
                }

                clipboardForLocal = false;
                clipboardForServer = true;
                sourceUI = treeView;
                rFiles.Add((DataTempletes.UniversalFileSystemInfo)treeView.SelectedNode.Tag);
            }
            else
            {
                clipboardForLocal = true;
                clipboardForServer = true;
                DataTempletes.UniversalFileSystemInfo curUFSI;
                sourceUI = listView;
                foreach (ListViewItem lvi in listView.SelectedItems)
                {
                    curUFSI = (DataTempletes.UniversalFileSystemInfo)lvi.Tag;
                    if (curUFSI.IsDir)
                        clipboardForLocal = false;
                    rFiles.Add(curUFSI);
                }
            }


            clipboardInner = new RemoteFilesInClipboard()
            { remoteFiles = rFiles, userAction = DragDropEffects.Move };


            if (clipboardForLocal)
                _CopyCutOrDrag(sourceUI, rFiles, false, false);

            CheckNShowClipboardIcon();
            ShowInfo("已复制到剪贴板(剪切)");
        }

        private void Paste()
        {
            // posible clips: filedrop, remotefiles, virfiles
            string targetRemoteDir = treeView.SelectedNode.FullPath == TreeNode_Server.FullPath ?
                core.UFTGetDir_serverAppDir :
                ((DataTempletes.UniversalFileSystemInfo)treeView.SelectedNode.Tag).FullName;

            if (clipboardForServer)
            {
                IDataObject cbDataObj = Clipboard.GetDataObject();
                if (cbDataObj.GetDataPresent(DataFormats.FileDrop))
                {
                    string[] localFiles = (string[])cbDataObj.GetData(DataFormats.FileDrop);

                    MemoryStream aDropEffect = (MemoryStream)Clipboard.GetData("Preferred DropEffect");
                    byte[] aMoveEffect = new byte[4];
                    aDropEffect.Read(aMoveEffect, 0, aMoveEffect.Length);
                    var aDragDropEffects = (DragDropEffects)BitConverter.ToInt32(aMoveEffect, 0);
                    bool aMove = aDragDropEffects.HasFlag(DragDropEffects.Move);


                    ThreadPool.QueueUserWorkItem(new WaitCallback((s) =>
                    {
                        if (_PasteOrDrag_uploadToServer(localFiles, targetRemoteDir, aMove))
                        {
                            //ShowInfo("上传文件完成", false, 0);
                            ReLoadSelectDir(targetRemoteDir + core.UFTGetDir_serverDirectorySeparator + GetName(localFiles[0]));
                        }
                        ClearClipBoard();
                    }));
                }
                else if (clipboardInner != null
                    && clipboardInner.remoteFiles.Count > 0
                    && clipboardInner.userAction.HasFlag(DragDropEffects.Move))
                {
                    //if (!isMove)                    
                    //    ShowInfo("无法粘贴，不支持粘贴服务器内复制的文件");

                    ThreadPool.QueueUserWorkItem(new WaitCallback((s) =>
                    {
                        if (_PasteOrDrag_moveWithinServer(clipboardInner.remoteFiles, targetRemoteDir))
                        {
                            //ShowInfo("移动文件完成", false, 0);
                            ReLoadSelectDir(targetRemoteDir + core.UFTGetDir_serverDirectorySeparator + clipboardInner.remoteFiles[0].Name);
                        }
                        ClearClipBoard();
                    }));
                }
            }
        }

        private delegate void ClearClipBoardDelegate();
        private void ClearClipBoard()
        {
            if (InvokeRequired)
            {
                ClearClipBoardDelegate callback
                    = new ClearClipBoardDelegate(ClearClipBoard);
                Invoke(callback);
            }
            else
            {
                dragDataInner = null;

                Clipboard.Clear();
                clipboardInner = null;

                clipboardForLocal = false;
                clipboardForServer = false;
                CheckNShowClipboardIcon();
            }
        }

        private void CheckNShowClipboardIcon()
        {
            bool isMove;
            bool isNotFileDrop = true;
            string tx = "";

            string[] fileDrops = CheckNShowClipboardIcon_TryGetFileDrop(out isMove);
            if (fileDrops != null && fileDrops.Length > 0)
            {
                tx = $"(F{fileDrops.Length})";
                isNotFileDrop = false;
                clipboardForLocal = true;
                clipboardForServer = true;
            }


            if (clipboardForLocal || clipboardForServer)
            {
                if (isNotFileDrop)
                {
                    bool isVF = CheckNShowClipboardIcon_CheckIfVirtualFiles(out isMove);

                    if (clipboardInner != null && isVF)
                    {
                        tx = $"(RV{clipboardInner.remoteFiles.Count})";
                    }
                    else if (clipboardInner != null)
                    {
                        tx = $"(R{clipboardInner.remoteFiles.Count})";
                    }
                    else if (isVF)
                    {
                        tx = $"(V)";
                    }
                    else
                    {
                        tx = "(?)";
                    }
                }

                if (clipboardForLocal && clipboardForServer)
                    tx += "->Svr->Loc";
                else if (clipboardForServer)
                    tx += "->Svr";
                else
                    tx += "->Loc";

                toolStripSplitButton_clipBoard.Image
                    = isMove ?
                        imageListIcon16.Images["CBCut"]
                        : imageListIcon16.Images["CBCopy"];
                toolStripSplitButton_clipBoard.Text = tx;
                toolStripSplitButton_clipBoard.Visible = true;
            }
            else
            {
                toolStripSplitButton_clipBoard.Visible = false;
            }
        }

        private string[] CheckNShowClipboardIcon_TryGetFileDrop(out bool isMove)
        {
            isMove = false;
            object testObj = Clipboard.GetData(DataFormats.FileDrop);
            if (testObj != null)
            {
                MemoryStream aDropEffect = (MemoryStream)Clipboard.GetData("Preferred DropEffect");
                byte[] aMoveEffect = new byte[4];
                aDropEffect.Read(aMoveEffect, 0, aMoveEffect.Length);
                var aDragDropEffects = (DragDropEffects)BitConverter.ToInt32(aMoveEffect, 0);
                isMove = aDragDropEffects.HasFlag(DragDropEffects.Move);

                return (string[])testObj;
            }
            return null;
        }
        private bool CheckNShowClipboardIcon_CheckIfVirtualFiles(out bool isMove)
        {
            isMove = false;
            string[] test = Clipboard.GetDataObject().GetFormats();
            if (test.Contains("FileGroupDescriptorW")
                && test.Contains("FileContents")
                && test.Contains("Preferred DropEffect"))
            {
                MemoryStream aDropEffect = (MemoryStream)Clipboard.GetData("Preferred DropEffect");
                byte[] aMoveEffect = new byte[4];
                aDropEffect.Read(aMoveEffect, 0, aMoveEffect.Length);
                var aDragDropEffects = (DragDropEffects)BitConverter.ToInt32(aMoveEffect, 0);
                isMove = aDragDropEffects.HasFlag(DragDropEffects.Move);

                return true;
            }
            return false;
        }

        #endregion

        #region drop

        private void listView_DragEnter(object sender, DragEventArgs e)
        { _DragEnter_TestNSetDragDropEffects(ref e); }
        private ListViewItem listView_DragOver_Pre = null;
        private ListViewItem listView_DragOver_Cur = null;
        private void listView_DragOver(object sender, DragEventArgs e)
        { _DragOver_TestNSetDragDropEffects(ref e, sender); }

        private void listView_DragDrop(object sender, DragEventArgs e)
        { _DragDrop_TestNAction(ref e, sender); }

        private bool _DragEnter_dataAvailable = false;
        private bool _DragEnter_isFileDrop = false;
        private void _DragEnter_TestNSetDragDropEffects(ref DragEventArgs enterEA)
        {
            _DragEnter_dataAvailable = false;
            _DragEnter_isFileDrop = false;
            //enterEA.Effect = DragDropEffects.None;
            if (enterEA.Data.GetDataPresent(DataFormats.FileDrop))
            {
                dragDataInner = null;
                string[] files = (string[])enterEA.Data.GetData(DataFormats.FileDrop);
                if (files.Length > 0)
                {
                    //enterEA.Effect = DragDropEffects.Link;
                    _DragEnter_dataAvailable = true;
                    _DragEnter_isFileDrop = true;
                }
            }
            else if (dragDataInner != null)
            {
                if (dragDataInner.remoteFiles.Count > 0)
                {
                    //enterEA.Effect = DragDropEffects.Link;
                    _DragEnter_dataAvailable = true;
                }
            }
        }
        private void _DragOver_TestNSetDragDropEffects
            (ref DragEventArgs enterEA, object sender)
        {
            if (!_DragEnter_dataAvailable)
                return;

            enterEA.Effect = DragDropEffects.Link;
            Control ctrlParent = (Control)sender;

            #region mouse over a dir lvItem?

            if (ctrlParent is TreeView)
            {
                treeView_DragOver_Cur = treeView.GetNodeAt(treeView.PointToClient(MousePosition));
                if (treeView_DragOver_Pre != treeView_DragOver_Cur)
                {
                    if (treeView_DragOver_Pre != null)
                        treeView_DragOver_Pre.BackColor = SystemColors.Window;
                    if (treeView_DragOver_Cur != null)
                        treeView_DragOver_Cur.BackColor = SystemColors.MenuHighlight;
                }
                treeView_DragOver_Pre = treeView_DragOver_Cur;

                if (treeView_DragOver_Cur == null)
                    enterEA.Effect = DragDropEffects.None;

                if (enterEA.Effect != DragDropEffects.None
                    && dragDataInner != null)
                {
                    string targetDir;
                    if (treeView_DragOver_Cur.Level == 0)
                        targetDir = core.UFTGetDir_serverAppDir;
                    else
                        targetDir = ((DataTempletes.UniversalFileSystemInfo)treeView_DragOver_Cur.Tag).FullName;

                    bool testFailed = false;
                    string test;
                    foreach (DataTempletes.UniversalFileSystemInfo a in dragDataInner.remoteFiles)
                    {
                        test = a.FullName;
                        if (test.StartsWith(targetDir)
                            && test.Length > targetDir.Length
                            && !test.Substring(targetDir.Length + 1).Contains(core.UFTGetDir_serverDirectorySeparator))
                        {
                            testFailed = true;
                            break;
                        }
                        else if (targetDir.StartsWith(test))
                        {
                            testFailed = true;
                            break;
                        }
                    }
                    if (testFailed)
                        enterEA.Effect = DragDropEffects.None;
                    else
                        enterEA.Effect = DragDropEffects.Move;
                }
            }
            else if (ctrlParent is ListView)
            {
                Point p2c = listView.PointToClient(MousePosition);
                listView_DragOver_Cur
                    = listView.GetItemAt(p2c.X, p2c.Y);

                if (listView_DragOver_Pre != listView_DragOver_Cur)
                {
                    if (listView_DragOver_Pre != null)
                        listView_DragOver_Pre.BackColor = SystemColors.Window;
                    if (listView_DragOver_Cur != null)
                        listView_DragOver_Cur.BackColor = SystemColors.MenuHighlight;
                }
                listView_DragOver_Pre = listView_DragOver_Cur;

                if (listView_DragOver_Cur != null
                    && !((DataTempletes.UniversalFileSystemInfo)listView_DragOver_Cur.Tag).IsDir)
                {
                    enterEA.Effect = DragDropEffects.None;
                }

                if (enterEA.Effect != DragDropEffects.None
                    && dragDataInner != null)
                {
                    string targetDir;
                    DataTempletes.UniversalFileSystemInfo listViewUFSI = null;
                    if (listView_DragOver_Cur != null)
                    {
                        listViewUFSI = (DataTempletes.UniversalFileSystemInfo)listView_DragOver_Cur.Tag;
                        targetDir = listViewUFSI.FullName;
                    }
                    else
                    {
                        if (treeView.SelectedNode.Level == 0)
                            targetDir = core.UFTGetDir_serverAppDir;
                        else
                            targetDir = ((DataTempletes.UniversalFileSystemInfo)
                                treeView.SelectedNode.Tag).FullName;
                    }

                    bool testFailed = false;
                    string test;
                    foreach (DataTempletes.UniversalFileSystemInfo a in dragDataInner.remoteFiles)
                    {
                        test = a.FullName;
                        if (test.StartsWith(targetDir)
                            && test.Length > targetDir.Length
                            && !test.Substring(targetDir.Length + 1).Contains(core.UFTGetDir_serverDirectorySeparator))
                        {
                            testFailed = true;
                            break;
                        }
                        else if (targetDir.StartsWith(test))
                        {
                            testFailed = true;
                            break;
                        }
                    }
                    if (testFailed)
                        enterEA.Effect = DragDropEffects.None;
                    else
                        enterEA.Effect = DragDropEffects.Move;
                }
            }
            #endregion

            if (enterEA.Effect != DragDropEffects.Link)
                return;



            // KeyState 4 = SFT
            // KeyState 8 = CTL
            // KeyState 32 = ALT
            // KeyState 8 + 32 = CTL + ALT
            if ((enterEA.KeyState & 4) == 4
                && (enterEA.AllowedEffect & DragDropEffects.Move) == DragDropEffects.Move)
                enterEA.Effect = DragDropEffects.Move;
            else if ((enterEA.AllowedEffect & DragDropEffects.Copy) == DragDropEffects.Copy)
                enterEA.Effect = DragDropEffects.Copy;
        }
        private void _DragDrop_TestNAction(ref DragEventArgs enterEA, object sender)
        {
            if (enterEA.Effect == DragDropEffects.None)
                return;

            if (sender is TreeView)
            {
                if (treeView_DragOver_Pre != null)
                {
                    treeView_DragOver_Pre.BackColor = SystemColors.Window;
                    treeView_DragOver_Pre = null;
                }
            }
            else if (sender is ListView)
            {
                if (listView_DragOver_Pre != null)
                {
                    listView_DragOver_Pre.BackColor = SystemColors.Window;
                    listView_DragOver_Pre = null;
                }
            }

            // get data
            string[] lFiles = null;
            RemoteFilesInClipboard rFiles = null;
            if (enterEA.Data.GetDataPresent(DataFormats.FileDrop))
            {
                lFiles = (string[])enterEA.Data.GetData(DataFormats.FileDrop);
                //files. 

            }
            else if (dragDataInner != null)
            {
                rFiles = dragDataInner;
            }

            // get target
            string target = null;
            if (sender is TreeView)
            {
                if (treeView_DragOver_Cur.Level == 0)
                {
                    // server tree node
                    target = core.UFTGetDir_serverAppDir;
                }
                else
                {
                    target = ((DataTempletes.UniversalFileSystemInfo)treeView_DragOver_Cur.Tag).FullName;
                }
            }
            else if (sender is ListView)
            {
                if (listView_DragOver_Cur != null)
                    target = ((DataTempletes.UniversalFileSystemInfo)listView_DragOver_Cur.Tag).FullName;
                else
                {
                    if (treeView.SelectedNode.FullPath == TreeNode_Server.FullPath)
                        target = core.UFTGetDir_serverAppDir;
                    else
                        target = ((DataTempletes.UniversalFileSystemInfo)treeView.SelectedNode.Tag).FullName;
                }
            }

            // move or copy

            if (_DragEnter_isFileDrop)
            {
                string[] localFiles = (string[])enterEA.Data.GetData(DataFormats.FileDrop);
                bool isCutOrCopy = enterEA.Effect == DragDropEffects.Move;
                ThreadPool.QueueUserWorkItem(new WaitCallback((s) =>
                {
                    if (_PasteOrDrag_uploadToServer(localFiles, target, isCutOrCopy))
                    {
                        //ShowInfo("上传文件完成", false, 0);
                        ReLoadSelectDir(target + core.UFTGetDir_serverDirectorySeparator + GetName(localFiles[0]));
                    }
                    ClearClipBoard();
                }));
            }
            else if (dragDataInner != null
                && enterEA.Effect == DragDropEffects.Move)
            {
                ThreadPool.QueueUserWorkItem(new WaitCallback((s) =>
                {
                    if (_PasteOrDrag_moveWithinServer(dragDataInner.remoteFiles, target))
                    {
                        //ShowInfo("移动文件完成", false, 0);
                        ReLoadSelectDir(target + core.UFTGetDir_serverDirectorySeparator + dragDataInner.remoteFiles[0].Name);
                    }
                    ClearClipBoard();
                }));
            }
        }


        private void treeView_DragEnter(object sender, DragEventArgs e)
        { _DragEnter_TestNSetDragDropEffects(ref e); }

        private TreeNode treeView_DragOver_Pre = null;
        private TreeNode treeView_DragOver_Cur = null;
        private void treeView_DragOver(object sender, DragEventArgs e)
        { _DragOver_TestNSetDragDropEffects(ref e, sender); }
        private void treeView_DragDrop(object sender, DragEventArgs e)
        { _DragDrop_TestNAction(ref e, sender); }

        private void listView_DragLeave(object sender, EventArgs e)
        {
            if (listView_DragOver_Pre != null)
            {
                listView_DragOver_Pre.BackColor = SystemColors.Window;
                listView_DragOver_Pre = null;
            }
        }

        private void treeView_DragLeave(object sender, EventArgs e)
        {
            if (treeView_DragOver_Pre != null)
            {
                treeView_DragOver_Pre.BackColor = SystemColors.Window;
                treeView_DragOver_Pre = null;
            }
        }

        #endregion

        #region drag

        private bool listView_IsMouseDown = false;
        private Point listView_MouseDownStartPoint;
        private void listView_MouseDown(object sender, MouseEventArgs e)
        {
            listView_IsMouseDown = true;
            listView_MouseDownStartPoint = MousePosition;
            dragDataInner = null;
        }
        private void listView_MouseUp(object sender, MouseEventArgs e)
        { listView_IsMouseDown = false; }
        private void listView_MouseLeave(object sender, EventArgs e)
        { listView_IsMouseDown = false; }


        private void listView_MouseMove(object sender, MouseEventArgs e)
        {
            if (!listView_IsMouseDown)
                return;

            Point curMP = MousePosition;
            if (System.Math.Abs(curMP.X - listView_MouseDownStartPoint.X) > 3
                || System.Math.Abs(curMP.Y - listView_MouseDownStartPoint.Y) > 3)
            {
                listView_IsMouseDown = false;
                if (listView.SelectedItems.Count == 0)
                    return;

                List<DataTempletes.UniversalFileSystemInfo> rFiles
                    = new List<DataTempletes.UniversalFileSystemInfo>();
                DataTempletes.UniversalFileSystemInfo curRF;
                bool haveDir = false;
                foreach (ListViewItem lvi in listView.SelectedItems)
                {
                    curRF = (DataTempletes.UniversalFileSystemInfo)lvi.Tag;
                    rFiles.Add(curRF);
                    if (curRF.IsDir)
                        haveDir = true;
                }

                dragDataInner = new RemoteFilesInClipboard()
                { remoteFiles = rFiles, userAction = DragDropEffects.All, };

                if (!haveDir)
                {
                    ShowInfo("准备[复制]、[移动]选中的[文件]");
                    _CopyCutOrDrag((Control)sender, rFiles, true, true);
                }
                else
                {
                    ShowInfo("准备[移动]选中的[文件]和[文件夹]");
                    listView.DoDragDrop(dragDataInner, DragDropEffects.Move);
                }
            }
        }


        private bool treeView_IsMouseDown = false;
        private Point treeView_MouseDownStartPoint;
        private TreeNode treeView_MouseDownDragingTN;
        private void treeView_MouseDown(object sender, MouseEventArgs e)
        {
            treeView_MouseDownDragingTN
                = treeView.GetNodeAt(treeView.PointToClient(MousePosition));
            if (treeView_MouseDownDragingTN != null)
            {
                treeView_IsMouseDown = true;
                treeView_MouseDownStartPoint = MousePosition;
            }
            else
            {
                treeView_IsMouseDown = false;
            }
            dragDataInner = null;
        }

        private void treeView_MouseUp(object sender, MouseEventArgs e)
        { treeView_IsMouseDown = false; }

        private void treeView_MouseLeave(object sender, EventArgs e)
        { treeView_IsMouseDown = false; }

        private void treeView_MouseMove(object sender, MouseEventArgs e)
        {
            if (!treeView_IsMouseDown)
                return;

            Point curMP = MousePosition;
            if (System.Math.Abs(curMP.X - treeView_MouseDownStartPoint.X) > 3
                || System.Math.Abs(curMP.Y - treeView_MouseDownStartPoint.Y) > 3)
            {

                List<DataTempletes.UniversalFileSystemInfo> rFiles
                    = new List<DataTempletes.UniversalFileSystemInfo>();
                if (treeView_MouseDownDragingTN.Level == 0)
                {
                    ShowInfo("不可拖拽服务器节点");
                    return;
                }

                rFiles.Add((DataTempletes.UniversalFileSystemInfo)treeView_MouseDownDragingTN.Tag);

                dragDataInner = new RemoteFilesInClipboard()
                { remoteFiles = rFiles, userAction = DragDropEffects.All, };

                ShowInfo("准备[移动]选中的[文件夹]");
                treeView.DoDragDrop(dragDataInner, DragDropEffects.Move);

            }



        }



        #endregion

        #endregion


        private void toolStripSplitButton_cancel_ButtonClick(object sender, EventArgs e)
        {
            core.UFTCancelFlag = true;
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            CheckNShowClipboardIcon();
        }
    }
    [Serializable]
    class RemoteFilesInClipboard
    {
        public static string FormatName = "RemoteFilesInClipboard";
        public string userActionCode;
        public DragDropEffects userAction // copy or cut
        {
            get
            {
                try
                {
                    return (DragDropEffects)Enum.Parse(typeof(DragDropEffects), userActionCode);
                }
                catch (Exception)
                {
                    return DragDropEffects.None;
                }
            }
            set
            {
                userActionCode = value.ToString();
            }
        }
        public List<DataTempletes.UniversalFileSystemInfo> remoteFiles
            = new List<DataTempletes.UniversalFileSystemInfo>();
    }
}
